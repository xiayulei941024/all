# 战略微头条H5

## Description

Based on vite-vanilla-template, only with pure (javascript, css, html) and no extra js-framework

## Get Started

npm run serve