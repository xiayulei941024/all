/**
 * 标状态管理
 */

  import API from '../../assets/js/api.js'
  import axios from 'axios'
  import qs from 'qs'
  // import _ from 'lodash'

  const table = {
    namespaced: true,
    state: {
      list: [],
      tableColumnTypes: [],
      tableControlsTypes: [],
      dimensionalList: [], // 维度树
      DimensionalCheckedList: [], // 维度树默认选择列表
      dimensionalDatasourceList: [], // 维度树默认展开数据源节点
      dimensionalPk: [], // 主键
      regularTypeList: [] // 正则列表
    },
    mutations: {
      updateControlsTypes (state, { list }) {
        state.tableControlsTypes = list
      },
      updateTableColumnTypes (state, { list }) {
        state.tableColumnTypes = list
      },
      updateList (state, { list }) {
        // for (let table of list) {
        //   if (state.list.indexOf(table) >= 0) {
        //     console.log(table)
        //   }
        // }
        // state.list[uuid] = list
        // for (let table of list) {
        //   if (state.list.indexOf(table.uuid) >= 0) {}
        // }
        // for (let table of list) {
        //   console.log(_.pluck(_.filter(state.list, table)))
        // }
        state.list = list
      },
      updateDimensionalList (state, { list }) {
        state.dimensionalList = list
      },
      updateDimensionalCheckedList (state, list) {
        state.DimensionalCheckedList = list
      },
      updateDimensionalDatasourceList (state, list) {
        state.dimensionalDatasourceList = list
      },
      updatePkUuid (state, list) {
        state.dimensionalPk = list
      },
      updateRegularType (state, {list}) {
        state.regularTypeList = list
      }
    },
    actions: {
      getControlsTypes ({ commit }) {
        axios.get(API.table.getControlsType).then(response => {
          const result = response.data
          commit('updateControlsTypes', {list: result.data})
        }).catch(error => {
          console.error(error)
        })
      },
      getTableColumnType ({ commit }, param) {
        axios.get(API.table.getTableColumnType + '?dbType=' + param).then(response => {
          const result = response.data
          commit('updateTableColumnTypes', {list: result.data})
        }).catch(error => {
          console.error(error)
        })
      },
      getList ({ commit }, uuid) {
        axios.post(API.table.getList).then(response => {
          const result = response.data
          commit('updateList', {list: result.data})
        }).catch(error => {
          console.error(error)
        })
      },
      // 获取维度树
      /* getDimensionaList ({commit, state, rootState}, param) {
        let params_ = {}
        params_.colId = param.colId
        params_.tableId = param.tableId
        return axios.post(API.table.getDimensionTree, qs.stringify(params_)).then((res) => {
          console.log(res)
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            console.log('dimensionality', JSON.parse(res.data.data))
            commit('updateDimensionalList', {list: JSON.parse(res.data.data)})
            let defaultNode = []
            let datasourceNode = ['table_0']
            let pk = []
            for (let item of JSON.parse(res.data.data)) {
              if (item.ifCheck === '1' && item.type === 'column') {
                defaultNode.push(item.uuid)
              } else if (item.type === 'datasource') {
                datasourceNode.push(item.uuid)
              } else if (item.type === 'column' && item.dbid) {
                pk.push(item.dbid)
              }
            }
            commit('updateDimensionalCheckedList', defaultNode)
            commit('updateDimensionalDatasourceList', datasourceNode)
            commit('updatePkUuid', pk)
          }
          return res
        }).catch(error => {
          console.error(error)
        })
      } */
      getDimensionaList ({commit, state, rootState}, param) {
        let params_ = {}
        params_.type = param.type || 'datasource'
        params_.colId = param.colId
        params_.uuid = param.uuid
        return axios.post(API.table.getDimensionTree, qs.stringify(params_)).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          }
          return res
        }).catch(error => {
          console.error(error)
        })
      },
      /**
       * 获取正则list
       * **/
      getRegularType ({ commit }) {
        axios.get(API.table.getRegularType).then(res => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            commit('updateRegularType', {list: res.data.data})
          }
        }).catch(error => {
          console.error(error)
        })
      }
    }
  }

  export default table
