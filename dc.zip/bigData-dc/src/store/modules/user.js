/**
 * 用户状态管理模块
 * @author chenqy9
 */

import API from '../../assets/js/api'
import axios from 'axios'
import qs from 'qs'

const user = {
  namespaced: true,
  /* 状态变量 */
  state: {
    loginUser: {}, // 登录的用户信息
    columns: [], // 用户字段
    list: [] // 用户列表
  },
  /* 状态维护 */
  mutations: {
    // 更新用户字段
    updateColumns (state, columns) {
      state.columns = columns
    },
    // 更新用户列表
    updateList (state, list) {
      state.list = list
      // state.list = [
      //   {
      //     user_name: 'zouhb2',
      //     user_id: '123',
      //     user_email: '657717653@qq.com'
      //   }
      // ]
    },
    // 更新登录用户信息
    updateUser (state, user) {
      state.loginUser = user
    }
  },
  /* 状态动作 */
  actions: {
    // 获取登录用户
    getUserInfo ({ commit }) {
      axios
        .post(API.getUserInfo)
        .then((response) => {
          if (
            response.status === 200 &&
            response.data &&
            typeof response.data === 'string' &&
            response.data.indexOf('<!DOCTYPE html>') >= 0
          ) {
            window.location.href = API.logout
          }
          const result = response.data
          const data = result.data
          commit('updateUser', JSON.parse(data))
        })
        .catch((error) => {
          console.log(error)
          // window.location.href = API.logout
        })
    },
    // 获取用户列表
    getUserList ({ commit }, params) {
      // axios.post(API.getAllUser, qs.stringify({pagenum: pageNum || 1})).then(response => {
      axios
        .post(
          API.user.getUserList,
          qs.stringify({
            pagenum: (params && params.pageNum) || 1,
            rownum: (params && params.rownum) || 10,
            userAccount: (params && params.userAccount) || ''
          })
        )
        .then((response) => {
          const result = response.data
          const data = JSON.parse(result.data)
          console.log(data.resultSet)
          commit('updateList', data.resultSet)
          commit('updateColumns', data.metadata)
          commit('updatePageTotalCount', data.totalRows, { root: true })
        })
        .catch((error) => {
          console.error(error)
        })
    },
    // 新增,修改用户
    setUserTableRow ({ commit, state, rootState }, param) {
      return axios
        .post(API.user.insert, param)
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    /* 删除表行 */
    delUserTableRow ({ commit, state, rootState }, param) {
      return axios
        .post(API.user.delete, qs.stringify(param))
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    // 获取某用户详情
    getUserDetail ({ commit, state, rootState }, param) {
      return axios
        .post(API.user.getUserDetail, qs.stringify({ uuid: param }))
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    /* 查询用户 */
    checkUser ({ commit, state, rootState }, param) {
      return axios
        .post(API.user.checkUser, qs.stringify(param))
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    /* 用户管理中用户查找 */
    searchUser ({ commit, state, rootState }, param) {
      return axios
        .post(API.user.searchUser, qs.stringify(param))
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    // 获取当前用户角色信息
    getUserRoles ({ commit }) {
      return axios
        .post(API.user.getUserRoles)
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            console.log(
              '用户角色信息:',
              JSON.parse(JSON.stringify(res.data.data))
            )
            return JSON.parse(JSON.stringify(res.data.data))
          } else {
            console.error('获取用户角色失败')
            return null
          }
        })
        .catch((error) => {
          console.error('请求失败:', error)
          throw error
        })
    }
  },
  /* 状态变量获取前置处理 */
  getters: {}
}

export default user
