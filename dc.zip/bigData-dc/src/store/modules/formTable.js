/**
 * Created by TONGXC1 on 2017-9-9.
 */
/**
 * form-table
 * 动态表单-增删改查
 */

import axios from 'axios'
import API from '../../assets/js/api.js'
import qs from 'qs'
// let resolve = (res) => {
// }
const dataSourceForm = {
  namespaced: true,
  /* 状态变量 */
  state: {
    tableList: [], // 表列
    tableHeader: [], // 表头
    pageTotalCount: 1,
    dimeList: [],
    isDurisdiction: true, // 是否有权限
    allDataPermissions: false, // 赋予表单所有数据权限
    SetRoleTableList: [], // 获取角色管理中设置表单权限-维表数据列表接口
    SetRoleTableCount: 1, // 获取角色管理中设置表单权限-维表数据列表count
    SetRoleTableisChecked: [], // 获取角色管理中设置表单权限-维表数据列表默认选择列表
    setSelTabelColumn: [],
    /* ouzm1 20180820 */
    pagenum: 1, // 页码
    rownum: 10, // 页行
    sortCols: [],  // 排序列
    tableMssList: []
  },
  /* 状态维护 */
  mutations: {
    /* 获取表列 */
    FORM_GETTABLELIST: (state, obj) => {
      state.tableList = obj
    },
    /* 获取表头 */
    FORM_GETTABLEHEADER: (state, obj) => {
      state.tableHeader = obj
    },
    /* 是否有权限 */
    FORM_TABLEISJURISDICTION: (state, obj) => {
      state.isDurisdiction = obj
    },
    /* 赋予表单所有数据权限 */
    FORM_TABLE_ALLDATAPERMISSIONS: (state, obj) => {
      state.allDataPermissions = obj
    },
    updatePageTotalCount (state, pageCount) {
      state.pageTotalCount = pageCount || 0
    },
    /* 获取维度list */
    updateDimeList: (state, obj) => {
      state.dimeList = obj
    },
    /** 获取角色管理中设置表单权限-维表数据列表接口 **/
    updateSetRoleTableList: (state, obj) => {
      state.SetRoleTableList = obj
    },
    /** 获取角色管理中设置表单权限-维表数据列表count **/
    updateSetRoleTableCount: (state, obj) => {
      state.SetRoleTableCount = obj
    },
    /** 获取角色管理中设置表单权限-维表数据列表默认选择列表 **/
    updateSetRoleTableisChecked: (state, obj) => {
      state.SetRoleTableisChecked = obj
    },
    /** 设置搜索字段 **/
    setSelTabelColumn (state, obj) {
      state.setSelTabelColumn = obj
    },
    /** 设置页码 **/
    setPagenum (state, obj) {
      state.pagenum = obj
    },
    /** 设置行数 **/
    setRownum (state, obj) {
      state.rownum = obj
    },
     /** 设置排序列 **/
    setSortCols (state, obj) {
      state.sortCols[0] = obj
    },
    updateTableMssList (state, obj) {
      state.tableMssList = obj
    }
  },
  /* 获取数据 */
  actions: {
    /** 获取table列表 **/
    getTableList ({commit, state, rootState}, param) {
      return axios.post(API.form_table.getList, JSON.stringify({colDtos: param.colDtos || [], tableUUID: param.tableUUID, pagenum: param.pagenum || 1, rownum: param.rownum || 10, sortCols: param.sortCols || []}), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          const result = res.data
          const data = JSON.parse(result.data)
          commit('FORM_GETTABLELIST', data.resultSet)
          commit('updatePageTotalCount', data.totalRows)
          // commit('FORM_GETTABLELIST', res.data.data)
        } else {
          if (res.data.__errorMessage) {
            alert(res.data.__errorMessage)
          } else {
            alert('获取表单内容失败')
          }
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 获取table头部 **/
    getTableHeader ({commit, state, rootState}, param) {
      return axios.post(API.table.getTable, qs.stringify({ uuid: param })).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          commit('FORM_TABLEISJURISDICTION', res.data.data.jurisdiction)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 获取table头部 **/
    getTableHeader2 ({commit, state, rootState}, param) {
      return axios.post(API.table.getTableIsJurisdiction, qs.stringify({ uuid: param })).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          commit('FORM_TABLEISJURISDICTION', res.data.data.jurisdiction)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 获取table头部 **/
    getTableHeader3 ({commit, state, rootState}, param) {
      return axios.post(API.table.getTableIsAllDataPermissions, qs.stringify({ tableId: param.uuid, roleId: param.roleId })).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
          commit('FORM_TABLEISJURISDICTION', res.data.data.jurisdiction)
          commit('FORM_TABLE_ALLDATAPERMISSIONS', res.data.data.allDataPermissions)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 获取用户配置的搜索字段 **/
    getUserSearchColumn ({commit, state, rootState}, param) {
      return axios.post(API.table.getUserSearchColumn, qs.stringify(param)).then((res) => {
        if (res.data && res.status === 200 && String(res.data.__statusCode) === '1') {
          state.setSelTabelColumn = JSON.parse(res.data.data)
        }
        return res
      }).catch(err => {
        console.log(err)
      })
    },
    /* 更新用户配置的搜索字段 */
    updateUserSearchColumn ({commit, state, rootState}, param) {
      console.log('1111111', API.table.updateUserSearchColumn)
      return axios.post(API.table.updateUserSearchColumn, JSON.stringify(param), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        return res
      })
    },
    /* 新增表行 */
    setTableRow ({commit, state, rootState}, param) {
      return axios.post(API.form_table.insert, qs.stringify(param)).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 修改表行 */
    changeTableRow ({commit, state, rootState}, param) {
      return axios.post(API.form_table.update, qs.stringify(param)).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 删除表行 */
    delTableRow ({commit, state, rootState}, param) {
      return axios.post(API.form_table.delete, qs.stringify(param)).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 获取关联表单维度内容list */
    getDimeList ({commit, state, rootState}, param) {
      return axios.post(API.form_table.demiPk, qs.stringify({ tableUUID: param })).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          commit('updateDimeList', JSON.parse(res.data.data))
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 搜索维度内容list */
    searchDimeList ({commit, state, rootState}, param) {
      let param_ = {}
      param_.colId = param.colId
      param_.collection = param.collection
      param_.parentDimeValue = param.parentDimeValue
      return axios.post(API.form_table.getDimention, qs.stringify(param_)).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          console.log(88888888, res)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 搜索维度内容list */
    getFormInfo ({commit, state, rootState}, param) {
      let param_ = {}
      param_.colId = param.colId
      param_.collection = param.collection
      return axios.post(API.form_table.getFormInfo, qs.stringify(param_)).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 角色中设置表单权限维度列表 **/
    getSetRoleTableList ({commit, state, rootState}, param) {
      return axios.post(API.form_table.showDataList, JSON.stringify({colDtos: param.colDtos || [], tableUUID: param.tableUUID, pagenum: param.pagenum || 1, rownum: param.rownum, roleId: param.roleId}), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        if (res.data && res.data.data && res.status === 200 && res.data.__statusCode === '1') {
          const result = res.data
          const data = JSON.parse(result.data)
          // commit('updateSetRoleTableList', data.resultSet)
          commit('updateSetRoleTableCount', data.totalRows)
          commit('updateSetRoleTableList', data.resultSet)
          let checkedList = []
          for (let item of data.resultSet) {
            if (item.isChecked === '1') {
              checkedList.push(item)
            }
          }
          commit('updateSetRoleTableisChecked', checkedList)
        } else {
          if (res.data.__errorMessage) {
            alert(res.data.__errorMessage)
          } else {
            alert('获取表单内容失败')
          }
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    getTableMssList ({commit, state, rootState}, param) {
      return axios.post(API.tableMss.list + '?uuid=' + param, JSON.stringify({uuid: param}), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        if (res.data.__statusCode === '1') {
          const result = res.data
          const data = result.data
          commit('updateTableMssList', data)
        } else {
          if (res.data.__errorMessage) {
            alert(res.data.__errorMessage)
          } else {
            alert('获取调度内容失败')
          }
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    reRun ({commit, state, rootState}, param) {
      return axios.post(API.tableMss.run + '?uuid=' + param.id, JSON.stringify({uuid: param.id}), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    }
  },
  getters: {
    accessTableHeader (state) {
      let form = {}
      let length = state.tableHeader.length
      if (length === 0) return []
      for (let i = 0; i < length; i++) {
        form[state.tableHeader[i].formAttributeName] = state.tableHeader[i].colDefaultValue
        // form[state.tableHeader[i].formAttributeName] = ''
      }
      return form
    },
    // 搜索表单
    tableSearchfrom (state) {
      let form = []
      let length = state.tableHeader.length
      if (length === 0) return []
      for (let i = 0; i < length; i++) {
        form.push({
          colName: state.tableHeader[i].colName,
          controlsType: state.tableHeader[i].controlsType,
          formValue: state.tableHeader.colDefaultValue,
          colName_des: state.tableHeader[i].colComment,
          uuid: state.tableHeader[i].uuid
        })
      }
      return form
    },
    isHaveTimestamp (state) { // 是否存在时间控件
      let timeTypeList = []
      let length = state.tableHeader.length
      for (let i = 0; i < length; i++) {
        if (state.tableHeader[i].controlsType === 'TIMESTAMP' || state.tableHeader[i].controlsType === 'DATETIME' || state.tableHeader[i].controlsType === 'DATE') {
          timeTypeList.push(state.tableHeader[i].formAttributeName)
        }
      }
      return timeTypeList
    },
    tableList_ (state) { // 格式化接口传来的时间
      let timeTypeList = []
      let length = state.tableHeader.length
      for (let i = 0; i < length; i++) {
        if (state.tableHeader[i].controlsType === 'TIMESTAMP' || state.tableHeader[i].controlsType === 'DATETIME' || state.tableHeader[i].controlsType === 'DATE') {
          timeTypeList.push(state.tableHeader[i].formAttributeName.toLocaleUpperCase())
        }
      }
      let tableList = []
      if (timeTypeList.length) {
        for (let item of state.tableList) {
          for (let b of timeTypeList) {
            if (item[b]) {
              let currentDate = new Date(item[b])
              let Y = currentDate.getFullYear()
              let M = currentDate.getMonth() > 8 ? currentDate.getMonth() + 1 : '0' + (currentDate.getMonth() + 1)
              let D = currentDate.getDate() > 9 ? currentDate.getDate() : '0' + currentDate.getDate()
              let h = currentDate.getHours() > 9 ? currentDate.getHours() : '0' + currentDate.getHours()
              let m = currentDate.getMinutes() > 9 ? currentDate.getMinutes() : '0' + currentDate.getMinutes()
              let s = currentDate.getSeconds() > 9 ? currentDate.getSeconds() : '0' + currentDate.getSeconds()
              item[b] = `${Y}-${M}-${D} ${h}:${m}:${s}` // 从这里改变
            }
          }
        }
      }
      tableList = state.tableList
      return tableList
    },
    SetRoleTableList_ (state) { // 格式化接口传来的时间
      let timeTypeList = []
      let length = state.tableHeader.length
      for (let i = 0; i < length; i++) {
        if (state.tableHeader[i].controlsType === 'TIMESTAMP' || state.tableHeader[i].controlsType === 'DATETIME' || state.tableHeader[i].controlsType === 'DATE') {
          timeTypeList.push(state.tableHeader[i].formAttributeName)
        }
      }
      let tableList = []
      if (timeTypeList.length) {
        for (let item of state.SetRoleTableList) {
          for (let b of timeTypeList) {
            if (item[b]) {
              let currentDate = new Date(item[b]).toISOString()
              let YMD = currentDate.slice(0, 10)
              let hhmmss = currentDate.slice(11, 19)
              item[b] = YMD + ' ' + hhmmss // 从这里改变
            }
          }
        }
      }
      tableList = state.SetRoleTableList
      return tableList
    }
  }
}

export default dataSourceForm
