/**
 * 数据源状态管理
 */

import axios from 'axios'
import API from '../../assets/js/api.js'
// import qs from 'qs'

const dataSource = {
  namespaced: true,
  /* 状态变量 */
  state: {
    dbTypeList: [], // 数据库类型列表
    list: [] // 数据源列表
  },
  /* 状态维护 */
  mutations: {
    updateDbTypeList (state, list) { // 更新数据源类型列表
      state.dbTypeList = list
    },
    updateList (state, list) { // 更新数据源列表
      state.list = list
    }
  },
  /* 获取数据 */
  actions: {
    getDbTypeList ({ commit }) {
      axios.get(API.dataSource.getDBType).then(response => {
        console.log(response)
        const result = response.data
        const dbTypeList = result.data
        commit('updateDbTypeList', dbTypeList)
      }).catch(error => {
        console.error(error)
      })
    },
    getList ({ commit }) { // 获取数据源列表
      axios.post(API.dataSource.getList).then(response => {
        console.log(response)
        const result = response.data
        const list = JSON.parse(result.data).resultSet
        commit('updateList', list)
        // todo: 数据处理
      }).catch(error => {
        console.error(error)
      })
    }
  }
}

export default dataSource
