/**
 * Created by tongxc1 on 2018-11-16.
 * 分组管理
 */

import axios from 'axios'
import API from '../../assets/js/api.js'
import qs from 'qs'

const formGroup = {
  namespaced: true,
  /* 状态变量 */
  state: {
    list: [] // 列表
  },
  /* 状态维护 */
  mutations: {
    updateList (state, list) { // 更新列表
      state.list = list
    }
  },
  /* 获取数据 */
  actions: {
    getFormList ({commit, state, rootState}, param) {
      return axios.post(API.role.getFormList, qs.stringify({showAll: 1})).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          commit('updateList', JSON.parse(res.data.data))
        }
        return JSON.parse(res.data.data)
      }).catch(error => {
        console.error(error)
      })
    },
    operation ({commit, state, rootState}, {path, params}) {
      return axios.post(path, JSON.stringify(params), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    }
  }
}

export default formGroup
