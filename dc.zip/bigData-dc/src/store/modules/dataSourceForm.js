/**
 * Created by TONGXC1 on 2017-9-7.
 */
/**
 * 数据源提交表单
 */

import axios from 'axios'
import API from '../../assets/js/api.js'
import qs from 'qs'
// let resolve = (res) => {
// }
const dataSourceForm = {
  namespaced: true,
  /* 状态变量 */
  state: {
    // formDataTypeList: []
    currentDataSourceForm: []
  },
  /* 状态维护 */
  mutations: {
    // 'FORM_GETDATATYPELIST': (state, obj) => {
    //   state.fromDataType = obj
    // }
  },
  /* 获取数据 */
  actions: {
    /** 连接数据库 **/
    conDataSource ({commit, state, rootState}, param) {
      return axios.post(API.dataSource.conDataSource, param).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 更新数据库 **/
    updateDataSource ({commit, state, rootState}, param) {
      return axios.post(API.dataSource.updateDataSource, param).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 检测连接状态 **/
    checkConnection ({commit, state, rootState}, param) {
      return axios.post(API.dataSource.checkConnection, param).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 检测code是否存在 **/
    validateDsrcCode ({commit, state, rootState}, param) {
      return axios.get(API.dataSource.validateDsrcCode + '?dsrcCode=' + param.dsrcCode).then((res) => {
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /** 获取数据源信息 **/
    getDataSourceDetail ({commit, state, rootState}, param) {
      return axios.post(API.dataSource.getDataSource, qs.stringify({uuid: param.uuid})).then((res) => {
        console.log(res)
        return res
      }).catch(error => {
        console.error(error)
      })
    }
  }
}

export default dataSourceForm
