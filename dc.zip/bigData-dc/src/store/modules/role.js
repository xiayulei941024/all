/**
 * Created by TONGXC1 on 2017-9-15.
 */
/**
 * 角色管理模块
 */

import API from '../../assets/js/api'
import axios from 'axios'
import qs from 'qs'

const user = {
  namespaced: true,
  /* 状态变量 */
  state: {
    columns: [], // 权限字段
    list: [], // 权限列表
    addRoleUserColums: [], // 新增权限用户表头
    addRoleUser: [], // 新增权限用户列表
    currentRoleUser: [], // 当前权限用户列表
    formTreeList: [], // 动态表单树
    formTreeList2: [], // 菜单树
    formTreeCheckedList: [], // 动态表单树默认选择数组
    formTreeCheckedList2: [], // 菜单树默认选择数组
    pageTotalCount: 1,
    setformTreeList: [] // 角色数据权限动态表单数据树
  },
  /* 状态维护 */
  mutations: {
    // 更新用户字段
    updateColumns (state, columns) {
      state.columns = columns
    },
    // 更新用户列表
    updateList (state, list) {
      state.list = list
    },
    // 更新新增权限用户列表
    upDateAddRoleUser (state, list) {
      state.addRoleUser = list
    },
    // 更新新增用户权限表头
    upDateAddRoleUserColums (state, list) {
      state.addRoleUserColums = list
    },
    // 更新当前权限用户列表
    upDateCurrentRoleUser (state, list) {
      state.currentRoleUser = list
    },
    // 更新目录树列表
    updateFormTreeList (state, list) {
      state.formTreeList = list
    },
    // 更新菜单目录树列表
    updateFormTreeList2 (state, list) {
      state.formTreeList2 = list
    },
    // 更新目录树默认选择列表
    updateFormTreeCheckedList (state, list) {
      state.formTreeCheckedList = list
    },
    // 更新菜单目录树列表
    updateFormTreeCheckedList2 (state, list) {
      state.formTreeCheckedList2 = list
    },
    updatePageTotalCount (state, pageCount) {
      state.pageTotalCount = pageCount || 0
    },
    // 更新角色数据权限动态表单数据树
    updateSetFormTreeList (state, list) {
      state.setformTreeList = list
    }
  },
  /* 状态动作 */
  actions: {
    // 获取权限列表
    getRoleList ({ commit }, params) {
      axios.post(API.role.getRoleList, qs.stringify({pagenum: (params && params.pageNum) || 1, rownum: (params && params.rownum) || 10})).then(response => {
        const result = response.data
        const data = JSON.parse(result.data)
        console.log(data.resultSet)
        commit('updateList', data.resultSet)
        commit('updateColumns', data.metadata)
        console.log(data.totalRows)
        commit('updatePageTotalCount', data.totalRows)
      }).catch(error => {
        console.error(error)
      })
    },
    // 新增用户
    setRoleTableRow ({commit, state, rootState}, param) {
      // return axios.post(API.role.insert + '?userIds=' + param.userIds + '&' + 'formIds=' + param.formids + '&' + 'menuIds=' + param.menuIds + '&forms=' + param.forms, param).then((res) => {
      return axios.post(API.role.insert, param).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.data) {
          // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 修改权限
    updateRoleTableRow ({commit, state, rootState}, param) {
      // return axios.post(API.role.update + '?userIds=' + param.userIds + '&' + 'formIds=' + param.formids + '&' + 'menuIds=' + param.menuIds + '&forms=' + param.forms, param, param).then((res) => {
      return axios.post(API.role.update, param).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.data) {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /* 删除表行 */
    delRoleTableRow ({commit, state, rootState}, param) {
      return axios.post(API.role.delete, qs.stringify(param)).then((res) => {
        if (res.data && res.status === 200 && res.data.data) {
          // commit('FORM_GETTABLEHEADER', res.data.data.tableColumns)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取角色权限信息
    getRoleDetail ({commit, state, rootState}, param) {
      return axios.post(API.role.getRoleDetail, qs.stringify(param)).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.data) {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 查询编码是否存在
    searchCode ({commit, state, rootState}, param) {
      return axios.get(API.role.searchCode + '?roleCode=' + param.roleCode, qs.stringify(param)).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.data) {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 新增权限用户
    addUserList ({ commit }, params) {
      let params_ = {}
      params.pageNum ? params_.pagenum = params.pageNum : ''
      if (params.userAccount) {
        params_.userAccount = params.userAccount || ''
      }
      if (params.roleId) {
        params_.roleId = params.roleId || []
      }
      return axios.post(API.user.getUserList, qs.stringify(params_)).then(response => {
        const result = response.data
        const data = JSON.parse(result.data)
        console.log(data)
        return data
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取动态表单列表
    getFormList ({commit, state, rootState}, param) {
      return axios.post(API.role.getFormTree, qs.stringify({roleId: param.roleId})).then((res) => {
        console.log(JSON.parse(res.data.data))
        if (res.data && res.status === 200 && res.data.data) {
          commit('updateFormTreeList', JSON.parse(res.data.data))
          let defaultNode = []
          for (let item of JSON.parse(res.data.data)) {
            if (item.ifCheck === '1' && item.type === 'table') {
              defaultNode.push(item.uuid)
            }
          }
          commit('updateFormTreeCheckedList', defaultNode)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 根据权限获取菜单树列表
    getMenuRoleTree ({commit, state, rootState}, param) {
      return axios.post(API.menu.getMenuRoleTree, qs.stringify({roleId: param.roleId})).then((res) => {
        console.log('updateFormTreeList2', JSON.parse(res.data.data))
        if (res.data && res.status === 200 && res.data.data) {
          let defaultNode2 = []
          let data_ = JSON.parse(res.data.data)
          commit('updateFormTreeList2', data_)
          for (let item of data_) {
            if (item.ifCheck === '1' && item.uuid) {
              defaultNode2.unshift(item.uuid)
            }
          }
          commit('updateFormTreeCheckedList2', defaultNode2)
        }
        return JSON.parse(res.data.data)
      }).catch(error => {
        console.error(error)
      })
    },
    // 提交表单权限控制接口
    saveRoleFormSet ({commit, state, rootState}, param) {
      return axios.post(API.dataJurisdiction.save, JSON.stringify(param), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        console.log('saveRoleFormSet', res)
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取表单权限控制接口
    getRoleFormList ({commit, state, rootState}, param) {
      return axios.post(API.dataJurisdiction.getList + '?tableId=' + param.tableId + '&roleId=' + param.roleId).then((res) => {
        console.log('saveRoleFormSet', res)
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取角色数据权限动态表单数据树
    getShowDataList ({commit, state, rootState}, param) {
      return axios.post(API.role.showDataList + '?uuid=' + param.uuid).then((res) => {
        console.log(JSON.parse(res.data.data))
        if (res.data && res.status === 200 && res.data.data) {
          commit('updateSetFormTreeList', JSON.parse(res.data.data))
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    }
  },
  /* 状态变量获取前置处理 */
  getters: {
    getDefaultNode (state) {
      let defaultNode = []
      for (let item of state.formTreeList) {
        if (item.ifCheck === '1' && item.type === 'table') {
          defaultNode.push(item.uuid)
        }
      }
      return defaultNode
    }
  }
}

export default user
