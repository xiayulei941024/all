/**
 * Created by TONGXC1 on 2017-10-21.
 * 角色管理模块
 */

import API from '../../assets/js/api'
import axios from 'axios'
import qs from 'qs'

const outSync = {
  namespaced: true,
  /* 状态变量 */
  state: {
  },
  /* 状态维护 */
  mutations: {
  },
  actions: {
    /**
     * 获取外部数据源树列表
     **/
    getOutSyncList ({commit, state, rootState}, param) {
      return axios.post(API.outSync.dataTree, qs.stringify(param)).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          console.log('outSync.dataTree', JSON.parse(res.data.data))
        } else {
          // alert(res.data.message)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    },
    /**
     *  同步外部数据源树列表
     **/
    insetSyncDataSource ({commit, state, rootState}, param) {
      return axios.post(API.outSync.syncDataSource, JSON.stringify(param), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then((res) => {
        console.log(res)
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
        } else {
          // alert(res.data.__errorMessage)
        }
        return res
      }).catch(error => {
        console.error(error)
      })
    }
  }
}
export default outSync
