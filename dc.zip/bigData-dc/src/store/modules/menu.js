/**
 * 菜单目录管理
 * @author chenqy9
 */
import axios from 'axios'
import API from '../../assets/js/api'
import qs from 'qs'

const menu = {
  namespaced: true,
  /* 状态变量 */
  state: {
    // 菜单模块列表
    moduleList: [],
    // 菜单树列表
    treeList: [],
    // 根据用户获取菜单树列表
    treeList_for_user: [],
    // 根据用户获取表单树列表
    formTreeList_for_user: [],
    // 菜单列表对象
    list: [
      {
        title: '数据补录',
        submenuList: []
      },
      {
        title: '系统管理',
        submenuList: []
      }
    ],
    list_siderbar: [
      {
        title: '数据补录',
        submenuList: []
      },
      {
        title: '系统管理',
        submenuList: []
      }
    ],
    // 当前的一级菜单
    currentFirstMenuIndex: 0,
    keyword: ''
  },
  /* 状态维护 */
  mutations: {
    // 更新模块列表
    updateModuleList (state, list) {
      state.moduleList = list
    },
    // 更新目录树列表
    updateTreeList (state, list) {
      state.treeList = list
    },
    // 更新目录树列表
    updateTreeList_for_user (state, list) {
      state.treeList_for_user = list
    },
    updateFormTreeList_for_user (state, list) {
      state.formTreeList_for_user = list
    },
    // 更新菜单
    updateList (state, list) {
      console.log('menu update list')
    },
    // 改变当前选择的一级菜单
    changeFirstMenuIndex (state, index) {
      state.currentFirstMenuIndex = index
    },
    updateLeftMenu (state, obj) {
      state.list[0].submenuList = obj
    },
    updateLeftMenu_for_user (state, obj) {
      state.list_siderbar[1].submenuList = obj
    },
    updateLeftForm_for_user (state, obj) {
      state.list_siderbar[0].submenuList = obj
    },
    setKeyword (state, data) {
      console.log('setKeyword=========', data)
      state.keyword = data
    }
  },
  /* 状态动作 */
  actions: {
    // // 获取菜单模块列表
    // getModuleList ({ commit }) {
    //   axios.get(API.gettreelist).then(response => {
    //     const result = response.data
    //     const data = result.data
    //     commit('updateModuleList', data)
    //     console.log(data)
    //   }).catch(error => {
    //     console.error(error)
    //   })
    // },
    // 获取目录树列表
    getTreeList ({ commit }) {
      axios
        .get(API.gettreelist)
        .then((response) => {
          const result = response.data
          const data = result.data
          commit('updateTreeList', JSON.parse(data))
        })
        .catch((error) => {
          console.error(error)
        })
    },
    /* newMenu-start */
    // 获取菜单列表
    getMenuList ({ commit, state, rootState }, param) {
      return axios
        .post(API.menu.getMenuTree, qs.stringify({ showAll: 0 }))
        .then((res) => {
          console.log(JSON.parse(res.data.data))
          if (res.data && res.status === 200 && res.data.data) {
            commit('updateTreeList', JSON.parse(res.data.data))
          }
          return res
        })
        .catch((error) => {
          console.error(error)
        })
    },
    // 根据用户获取菜单列表
    getMenuList_for_user ({ commit, state, rootState }, param) {
      return axios
        .post(API.menu.getMenuTree, qs.stringify({ showAll: 0 }))
        .then((res) => {
          console.log(112, JSON.parse(res.data.data))
          if (res.data && res.status === 200 && res.data.data) {
            commit('updateTreeList_for_user', JSON.parse(res.data.data))
          }
          return JSON.parse(res.data.data)
        })
        .catch((error) => {
          console.error(error)
        })
    },
    // 根据用户获取菜表单列表
    getFormList_for_user ({ commit, state, rootState }, param) {
      return axios
        .post(API.role.getFormList, qs.stringify({ showAll: 0 }))
        .then((res) => {
          if (res.data && res.status === 200 && res.data.data) {
            commit('updateFormTreeList_for_user', JSON.parse(res.data.data))
          }
          return JSON.parse(res.data.data)
        })
        .catch((error) => {
          console.error(error)
        })
    }
    /* newMenu-end */
  },
  /* 状态变量获取前置处理 */
  getters: {
    // 获取一级菜单
    firstMenuList: (state) => {
      let list = []
      for (let menuItem of state.list) {
        list.push(menuItem.title)
      }
      return list
    },
    // 获取当前一级菜单下面的子菜单
    sideMenulist: (state) => {
      return state.list_siderbar[state.currentFirstMenuIndex].submenuList
    }
  }
}

export default menu
