/**
 * tab 全局状态管理
 */

// import Tab from '../../assets/models/Tab.js'

const tabs = {
  state: {
    // tab对象列表
    list: [
      {
        name: '首页',
        url: '/'
      }
    ]
    // 当前的激活菜单索引
    // activeIndex: 0
  },
  mutations: {
    addTab: (state, tab) => {
      try {
        console.log('addTab')
        state.list.push(tab)
        // state.activeIndex = state.list.length - 1
      } catch (error) {
        console.error(error)
      }
    },
    removeTab (state, tabName) {
      try {
        // if (!index || index > state.list.length) return
        state.list = state.list.filter(tab => tab.name !== tabName)
        // state.activeIndex = state.list[state.activeIndex + 1] ? state.activeIndex + 1 : state.activeIndex - 1
      } catch (error) {
        console.error(error)
      }
    }
  },
  actions: {

  },
  getters: {
  }
}

export default tabs
