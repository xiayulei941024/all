/**
 * 维表级联设置状态管理
 * author luoshuai1
 * 2017 11 23
 */

import API from '../../assets/js/api.js'
import axios from 'axios'
import qs from 'qs'
// import _ from 'lodash'

const parentDimension = {
  namespaced: true,
  state: {
    list: [], // 获取回来的数据
    parentDeminData: [], // 选中的父节点
    childDeminData: [], // 选中的子节点
    commitDeminsionData: [] // 提交的数据
  },
  mutations: {
    updateAllDimenData (state, { list }) {
      state.list = list
    },
    updateParentDimenData (state, { list }) {
      state.list = list
    },
    updatecommitDeminsionData (state, { list }) {
      state.list = list
    },
    updateContent (state, { list }) {
      state.list = list
    }
    // updateTableColumnTypes (state, { list }) {
    //   state.parentDeminData = list
    // },
    // updateList (state, { list }) {
    //   state.list = list
    // },
    // updateDimensionalList (state, { list }) {
    //   state.childDeminData = list
    // },
    // updateDimensionalList (state, { list }) {
    //   state.commitDeminsionData = list
    // }
  },
  actions: {
    getAllParentDimensionData ({commit, state, rootState}, param) {
      let params_ = {}
      params_.type = param.type || 'datasource'
      params_.colId = param.colId
      params_.uuid = param.uuid
      return axios.post(API.table.getDimensionTree, qs.stringify(params_)).then(response => {
        if (response.data && response.status === 200 && response.data.__statusCode === '1') {
          commit('updateAllDimenData', {list: response.data.data})
        }
        return response
      }).catch(error => {
        console.error(error)
      })
    },
    getParentDimensionTree ({commit, state, rootState}, param) {
      let params_ = {}
      params_.type = param.type || 'datasource'
      params_.colId = param.colId
      params_.uuid = param.uuid
      params_.flag = param.flag
      return axios.post(API.table.getparentDimensionTree, qs.stringify(params_)).then(response => {
        if (response.data && response.status === 200 && response.data.__statusCode === '1') {
          commit('updateParentDimenData', {list: response.data.data})
        }
        return response
      }).catch(error => {
        console.error(error)
      })
    },
    postParentDimensionData ({commit, state, rootState}, param) {
      let params_ = {}
      params_.columnId = param.columnId
      params_.parentColumnId = param.parentColumnId
      return axios.post(API.table.postParentDimensionData, JSON.stringify(params_), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(response => {
        if (response.data && response.status === 200 && response.data.__statusCode === '1') {
          commit('updatecommitDeminsionData', {list: response.data.data})
        }
        return response
      }).catch(error => {
        console.error(error)
      })
    },
    getContent ({commit, state, rootState}, param) {
      let params_ = {}
      params_.colId = param.colId
      return axios.post(API.table.getContent + '?colId=' + param.colId, JSON.stringify(params_), {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(response => {
        if (response.data && response.status === 200 && response.data.__statusCode === '1') {
          commit('updateContent', {list: response.data.data})
        }
        return response
      }).catch(error => {
        console.error(error)
      })
    }
  }
}

export default parentDimension
