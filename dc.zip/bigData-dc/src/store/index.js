import Vue from 'vue'
import Vuex from 'vuex'

import menu from './modules/menu'
import tab from './modules/tab'
import user from './modules/user'
import dataSource from './modules/dataSource'
import table from './modules/table'
import dataSourceForm from './modules/dataSourceForm'
import formTable from './modules/formTable'
import role from './modules/role'
import outSync from './modules/outSync'
import parentDimension from './modules/parentDimension'
import formGroup from './modules/fromGroup'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    pageTotalCount: 0, // 当前table的总页数
    isShowDialog: true, // 是否显示dialog
    isShowTableDialog: true // 是否显示表弹窗
  },
  mutations: {
    updatePageTotalCount (state, pageCount) {
      state.pageTotalCount = pageCount || 0
    },
    updateIsShowDialog (state, isShow) {
      state.isShowDialog = isShow
    },
    updateIsShowTableDialog (state, isShow) {
      console.log(isShow)
      state.isShowTableDialog = isShow
    }
  },
  modules: {
    menu,
    tab,
    user,
    dataSource,
    table,
    dataSourceForm,
    formTable,
    role,
    outSync,
    parentDimension,
    formGroup
  }
})

export default store
