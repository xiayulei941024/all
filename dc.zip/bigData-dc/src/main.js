// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.

/* 应用程序主入口 */

/* 引入全局插件模块 */
import 'babel-polyfill'
import 'normalize.css' // 重置样式
import 'element-ui/lib/theme-default/index.css' // 引入element UI样式
// import 'font-awesome/css/font-awesome.min.css' // 引入font-awesome icon
import NProgress from 'nprogress' // Progress 进度条
import 'nprogress/nprogress.css' // Progress 进度条样式
import jquery from 'jquery'
import 'jquery-ui'

/* 引入Vue及相关组件、插件 */
import Vue from 'vue'
import App from './App'
import store from './store'
import router from './router'
import ElementUI from 'element-ui'
import VueI18n from 'vue-i18n'
// 引入语言包
import CN from '@/assets/lang/cn'
import EN from '@/assets/lang/en'
/* 注册window全局模块 */
window.$ = jquery
const eventHub = new Vue()
Vue.prototype.eventHub = eventHub

/* 注册Vue全局插件 */
Vue.use(ElementUI)
    // 注册国际化
Vue.use(VueI18n)

let lan = localStorage.getItem('lan') ? localStorage.getItem('lan') :'zh-CN'
const i18n = new VueI18n({
        locale: localStorage.getItem('lan'), // 语言标识
        //this.$i18n.locale // 通过切换locale的值来实现语言切换
        messages: {
            'zh-CN': CN, // 中文语言包
            'en-US': EN // 英文语言包
        }
    })
    /* router 前置处理 */
router.beforeEach((to, from, next) => {
    NProgress.start() // 开启Progress进度条
    next()
})

/* router 后置处理 */
router.afterEach(() => {
    NProgress.done() // 结束Progress进度条
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
    el: '#app',
    store,
    i18n,
    router,
    template: '<App/>',
    components: { App }
})