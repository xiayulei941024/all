// 国际化设置
import Vue from 'vue'
import VueI18n from 'vue-i18n'
// 引入语言包
import CN from './cn'
import EN from './en'
Vue.use(VueI18n)
let lang = 'en'
if(window.localStorage.getItem('lang')){
    lang = window.localStorage.getItem('lang')
} else if(navigator && navigator.language){
    if(navigator.language.indexOf('zh') > -1){
        lang =  'zh';
    }
    if(navigator.language.indexOf('en') > -1){
        lang =  'en';
    }
    window.localStorage.setItem('lang', lang)    
}

// if(lang === 'zh') {
//     require('@/assets/theme/zh/iview.css')
// }
// if(lang === 'en') {
//     require('@/assets/theme/en/iview.css')
// }

const i18n = new VueI18n({
    // 当前语言环境
    locale: lang,
    // 默认语言环境。如果locale中无匹配项则采用该项值
    fallbackLocale: lang,
     messages: {
        'zh-CN': CN, // 中文语言包
        'en-US': EN // 英文语言包
    }
})
export default i18n