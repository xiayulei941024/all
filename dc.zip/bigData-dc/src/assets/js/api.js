// const HOST = 'http://localhost:8080'
// const HOST = '/api'
const DOMAIN = window.location.hostname
if (!window.location.origin) {
  window.location.origin =
    window.location.protocol +
    '//' +
    window.location.hostname +
    (window.location.port ? ':' + window.location.port : '')
}
console.log(window.location.pathname)
const pathname = window.location.pathname.split('/')
let pathname_ = ''
pathname.map((item) => {
  if (item !== '') {
    pathname_ = item
  }
})
// let HOST = 'http://localhost:8080/dataCollection'
let HOST = ''
if (!pathname_) {
  HOST = window.location.origin
} else {
  HOST = window.location.origin + '/' + pathname_
}
if (DOMAIN.indexOf('localhost') > -1) {
  // HOST = 'http://10.14.35.9:8082/dataCollection'
  // HOST = 'http://10.14.32.20:8082/dataCollection'
  // HOST = 'http://10.14.32.20:8082' + '/' + pathname_ // weibiao本地
}

const API = {
  logout: HOST + '/dcLogOut',
  getAllUser: HOST + '/roles_code/getAllUser', // 获取所有用户信息
  getUserInfo: HOST + '/user/getUserInfo', // 获取登录用户信息
  getAllDataSource: HOST + '/table/getAllDataSource', // 获取所有的数据源信息
  gettreelist: HOST + '/modelGroup/gettreelist', // 获取菜单模块列表
  /* 数据表接口 */
  table: {
    getList: HOST + '/table/list', // 获取表列表
    delete: HOST + '/table/delete', // 删除表
    insert: HOST + '/table/insert', // 插入表
    getTable: HOST + '/table/getTable', // 获取表
    getTableIsJurisdiction: HOST + '/table/getTableIsJurisdiction',
    getTableIsAllDataPermissions: HOST + '/table/getTableIsAllDataPermissions',
    update: HOST + '/table/update', // 更新表
    getTableColumnType: HOST + '/table/getTableColumnType', // 获取表字段类型
    getControlsType: HOST + '/table/getControlsType', // 获取表字段控件类型
    getDimensionTree: HOST + '/table/dimensionTree', // 获取维度树列表
    getRegularType: HOST + '/table/getRegularType', // 获取正则列表
    getparentDimensionTree: HOST + '/table/parentDimensionTree', // 获取维表级联设置列表
    postParentDimensionData: HOST + '/parentTableDimension/save', // 提交维表级联设置数据
    getContent: HOST + '/table/getContent', // 获取已设置维表级联数据
    getUserSearchColumn: HOST + '/table/getUserSearchColumn', // 获取用户配置的搜索字段
    updateUserSearchColumn: HOST + '/table/updateUserSearchColumn'
  },
  tableMss: {
    configuration: HOST + '/tableMss/configuration',
    list: HOST + '/tableMss/list',
    run: HOST + '/tableMss/run'
  },
  /* 数据源接口 */
  dataSource: {
    getDBType: HOST + '/dataSource/getDBType', // 获取数据库类型列表
    getList: HOST + '/dataSource/list', // 获取数据源列表
    delete: HOST + '/dataSource/delete', // 删除数据源
    conDataSource: HOST + '/dataSource/insert', // 连接数据库
    updateDataSource: HOST + '/dataSource/update', // 更新数据库
    validateDsrcCode: HOST + '/dataSource/validateDsrcCode', // 效验系统编码是否存在
    checkConnection: HOST + '/dataSource/checkConnection', // 检测数据库连接
    getDataSource: HOST + '/dataSource/getDataSource'
  },
  /* form-table动态表单 */
  form_table: {
    delete: HOST + '/form/delete',
    insert: HOST + '/form/insert',
    getList: HOST + '/form/list',
    update: HOST + '/form/update',
    importExel: HOST + '/form/importExcel',
    downExcel: HOST + '/form/exportOut',
    downExcl: HOST + '/form/downExcl',
    downDimeExcl: HOST + '/form/downDimeExcl',
    demiPk: HOST + '/form/demiPK',
    downModelExcl: HOST + '/form/downModelExcl', // 导入模板下载接口
    getDimention: HOST + '/form/getDimention', // 搜索维度信息接口
    getFormInfo: HOST + '/form/getFormInfo', // 动态表单字段信息
    showDataList: HOST + '/form/showDataList' // 角色数据权限动态表单列表
  },
  /* user用户管理 */
  user: {
    insert: HOST + '/user/saveCustomUserInfo', // 新增,修改用户信息
    delete: HOST + '/user/delete', // 删除用户
    checkUser: HOST + '/user/checkUserInfo', // 验真用户是否已添加
    searchUser: HOST + '/user/checkldap', // 用户管理中用户查找
    // getUserInfo: HOST + '/user/getUserInfo', // 获取用户登录信息
    getUserList: HOST + '/user/list', // 获取用户列表
    getUserDetail: HOST + '/user/detail', // 获取用户详情列表
    getUserRoles: HOST + '/user/queryUserRoles', // 获取当前角色信息
    getUserRoleTableInfo: HOST + '/user/roleTabInfos' // 获取当前角色报表信息
    // copyData: HOST + '/user/saveCopyData', // 用户复制权限
    // exportData: HOST + '/user/exportdata', // 用户列表导出
    // downExcel: HOST + ' /user/downExcelImport' // 下载excel
  },
  /* menu菜单管理 */
  menu: {
    getMenuTree: HOST + '/menu/tree',
    insert: HOST + '/menu/insert',
    delete: HOST + '/menu/delete',
    update: HOST + '/menu/update',
    getMenu: HOST + '/menu/getMenu',
    getMenuRoleTree: HOST + '/menu/menuTree' // 单个角色菜单树
  },
  /* role权限管理 */
  role: {
    getRoleList: HOST + '/role/list',
    insert: HOST + '/role/insert',
    delete: HOST + '/role/delete',
    update: HOST + '/role/update',
    getRoleDetail: HOST + '/role/getRole',
    searchCode: HOST + '/role/validateRoleCode',
    getFormList: HOST + '/role/formList',
    getFormTree: HOST + '/role/formTree',
    showDataList: HOST + '/role/showDataList' // 角色数据权限动态表单数据树
  },
  /**
   * 外部数据源outSync
   * **/
  outSync: {
    dataTree: HOST + '/outDataSource/dataTree',
    syncDataSource: HOST + '/outDataSource/syncDataSource'
  },
  /**
   * 表单权限控制接口
   * **/
  dataJurisdiction: {
    save: HOST + '/dataJurisdiction/saveJurisdiction',
    getList: HOST + '/dataJurisdiction/list'
  },
  // 表单分组
  formGroup: {
    insert: HOST + '/formGroup/insert',
    update: HOST + '/formGroup/update',
    delete: HOST + '/formGroup/delete',
    formForGroup: HOST + '/formGroup/formForGroup',
    getFormGroupOptions: HOST + '/formGroup/getFormGroupOptions'
  }
}

export default API
