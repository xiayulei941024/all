/**
 * 公共方法工具集合
 */

// 根据树形数组构造目录树
function getTree ({treeList, root}) {
  if (!treeList) {
    return
  }
  // 找出树形数组中的根节点
  let roots = treeList.filter(node => {
    return node.parentid === '0'
  })

  if (root) {
    root.children = roots
    root = [root]
  } else if (roots.length > 1) {
    root = [{
      id: -1,
      uuid: 'table_0',
      name: '根目录',
      lable_des: '根目录',
      children: roots
    }]
  } else {
    root = roots
  }

  findChildren(roots, treeList)
  console.log('root', root)
  return root

  // 节点组从数组中寻找自己的子节点
  function findChildren (nodes, list) {
    for (let node of nodes) {
      node.lable_des = node.name_des || node.name
      node.children = list.filter(item => {
        return item.parentid === node.uuid
      })
      // 如果节点找到子节点继续递归寻找
      if (node.children.length > 0) {
        findChildren(node.children, list)
      }
    }
  }
}
function getDateString (val, newDate) {
  function pad2 (n) { return n < 10 ? '0' + n : n }
  const date = newDate || new Date()
  const Y = date.getFullYear() + '.'
  const M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '.'
  const M2 = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1)
  const D = date.getDate()
  const time = date.getFullYear().toString() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate()) + ' ' + pad2(date.getHours()) + ':' + pad2(date.getMinutes()) + ':' + pad2(date.getSeconds())
  if (val === 'YYYYMMDD') {
    return Y + M + D
  } else if (val === 'YYYYMM') {
    return Y + M2
  } else if (val === 'YYYY-MM-DD hh:mm:ss') {
    return time
  } else {
    return Y + M + D
  }
}

export { getTree, getDateString }
