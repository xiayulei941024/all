class TableColumn {
  constructor () {
    this.colName = ''
    this.colComment = ''
    this.colDefaultValue = ''
    this.colEmpty = true
    this.colPointSize = 0
    this.colSize = 255
    this.colType = 'VARCHAR'
    this.controlsType = 'TEXT'
    this.formName = ''
    this.formAttributeName = ''
    this.primaryKey = false
    this.dimension = false
    this.dimensions = null
    this.regular = ''
  }
}

export default TableColumn
