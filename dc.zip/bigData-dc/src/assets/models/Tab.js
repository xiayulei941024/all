/**
 * Tab 类
 */

class Tab {
  constructor (params) {
    const { label, disabled, name, closable } = params
    this.label = label // tab显示的名字
    this.disabled = disabled // 标签是否禁止
    this.name = name // tab的标识
    this.closable = closable // 是否可以关闭
  }
}

export default Tab
