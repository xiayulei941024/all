<template>
  <div id="app" :theme="theme" @click="goCas">
    <default-layout></default-layout>
    <dialog-panel></dialog-panel>
    <!--数据源管理--新增表model-->
    <table-dialog v-if="isShowTableDialog"></table-dialog>
    <!--数据源管理--新增model-->
    <data-source-form></data-source-form>
    <!--补录系统--数据源表增删改model-->
    <dynamic-table-model></dynamic-table-model>
    <!--用户管理--用户增删改查model-->
    <user-table-model></user-table-model>
    <!--权限管理--权限管理增删改查model-->
    <role-table-model></role-table-model>
    <!--权限管理--关联用户-->
    <role-sel-user-model></role-sel-user-model>
    <!--z数据源管理--关联维度-->
    <table-dialog-dimensionality></table-dialog-dimensionality>
    <!--补录系统--表搜索model-->
    <dynamic-table-search-model></dynamic-table-search-model>
    <!-- 配置搜索字段 -->
    <dynamic-table-search-model2></dynamic-table-search-model2>
    <!-- 行详情弹框 -->
    <dynamic-table-rowdetail></dynamic-table-rowdetail>
    <!-- 分组弹框 -->
    <form-group-model></form-group-model>
    <div class="loading-warpper"  v-show="box1">
      <div class="loader loader--style1" title="0">
        <svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="60px" height="60px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
  <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
    s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
    c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
  <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
    C22.32,8.481,24.301,9.057,26.013,10.047z">
    <animateTransform attributeType="xml"
      attributeName="transform"
      type="rotate"
      from="0 20 20"
      to="360 20 20"
      dur="0.5s"
      repeatCount="indefinite"/>
    </path>
  </svg>
        <p style="color: #fff">上传中</p>
      </div>
    </div>
  </div>
</template>

<script>
import DefaultLayout from './components/layout/DefaultLayout'
import DialogPanel from './components/page/common/DialogPanel'
import TableDialog from './components/page/TableDialog'
import DataSourceForm from './components/page/DataSourceForm'
import DynamicTableModel from './components/page/DynamicTableModel.vue'
import DynamicTableSearchModel from './components/page/DynamicTableSearchModle.vue'
import DynamicTableSearchModel2 from './components/page/DynamicTableSearchModle2.vue'
import DynamicTableRowdetail from './components/page/DynamicTableRowdetail.vue'
// 用户新增修改组件弹窗
import UserTableModel from './components/page/user/UserTableModel.vue'
// 权限管理组件Model
import RoleTableModel from './components/page/role/RoleAdminModel.vue'
import RoleSelUserModel from './components/page/role/RoleSelUserModel.vue'
// 数据源管理 关联维度
import TableDialogDimensionality from './components/page/tableDialogDimensionality.vue'
// 分组管理
import formGroupModel from './components/page/formGroup/formGroupModel.vue'
// import API from './assets/js/api'
// import axios from 'axios'

export default {
  name: 'app',
  data () {
    return {
      theme: 'light',
      box1: false
    }
  },
  methods: {
    goCas () {
      this.$store.dispatch('user/getUserInfo')
    }
  },
  computed: {
    isShowTableDialog () {
      return this.$store.state.isShowTableDialog
    }
  },
  created () {
    this.$store.dispatch('user/getUserInfo') // 获取登录用户信息
    // this.eventHub.$on('showTableDialog', (params) => {
    //   console.log(params)
    //   this.isShowTableDialog = true
    // })
    setInterval(() => {
      this.$store.dispatch('user/getUserInfo')
    }, 10 * 60 * 1000)
  },
  mounted () {
    this.eventHub.$on('isShow', () => {
      this.box1 = true
    })
    this.eventHub.$on('ishidden', () => {
      console.log(222222)
      this.box1 = false
    })
  },
  components: {
    DefaultLayout,
    DialogPanel,
    TableDialog,
    DataSourceForm,
    DynamicTableModel,
    UserTableModel,
    RoleTableModel,
    RoleSelUserModel,
    TableDialogDimensionality,
    DynamicTableSearchModel,
    DynamicTableSearchModel2,
    DynamicTableRowdetail,
    formGroupModel
  }
}
</script>

<style lang="scss">
  @import './assets/styles/reset.scss';
  @import './assets/styles/app.scss';
  @import './assets/styles/theme.scss';
  .loader {
    margin: 0 0 2em;
    height: 100px;
    width: 20%;
    text-align: center;
    padding: 1em;
    margin: 0 auto 1em;
    display: inline-block;
    vertical-align: top;
  }
  svg path,
  svg rect {
    fill: #fff;
  }
  .loading-warpper{
    width: 100%;
    height: 100%;
    background: #000;
    position: absolute;
    z-index: 9999;
    opacity: 0.3;
    .loader--style1{
      position: absolute;
      top: 40%;
      left: 50%;
      transform: translate(-50%,-40%);
    }
  }

</style>

