<template>
  <!-- 顶部导航栏 -->
  <div class="component-navbar">
    <div class="navbar-menu">
      <el-menu  mode="horizontal" default-active="0" style="background:none" >
        <el-menu-item style='color:#fff' v-for="(menuItem, index) of menuList" v-show="menuListAll[index].submenuList.length"
                      :key="index" :index="index.toString()"
                      @click="changeMenuIndex(index)">
          {{menuItem}}
        </el-menu-item>
        <!-- <el-menu-item class="menu-user" index="-1">
          <span class="fa fa-user">陈庆耀</span><i class="el-icon-arrow-down"></i>
        </el-menu-item> -->
      </el-menu>
    </div>
    <div class="navbar-user">
      <el-input v-model="searchName" placeholder="请输入" icon="search" clearable style="width: 200px;margin-right: 20px;" :on-icon-click="getMenuList" @keyup.enter.native="getMenuList" />
      <!-- <i class="fa fa-user-circle-o fa-lg"></i> -->
      <!-- <el-dropdown> -->
      <!-- <span class="el-dropdown-link"> -->
      <span style="font-size: 14px;">{{$t('common.welcomeText')}}{{userInfo.userName ? userInfo.userName.split("@")[0]:''}} </span>
      <el-dropdown style="margin:0 20px" @command="changeLan">
            <span class="el-dropdown-link" style="cursor: pointer;">
              {{$t('common.lan')}}  {{lan}}<i class="el-icon-arrow-down el-icon--right" style='font-size:14px'></i>
            </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="zh-CN">中文</el-dropdown-item>
          <el-dropdown-item command="en-US">ENGLISH</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <!-- <i class="el-icon-caret-bottom el-icon--right"></i> -->
      <!-- </span> -->
      <a :href="logoutUrl">
        <!-- <i class="fa fa-sign-out"></i> -->
        <span  style='color:#fff; font-size:14px'>{{$t('common.exit')}}</span>
        <!-- <span>退出系统</span> -->
      </a>
      <!-- <el-dropdown-menu slot="dropdown">
        <el-dropdown-item>
          <i class="fa fa-id-card"></i>
          <span>个人信息</span>
        </el-dropdown-item>
        <el-dropdown-item>
          <i class="fa fa-gears"></i>
          <span>更换主题</span>
        </el-dropdown-item>
        <a :href="logoutUrl">
          <el-dropdown-item>
            <i class="fa fa-sign-out"></i>
            <span>{{$t('common.exit')}}</span>
            <span>退出系统</span>
          </el-dropdown-item>
        </a>

      </el-dropdown-menu> -->
      <!-- </el-dropdown> -->
    </div>
  </div>
</template>

<style lang="scss">
.el-dropdown-menu__item{
  font-size: 14px;
  color:#666
}
.component-navbar {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  background: #2173dc;
  background: -webkit-linear-gradient(90deg,#1d42ab,#2173dc,#1e93ff);
  background: -moz-linear-gradient(to right,#1d42ab,#2173dc,#1e93ff);
  background: -o-linear-gradient(to right,#1d42ab,#2173dc,#1e93ff);
  background: linear-gradient(90deg,#1d42ab,#2173dc,#1e93ff);
  .navbar-menu {
    /*width: 100%;*/
    /*padding-right: 200px;*/
    /*font-size: 20px !important;*/
  }

  .navbar-user {
    position: absolute;
    right: 20px;
    color: #fff;
  }
  .el-dropdown-link {
    color: #fff;
  }
  .el-menu-item{
    font-weight: normal!important;
    border-bottom: 0

  }
  .el-menu-item:hover{
    border-bottom: 3px solid #fff!important;
  }
  .el-menu-item [class^=el-icon-] {
    margin-right: 0;
    width: 16px;
  }


  /*.fa-user-circle-o {*/
  /*color: #409EFF;*/
  /*}*/
  // .menu-user:active {
  //   border: none;
  // }
}
</style>

<script>
import API from '../../assets/js/api'
export default {
  name: 'navbar',
  data () {
    return {
      logoutUrl: API.logout,
      lan: '中文',
      searchName: ''
    }
  },
  computed: {

    menuList () {
      return this.$store.getters['menu/firstMenuList']
    },
    userInfo () {
      return this.$store.state.user.loginUser
    },
    menuListAll () {
      return this.$store.state.menu.list_siderbar
    },
    menuTree () {
      return this.$store.state.menu.formTreeList_for_user
    }
  },
  created () {
    // 获取模块列表
    // this.$store.dispatch('menu/getModuleList')
    let isLan = localStorage.getItem('lan')
    if (isLan === 'zh-CN') {
      this.lan = '中文'
    } else {
      this.lan = 'ENGLISH'
    }
  },
  methods: {
    // 语言切换
    changeLan (data) {
      if (data === 'zh-CN') {
        this.lan = '中文'
      } else {
        this.lan = 'ENGLISH'
      }
      // console.log(1111111,this.i18n)
      // i18n.locale = data
      localStorage.setItem('lan', data)
      window.location.reload()
    },
    changeMenuIndex (index) {
      this.$store.commit('menu/changeFirstMenuIndex', index)
    },
    getMenuList () {
      console.log('输入的内容：', this.searchName)
      this.$store.commit('menu/setKeyword', this.searchName)
    }
  }
}
</script>


