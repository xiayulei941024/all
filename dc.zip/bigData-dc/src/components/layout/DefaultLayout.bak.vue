<template>
  <!-- 默认布局 -->
  <div class="component-layout-default">
    <!-- 左侧菜单栏 -->
    <div class="container-sidebar">
      <sidebar></sidebar>
    </div>
    <!-- 内容容器 -->
    <div class="container-content">
      <!-- 顶部导航栏 -->
      <div class="container-navbar">
        <navbar></navbar>
      </div>
      <!-- 中部页面内容 -->
      <div class="container-page">
        <page></page>
      </div>
      <!-- 顶部tab内容 -->
      <div class="container-tab">
        <tabbar></tabbar>
      </div>
    </div>
  </div>
</template>

<script>
  import Navbar from '../navbar/Navbar.vue'
  import Sidebar from '../sidebar/Sidebar.vue'
  import Page from '../page/Page.vue'
  import Tabbar from './Tabbar.vue'

  export default {
    name: 'defaultLayout',
    components: {
      Navbar,
      Sidebar,
      Page,
      Tabbar
    }
  }
</script>

<style lang="scss" scoped>
  /* 整体布局 */
  .component-layout-default {
    width: 100%;
    height: 100%;

    $height_container_navbar: 60px;
    $width_container_sidebar: 200px;
    $height_container_tabbar: 42px;

    /* 左侧菜单 */
    .container-sidebar {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 999;
      width: $width_container_sidebar;
      height: 100%;
      overflow-x: hidden;
      overflow-y: hidden;
    }

    /* 右侧内容 */
    .container-content {
      position: absolute;
      top: 0;
      left: 0;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      overflow: hidden;

      /* 顶部导航栏 */
      .container-navbar {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 888;
        box-sizing: border-box;
        width: 100%;
        height: $height_container_navbar;
        padding-left: $width_container_sidebar;
        overflow: hidden;
      }

      /* 中部页面区域 */
      .container-page {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 777;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
        padding-left: $width_container_sidebar;
        padding-top: $height_container_navbar;
        padding-bottom: $height_container_tabbar;
        // padding-bottom: 65px;
        /*overflow: auto;*/
      }

      /* 底部tab标签 */
      .container-tab {
        position: absolute;
        bottom: 0;
        left: 0;
        z-index: 888;
        width: 100%;
        height: $height_container_tabbar;
        padding-left: $width_container_sidebar;
        overflow: hidden;
      }
    }
  }
</style>


