<template>
  <div class="component-tabbar">
    <!-- <el-tabs v-model="activeTabIndex" type="border-card" editable @edit="handleTabsEdit"> -->
    <el-tabs v-model="activeTabName" type="border-card" @tab-remove="removeTab" @tab-click="changeTab">
      <el-tab-pane
        v-for="(tab, index) in tabs"
        :key="tab.name"
        :closable="index !== 0"
        :label="tab.name"
        :name="tab.name">
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  export default {
    name: 'tabbar',
    data () {
      return {
        activeTabName: '首页'
      }
    },
    created () {
      this.eventHub.$on('activeTab', ({name, url}) => {
        // debugger
        for (let tab of this.$store.state.tab.list) {
          if (tab.name === name) {
            this.activeTabName = name
            return
          }
        }
        this.$store.commit('addTab', {name: name, url: url})
        this.activeTabName = name
        // if (this.$store.state.tab.list.indexOf(name) < 0) {
        //   this.$store.commit('addTab', name)
        //   this.activeTabName = name
        // } else {
        //   this.activeTabName = name
        // }
      })
      // this.activeTabName = this.$store.state.tab.list[this.$store.state.tab.activeIndex]
    },
    computed: {
      tabs () {
        return this.$store.state.tab.list
      }
    },
    methods: {
      changeTab (tab) {
        console.log(this.tabs[tab.index])
        this.$router.push(this.tabs[tab.index].url)
      },
      removeTab (targetName) {
        let tabs = this.tabs
        let activeName = this.activeTabName
        if (targetName === tabs[0].name) return
        if (activeName === targetName) {
          tabs.forEach((tab, index) => {
            if (tab.name === targetName) {
              let nextTab = tabs[index + 1] || tabs[index - 1]
              if (nextTab) {
                activeName = nextTab.name
                console.log(nextTab)
                this.$router.push(nextTab.url)
              }
            }
          })
        }
        this.activeTabName = activeName
        this.$store.commit('removeTab', targetName)
        // console.log(tabs.filter(tab => tab.name === targetName))
        // this.tabs = tabs.filter(tab => tab.name !== targetName)
      }
    }
    // data () {
    //   return {
    //     editableTabsValue: '2',
    //     editableTabs: [{
    //       title: 'Tab 1',
    //       name: '1',
    //       content: 'Tab 1 content'
    //     }, {
    //       title: 'Tab 2',
    //       name: '2',
    //       content: 'Tab 2 content'
    //     }],
    //     tabIndex: 2
    //   }
    // },
    // methods: {
    //   handleTabsEdit (targetName, action) {
    //     if (action === 'add') {
    //       let newTabName = ++this.tabIndex + ''
    //       this.editableTabs.push({
    //         title: 'New Tab',
    //         name: newTabName,
    //         content: 'New Tab content'
    //       })
    //       this.editableTabsValue = newTabName
    //     }
    //     if (action === 'remove') {
    //       let tabs = this.editableTabs
    //       let activeName = this.editableTabsValue
    //       if (activeName === targetName) {
    //         tabs.forEach((tab, index) => {
    //           if (tab.name === targetName) {
    //             let nextTab = tabs[index + 1] || tabs[index - 1]
    //             if (nextTab) {
    //               activeName = nextTab.name
    //             }
    //           }
    //         })
    //       }
    //       this.editableTabsValue = activeName
    //       this.editableTabs = tabs.filter(tab => tab.name !== targetName)
    //     }
    //   }
    // }
  }
</script>

<style lang="scss" >
  .component-tabbar {
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
	.el-tabs{
		border: 0;
		.el-tabs__header{
			border-bottom: 0;
			.el-tabs__item{
				margin: 5px 0;
				height: 32px;
				line-height: 32px;
    background: #fff;
    border-radius: 3px;
    border: none;
    margin-right: 6px;
    color: #808695;
			}
			.el-tabs__item.is-active{
				color: #2d8cf0
			}
		}
	}
</style>

