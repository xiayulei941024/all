<template>
  <!-- 默认布局 -->
  <div class="component-layout-default" :class="{isCollapse: isCollapse}">
    <!-- 左侧菜单栏 -->
    <div class="container-sidebar" :class="{isCollapse: isCollapse}">
      <sidebar></sidebar>
      <i class="collapse-icon" @click="isCollapse = !isCollapse" :class="{'el-icon-arrow-right': isCollapse, 'el-icon-arrow-left': !isCollapse}"></i>
    </div>
    <!-- 内容容器 -->
    <div class="container-content">
      <!-- 顶部导航栏 -->
      <div class="container-navbar" :class="{isCollapse: isCollapse}">
        <navbar></navbar>
      </div>
			<div class="container-tab" :class="{isCollapse: isCollapse}">
			  <tabbar></tabbar>
			</div>
      <!-- 中部页面内容 -->
      <div class="container-page" v-loading.lock="loading"
           element-loading-text="拼命加载中"
           element-loading-spinner="el-icon-loading" :class="{isCollapse: isCollapse}">
        <page></page>
      </div>
      <!-- 顶部tab内容 -->
      
      <div class="page-component-up" v-if="showScrollTopBtn" @click="scrollTo">
        <i class="el-icon-caret-top"></i>
      </div>
    </div>
  </div>
</template>

<script>
  import Navbar from '../navbar/Navbar.vue'
  import Sidebar from '../sidebar/Sidebar.vue'
  import Page from '../page/Page.vue'
  import Tabbar from './Tabbar.vue'
  export default {
    name: 'defaultLayout',
    data () {
      return {
        isCollapse: false,
        showScrollTopBtn: false
      }
    },
    computed: {
      loading () {
        return this.$store.state.loading
      }
    },
    methods: {
      scrollTo () {
        document.getElementById('my-scroll-page').scrollTop = 0
        this.showScrollTopBtn = false
      },
      onScroll () {
        if (document.getElementById('my-scroll-page').scrollTop) {
          this.showScrollTopBtn = true
        } else {
          this.showScrollTopBtn = false
        }
      }
    },
    mounted () {
      document.getElementById('my-scroll-page').addEventListener('scroll', this.onScroll)
    },
    components: {
      Navbar,
      Sidebar,
      Page,
      Tabbar
    }
  }
</script>

<style lang="scss">
  /* 整体布局 */
  .component-layout-default {
    width: 100%;
    height: 100%;

    $height_container_navbar: 60px;
    $width_container_sidebar: 250px;
    $height_container_tabbar: 50px;

    /* 左侧菜单 */
    .container-sidebar {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 999;
      width: $width_container_sidebar;
      height: 100%;
      /*overflow-x: hidden;*/
      /*overflow-y: hidden;*/
      &.isCollapse {
        left: -$width_container_sidebar;
      }
      .collapse-icon {
        display: flex;
        position: absolute;
        top: 50%;
        right: -15px;
        z-index: 1000;
        opacity: .7;
        height: 50px;
        line-height: 50px;
        width: 15px;
        padding: 0;
        color: #fff;
        background-color: #545c64;
        &:hover {
          opacity: 1;
        }
      }
    }

    /* 右侧内容 */
    .container-content {
      position: absolute;
      top: 0;
      left: 0;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      overflow: hidden;

      /* 顶部导航栏 */
      .container-navbar {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 888;
        box-sizing: border-box;
        width: 100%;
        height: $height_container_navbar;
        padding-left: $width_container_sidebar;
        overflow: hidden;
        &.isCollapse {
          padding-left: 0;
        }
      }

      /* 中部页面区域 */
      .container-page {

        position: absolute;
        top: 0;
        left: 0;
        z-index: 777;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
        padding-left: $width_container_sidebar;
        padding-top: $height_container_tabbar + $height_container_navbar;
        // padding-bottom: 65px;
        overflow: auto;
        &.isCollapse {
          padding-left: 0;
        }
      }

      /* 底部tab标签 */
      .container-tab {
        position: absolute;
        top: 60px;
        left: 0;
        z-index: 888;
        width: 100%;
        height: $height_container_tabbar;
        padding-left: $width_container_sidebar;
        overflow: hidden;
        box-sizing: border-box;

        &.isCollapse {
          padding-left: 0;
        }
      }

      /* 滚动按钮 */
      .page-component-up {
				
        background-color: #545c64;
        opacity: 0.7;
        position: fixed;
        right: 100px;
        bottom: 150px;
        width: 40px;
        height: 40px;
        border-radius: 20px;
        cursor: pointer;
        color: #fff;
        transition: .3s;
        box-shadow: 0 0 6px rgba(0,0,0,.12);
        z-index: 1000;
        &:hover {
          opacity: 1;
        }
        i {
          display: block;
          line-height: 40px;
          text-align: center;
          font-size: 18px;
        }
      }
    }
    .el-loading-mask {
      /*left: 200px;*/
    }
    &.isCollapse {
      .el-loading-mask {
        left: 0;
      }
    }
  }
</style>


