<template>
  <div class="component-sidebar">
    <div class="logo">
      <img :src="logoUrl" alt="" style="width: 100px;">
      补录系统
    </div>
    <!-- 左侧菜单 -->
    <div id="my-scroll" class="sidebar-menu">
      <el-menu class="sidebar-menu" theme="dark">
        <!-- 遍历一级菜单数组对象 -->
        <div v-for="(menuItem, index_1) of menuList" :key="index_1">
          <!-- 有二级菜单的一级菜单 -->
          <el-submenu v-if="menuItem.submenuList&&menuItem.submenuList.length" :index="index_1.toString()">
            <!-- 一级菜单标题 -->
            <div slot="title" :title="menuItem.title">
              <!-- <i class="el-icon-menu"></i> -->
              {{menuItem.title}}
            </div>
            <!-- 遍历二级菜单数组对象 -->
            <div v-for="(menuItem, index_2) of menuItem.submenuList"
                 :key="index_2">
              <!-- 有三级菜单的二级菜单 -->
              <el-submenu v-if="menuItem.submenuList&&menuItem.submenuList.length" :index="index_1 + '-' + index_2">
                <!-- 二级菜单标题 -->
                <div :title="menuItem.title" slot="title">
                  {{menuItem.title}}
                </div>
                <!-- 遍历三级菜单数组对象 -->
                <div v-for="(menuItem, index_3) of menuItem.submenuList" :key="index_3">
                  <!-- 有四级菜单的三级菜单 -->
                  <el-submenu v-if="menuItem.submenuList&&menuItem.submenuList.length" :index="index_1 + '-' + index_2 + '_' + index_3">
                    <!-- 三级菜单标题 -->
                    <div :title="menuItem.title" slot="title">
                      {{menuItem.title}}
                    </div>
                    <!-- 遍历四级菜单对象 -->
                    <el-menu-item v-for="(menuItem, index_4) of menuItem.submenuList"
                                  :key="index_4"
                                  :index="index_1 + '-' + index_2 + '_' + index_3 + '_' + index_4"
                                  @click="changeView(menuItem)">
                      <!-- 四级菜单标题 -->
                      <div :title="menuItem.title"> {{menuItem.title}}</div>
                    </el-menu-item>
                  </el-submenu>
                  <!-- 无四级菜单的三级菜单 -->
                  <el-menu-item v-else
                                @click="changeView(menuItem)"
                                :index="index_1 + '-' + index_2 + '-' + index_3">
                    <!-- 三级菜单标题 -->
                    <div :title="menuItem.title"> {{menuItem.title}}</div>
                  </el-menu-item>
                </div>
              </el-submenu> <!-- 三级菜单 end -->
              <!-- 无三级菜单的二级菜单 -->
              <el-menu-item v-else  @click="changeView(menuItem)" :index="index_1 + '-' + index_2">
                <!-- 二级菜单标题 -->
                <div :title="menuItem.title"> {{menuItem.title}}</div>
              </el-menu-item>
            </div>
          </el-submenu> <!-- 二级菜单 end -->
          <!-- 无二级菜单的一级菜单 -->
          <el-menu-item v-if="!menuItem.submenuList.length"
                        :index="index_1.toString()"
                        @click="changeView(menuItem)">
            <div :title="menuItem.title"> {{menuItem.title}}</div>
          </el-menu-item>
        </div> <!-- 一级菜单 end -->
      </el-menu>
    </div>
  </div>
</template>

<style lang="scss">
.component-sidebar {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 8px 0 rgba(29,35,41,.05);

  .logo {
    /*height: 60px;*/
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    white-space: pre-wrap;
    align-items: center;
    font-size: 18px;
    border-bottom: 1px solid #f8f8f9;
    // flex: 0 0 120px;
    // color: #2173dc!important;
    color: #fff;
    background: #1d42ab;
    span {
      display: block;
      width: 100%;
    }
  }

  .sidebar-menu {
    flex-grow: 1;
    height: 100%;
    /*overflow-y: auto;*/
    /*overflow-x: hidden;*/
    overflow: auto;
    background: #fff;
  }
  .el-menu-item:hover{
    color: #2d8cf0;
    background: none;
  }
  .el-menu-item, .el-submenu__title {
    height: 46px;
    line-height: 46px;
    color: #515a6e;

  }
  .el-menu-item, .el-submenu__title:hover{
    background: none;
  }
  .el-menu {
    border-right: none;
  }
  .el-menu--dark .el-submenu .el-menu .el-menu-item:hover,.el-menu-item.is-active {
    background-color: #f0faff;
    color: #2d8cf0;
    ::after{
      content: "";
      display: block;
      width: 2px;
      position: absolute;
      top: 0;
      bottom: 0;
      right: 0;
      background: #2d8cf0;
    }
  }
  .is-active{

  }

  .el-menu--dark .el-submenu .el-menu {
    background-color: #fff;
  }
  .el-menu--dark .el-menu-item:hover, .el-menu--dark .el-submenu__title:hover {
    color: #2d8cf0;
  }
}
</style>

<script>
import Scrollbar from 'smooth-scrollbar'
import logoUrl from '@/assets/img/logo.png'
export default {
  name: 'sidebar',
  data () {
    return {
      logoUrl
    }
  },
  computed: {
    menuList () {
      // console.log(this.$store.getters.sideMenulist)
      return this.$store.getters['menu/sideMenulist']
    },
    dataSourceList () { // 数据源一级目录
      return this.$store.state.dataSource.list
    },
    tableList () { // 获取全部表
      return this.$store.state.table.list
    },
    menuUserList_for_user () { // 根据用户获取菜单列表
      return this.$store.state.menu.treeList_for_user
    },
    menuFormList_for_user () { // 根据用户获取菜单列表
      return this.$store.state.menu.formTreeList_for_user
    },
    userInfo () {
      return this.$store.state.user.loginUser
    },
    keyword () {
      // console.log('this.$store.state.menu.keyword',this.$store.state.menu.keyword)
      return this.$store.state.menu.keyword
    }
  },
  watch: {
    dataSourceList (val) {
//      console.log(val)
      this.accessDataSourceList(this.tableList)
    },
    tableList (val) {
//      console.log(val)
      this.accessDataSourceList(val)
    },
    menuFormList_for_user (val) {
//      console.log(val)
      this.accessMenuList2(val)
    },
    menuUserList_for_user (val) {
      this.accessMenuList(val)
    },
    keyword (val) {
      this.accessMenuList2(this.$store.state.menu.formTreeList_for_user)
    }
  },
  methods: {
    matchTreeData (arr, value) {
      let newarr = []
      arr.forEach(element => {
        if (((element.name_des.toUpperCase().indexOf(value.toUpperCase()) > -1) || (element.name.toUpperCase().indexOf(value.toUpperCase()) > -1))) { // 判断条件
          newarr.push(element)
        } else {
          if (element.submenuList && element.submenuList.length > 0) {
            let redata = this.matchTreeData(element.submenuList, value)
            if (redata && redata.length > 0) {
              let obj = {
                ...element,
                submenuList: redata
              }
              newarr.push(obj)
            }
          }
        }
      })
      return newarr
    },
    changeView ({title, url}) {
      try {
        this.$router.push(url)
        this.eventHub.$emit('activeTab', {name: title, url: url})
      } catch (error) {
        console.error(error)
      }
    },
    activeTab (tabName) {
      console.log(tabName)
    },
    accessDataSourceList (list) {
      let menuList = []
      let length = this.dataSourceList.length
      for (let i = 0; i < length; i++) {
        let currenListTable = list.filter((value, index, arr) => {
          value.title = value.tableName_des || value.tableName
          value.url = '/table/' + value.uuid
          return value.dbId === this.dataSourceList[i].uuid
        })
        menuList.push({
          title: this.dataSourceList[i].dsrcName,
          submenuList: currenListTable
        })
//        console.warn('mune', currenListTable)
      }
//      console.warn('mune', menuList)
      this.$store.commit('menu/updateLeftMenu', menuList)
    },
    accessMenuList (treeList, root) {
      if (!treeList) {
        return
      }
      // 找出树形数组中的根节点
      let roots = treeList.filter(node => {
        return node.parentid === '0'
      })

      if (root) {
        root.submenuList = roots
        root = [root]
      } else if (roots.length > 1) {
        root = {
          title: '系统管理',
          submenuList: roots
        }
      } else {
//        root = roots
        root = {
          title: '系统管理',
          submenuList: roots
        }
      }

      findChildren(roots, treeList)

      // 节点组从数组中寻找自己的子节点
      function findChildren (nodes, list) {
        for (let node of nodes) {
          node.submenuList = list.filter(item => {
            item.title = item.name_des || item.name
            item.url = item.href
            return item.parentid === node.uuid
          })
          // 如果节点找到子节点继续递归寻找
          if (node.submenuList.length > 0) {
            findChildren(node.submenuList, list)
          }
        }
      }
      this.$store.commit('menu/updateLeftMenu_for_user', root.submenuList)
    },
    accessMenuList2 (treeList, root) {
      let _this = this
      if (!treeList) {
        return
      }
      console.log(treeList)
      // 找出树形数组中的根节点
      let roots = treeList.filter(node => {
        return node.parentid === '0'
      })

      if (root) {
        root.submenuList = roots
        root = [root]
      } else if (roots.length >= 1) {
        root = {
          title: '数据补录',
          submenuList: roots
        }
      } else {
//        root = roots
        root = {
          title: '数据补录',
          submenuList: roots
        }
      }

      findChildren(roots, treeList)
      console.log('root', root)

      // 节点组从数组中寻找自己的子节点
      function findChildren (nodes, list) {
        for (let node of nodes) {
          node.submenuList = list.filter(item => {
            item.title = item.name_des || item.name
            if (item.type === 'table') {
              item.url = '/table/' + item.uuid.slice(6)
            }
            return item.parentid === node.uuid
          })
          // 如果节点找到子节点继续递归寻找
          if (node.submenuList.length > 0) {
            findChildren(node.submenuList, list)
          }
        }
      }
      if (_this.keyword !== '') {
        let newArr = []
        newArr = _this.matchTreeData(root.submenuList, _this.keyword)
        console.log(newArr, 'newArr===================')
        _this.$store.commit('menu/updateLeftForm_for_user', newArr)
      } else {
        _this.$store.commit('menu/updateLeftForm_for_user', root.submenuList)
      }
    }
  },
  created () {
//    this.$store.dispatch('dataSource/getList').then(() => {
//      this.$store.dispatch('table/getList')
//    }).then(() => {
//      this.accessDataSourceList(this.tableList)
//    })
    this.$store.dispatch('menu/getFormList_for_user').then((res) => {
      console.log(111, res)
      this.accessMenuList2(this.menuFormList_for_user)
    })
    this.$store.dispatch('menu/getMenuList_for_user').then((res) => {
      console.log(111, res)
      this.accessMenuList(this.menuUserList_for_user)
    })
  },
  mounted () {
    Scrollbar.init(document.querySelector('#my-scroll'))
  }
}
</script>


