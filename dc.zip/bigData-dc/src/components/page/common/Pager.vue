<template>
  <div class="component-pager">
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :total="totalPage"
      @size-change="handleSizeChange"
      :page-sizes="[10, 50, 100, 200]"
      :page-size="currentSize"
      layout="sizes, total, prev, pager, next, jumper">
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: 'pager',
  props: {
    currentPage: {
      default: 1
    },
    totalPage: {
      default: 0
    },
    pageSize: {
      default: 10
    },
    currentSize: {
      default: 10
    }
  },
  created () {
    console.log(this.totalPage)
  },
  watch: {
    totalPage (newVal) {
      console.log(newVal)
    }
  },
  methods: {
    handleCurrentChange (pageNum) {
      this.$emit('switchPage', pageNum)
    },
    handleSizeChange (size) {
      this.$emit('sizeChange', size)
    }
  }
}
</script>

<style lang="scss" scoped>
  .component-pager {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>


