<template>
  <!-- 工具栏 -->
  <div class="component-toolbar" id="scrollParent">
    <i v-if="isScrollShow" class="left el-icon-arrow-left" @click="leftClick"></i>
    <div id="scrollBox" class="scroll-box" :class="{'addPd': addPd}">
      <el-button :disabled="!isDisabled" type="primary" icon="plus" @click="create">{{$t('common.create')}}</el-button>
      <el-button :disabled="!isDisabled" type="primary" icon="edit" @click="update">{{$t('common.update')}}</el-button>
      <el-button :disabled="!isDisabled" type="primary" icon="delete" @click="remove">{{$t('common.delete')}}</el-button>
      <el-dropdown style="margin-left: 10px" v-if="tableAlignAble">
        <el-button type="primary">
          {{$t('common.alignType')}} <i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown" @command="adjustAlign" >
          <el-dropdown-item @click.native.prevent="adjustAlign('left')" >{{$t('common.alignLeft')}}</el-dropdown-item>
          <el-dropdown-item @click.native.stop="adjustAlign('center')">{{$t('common.alignCenter')}}</el-dropdown-item>
          <el-dropdown-item @click.native="adjustAlign('right')">{{$t('common.alignRight')}}</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <el-button v-if="isRoleFormSet" type="primary" @click="roleFormSet">{{$t('common.formRoleSet')}}</el-button>
      <!--<a  type="primary" :href="URL_" style="display: inline-block;margin-left:10px">-->
      <!--<el-button type="primary" v-if="showDown" @click="excelDown">导出模版</el-button>-->
      <!--</a>-->
      <a :href="URL_2"  type="primary" style="display: inline-block;margin-left:10px">
        <el-button type="primary" v-if="showDown" @click="excelDown()">{{$t('common.exportForm')}}</el-button>
      </a>
      <a type="primary" style="display: inline-block;margin-left:10px">
        <el-button type="primary" v-if="showDown" @click="excelDown('3')">{{$t('common.exportDim')}}</el-button>
      </a>
      <a :href="URL_4" type="primary" style="display: inline-block;margin-left:10px">
        <el-button type="primary" v-if="showDown" @click="excelDown()">{{$t('common.exportTemplate')}}</el-button>
      </a>
      <div style="display: inline-block; margin-left: 10px;">
        <slot name="importButton"></slot>
      </div>
      <el-button v-if="showDown" style="margin-left: 10px;" icon="el-icon-setting" type="primary" @click="setColumn"><i class="el-icon-setting"></i>  {{$t('common.setSearchWord')}}</el-button>
      <!-- <el-button style="margin-left: 10px;" icon="search" type="primary" v-if="showDown" @click="search">搜索</el-button> -->
      <div v-if="textSearch" style="display: inline-block; margin-left: 10px;">
        <el-input v-model="searchText" :placeholder="$t('common.enterAccount')" auto-complete="off"></el-input>
        <el-button type="primary" @click="onTextSearch">{{$t('common.search')}}</el-button>
      </div>
    </div>
    <i v-if="isScrollShow" class="right el-icon-arrow-right" @click="rightClick"></i>
  </div>
</template>

<script>
import API from '../../../assets/js/api'
import axios from 'axios'
export default {
  name: 'toolbar',
  data () {
    return {
      searchKey: '',
      URL_: '',
      URL_2: '',
      URL_3: '',
      URL_4: '',
      left: 0,
      isScrollShow: false,
      addPd: false,
      searchText: '',
      colDtos: []
    }
  },
  props: {
    showDown: { // 是否显示导入到处按钮
      type: Boolean,
      default: function () {
        return false
      }
    },
    isDisabled: { // 是否禁言按钮
      type: Boolean,
      default: function () {
        return true
      }
    },
    isRoleFormSet: { // 是否显示表单权限设置按钮
      type: Boolean,
      default: function () {
        return false
      }
    },
    tableAlignAble: {
      type: Boolean,
      default: function () {
        return false
      }
    },
    textSearch: {
      type: Boolean,
      default: function () {
        return false
      }
    },
    colDtos: {
      type: Object,
      default: function () {
        return []
      }
    }
  },
  computed: {
    routeId () {
      return this.$route.params.uuid
    }
  },
  watch: {
    routeId () {
      this.URL_ = API.form_table.downExcel + '?tableUUID=' + this.$route.params.uuid
      this.URL_2 = API.form_table.downExcl + '?tableUUID=' + this.$route.params.uuid
      this.URL_3 = API.form_table.downDimeExcl + '?tableUUID=' + this.$route.params.uuid
      this.URL_4 = API.form_table.downModelExcl + '?tableUUID=' + this.$route.params.uuid
    },
    colDtos () {
      console.log(this.colDtos, 'this.colDtos--------')
      const encodedColDtos = encodeURIComponent(JSON.stringify(this.colDtos))
      console.log(encodedColDtos, 'encodedColDtos--------')
      this.URL_2 = API.form_table.downExcl + '?tableUUID=' + this.$route.params.uuid + '&colDtos=' + encodedColDtos
    }
  },
  mounted () {
    // this.URL_ = window.location.origin + API.form_table.downExcel + '?tableUUID=' + this.$route.params.uuid
    this.URL_ = API.form_table.downExcel + '?tableUUID=' + this.$route.params.uuid
    this.URL_2 = API.form_table.downExcl + '?tableUUID=' + this.$route.params.uuid
    this.URL_3 = API.form_table.downDimeExcl + '?tableUUID=' + this.$route.params.uuid
    this.URL_4 = API.form_table.downModelExcl + '?tableUUID=' + this.$route.params.uuid
    this.resize()
    window.addEventListener('resize', this.resize)
  },
  methods: {
    create () {
      this.$emit('create')
    },
    update () {
      this.$emit('update')
    },
    remove () {
      this.$emit('delete')
    },
    roleFormSet () {
      this.$emit('roleFormSet')
    },
//    search () {
//      this.$emit('search', this.searchKey)
//    },
    setColumn () {
      this.$emit('setColumn')
    },
    search () {
      this.$emit('search')
    },
    excelDown (val) {
      if (val === '3') {
        let api = {
          '2': API.form_table.downExcl + '?tableUUID=' + this.$route.params.uuid,
          '3': API.form_table.downDimeExcl + '?tableUUID=' + this.$route.params.uuid,
          '4': API.form_table.downModelExcl + '?tableUUID=' + this.$route.params.uuid
        }
        axios.get(api[val]).then(res => {
          const result = res.data
          if (result.__statusCode === '0') {
            alert(result.__errorMessage)
          } else {
            window.location.href = api[val]
          }
        }).catch(error => {
          console.error(error)
        })
      }
      this.$emit('excelDown')
    },
    leftClick () {
      if (this.left < 0) {
        if (window.$('#scrollBox').width() <= 1040) {
          this.left = this.left + 160
          window.$('#scrollBox').css('transform', 'translateX(' + this.left + 'px)')
        }
      }
    },
    rightClick () {
      if (window.$('#scrollBox').width() <= 1040) {
        if (-this.left < (window.$('#scrollBox').width() - window.$('#scrollParent').width())) {
          this.left = this.left - 160
          window.$('#scrollBox').css('transform', 'translateX(' + this.left + 'px)')
        }
      }
    },
    resize () {
      if (window.$('#scrollParent').width() <= 1040) {
        this.addPd = true
        this.isScrollShow = true
      } else {
        this.isScrollShow = false
        this.addPd = false
      }
    },
    // 设置对其方式
    adjustAlign (direction) {
      this.$emit('adjustAlign', direction)
    },
    onTextSearch () {
      this.$emit('textSearch', this.searchText)
    }
  }
}
</script>

<style lang="scss" scoped>
.component-toolbar {
  width: 100%;
  height: 100%;

  .toolbar-search {
    width: 200px;
    margin-left: 10px;
  }
  .scroll-box {
    width: 100%;
    height: 100%;
    min-width: 1000px;
    transition: all .5s linear;
  }
  .left {
    position: absolute;
    left: -1px;
    top: 0;
    z-index: 100;
  }
  .right {
    position: absolute;
    right: -1px;
    top: 0;
    z-index: 100;
  }
  .left,.right {
    display: inline-block;
    height: 37px;
    width: 20px;
    line-height: 36px;
    cursor: pointer;
    background-color: #fff;
  }
  .addLeft {
    transform: translateX(-80px);
  }
  .addPd {
    padding-left: 20px;
  }
}
</style>
