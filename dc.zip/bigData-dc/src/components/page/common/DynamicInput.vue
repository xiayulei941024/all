<template>
  <div class="component-dynamic-input">
    <!-- 日期时间选择器 -->
    <div v-if="controlType === 'datetime'">
      <el-date-picker
        type="datetime"
        v-model="controlModel.value">
      </el-date-picker>
    </div>
    <div v-else>
      <!-- 字符输入框 TEXT TEXTAREA PASSWORD-->
      <el-input :type="controlType" :name="controlModel.name" v-model="controlModel.name"></el-input>
    </div>
  </div>
</template>

<style lang="scss" scoped>
  .component-dynamic-input {
    width: 100%;
    height: 100%;
  }
</style>

<script>
/*
 * "PASSWORD",
    "TEXT",
    "HIDDEN",
    "TEXTAREA",
    "CHECKBOX",
    "RADIO",
    "SELECT",
    "FILE"
*/
export default {
  name: 'dynamicInput',
  props: {
    // 控件类型
    controlType: {
      type: String,
      default: 'text'
    },
    // 控件模型
    controlModel: {
      type: Object,
      default: function () {
        return {
          name: '',
          value: ''
        }
      }
    }
  }
}
</script>




