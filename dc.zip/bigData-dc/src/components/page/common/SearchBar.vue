<template>
  <div class="component-searchbar">
    <el-row>
      <el-col style="width: 97px;" :xs="{span: 6}"  :sm="{span: 6}" :md="{span: 3}" :lg="{span: 3}">
        <el-button @click="search" :disabled="searchAble" icon="search" type="primary"> {{$t('common.searchTextTitle')}}</el-button>
      </el-col>
      <el-col v-if="setSelTabelColumn.length > 0" :xs="{span: 18}"  :sm="{span: 18}" :md="{span: 21}" :lg="{span: 21}">
        <el-form :inline="true" id="form1" :model="formParams_" class="demo-form-inline" label-width="80px">
          <el-row>
            <el-col :xs="{span: 24}" :ms="{span: 12}" :md="{span: 12}" :lg="{span: 8}" v-for="(item,index) in setSelTabelColumn" :key="index">
              <el-form-item  class="label-row">
                <div slot="label">
                  <el-tooltip class="item" effect="dark" :content="item.formName" placement="top">
                    <span>{{item.formName}}</span>
                  </el-tooltip>
                </div>
                <el-date-picker
                  v-if="item.controlsType === 'TIMESTAMP' && !item.dimension"
                  v-model="formParams_[item.colName]"
                  type="datetime"
                  @change="formatDate"
                  @blur="changeCurrentDate(item.colName)"
                  :placeholder="$t('common.checkDate')"
                  format="yyyy-MM-dd HH:mm:ss"
                  style="display: inline-block;max-width:168px">
                </el-date-picker>
                <div v-else-if="item.dimension" @click="focus(item.uuid)">
                  <el-select style="display: none" v-model="formParams_[item.colName]"  filterable placeholder="请选择" :disabled="true">
                    <el-option
                      :value="formParams_[item.colName]">
                    </el-option>
                  </el-select>
                  <el-autocomplete
                    v-model="searchData[item.colName]"
                    :fetch-suggestions="querySearchAsync"
                    placeholder="$t('common.searchInfo')"
                    @select="handleSelect"
                  ></el-autocomplete>
                </div>
                <el-input width="130" v-else :type="upCaselowCase(item.controlsType)" v-model="formParams_[item.colName]"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-col>
      <el-col v-if="setSelTabelColumn.length === 0" :span="18">
        <div class="tips">
          <span > {{$t('common.searchText')}}</span>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'SearchBar',
  data () {
    return {
      formLabelWidth: '120px',
      formParams_: {},
      colDtos: [],
      searchData: {},
      currentColId: '',
      currentSelDate: '',
      searchAble: true
    }
  },
  props: {
  },
  computed: {
    setSelTabelColumn () {
      return this.$store.state.formTable.setSelTabelColumn
    },
    formSearchParams () {
      return this.$store.getters['formTable/tableSearchfrom']
    },
    formParams () {
      return this.$store.getters['formTable/accessTableHeader']
    },
    routeUuid () {
      return this.$route.params.uuid
    },
    pagenum () {
      return this.$store.state.formTable.pagenum
    },
    rownum () {
      return this.$store.state.formTable.rownum
    }
  },
  watch: {
    routeUuid () {
      this.selValue = []
      this.searchData = {}
    },
    formParams (newVel) {
      console.log('watch', newVel)
      this.formParams_ = newVel
    },
    setSelTabelColumn (newVal) {
      console.log('changed', newVal)
      this.searchAble = newVal.length < 1
    }
  },
  methods: {
    setColumn () {
      this.$emit('setColumn')
    },
    upCaselowCase (val) {
      return val.toLowerCase()
    },
    formatDate (val) {
      this.formParams_[this.currentSelDate] = val
    },
    changeCurrentDate (val) {
      console.log('val', val)
      this.currentSelDate = val
    },
    querySearchAsync (queryString, cb, colname) {
      if (!queryString) {
        // 清空搜索字段
        this.setSelTabelColumn.forEach(el => {
          if (el.uuid === this.currentColId) {
            this.formParams_[el.colName] = ''
            return
          }
        })
        return cb([])
      }
      setTimeout(() => {
        this.$store.dispatch('formTable/searchDimeList', {collection: queryString, colId: this.currentColId}).then((res) => {
          console.log(res)
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.restaurants = res.data.data
          }
          cb(this.restaurants)
        })
      }, 300)
    },
    handleSelect (item) {
      console.log(item)
      console.log(this.searchData)
      // 关联查询结果
      for (let i in this.searchData) {
        if (this.searchData[i] === item.value) {
          this.formParams_[i] = item.key
          return
        }
      }
    },
    focus (val) {
      console.log('focus', val)
      this.currentColId = val
    },
    search () {
      let params = {}
      params.tableUUID = this.routeUuid
      let colDtos = []
      let selCol = this.setSelTabelColumn.map(el => {
        return el.uuid
      })
      console.log('selCol', selCol)
      for (let item of selCol) {
        colDtos.push(this.formSearchParams.filter((val) => {
          return val.uuid === item
        })[0])
      }
      console.log('colDotos', colDtos)
      // 赋值
      colDtos.map((cal) => {
        cal.formValue = this.formParams_[cal.colName] || ''
      })
      // 发送给父层，用来缓存搜索结果
      this.$emit('searchCache', colDtos)
      this.$store.commit('formTable/setPagenum', 1)
      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, colDtos: colDtos, pagenum: this.pagenum, rownum: this.rownum}).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          setTimeout(() => {
            this.dialogFormVisible = false
          }, 500)
        } else {
        }
      })
    }
  },
  created () {
    this.formParams_ = {}
    this.formParams_ = this.formParams
  }
}
</script>

<style lang="scss" >
.component-searchbar {
  position: relative;
  padding-top: 10px;
  #form1{
    .label-row {
      margin-bottom: 10px;
      .el-form-item__label {
        margin-right: 10px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }
  .tips{
    padding: 10px;
  }
}

</style>


