<template>
  <!-- 数据源管理 -->
  <div class="component-dataSource-admin" id="DataSourceAdminId" v-loading="loading"
       target="#DataSourceAdminId"
       element-loading-text="拼命加载中">
    <!-- <el-select v-model="dbType" placeholder="请选择数据源类型">
      <el-option v-for="item in dbTypeList"
        :key="item"
        :label="item"
        :value="item">
      </el-option>
    </el-select> -->
    <el-tree
      :data="treeData"
      node-key="id"
      :default-expanded-keys="[-1]"
      :render-content="renderContent">
    </el-tree>
  </div>
</template>

<script>
import axios from 'axios'
import API from '../../assets/js/api'
import qs from 'qs'
// let id = 1000
export default {
  name: 'dataSourceAdmin',
  data () {
    let data = {}
    data.dbType = ''
    data.treeStore = ''
    data.treeData = [
      {
        id: -1,
        label: '数据源目录',
        children: []
      }
    ]
    data.loading = true
    data.roleId = false
    return data
  },
  computed: {
    dbTypeList () {
      return this.$store.state.dataSource.dbTypeList
    },
    dataSoureList () {
      return this.$store.state.dataSource.list
    },
    tableList () {
      return this.$store.state.table.list
    }
  },
  created () {
    // 获取数据源
    this.$store.dispatch('dataSource/getList')
    // 获取表
    this.$store.dispatch('table/getList')
    // 获取数据库类型列表
    this.$store.dispatch('dataSource/getDbTypeList')
//      // 获取表字段类型
//      this.$store.dispatch('table/getTableColumnType', 'MYSQL')
    // 获取表字段控件类型
    this.$store.dispatch('table/getControlsTypes')
    // 获取表正则list
    this.$store.dispatch('table/getRegularType')
    // 获取用户角色
    this.$store.dispatch('user/getUserRoles').then((res) => {
      console.log(JSON.parse(res), JSON.parse(res).length, 'res===========获取用户角色')
      this.roleId = !!(JSON.parse(res).length > 0 && JSON.parse(res).find(el => el === '1'))
    })
  },
  watch: {
    dbTypeList () {
      this.dbType = this.dbTypeList[0]
    },
    dbType () {
      // 获取数据源
      this.$store.dispatch('dataSource/getList')
    },
    dataSoureList () {
      this.loading = true
      this.accessTreeData()
      this.loading = false
    },
    tableList (newVal) {
      console.log('tableList change')
      // for (let source of this.treeData[0].children) {
      //   source.children = newVal.filter(node => {
      //     node.label = node.tableName
      //     node.id = node.uuid
      //     return node.dbId === source.uuid
      //   })
      this.loading = true
      this.accessTableData()
      this.loading = false
    }
  },
  methods: {
    accessTableData () {
      for (let source of this.treeData[0].children) {
        source.children = this.tableList.filter(node => {
          node.label = node.tableComment + ' (' + node.tableName + ')' || node.tableName
          node.id = node.uuid
          return node.dbId === source.uuid
        })
      }
    },
    accessTreeData () {
      this.treeData[0].children = []
      for (let dataSource of this.dataSoureList) {
        this.treeData[0].children.push({
          id: dataSource.uuid,
          uuid: dataSource.uuid,
          dbType: dataSource.dbType,
          label: dataSource.dsrcName + ' (' + dataSource.dsrcCode + ')' || dataSource.dsrcCode,
          children: []
        })
        // this.$store.dispatch('table/getList', dataSource.uuid)
      }
      this.accessTableData()
    },
    append (store, data, node) {
      console.log(store)
      console.log(data)
      console.log(node)
      this.treeStore = store
      if (node.level === 1) {
        // 新增数据源
        this.eventHub.$emit('showDataSourceDialog')
      } else if (node.level === 2) {
        // 新增表
        // this.$store.commit('updateIsShowTableDialog', true)
        // this.$store.commit('updateIsShowTableDialog', true)
        this.eventHub.$emit('showTableDialog', {type: 'add', id: data.uuid, dbType: data.dbType})
      }
      // store.append({ id: id++, label: 'testtest', children: [] }, data)
    },
    remove (store, data, node) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        console.log(data)
        console.log(node)
        let api = API.dataSource.delete
        let action = 'dataSource/getList'
        if (node.level === 2) {
          api = API.dataSource.delete
          action = 'dataSource/getList'
        } else if (node.level === 3) {
          api = API.table.delete
          action = 'table/getList'
        }
        axios.post(api, qs.stringify({ id: data.uuid })).then(response => {
          const result = response.data
          if (result.__statusCode === '1') {
            this.$notify({
              title: '操作结果',
              message: result.data,
              type: 'success',
              duration: '5000'
            })
            this.$store.dispatch(action)
          } else {
            this.$notify({
              title: '操作结果',
              message: result.__errorMessage,
              type: 'error',
              duration: '5000'
            })
          }
        }).catch(error => {
          console.error(error)
        })
      })
      // store.remove(data)
    },
    edit (store, data, node) {
      console.log(node)
      if (node.level === 2) {
        // 编辑数据源
        this.eventHub.$emit('showEditDataSourceDialog', data.uuid)
      } else if (node.level === 3) {
        console.log('showTableDialog')
        // 编辑表
        this.eventHub.$emit('showTableDialog', {type: 'edit', id: data.uuid, dbType: node.parent.data.dbType})
        // console.log(store)
        // console.log(data)
        // console.log('edit')
      }
    },
    hoverNode (store, data) {
      console.log(store)
      console.log(data)
      console.log('hover')
    },
    renderContent (h, { node, data, store }) {
//        console.log('成功', data)
      // console.log(node)
      // console.log(data)
      // console.log(store)
      if (node.level === 1) {
        if (this.roleId) {
          return (
            <span>
                <span>
                  <span>{node.label}</span>
                </span>
                <span style="margin-left:10px;">
                  <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>新增数据源</el-button>
                </span>
              </span>
          )
        } else {
          return (
            <span>
                <span>
                  <span>{node.label}</span>
                </span>
              </span>
          )
        }
      }
      if (node.level === 3) {
        if (this.roleId) {
          return (
            <span>
                <span>
                  <i class="fa fa-table"></i>&nbsp;
                  <span>{node.label}</span>
                </span>
                <span style="margin-left:10px;">
                  <el-button-group>
                    <el-button type="primary" size="mini" on-click={ () => this.edit(store, data, node) }>编辑</el-button>
                    <el-button type="primary" size="mini" on-click={ () => this.remove(store, data, node) }>删除</el-button>
                  </el-button-group>
                </span>
              </span>
          )
        } else {
          return (
            <span>
                <span>
                  <i class="fa fa-table"></i>&nbsp;
                  <span>{node.label}</span>
                </span>
                <span style="margin-left:10px;">
                  <el-button-group>
                    <el-button type="primary" size="mini" on-click={ () => this.edit(store, data, node) }>编辑</el-button>
                    <el-button type="primary" size="mini" on-click={ () => this.remove(store, data, node) }>删除</el-button>
                  </el-button-group>
                </span>
              </span>
          )
        }
      }
      if (this.roleId) {
        return (
          <span>
              <span>
                <i class="fa fa-database"></i>&nbsp;
                <span>{node.label}</span>
              </span>
              <span style="margin-left:10px;">
                <el-button-group>
                  <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>新增表</el-button>
                  <el-button type="primary" size="mini" on-click={ () => this.edit(store, data, node) }>编辑</el-button>
                  <el-button type="primary" size="mini" on-click={ () => this.remove(store, data, node) }>删除</el-button>
                </el-button-group>
              </span>
            </span>
        )
      } else {
        return (
          <span>
              <span>
                <i class="fa fa-database"></i>&nbsp;
                <span>{node.label}</span>
              </span>
              <span style="margin-left:10px;">
                <el-button-group>
                  <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>新增表</el-button>
                </el-button-group>
              </span>
            </span>
        )
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.component-dataSource-admin {
  width: 100%;
  height: 100%;
}
</style>


