<template>
  <div class="outSync-swaper"
       id="outSyncAdminId" v-loading="loading"
       target="#outSyncAdminId"
       element-loading-text="拼命加载中">
    <el-button @click="insertSync" type="primary" style="margin-bottom: 10px">同步</el-button>
    <el-input style="display: block; width: 100%;margin-bottom: 10px;"
      placeholder="输入关键字进行过滤"
      v-model="filterText">
    </el-input>
    <el-tree
      :data="tree"
      :props="defaultProps"
      :accordion="true"
      node-key="dbid"
      show-checkbox
      :render-content="renderContent"
      :expand-on-click-node="true"
      :default-expanded-keys="defaultExpandedKeys"
      :filter-node-method="filterNode"
      ref="outSyncAdmin"
      @check-change="handleCheckChange">
    </el-tree>
  </div>
</template>
<script>
    import lodash from 'lodash'

    export default {
      name: 'outSyncAdmin',
      data () {
        return {
          defaultProps: {
            children: 'children',
            label: 'name_des'
          },
          isDimension: {},
          searchDate: {},
          tree: [{'name_des': '根目录', dbid: -1, children: []}],
          filterText: '',
          loading: true,
          defaultExpandedKeys: [-1]
        }
      },
      computed: {
      },
      watch: {
        filterText (val) {
          this.$refs.outSyncAdmin.filter(val)
        }
      },
      methods: {
        handleCheckChange (data, checked, indeterminate) {
          console.log(data, checked, indeterminate)
        },
        handleNodeClick (data) {
          console.log(data)
        },
        insertSync () { // 同步
          let CheckedNodesArray = this.$refs.outSyncAdmin.getCheckedNodes()
          if (CheckedNodesArray.length === 0) {
            return this.$message({
              type: 'info',
              message: '请选择!'
            })
          }
          let currentDataSource = []
          let params = []
          CheckedNodesArray.map((item) => {
            if (item.type === 'table') {
              currentDataSource.push(item.parentid)
              params.push({
                colName: item.name,
                dimensionTable: this.isDimension[item.dbid],
                tableComment: item.name_des
              })
            }
          })
          let lodashList = lodash.uniq(currentDataSource)
          if (lodashList.length > 1) {
            return this.$message({
              type: 'info',
              message: '暂不支持同步多个数据源的表!'
            })
          } else if (lodashList.length === 0) {
            return this.$message({
              type: 'info',
              message: '请选择表!'
            })
          } else {
            this.$store.dispatch('outSync/insetSyncDataSource', {tableRestDTOs: params, dbId: lodashList[0].slice(11)}).then((res) => {
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                this.loadData()
                this.$message({
                  type: 'success',
                  message: '同步成功!'
                })
              } else {
                alert(res.data.__errorMessage)
                return
              }
            })
          }
        },
        append (store, data, node) {
          console.log('node', node)
          console.log('data', data)
          this.loading = true
          node.childNodes = []
          this.$store.dispatch('outSync/getOutSyncList', {dbId: node.data.dbid, tableName: this.searchDate[data.dbid]}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              console.log('outSyncTable', JSON.parse(res.data.data))
              this.loading = false
              this.defaultExpandedKeys = [-1, data.dbid]
              if (JSON.parse(res.data.data).length !== 0) {
                for (let item of JSON.parse(res.data.data)) {
                  item.children = []
//                store.append({ dbid: item.name + item.dbid, type: item.type, id: item.dbid, name_des: item.name_des, children: [] }, data)
                  item.dbid = item.name + item.dbid
                  store.append(item, data)
                }
              } else {
                return this.$message({
                  type: 'info',
                  message: '该数据源暂无表'
                })
              }
            } else {
              this.loading = false
              return this.$message({
                type: 'info',
                message: '获取该数据源表失败:' + res.data.message + '!'
              })
            }
          })
        },
        renderContent (h, { node, data, store }) {
          if (node.level === 1) {
            return (
              <span>
              <span>
              <span>{node.label}</span>
            </span>
            </span>)
          }
          if (node.level === 2) {
            return (
              <span>
                <span>
                  <span>{node.label}</span>
                </span>
                <span style="float: right; margin-right:100px; clear:both">
                  <el-input class="my-input" v-model={this.searchDate[data.dbid]} placeholder="搜索内容"></el-input>
                  <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>搜索表</el-button>
                </span>
              </span>
            )
          }
          if (node.level === 3) {
            return (
              <span>
                <span>
                  <span>{node.label}</span>
                </span>
                <span style="float: right; margin-right:100px; clear:both">
                  <el-checkbox v-model={this.isDimension[data.dbid]}>维表</el-checkbox>
                </span>
              </span>
            )
          }
        },
        filterNode (value, data) {
          if (!value) return true
          return data.name_des.indexOf(value) !== -1
        },
        loadData () {
          this.loading = true
          this.$store.dispatch('outSync/getOutSyncList', {}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.tree[0].children = JSON.parse(res.data.data)
              this.loading = false
            } else {
              this.loading = false
              return this.$message({
                type: 'info',
                message: '获取数据源列表失败:' + res.data.message + '!'
              })
            }
          })
        }
      },
      created () {
        this.loadData()
      }
    }
</script>
<style lang="scss">
  .outSync-swaper {
    box-sizing: border-box;
    /*padding-bottom: 44px;*/
  }
  .my-input {
    width: 150px;
    input {
      height: 30px;
    }
  }
  .el-button--mini {
    padding: 7px;
    margin-left: 5px;
  }
</style>
