<template>
  <div class="component-table-row-detail">
    <el-dialog slot="tips" trigger="manual" :visible.sync="dialogVisible"  ref="rowDetailDialog" width="40%" title="Row details">
        <el-table
          :data="currentRowDetail"
          :show-header="false"
          min-width="500px"
          size="mini"
          stripe
          id="popover">
          <el-table-column
            show-overflow-tooltip
            prop="colName"
            class-name="tips-cell tips-cell-label">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="value"
            class-name="tips-cell">
          </el-table-column>
        </el-table>
      </el-dialog>
  </div>
</template>
<script>
export default {
  name: 'rowDetailDialog',
  data () {
    return {
      dialogVisible: false,
      currentRowDetail: []
    }
  },
  created () {
    this.eventHub.$on('showRowDetailDialog', (currentRowDetail) => {
      console.log('row', currentRowDetail)
      this.currentRowDetail = currentRowDetail
      this.dialogVisible = true
    })
  }
}
</script>
<style lang="scss">
  .component-table-row-detail {
    .el-dialog__header .el-dialog__title {
      font-size: 18px;
      color: #7b7a7a;
    }
    .el-table__row {
      height: 34px;
      .tips-cell {
        height: 34px;
        .cell {
          padding-left: 8px;
          padding-right: 8px;
        }
      }
      .tips-cell-label {
        .cell {
          font-weight: bold;
        }
      }
    }
  }
</style>

