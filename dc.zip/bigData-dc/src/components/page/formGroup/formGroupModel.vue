<template>
  <div>
    <el-dialog title="组添加" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="分组名称" label-width="120px" v-if="type !== 'fromGroup'">
          <el-input v-model="form.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="父级组别" label-width="120px" v-if="type === 'fromGroup'">
          <el-select v-model="form.optionId" placeholder="请选择数据库类型">
            <el-option v-for="(item, i) in groupList" :label="item.name" :value="item.id" :key="i"></el-option>
          </el-select>
        </el-form-item>
        <!-- <el-form-item label="排序" label-width="120px" v-if="type !== 'fromGroup'">
          <el-input v-model="form.sort" auto-complete="off"></el-input>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="onSubmit">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import API from '../../../assets/js/api'
  export default {
    name: '',
    data () {
      return {
        form: {
          name: '',
          sort: '',
          optionId: ''
        },
        dialogFormVisible: false,
        groupList: [],
        type: '',
        node: {}
      }
    },
    methods: {
      onSubmit () {
        let pathParams = {}
        if (this.type === 'append') {
          pathParams = {path: API.formGroup.insert, params: Object.assign({}, this.form, {parentId: this.node.uuid})}
        } else if (this.type === 'edit') {
          pathParams = {path: API.formGroup.update, params: Object.assign({}, this.form, {parentId: this.node.parentid, uuid: this.node.uuid})}
        } else {
          pathParams = {path: `${API.formGroup.formForGroup}?optionId=${this.form.optionId}&tableId=${this.node.uuid}`, params: {optionId: this.form.optionId, tableId: this.node.uuid}}
        }
        this.$store.dispatch('formGroup/operation', pathParams).then(res => {
          if (res.data.__statusCode === '1') {
            this.$message({
              type: 'info',
              message: '保存成功'
            })
            this.dialogFormVisible = false
            this.$store.dispatch('formGroup/getFormList')
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      }
    },
    mounted () {
      this.eventHub.$on('formGroupDialog', ({type, node}) => {
        this.dialogFormVisible = true
        this.type = type
        if (type === 'edit') {
          this.form = node
        } else {
          this.form = {
            name: '',
            sort: '',
            optionId: ''
          }
        }
        if (type === 'fromGroup') {
          this.$store.dispatch('formGroup/operation', {path: `${API.formGroup.getFormGroupOptions}?tableId=${node.uuid}`, params: {tableId: node.uuid}}).then(res => {
            if (res.data.__statusCode === '1') {
              this.groupList = res.data.data
            } else {
              this.$message({
                type: 'info',
                message: res.data.__errorMessage
              })
            }
          })
        }
        this.node = node
      })
    }
  }
</script>
