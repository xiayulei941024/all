<template>
  <!-- 数据源管理 -->
  <div class="component-form-group-admin" id="formGroupAdminId" v-loading="loading"
       target="#formGroupAdminId"
       element-loading-text="拼命加载中">
    <el-tree
      :data="treeData"
      node-key="id"
      :props="props"
      :render-content="renderContent">
    </el-tree>
  </div>
</template>

<script>
  import axios from 'axios'
  import API from '../../../assets/js/api'
  import qs from 'qs'
  // let id = 1000
  export default {
    name: 'formGroupAdmin',
    data () {
      let data = {}
      data.treeData = [
        {
          id: -1,
          label: '数据源目录',
          children: []
        }
      ]
      data.loading = true
      data.props = {
        label: 'name',
        children: 'submenuList'
      }
      data.type = ''
      data.node = {}
      return data
    },
    computed: {
      list () {
        return this.$store.state.formGroup.list
      }
    },
    created () {
      this.$store.dispatch('formGroup/getFormList')
    },
    watch: {
      list (newVal) {
        this.loading = true
        this.accessList(newVal)
        this.loading = false
      }
    },
    methods: {
      accessList (treeList, root) {
        if (!treeList) {
          return
        }
        console.log(treeList)
        // 找出树形数组中的根节点
        let roots = treeList.filter(node => {
          return node.parentid === '0'
        })

        findChildren(roots, treeList)

        // 节点组从数组中寻找自己的子节点
        function findChildren (nodes, list) {
          for (let node of nodes) {
            node.submenuList = list.filter(item => {
              item.name = item.name_des || item.name
              return item.parentid === node.uuid
            })
            // 如果节点找到子节点继续递归寻找
            if (node.submenuList.length > 0) {
              findChildren(node.submenuList, list)
            }
          }
        }
        this.treeData = roots
      },
      append (store, data, node) {
        this.eventHub.$emit('formGroupDialog', {type: 'append', node: data})
      },
      remove (store, data, node) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let api = API.formGroup.delete
          axios.post(api, qs.stringify({ uuid: data.uuid })).then(response => {
            const result = response.data
            if (result.__statusCode === '1') {
              this.$notify({
                title: '操作结果',
                message: result.data,
                type: 'success',
                duration: '5000'
              })
              this.$store.dispatch('formGroup/getFormList')
            } else {
              this.$notify({
                title: '操作结果',
                message: result.__errorMessage,
                type: 'error',
                duration: '5000'
              })
            }
          }).catch(error => {
            console.error(error)
          })
        })
        // store.remove(data)
      },
      edit (store, data, node) {
        this.eventHub.$emit('formGroupDialog', {type: 'edit', node: data})
      },
      fromGroup (store, data, node) {
        this.eventHub.$emit('formGroupDialog', {type: 'fromGroup', node: data})
      },
      hoverNode (store, data) {
        console.log(store)
        console.log(data)
        console.log('hover')
      },
      renderContent (h, { node, data, store }) {
//        console.log('成功', data)
        // console.log(node)
        // console.log(data)
        // console.log(store)
        if (data.type === 'datasource') {
          return (
            <span>
            <span>
            <i class="fa fa-database"></i>&nbsp;
            <span>{node.label}</span>
          </span>
          <span style="margin-left:10px;">
            <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>添加组</el-button>
          </span>
          </span>)
        }
        if (data.type === 'group') {
          return (
            <span>
            <span>
            <i class="fa fa-folder"></i>&nbsp;
        <span>{node.label}</span>
          </span>
          <span style="margin-left:10px;">
            <el-button-group>
            <el-button type="primary" size="mini" on-click={ () => this.append(store, data, node) }>添加组</el-button>
            <el-button type="primary" size="mini" on-click={ () => this.edit(store, data, node) }>编辑</el-button>
          <el-button type="primary" size="mini" on-click={ () => this.remove(store, data, node) }>删除</el-button>
          </el-button-group>
          </span>
          </span>)
        }
        if (data.type === 'table') {
          return (
            <span>
            <span>
            <i class="fa fa-table"></i>&nbsp;
        <span>{node.label}</span>
          </span>
          <span style="margin-left:10px;">
            <el-button type="primary" size="mini" on-click={ () => this.fromGroup(store, data, node) }>分配组</el-button>
          </span>
          </span>)
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .component-form-group-admin {
    width: 100%;
    height: 100%;
  }
</style>
