<template>
  <el-dialog :title="form_title"  size="large" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
    <el-form :model="form" ref="userFormModel" :rules="rules">
      <el-form-item label="编码" prop="roleCode" :label-width="formLabelWidth">
        <el-input :disabled="isDisabled" v-model="form.roleCode" auto-complete="off"></el-input>
        <el-button :disabled="isDisabled" type="primary" @click="onSearch">查询</el-button>
      </el-form-item>
      <el-form-item label="角色名" prop="roleName" :label-width="formLabelWidth">
        <el-input v-model="form.roleName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="描述" prop="roleDesc" :label-width="formLabelWidth">
        <el-input type="textarea" v-model="form.roleDesc" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="关联用户" :label-width="formLabelWidth">
        <el-input :disabled="true" type="textarea" v-model="addUserList.userName" auto-complete="off"></el-input>
        <el-button  type="primary" @click="onSel">选择</el-button>
      </el-form-item>
      <el-form-item label="关联表单" :label-width="formLabelWidth">
        <el-tree
          :data="treeData"
          :props="defaultProps"
          :render-content="renderContent"
          @check-change="handleNodeClickChange"
          :default-checked-keys="defaultCheckedKeys"
          node-key="uuid"
          show-checkbox=""
          ref="tree"
          :disabled="!isAdminRole">
        </el-tree>
      </el-form-item>
      <el-form-item label="关联菜单" :label-width="formLabelWidth">
        <el-tree
          :data="treeData2"
          :props="defaultProps2"
          @check-change="handleNodeClickChange2"
          :default-checked-keys="defaultCheckedKeys2"
          node-key="uuid"
          show-checkbox
          ref="tree2"
          :disabled="!isAdminRole">
        </el-tree>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="commitAllForm('userFormModel')" :disabled="isCommit">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getTree } from '../../../assets/js/util'
  export default {
    name: 'RoleTableModel',
    data () {
      return {
        userRoleId: '',
        isAdminRole: false,
        dialogFormVisible: false,
        isDisabled: false,
        isCommit: true,
        form: {
          roleCode: '',
          roleDesc: '',
          roleName: '',
          userIds: [],
          uuid: ''
        },
        formLabelWidth: '200px',
        rules: {
          roleCode: [
            { required: true, message: '请输入活动名称', trigger: 'blur' }
          ],
          roleDesc: [
            { message: '内容不能为空', trigger: 'blur' }
          ],
          roleName: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ]
        },
        FORM_STATE: 0, // 表单状态 0提交,1修改,2删除,默认为0
        form_title: '新增权限',
        defaultProps: {
          children: 'children',
          label: 'name_des'
        },
        defaultProps2: {
          children: 'children',
          label: 'name'
        }
      }
    },
    computed: {
      userList () {
        console.log(this.$store.state.role.list)
        return this.$store.state.role.list
      },
      columns () {
        console.log(this.$store.state.role.columns)
        return this.$store.state.role.columns
      },
      addUserList () {
        return this.filterQueUserList(this.$store.state.role.currentRoleUser)
      },
      treeData () {
        return getTree({treeList: this.$store.state.role.formTreeList})
      },
      treeData2 () {
        return getTree({treeList: this.$store.state.role.formTreeList2})
      },
      defaultCheckedKeys () {
        return this.$store.state.role.formTreeCheckedList
      },
      defaultCheckedKeys2 () {
        return this.$store.state.role.formTreeCheckedList2
      }
    },
    methods: {
      commitAllForm (userFormModel) { // 根据当前状态选择提交方式
        this.$refs[userFormModel].validate((valid) => {
          if (valid) {
            this.FORM_STATE === 1 ? this.commitFormChange() : this.commitForm()
          } else {
            return false
          }
        })
      },
      commitForm () { // 提交表单
        let params = this.form
       /* params.formids = this.defaultCheckedKeys.map((item) => {
          return item.slice(6)
        }) */
        params.forms = []
        this.$refs.tree.getCheckedNodes().map(item => {
          if (item.type === 'table') {
            params.forms.push({formId: item.uuid.slice(6), jurisdiction: item.jurisdiction})
          }
        })
        console.log('1122', this.$refs.tree.getCheckedNodes())
        params.menuIds = this.defaultCheckedKeys2
        this.$store.dispatch('role/setRoleTableRow', params).then((res) => {
          console.log('roleForm', res)
          if (res.status === 200 && res.data && res.data.__statusCode === '1') {
            this.$store.dispatch('role/getRoleList')
            this.$store.dispatch('menu/getFormList_for_user')
            this.$store.dispatch('menu/getMenuList_for_user')
            this.$message({
              type: 'success',
              message: '提交成功!'
            })
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.$message({
              type: 'info',
              message: '提交失败!'
            })
          }
        })
      },
      commitFormChange () { // 修改表单
        let params = this.form
        /* params.formids = this.defaultCheckedKeys.map((item) => {
          return item.slice(6)
        }) */
        params.forms = []
        this.$refs.tree.getCheckedNodes().map(item => {
          if (item.type === 'table') {
            params.forms.push({formId: item.uuid.slice(6), jurisdiction: item.jurisdiction})
          }
        })
        params.menuIds = this.defaultCheckedKeys2
        this.$store.dispatch('role/updateRoleTableRow', params).then((res) => {
          console.log('roleForm', res)
          if (res.status === 200 && res.data && res.data.__statusCode === '1') {
            this.$store.dispatch('role/getRoleList')
            this.$store.dispatch('menu/getFormList_for_user')
            this.$store.dispatch('menu/getMenuList_for_user')
            this.$message({
              type: 'success',
              message: '提交成功!'
            })
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.$message({
              type: 'info',
              message: '提交失败!'
            })
          }
        })
      },
      changeTableRow (val) { // 修改行 只支持单行修改
        console.log(11, val)
        this.form = {
          roleCode: val.roleCode,
          roleDesc: val.roleDesc,
          roleName: val.roleName,
          uuid: val.uuid
        }
      },
      onSearch () {
        let params = {}
        params.roleCode = this.form.roleCode
        if (!this.form.roleCode) {
          this.$message({
            type: 'info',
            message: '请输入编码'
          })
          return
        }
        this.$store.dispatch('role/searchCode', params).then((res) => {
          console.log('code', res.data.data)
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            if (res.data.data) {
              this.$message({
                type: 'info',
                message: '编码已存在'
              })
            } else {
              this.isCommit = false
              this.$message({
                type: 'info',
                message: '编码可用'
              })
            }
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      onSel () {
        this.eventHub.$emit('showRoleSelUserModel')
      },
      filterQueUserList (val) { // 加载用户
        let params = {
          userName: '',
          userIds: []
        }
        for (let item of val) {
          params.userName = params.userName + ' ' + item.userName
          params.userIds.push(item.uuid)
        }
        this.form.userIds = params.userIds
        return params
      },
      handleNodeClickChange (data, checked, inde) {
        console.log('handleNodeClickChange', this.isAdminRole, data, checked, inde)
        if (checked && data.type === 'table') {
          if (this.defaultCheckedKeys.indexOf(data.uuid) < 0) {
            this.defaultCheckedKeys.push(data.uuid)
          }
        } else if (!checked && data.type === 'table') {
          data.jurisdiction = false
          let i = this.defaultCheckedKeys.indexOf(data.uuid)
          if (i >= 0) {
            this.defaultCheckedKeys.splice(i, 1)
          }
        }
        this.$store.commit('role/updateFormTreeCheckedList', this.defaultCheckedKeys)
      },
      handleNodeClickChange2 (data, checked, inde) {
        console.log('handleNodeClickChange2', this.isAdminRole, data, checked, inde)
        if (checked && data.uuid) {
          if (this.defaultCheckedKeys2.indexOf(data.uuid) < 0) {
            this.defaultCheckedKeys2.push(data.uuid)
          }
        } else if (!checked && data.uuid) {
          let i = this.defaultCheckedKeys2.indexOf(data.uuid)
          if (i >= 0) {
            this.defaultCheckedKeys2.splice(i, 1)
          }
        }
        this.$store.commit('role/updateFormTreeCheckedList2', this.defaultCheckedKeys2)
      },
      renderContent (h, { node, data, store }) {
        console.log('renderContent', this.isAdminRole, node, data)
        const nameDes = data.name_des || ''
        const name = data.name || ''

        if (data.type === null) {
          return h('span', { domProps: { textContent: nameDes } })
        }
        if (data.type !== 'table') {
          return h('span', [
            h('span', { domProps: { textContent: `${nameDes} (${name})` } })
          ])
        } else {
          const checkboxDisabled = !this.isAdminRole || !node.checked
          return h('span', [
            h('span', { domProps: { textContent: `${nameDes} (${name})` } }),
            h('span', { style: 'float: right; margin-right: 100px; clear: both' }, [
              h('el-checkbox', {
                props: { value: data.jurisdiction, disabled: checkboxDisabled },
                on: { input: value => { data.jurisdiction = value } }
              }, '有无表单权限')
            ])
          ])
        }
      }
    },
    created () {
      this.eventHub.$on('showRoleDialog', () => { // 新增权限事件监听
        this.form_title = '新增角色'
        this.FORM_STATE = 0
        this.isDisabled = false
        this.isCommit = true
        this.dialogFormVisible = true
        this.form = {
          roleCode: '',
          roleDesc: '',
          roleName: '',
          uuid: '',
          userIds: []
        }
        // 清空权限用户列表
        this.$store.commit('role/upDateCurrentRoleUser', [])
        // 新增获取动态表单树
        this.$store.dispatch('role/getFormList', {roleId: ''})
        // 新增获取菜单树
        this.$store.dispatch('role/getMenuRoleTree', {roleId: ''})
      })
      // 修改权限事件监听
      this.eventHub.$on('showRoleDialogChange', (val) => {
        console.log('showRoleDialogChange val的值为：', val)
        this.form_title = '修改权限信息'
        this.dialogFormVisible = true
        this.FORM_STATE = 1
        this.isDisabled = true
        this.isCommit = false
        let params = val.uuid
        this.$store.dispatch('role/getRoleDetail', {uuid: params}).then((res) => {
          if (res.status === 200 && res.data && res.data.data) {
            this.changeTableRow(res.data.data)
          } else {
            this.$message({
              type: 'info',
              message: '获取权限详情失败'
            })
          }
        })
        // 获取权限用户
        this.$store.dispatch('role/addUserList', {roleId: val.uuid}).then((data) => {
          this.$store.commit('role/upDateCurrentRoleUser', data.resultSet)
        })
        // 根据权限获取动态表单树
        this.$store.dispatch('role/getFormList', {roleId: val.uuid})
        // 根据权限获取菜单树
        this.$store.dispatch('role/getMenuRoleTree', {roleId: val.uuid})
      })
//      this.$refs.tree.setCheckedKeys(this.defaultCheckedKeys)
    },
    mounted () {
      // 获取用户角色
      this.$store.dispatch('user/getUserRoles').then((res) => {
        console.log(JSON.parse(res), JSON.parse(res).length, 'res===========获取用户角色')
        this.isAdminRole = !!(JSON.parse(res).length > 0 && JSON.parse(res).find(el => el === '1'))
        this.userRoleId = JSON.parse(res).join(',')
        console.log('userRoleId', this.userRoleId)
      })
    }
  }
</script>

<style lang="scss" scoped>
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  .el-input {
    width: 300px;
  }
</style>
