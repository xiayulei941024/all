<template>
  <el-dialog title="关联用户" :visible.sync="dialogTableVisible">
    <div>
      <el-input v-model="form.userAccount" placeholder="请输入用户账号" auto-complete="off"></el-input>
      <el-button type="primary" @click="onSearch">查询</el-button>
      <el-button :disabled="isDisabled" type="primary" @click="onAdd">添加</el-button>
    </div>
    <el-table :data="userList"
              ref="multipleTable"
              border
              tooltip-effect="dark"
              @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column type="index" width="55"></el-table-column>
      <el-table-column property="userAccount" label="账号"></el-table-column>
      <el-table-column property="userName" label="姓名"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="small"
            type="danger"
            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-dialog>
</template>
<script>
    export default {
      name: 'RoleSelUserModel',
      data () {
        return {
          dialogTableVisible: false,
          multipleSelection: [],
          form: {
            userAccount: ''
          },
          isDisabled: true,
          isCommit: false
        }
      },
      computed: {
        userList () {
          return this.$store.state.role.addRoleUser
        },
        columns () {
          return this.$store.state.role.addRoleUserColumns
        },
        addUserList () {
          return this.$store.state.role.currentRoleUser
        }
      },
      created () {
        this.eventHub.$on('showRoleSelUserModel', (val) => {
          this.dialogTableVisible = true;
          // 获取当前角色对应的用户列表数据
          this.fetchUserListByUuid(val.uuid);
        });
        this.eventHub.$on('showRoleDialogChange', (val) => {
          // 获取权限用户
          this.$store.dispatch('role/addUserList', {roleId: val.uuid}).then((data) => {
            this.$store.commit('role/upDateCurrentRoleUser', data.resultSet);
          });
          // 再次获取更新后的用户列表数据
          this.fetchUserListByUuid(val.uuid);
        });
      },
      methods: {
        onSearch () {
          if (!this.form.userAccount) {
            this.$message({
              type: 'info',
              message: '请输入账号'
            })
            return
          }
          this.$store.dispatch('role/addUserList', {userAccount: this.form.userAccount}).then((data) => {
            if (data.totalRows) {
              this.isDisabled = false
              this.$store.commit('role/upDateAddRoleUser', data.resultSet)
              this.$store.commit('role/upDateAddRoleUserColums', data.metadata)
            } else {
              this.$message({
                type: 'info',
                message: '账号不存在'
              })
            }
          })
        },
        onAdd () {
//          if (!this.form.userAccount) {
//            this.$message({
//              type: 'info',
//              message: '请输入账号'
//            })
//            return
//          }
          if (!this.multipleSelection.length) {
            this.$message({
              type: 'info',
              message: '请选择用户'
            })
          } else {
            this.filterAddUserList(this.multipleSelection)
            setTimeout(() => {
              this.dialogTableVisible = false
            }, 800)
          }
        },
        handleSelectionChange (val) {
          this.multipleSelection = val
        },
        filterAddUserList (val) {
          for (let item of val) {
            if (val.length === 0) return
            for (let i of this.addUserList) {
              if (i.uuid === item.uuid) {
                this.$message({
                  type: 'info',
                  message: item.userName + '已添加'
                })
                return
              }
            }
          }
          this.$store.commit('role/upDateCurrentRoleUser', this.addUserList.concat(val))
        },
        handleDelete (index, row) {
          console.log(row)
          let length = this.addUserList.length
          if (length === 0) return
          for (let i = 0; i < length; i++) {
            if (this.addUserList[i].uuid === row.uuid) {
              this.addUserList.splice(i, 1)
              this.$store.commit('role/upDateCurrentRoleUser', this.addUserList)
              break
            }
          }
          this.dialogTableVisible = false
        },
        fetchUserListByUuid (uuid) {
          this.$store.dispatch('role/addUserList', {roleId: uuid}).then((data) => {
            if (data.totalRows) {
              this.isDisabled = false;
              this.$store.commit('role/upDateAddRoleUser', data.resultSet);
              this.$store.commit('role/upDateAddRoleUserColums', data.metadata);
            } else {
              this.$message({
                type: 'info',
                message: '账号不存在'
              });
            }
          });
        }
      }
    }
</script>
<style scoped>
  .el-input {
    width: 30%;
  }
</style>
