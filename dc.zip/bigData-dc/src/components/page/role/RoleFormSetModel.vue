<!--表单内容权限设置-->
<template>
  <el-dialog title="表单权限设置" size="large" :visible.sync="showRoleFormSetModel">
    <el-row>
      <el-col :span="12">
        <el-tree
          :accordion="true"
          :data="treeData"
          :props="defaultProps"
          node-key="uuid"
          :show-checkbox="false"
          :render-content="renderContent"
          ref="tree">
        </el-tree>
        <el-transfer
          v-if="!isDemension"
          v-model="selValue"
          :props="{key: 'uuid',label: 'formName'}"
          :data="tableHeader">
        </el-transfer>
      </el-col>
      <el-col :offset="1" :span="11" v-if="!isDemension">
        <el-form :model="formParams_">
          <el-row>
            <el-col v-show="matchUuidSearch(item.uuid)" :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 24}" :lg="{span: 24}" v-for="(item,index) in tableHeader" :key="index">
              <div @click="focus(item.uuid)">
                <el-form-item :label="item.formName" :label-width="formLabelWidth">
                  <el-select
                    v-model="formParams_[item.uuid]"
                    multiple
                    filterable
                    remote
                    placeholder="请输入关键词"
                    :remote-method="remoteMethod"
                    :loading="loading">
                    <el-option
                      v-for="(items,i) in options"
                      :key="i"
                      :label="items.key"
                      :value="items.key">
                    </el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="24" v-if="isDemension">
        <el-row>
          <el-col :span="24">维表</el-col>
        </el-row>
      </el-col>
    </el-row>
    <div slot="footer" class="dialog-footer">
      <el-button @click="showRoleFormSetModel = false">取 消</el-button>
      <el-button type="primary" @click="commitForm">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getTree } from '../../../assets/js/util'
  export default {
    name: 'RoleFormSetModel',
    data () {
      return {
        showRoleFormSetModel: false,
        formParams_: {}, // 控件绑定对象
        formLabelWidth: '120px',
        defaultProps: {
          children: 'children',
          label: 'lable_des'
        },
        isDemension: false,
        loading: false,
        selValue: [], // 表字段已选值
        currentColId: '',
        options: [], // 搜索
        commitParam: { // 提交表单参数
          tableId: '',
          roleId: '',
          dataList: []
        }
      }
    },
    computed: {
      tableHeader () {
        return this.$store.state.formTable.tableHeader
      },
      treeData () {
        return getTree({treeList: this.$store.state.role.formTreeList})
      }
    },
    methods: {
      renderContent (h, { node, data, store }) {
        if (node.level === 1 || node.level === 2) {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          </span>)
        }
        if (node.level === 3) {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          <span style="float: right; margin-right:100px; clear:both">
            <el-button type="primary" size="mini" on-click={ () => this.setFormRole(store, data, node) }>设置</el-button>
          </span>
          </span>
          )
        }
      },
      setFormRole (store, data, node) {
        console.log(data)
        this.formParams_ = {}
        this.selValue = []
        this.options = []
        this.commitParam.tableId = data.uuid.slice(6)
        this.$store.dispatch('formTable/getTableHeader', data.uuid.slice(6)).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
        let param = {}
        param.tableId = this.commitParam.tableId
        param.roleId = this.commitParam.roleId
        this.$store.dispatch('role/getRoleFormList', param).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1' && JSON.stringify(res.data.data) !== '{}') {
            let result = JSON.parse(res.data.data)
            for (let item in result) {
              this.formParams_[item] = result[item]
              this.selValue.push(item)
//                  for (let op of result[item]) {
//                    this.options.push({key: op, value: op})
//                  }
            }
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      matchUuidSearch (val) { // 显示from控件方法
        let isShow = false
        for (let item of this.selValue) {
          if (item === val) {
            isShow = true
          }
        }
        return isShow
      },
      remoteMethod (query) {
        if (query !== '') {
          this.loading = true
          setTimeout(() => {
            this.$store.dispatch('formTable/getFormInfo', {colId: this.currentColId, collection: query}).then((res) => {
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                console.log(res.data)
                this.loading = false
                this.options = res.data.data
              } else {
                this.options = []
              }
            })
          }, 200)
        } else {
          this.options = []
        }
      },
      focus (val) {
        console.log(val)
        this.currentColId = val
      },
      commitForm () { // 提交表单权限
        let colDtos = []
        for (let item in this.formParams_) {
          colDtos.push({
            tableColumnId: item,
            tableColumns: this.formParams_[item]
          })
        }
        this.commitParam.dataList = colDtos
        this.$store.dispatch('role/saveRoleFormSet', this.commitParam).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            setTimeout(() => {
              this.showRoleFormSetModel = false
            }, 500)
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      }
    },
    created () {
      this.eventHub.$on('showRoleFormSetModel', (val) => { // 表单权限设置事件监听
        this.showRoleFormSetModel = true
        this.commitParam.roleId = val.uuid
        // 获取动态表单树
        this.$store.dispatch('role/getFormList', {roleId: ''})
      })
    }
  }
</script>

<style lang="scss" scoped>
  .col-left {
    border-right: 1px solid #ddd;
  }
  .row-top {
    height: 100%;
  }
  .el-select {
    width: 100%;
  }
</style>
