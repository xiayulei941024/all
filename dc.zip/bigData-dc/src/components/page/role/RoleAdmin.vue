<template>
  <div class="component-user-admin">
    <table-page-layout id="roleAdminId" v-loading="loading"
                       target="#roleAdminId"
                       element-loading-text="拼命加载中"
                       :userPage="true">
      <tool-bar slot="toolbar" :isRoleFormSet="true"
                @create="create" @update="update" @delete="remove" @search="search" @roleFormSet="roleFormSet">
      </tool-bar>
      <el-table slot="table"
                @row-click="rowClick"
                ref="multipleTable"
                :data="userList"
                border
                tooltip-effect="dark"
                @selection-change="handleSelectionChange"
                style="width: 100%">
        <el-table-column
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column
          type="index"
          width="55">
        </el-table-column>
        <el-table-column width="200" v-for="col of columns" align="center"
                         :key="col.colIndex" :label="addAnnotation(col.colName) || col.colName" :prop="col.colName">
        </el-table-column>
      </el-table>
      <pager slot="pager" @sizeChange="sizeChange" :totalPage="pageCount" @switchPage="switchPage"></pager>
      <!-- <dialog-panel slot="dialog"></dialog-panel> -->
    </table-page-layout>
  </div>
</template>

<script>
  import TablePageLayout from '../TablePageLayout.vue'
  import ToolBar from '../common/ToolBar'
  import Pager from '../common/Pager'
  import DialogPanel from '../common/DialogPanel'
  export default {
    name: 'RoleAdmin',
    data () {
      return {
        multipleSelection: [],
        loading: true
      }
    },
    computed: {
      userList () {
        console.log(this.$store.state.role.list)
        return this.$store.state.role.list
      },
      columns () {
        console.log(this.$store.state.role.columns)
        return this.$store.state.role.columns
      },
      pageCount () {
        return this.$store.state.role.pageTotalCount
      }
    },
    watch: {
      pageCount (newVal) {
        console.log('pageCount:' + newVal)
        this.$store.dispatch('role/getRoleList', newVal)
      },
      userList () {
        this.loading = false
      }
    },
    created () {
      // 获取用户列表
      this.$store.dispatch('role/getRoleList')
    },
    methods: {
      create () {
        console.log('create')
        this.eventHub.$emit('showRoleDialog')
      },
      update () {
        console.log('update')
        if (this.multipleSelection.length === 0) {
          return this.$message({
            type: 'info',
            message: '请选择!'
          })
        } else if (this.multipleSelection.length > 1) {
          return this.$message({
            type: 'info',
            message: '不支持多行修改!'
          })
        }
        this.eventHub.$emit('showRoleDialogChange', this.multipleSelection[0])
      },
      remove () {
        console.log('remove')
        if (this.multipleSelection.length === 0) {
          return this.$message({
            type: 'info',
            message: '请选择!'
          })
        }
        this.open2()
      },
      roleFormSet () {
        console.log('roleFormSet')
        if (this.multipleSelection.length === 0) {
          return this.$message({
            type: 'info',
            message: '请选择!'
          })
        } else if (this.multipleSelection.length > 1) {
          return this.$message({
            type: 'info',
            message: '不支持设置多个角色表单权限!'
          })
        }
        this.$router.push({path: '/admin/role/RoleFormTree', query: {id: this.multipleSelection[0].uuid}})
//        this.eventHub.$emit('showRoleFormSetModel', this.multipleSelection[0])
      },
      search (searchKey) {
        console.log(searchKey)
      },
      switchPage (pageNum) {
        this.$store.dispatch('role/getRoleList', {pageNum: pageNum})
      },
      sizeChange (size) {
        this.$store.dispatch('role/getRoleList', {rownum: size})
      },
      handleSelectionChange (val) { // select 事件
        this.multipleSelection = val
        console.log(val)
//        if (val.length > 1) {
//          this.$refs.multipleTable.clearSelection()
//          this.$refs.multipleTable.toggleRowSelection(val[0])
//          this.$message({
//            type: 'info',
//            message: '暂不支持多行操作!'
//          })
//        } else {
//          this.multipleSelection = val
//        }
      },
      changeTableRow (val) { // 修改行 只支持单行修改
        // 当val.uuid为1时，提示无法删除系统管理员角色并直接返回，不执行后续删除操作
        if (val.uuid === 1) {
          this.$message({
            type: 'warning',
            message: '无法删除系统管理员角色'
          })
          return
        }
        let form = {
          uuid: val.uuid
        }
        this.$store.dispatch('role/delRoleTableRow', form).then((res) => {
          if (res.status === 200 && res.data && res.data.__statusCode === '1') {
            this.$store.dispatch('role/getRoleList')
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          } else {
            this.$message({
              type: 'info',
              message: '删除失败!'
            })
          }
        })
      },
      open2 () {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          for (let item of this.multipleSelection) {
            this.changeTableRow(item)
          }
//          this.changeTableRow(this.multipleSelection[0])
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      rowClick (row, event, colum) {
        this.$refs.multipleTable.toggleRowSelection(row)
      },
      addAnnotation (val) {
//      alert(val)
        let obj = {
          roleCode: '编码',
          roleName: '角色名',
          roleDesc: '描述'
        }
        if (obj[val]) {
          return obj[val]
        } else {
          return ''
        }
      }
    },
    components: {
      TablePageLayout,
      ToolBar,
      Pager,
      DialogPanel
    }
  }
</script>

<style lang="scss" scoped>
  .component-user-admin{
    position: relative;
    width: 100%;
    height: 100%;
  }
</style>


