<template>
  <div id="RoleFormSetId" v-loading="loadingPage"
       target="#RoleFormSetId"
       element-loading-text="拼命加载中">
    <table-page-layout>
      <div slot="toolbar" class="bar-box ">
        <el-button @click="$router.go(-1)">返 回</el-button>
        <el-button type="primary" @click="commitForm">保 存</el-button>
        <span>赋予表单所有数据权限</span>
        <el-switch
          v-model="allDataPermissions"
          on-text="有"
          off-text="无">
        </el-switch>
      </div>
      <div slot="table">
        <el-row v-if="!$route.query.type">
          <el-col :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 12}" :lg="{span: 12}">
            <el-transfer
              v-if="!isDemension"
              v-model="selValue"
              :props="{key: 'uuid',label: 'formName'}"
              :data="tableHeader">
            </el-transfer>
          </el-col>
          <el-col :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 12}" :lg="{span: 12}">
            <el-form :model="formParams_">
              <el-row>
                <el-col v-show="matchUuidSearch(item.uuid)" :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 24}" :lg="{span: 24}" v-for="(item,index) in tableHeader" :key="index">
                  <div @click="focus(item.uuid)">
                    <el-form-item :label="item.formName" :label-width="formLabelWidth" v-if="!item.dimension">
                      <el-select
                        v-model="formParams_[item.uuid]"
                        multiple
                        filterable
                        remote
                        placeholder="请输入关键词"
                        :remote-method="remoteMethod"
                        :loading="loading">
                        <el-option
                          v-for="(items,i) in options_[item.uuid]"
                          :key="i"
                          :label="items.value"
                          :value="items.key">
                        </el-option>
                      </el-select>
                    </el-form-item>
                    <el-form-item :label="item.formName" :label-width="formLabelWidth" v-if="item.dimension">
                      <el-select
                        v-model="formParams_[item.uuid]"
                        multiple
                        filterable
                        remote
                        placeholder="请输入关键词"
                        :remote-method="remoteMethodDime"
                        :loading="loading">
                        <el-option
                          v-for="(items,i) in options_[item.uuid]"
                          :key="i"
                          :label="items.value"
                          :value="items.key">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
              </el-row>
            </el-form>
          </el-col>
        </el-row>
        <el-row v-if="$route.query.type">
          <el-col>
            <el-table @row-click="rowClick"
                      ref="multipleTable"
                      :data="myPagingList[myPagingCurrent]"
                      border
                      tooltip-effect="dark"
                      @selection-change="handleSelectionChange"
                      style="width: 100%">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                type="index"
                width="55">
              </el-table-column>
              <el-table-column :width="(col.formName + '('+ col.colName +')').length * 10"
                               :show-overflow-tooltip="true"
                               v-for="(col,index) in tableHeader"
                               :key="index" :label="col.formName || col.colName "
                               :class-name="'className'"
                               :label-class-name="'label-class-name_' + col.colName"
                               :prop="col.dimension?col.colName+'_des':col.colName"
                               align="center">
              </el-table-column>
            </el-table>
          </el-col>
        </el-row>
      </div>
      <pager v-if="$route.query.type" slot="pager" @sizeChange="sizeChange"  :totalPage="pageCount" @switchPage="switchPage"></pager>
    </table-page-layout>
  </div>
</template>
<script>
  import TablePageLayout from '../TablePageLayout.vue'
  import Pager from '../common/Pager'
  import _ from 'lodash'
  export default {
    name: 'RoleFormSet',
    data () {
      return {
        formParams_: {}, // 控件绑定对象
        formLabelWidth: '150px',
        isDemension: false,
        allDataPermissions: false,
        loading: false,
        selValue: [], // 表字段已选值
        currentColId: '',
        options: [], // 搜索
        options_: {},
        commitParam: { // 提交表单参数
          tableId: '',
          roleId: '',
          dataList: []
        },
        multipleSelection: [], // 点击后的已选对象,切换页面时赋值給myPagingListChecked里面的相应分页
        multipleSelectionAll: [], // 提交时将全部分页整合
        loadingPage: true,
        // 分页状态
        myPagingSize: 10, // 每页条数
        myPagingCurrent: 0, // 当前页
        myPagingList: [], // 全部分页对象
        sizeLoading: false, // 是否切换每页数量
        myPagingListChecked: [] // 全部分页已选对象
      }
    },
    computed: {
      tableHeader () {
        return this.$store.state.formTable.tableHeader
      },
      allDataPermissions_ () {
        return this.$store.state.formTable.allDataPermissions
      },
      tableList () {
        return this.$store.getters['formTable/SetRoleTableList_']
      },
      tableCheckedList () { // 已取消使用,以后可能会用
        return this.$store.state.formTable.SetRoleTableisChecked
      },
      pageCount () {
        return this.$store.state.formTable.SetRoleTableCount
      }
    },
    methods: {
      setFormRole () {
        let param = {}
        param.tableId = this.commitParam.tableId
        param.roleId = this.commitParam.roleId
        this.$store.dispatch('role/getRoleFormList', param).then((res) => {
          this.loadingPage = false
          if (res.data && res.status === 200 && res.data.__statusCode === '1' && JSON.stringify(res.data.data) !== '{}') {
            let result = JSON.parse(res.data.data)
            for (let item in result) {
              this.formParams_[item] = result[item].map((val) => {
                return val.key
              })
              this.options_[item] = result[item]
              this.selValue.push(item)
            }
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      matchUuidSearch (val) { // 显示from控件方法
        let isShow = false
        for (let item of this.selValue) {
          if (item === val) {
            isShow = true
          }
        }
        return isShow
      },
      remoteMethod (query) {
        if (query !== '') {
          this.loading = true
          setTimeout(() => {
            this.$store.dispatch('formTable/getFormInfo', {colId: this.currentColId, collection: query}).then((res) => {
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                console.log(res.data)
                this.loading = false
                this.options_[this.currentColId] = res.data.data
              } else {
                this.options[this.currentColId] = []
              }
            })
          }, 200)
        } else {
          this.options = []
        }
      },
      remoteMethodDime (query) {
        if (query !== '') {
          this.loading = true
          setTimeout(() => {
            this.$store.dispatch('formTable/searchDimeList', {collection: query, colId: this.currentColId}).then((res) => {
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                console.log(res.data)
                this.loading = false
                this.options_[this.currentColId] = res.data.data
              } else {
                this.options_[this.currentColId] = []
              }
            })
          }, 200)
        } else {
          this.options = []
        }
      },
      focus (val) {
        console.log(val)
        this.currentColId = val
      },
      commitForm () { // 提交表单权限
        let colDtos = []
        this.multipleSelectionAll = []
        this.myPagingListChecked[this.myPagingCurrent] = this.multipleSelection.slice(0)
        if (this.$route.query.type) { // 如果是维表
          for (let item of this.myPagingListChecked) {
            console.log(item)
            this.multipleSelectionAll = this.multipleSelectionAll.concat(item)
          }
          // 选择为空也可保存
          /* if (this.multipleSelectionAll.length === 0) {
            return this.$message({
              type: 'info',
              message: '请选择!'
            })
          } */
          let PKObj = {}
          for (let val of this.tableHeader) {
            if (val.primaryKey) {
              PKObj = val
              break // 维表现在只是单主键,如果是多主键需要修改
            }
          }
          let tableColumns = []
          for (let col of this.multipleSelectionAll) {
            tableColumns.push(col[PKObj.colName])
          }
          colDtos.push({
            tableColumnId: PKObj.uuid,
            tableColumns: tableColumns
          })
        } else { // 不是维表
          for (let item in this.formParams_) {
            if (item && item.length !== 0) {
              colDtos.push({
                tableColumnId: item,
                tableColumns: this.formParams_[item]
              })
            }
          }
        }
        this.commitParam.dataList = colDtos
        this.commitParam.allDataPermissions = this.allDataPermissions // 赋予表单所有数据权限
        this.$store.dispatch('role/saveRoleFormSet', this.commitParam).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            setTimeout(() => {
              this.$router.go(-1)
            }, 500)
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      rowClick (row, event, colum) {
        this.$refs.multipleTable.toggleRowSelection(row)
      },
      handleSelectionChange (val) { // select 事件
        console.log('12', val)
        this.multipleSelection = val.slice(0)
      },
//      judgeDelOrAdd () { // 以后做优化分页可用
//        let PKObj = {}
//        for (let val of this.tableHeader) {
//          if (val.primaryKey) {
//            PKObj = val
//            break // 维表现在只是单主键,如果是多主键需要修改
//          }
//        }
//        this.multipleSelectionAll = _.uniq(this.multipleSelectionAll, PKObj.colName)
//        for (let row of this.multipleSelection) {
//          let delAndAdd = _.findIndex(this.multipleSelectionAll, function (chr) {
//            return chr[PKObj.colName] === row[PKObj.colName]
//          })
//          if (delAndAdd > 0) {
// //            this.multipleSelectionAll.splice(delAndAdd, 1)
//          } else {
// //            this.multipleSelectionAll.push(row)
//          }
//        }
//      },
      toggleSelection (rows) {
        if (rows) {
          rows.forEach(row => {
            this.$refs.multipleTable.toggleRowSelection(row, true)
          })
        }
      },
      sizeChange (size) {
        this.sizeLoading = true
        this.loadingPage = true
        this.myPagingCurrent = 0
        this.multipleSelection = []
        this.myPaging(this.pageCount, size, this.myPagingCurrent)
        this.loadingPage = false
        setTimeout(() => {
          this.toggleSelection(this.myPagingListChecked[this.myPagingCurrent])
        }, 200)
//        this.$store.dispatch('formTable/getSetRoleTableList', {tableUUID: this.$route.query.tableId, rownum: size, roleId: this.$route.query.roleId}).then((res) => {
//          this.loadingPage = false
//          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
//            this.toggleSelection(this.tableCheckedList)
//          }
//        })
      },
      switchPage (pageNum) {
        if (!this.sizeLoading) { // 切换每页数量时,将已选值存入该数组
          this.myPagingListChecked[this.myPagingCurrent] = this.multipleSelection.slice(0)
        }
        this.myPagingCurrent = pageNum - 1
        setTimeout(() => {
          this.toggleSelection(this.myPagingListChecked[this.myPagingCurrent])
        }, 200)
        this.sizeLoading = false
//        this.loadingPage = true
//        this.$store.dispatch('formTable/getSetRoleTableList', {tableUUID: this.$route.query.tableId, pagenum: pageNum, roleId: this.$route.query.roleId}).then((res) => {
//          this.loadingPage = false
//          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
//            this.toggleSelection(this.tableCheckedList)
//          }
//        })
      },
      myPaging (count, size, currentPage) {
        this.myPagingListChecked = []
        this.myPagingList = _.chunk(this.tableList, size)
        for (let item of this.myPagingList) {
          let listChecked = []
          console.log(1111, item)
          for (let val of item) {
            if (val.isChecked === '1') {
              listChecked.push(val)
            }
          }
          this.myPagingListChecked.push(listChecked)
        }
      }
    },
    watch: {
      allDataPermissions_ (val) {
        this.allDataPermissions = val
      }
    },
    mounted () {
      this.commitParam.roleId = this.$route.query.roleId
      this.commitParam.tableId = this.$route.query.tableId
      this.allDataPermissions = this.allDataPermissions_
      let obj = {}
      for (let item of this.tableHeader) {
        obj[item.uuid] = []
      }
      this.options_ = obj
      if (this.$route.query.type) {
        // 单表为维度时获取列表
        this.$store.dispatch('formTable/getSetRoleTableList', {tableUUID: this.$route.query.tableId, roleId: this.$route.query.roleId, rownum: 0}).then((res) => {
          this.loadingPage = false
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.myPaging(this.pageCount, this.myPagingSize, this.myPagingCurrent)
            setTimeout(() => {
              this.toggleSelection(this.myPagingListChecked[this.myPagingCurrent])
            }, 200)
          }
        })
      } else {
        // 当表为非维度时获取列表
        this.setFormRole()
      }
    },
    components: {
      TablePageLayout,
      Pager
    }
  }
</script>
<style lang="scss">
  #RoleFormSetId {
    position: relative;
    width: 100%;
    height: 100%;
    .el-select {
      width: 100%;
    }
    .bar-box {
      /*margin-bottom: 10px;*/
    }
    .el-transfer-panel {
      width: 177px;
    }
  }
</style>
