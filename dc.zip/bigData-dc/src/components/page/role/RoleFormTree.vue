<template>
  <div id="roleFormTreeId" v-loading="loading"
       target="#roleFormTreeId"
       element-loading-text="拼命加载中">
    <div class="bar-box">
      <el-button @click="$router.go(-1)">返 回</el-button>
    </div>
    <el-tree
      :accordion="true"
      :data="treeData"
      :props="defaultProps"
      :default-expanded-keys="['table_0']"
      node-key="uuid"
      :show-checkbox="false"
      :render-content="renderContent"
      ref="tree">
    </el-tree>
  </div>
</template>
<script>
  import { getTree } from '../../../assets/js/util'
  export default {
    name: 'RoleFormTree',
    data () {
      return {
        defaultProps: {
          children: 'children',
          label: 'lable_des'
        },
        loading: true
      }
    },
    computed: {
      treeData () {
        return getTree({treeList: this.$store.state.role.setformTreeList})
      }
    },
    methods: {
      renderContent (h, { node, data, store }) {
        if (data.type !== 'table') {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          </span>)
        } else {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          <span style="float: right; margin-right:100px; clear:both">
            <el-button type="primary" size="mini" on-click={ () => this.setFormRole(store, data, node) }>设置权限</el-button>
          </span>
          </span>
          )
        }
      },
      setFormRole (store, data, node) {
        this.loading = true
        this.$store.dispatch('formTable/getTableHeader3', {uuid: data.uuid.slice(6), roleId: this.$route.query.id}).then((res) => {
          this.loading = false
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.$router.push({path: '/admin/role/RoleFormSet', query: {tableId: data.uuid.slice(6), roleId: this.$route.query.id, type: res.data.data.dimensionTable}})
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      }
    },
    created () {
      this.$store.dispatch('role/getShowDataList', {uuid: this.$route.query.id}).then(() => {
        this.loading = false
      })
    }
  }
</script>
<style lang="scss" scoped>
  #roleFormTreeId {
    position: relative;
    width: 100%;
    height: 100%;
  }
  .bar-box {
    margin-bottom: 10px;
  }
</style>
