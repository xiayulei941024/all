<template>
  <!-- 
    @author chenqy9
    @description 修改表单字段顺序，
    （库名，用户名，密码）这三个字段按这个顺序放在端口信息后面
    @date 2018-08-23
   -->
  <el-dialog title="数据源信息" size="small" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
    <el-form :model="form" ref="DataSourceFormRef" :rules="rules" label-position="top">
      <el-form-item label="数据库" prop="dbType" :label-width="formLabelWidth">
        <el-select v-model="form.dbType" placeholder="请选择数据库类型">
          <el-option v-for="(item, i) in dataTypeList" :label="item" :value="item" :key="i"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="系统Code" prop="dsrcCode" :label-width="formLabelWidth">
        <el-input v-model="form.dsrcCode" auto-complete="off"></el-input>
        <el-button type="primary" @click="onSearch">查询系统code是否存在</el-button>
      </el-form-item>
      <el-form-item label="数据库名称" prop="dsrcName" :label-width="formLabelWidth">
        <el-input v-model="form.dsrcName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="数据库IP" prop="dsrcName" :label-width="formLabelWidth">
        <el-input v-model="form.ip" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="数据库端口" prop="dsrcName" :label-width="formLabelWidth">
        <el-input v-model="form.port" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="数据库连接用户名" prop="username" :label-width="formLabelWidth">
        <el-input v-model="form.username" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="用户信息密码" prop="password" :label-width="formLabelWidth">
        <el-input type="password" v-model="form.password" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="初始化连接池大小" prop="initSize" :label-width="formLabelWidth">
        <el-input-number v-model="form.initSize" @change="handleChange" :min="1" :max="50"></el-input-number>
      </el-form-item>
      <el-form-item label="最大连接池会话数目" prop="maxActive" :label-width="formLabelWidth">
        <el-input-number v-model="form.maxActive" @change="handleChange" :min="1" :max="50"></el-input-number>
      </el-form-item>

      <el-form-item label="连接等待超时的时间" prop="maxWait" :label-width="formLabelWidth">
        <el-input-number v-model="form.maxWait" @change="handleChange" :min="1" :max="1200000"></el-input-number>
      </el-form-item>
      <el-form-item label="连接在池中最小生存的时间(s)" prop="minEvictableIdleTimeMillis" :label-width="formLabelWidth">
        <el-input-number v-model="form.minEvictableIdleTimeMillis" @change="handleChange" :min="0" :max="18000000"></el-input-number>
      </el-form-item>
      <el-form-item label="最小空闲连接数"  prop="minIdle":label-width="formLabelWidth">
        <el-input-number v-model="form.minIdle" @change="handleChange" :min="0" :max="18000000"></el-input-number>
      </el-form-item>
      <el-form-item label="SQL查询超时时间(ms)" :label-width="formLabelWidth" prop="queryTimeout">
        <el-input-number v-model="form.queryTimeout" @change="handleChange" :min="0" :max="18000000"></el-input-number>
      </el-form-item>
      <el-form-item label="库名称（数据库实例）" prop="serviceName" :label-width="formLabelWidth">
        <el-input v-model="form.serviceName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="检测间隔(s)" prop="timeBetweenEvictionRunMillis" :label-width="formLabelWidth">
        <el-input-number v-model="form.timeBetweenEvictionRunMillis" @change="handleChange" :min="0" :max="18000000"></el-input-number>
      </el-form-item>
      <!--<el-form-item label="数据库连接URL" prop="url" :label-width="formLabelWidth">-->
        <!--<el-input v-model="form.url" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
      <!--<el-form-item label="主键（自动生成）" prop="uuid" :label-width="formLabelWidth">-->
        <!--<el-input v-model="form.uuid" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
      <!--<el-form-item label=" 验证查询SQL" prop="validationQuery" :label-width="formLabelWidth">-->
        <!--<el-input v-model="form.validationQuery" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
    </el-form>
    <div slot="footer" class="dialog-footer">
      <!-- 
        @author cehnqy9
        @description 增加操作提示
       -->
      <div class="msg msg-confirm">
        <p>
          <span class="el-icon-information"></span>
          您需要先<strong><em>“检查系统code是否存在”</em></strong>，
          然后点击<strong><em>“检测”</em></strong>
          通过后，才能点击确定按钮保存
        </p>
      </div>
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="onCheckConnection('DataSourceFormRef')">检测</el-button>
      <el-button :disabled="isDisabled" type="primary" @click="commitAllForm('DataSourceFormRef')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  export default {
    name: 'DataSourceForm',
    data () {
      return {
        dialogFormVisible: false,
        num8: 10,
        form: {
          dbType: 'MYSQL',
          dsrcCode: 'localhost_test',
          dsrcName: '本地测试',
          initSize: 0,
          maxActive: 10,
          maxWait: 120000,
          minEvictableIdleTimeMillis: 1800000,
          minIdle: 0,
          password: '123456',
          queryTimeout: 120000,
          serviceName: 'dc',
          timeBetweenEvictionRunMillis: 120000,
          username: 'root',
          uuid: '1',
          ip: '',
          port: '3306'
        },
        formLabelWidth: '200px',
        rules: {
          dbType: [
            { required: true, message: '请输入活动名称', trigger: 'blur' }
          ],
          dsrcCode: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          dsrcName: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          initSize: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'change' }
          ],
          maxActive: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'change' }
          ],
          maxWait: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'change' }
          ],
          minEvictableIdleTimeMillis: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'change' }
          ],
          minIdle: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'change' }
          ],
          password: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          queryTimeout: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          serviceName: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          timeBetweenEvictionRunMillis: [
            { type: 'number', required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          url: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          username: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          uuid: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          validationQuery: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          ip: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ],
          port: [
            { required: true, message: '内容不能为空', trigger: 'blur' }
          ]
        },
        FORM_STATE: 0, // 表单状态 0提交,1修改,2删除,默认为0
        isDisabled: true
      }
    },
    computed: {
      dataTypeList () { // 数据源类型列表
        return this.$store.state.dataSource.dbTypeList
      },
      dataSourceList () { // 数据源列表
        return this.$store.state.dataSource.list
      }
    },
    methods: {
      handleChange (value) {
        console.log(value)
      },
      commitAllForm (DataSourceFormRef) { // 根据当前状态选择提交方式
        this.$refs[DataSourceFormRef].validate((valid) => {
          if (valid) {
            let params = {}
            params = this.form
            this.$store.dispatch('dataSourceForm/checkConnection', params).then((res) => {
              console.log(res)
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                if (res.data.data) {
                  this.FORM_STATE === 1 ? this.commitFormChange() : this.commitForm()
                } else {
                  this.$message({
                    type: 'info',
                    message: '连接失败'
                  })
                }
              } else {
                this.$message({
                  type: 'info',
                  message: res.data.__errorMessage
                })
              }
            })
          } else {
            return false
          }
        })
      },
      commitForm () { // 提交表单
        let params = this.form
        this.$store.dispatch('dataSourceForm/conDataSource', params).then((res) => {
          console.log('dataSourceForm', res)
          if (res.status === 200 && res.data.__statusCode === '1') {
            this.$store.dispatch('dataSource/getList')
            this.open1()
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.open2()
          }
        })
      },
      commitFormChange () { // 提交表单
        let params = this.form
        this.$store.dispatch('dataSourceForm/updateDataSource', params).then((res) => {
          console.log('dataSourceForm', res)
          if (res.status === 200 && res.data.__statusCode === '1') {
            this.$store.dispatch('dataSource/getList')
            this.$store.dispatch('menu/getFormList_for_user')
            this.open1()
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.open2()
          }
        })
      },
      open1 () {
        this.$notify({
          title: '提交成功',
          type: 'success'
        })
      },
      open2 () {
        this.$notify({
          title: '提交失败',
          type: 'error'
        })
      },
      searchDataSource (uuid) { // 查找编辑是数据源信息
        console.warn('list', uuid)
//        let listLength = this.dataSourceList.length
//        for (let i = 0; i < listLength; i++) {
//          if (this.dataSourceList[i].uuid === uuid) {
//            this.form = this.dataSourceList[i]
//          }
//        }
        this.$store.dispatch('dataSourceForm/getDataSourceDetail', {uuid: uuid}).then((res) => {
          console.log(res)
          if (res.status === 200 && res.data.__statusCode === '1') {
            if (res.data.data) {
              this.form = res.data.data
            } else {
              this.$message({
                type: 'info',
                message: '暂无数据源信息'
              })
            }
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      onSearch () {
        let params = {}
        params.dsrcCode = this.form.dsrcCode
        if (!this.form.dsrcCode) {
          this.$message({
            type: 'info',
            message: '请输入系统code'
          })
          return
        }
        this.$store.dispatch('dataSourceForm/validateDsrcCode', params).then((res) => {
          console.log(res)
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            if (!res.data.data) {
              this.$message({
                type: 'info',
                message: 'code可用'
              })
              this.isDisabled = false
            } else {
              this.$message({
                type: 'info',
                message: 'code已存在'
              })
            }
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      },
      onCheckConnection (DataSourceFormRef) {
        this.$refs[DataSourceFormRef].validate((valid) => {
          if (valid) {
            let params = {}
            params = this.form
            this.$store.dispatch('dataSourceForm/checkConnection', params).then((res) => {
              console.log(res)
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
                if (res.data.data) {
                  this.$message({
                    type: 'info',
                    message: '连接成功'
                  })
                } else {
                  this.$message({
                    type: 'info',
                    message: '连接失败'
                  })
                }
              } else {
                this.$message({
                  type: 'info',
                  message: res.data.__errorMessage
                })
              }
            })
          } else {
            return false
          }
        })
      }
    },
    created () {
      this.eventHub.$on('showDataSourceDialog', () => { // 新增数据源事件监听
        this.isDisabled = true
        this.dialogFormVisible = true
        this.FORM_STATE = 0
      })
      this.eventHub.$on('showEditDataSourceDialog', (uuid) => { // 编辑数据源事件监听
        this.isDisabled = false
        this.dialogFormVisible = true
        this.FORM_STATE = 1
        this.searchDataSource(uuid)
      })
    },
    mounted () {
      this.$store.dispatch('dataSource/getDbTypeList')
    }
  }
</script>

<style lang="scss" scoped>
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  /*
   * @author chenqy9
   * @descrition 操作提示样式
   */
  .msg.msg-confirm {
    text-align: left;
    color: #13CE66;
    font-size: 12px;
    line-height: 1.5em;
  }
</style>
