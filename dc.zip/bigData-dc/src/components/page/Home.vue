<template>
  <div class="component-home">
    <h1>{{ $t('common.welcome')}} {{userInfo.title || ' '}}</h1>
    <h3>{{ $t('common.notice')}}</h3>
    <footer>COPY RIGHT &copy; {{userInfo.copyRight || ' '}}</footer>
  </div>
</template>

<script>
  export default {
    name: 'home',
    computed: {
      userInfo () {
        return this.$store.state.user.loginUser
      }
    },
    watch: {
      userInfo () {
        document.getElementById('my-title').innerHTML = this.userInfo.title || ''
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>



