<template>
  <el-dialog :title="form_title"  @close="closeDialog" size="large" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
    <el-breadcrumb separator=">" style="margin-bottom: 10px">
      <el-breadcrumb-item>已选择维度</el-breadcrumb-item>
      <el-breadcrumb-item>{{currentRow.dimensions && currentRow.dimensions[0].dbName}}</el-breadcrumb-item>
      <el-breadcrumb-item>{{currentRow.dimensions && currentRow.dimensions[0].tableName}}</el-breadcrumb-item>
      <el-breadcrumb-item>
        <span v-for="(item,i) in currentRow.dimensions">{{item.dimensionName}}&nbsp;&nbsp;</span>
      </el-breadcrumb-item>
    </el-breadcrumb>
    <el-tree
      :data="treeDataLoading"
      :props="defaultProps"
      @check-change="handleNodeClickChange"
      @current-change="currentChange"
      @node-expand="nodeExpand"
      node-key="uuid"
      show-checkbox
      :load="loadNode"
      lazy
      ref="dimensionTreeLoading">
    </el-tree>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog">取 消</el-button>
      <el-button type="primary" @click="insertDimension">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
//  import { getTree } from '../../assets/js/util'
  import lodash from 'lodash'
  export default {
    name: 'tableDimensionality',
    data () {
      return {
        form_title: '关联维度',
        dialogFormVisible: false,
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        currentRow: {},
        currentTable: [], // 当前表id
        treeDataLoading: [{'name': '根目录', disabled: true}],
        checkedData: [],
        defaultCheckFlag: true  // 初始进入默认选中
      }
    },
    computed: {
      selDimensionList () {
      },
      tableid () {
        return this.currentRow.dimensions ? this.currentRow.dimensions[0].dimensionTableid : undefined
      }
//      treeData () {
//        return getTree({treeList: this.$store.state.table.dimensionalList})
//      },
//      defaultCheckedKeys () {
//        return this.$store.state.table.DimensionalCheckedList
//      },
//      dimensionalDatasourceList () {
//        return this.$store.state.table.dimensionalDatasourceList
//      },
//      dimensionalPk () {
//        return this.$store.state.table.dimensionalPk
//      }
    },
    methods: {
      closeDialog () {
        this.checkedData.length = 0
        this.dialogFormVisible = false
        // 关闭时候 重新渲染数据
        this.treeDataLoading = [{'name': '根目录', disabled: true}]
      },
      currentChange (data, node) {
      },
      nodeExpand (data, node, com) {
        // 确定是否为该节点的子节点选中
        if (this.defaultCheckFlag && this.currentRow.dimensions && node.level === 3) {
          if (data.type === 'table' && data.uuid.slice(6) === this.tableid) {
            setTimeout(() => {
              console.log(this.checkedData)
              this.$refs.dimensionTreeLoading.setCheckedKeys(this.checkedData)
              this.defaultCheckFlag = false
            }, 300)
          }
        }
      },
      handleNodeClickChange (data, checked, inde) {
        // console.log(333, data)
        // console.log(333333, data, checked, inde)
//        if (data.type === 'column' && checked && this.currentTable.indexOf(data.parentid) < 0) {
//          this.currentTable.push(data.parentid)
//        }
//        if (data.type === 'column' && !checked && this.currentTable.indexOf(data.parentid) >= 0) {
//          this.currentTable.splice(this.currentTable.indexOf(data.parentid), 1)
//        }
//        if (checked && data.type === 'column') {
//          if (this.defaultCheckedKeys.indexOf(data.uuid) < 0) {
//            this.defaultCheckedKeys.push(data.uuid)
//          }
//        } else if (!checked && data.type === 'column') {
//          let i = this.defaultCheckedKeys.indexOf(data.uuid)
//          if (i >= 0) {
//            this.defaultCheckedKeys.splice(i, 1)
//          }
//        }
//        this.$store.commit('table/updateDimensionalCheckedList', this.defaultCheckedKeys)
      },
      insertDimension () {
        let CheckedNodesArray = this.$refs.dimensionTreeLoading.getCheckedNodes()
        console.log('CheckedNodesArray', CheckedNodesArray)
        if (CheckedNodesArray.length === 1 && CheckedNodesArray[0].dbid && CheckedNodesArray[0].type === 'column') {
          return this.$message({
            type: 'info',
            message: '当前维度为主键,请继续选择当前表的其他维度!'
          })
        }
        this.currentTable = []
        CheckedNodesArray.map((item) => {
          if (item.type === 'column') {
            this.currentTable.push(item.parentid)
          }
        })
        let lodashList = lodash.uniq(this.currentTable)
        if (lodashList.length > 1) {
          return this.$message({
            type: 'info',
            message: '暂不支持关联多张表!'
          })
        } else if (lodashList.length === 0) {
          return this.$message({
            type: 'info',
            message: '请选择关联维度!'
          })
        } else {
          // 是否存在主键,如果不存在需接口返回添加
          this.$store.dispatch('table/getDimensionaList', {type: 'column', uuid: lodashList[0].slice(6)}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              let dimensions = []
              let isExistPK = false
              CheckedNodesArray.map((item) => {
                if (item.type === 'column') {
                  if (item.dbid) { // dbid不为null说明是主键
                    isExistPK = true
                  }
                  dimensions.push({
                    dimensionColid: item.uuid.slice(7),
                    tableid: lodashList[0].slice(6),
                    primaryKey: Boolean(item.dbid),
                    dimensionName: item.name,
                    tableName: item.name_export,
                    dbName: item.name_export1
                  })
                }
              })
              if (!isExistPK) {
                for (let item of JSON.parse(res.data.data)) {
                  if (item.dbid) {
                    dimensions.push({
                      dimensionColid: item.uuid.slice(7),
                      tableid: lodashList[0].slice(6),
                      primaryKey: true,
                      dimensionName: item.name,
                      tableName: item.name_export,
                      dbName: item.name_export1
                    })
                  }
                }
              }
              if (dimensions.length === 1 && dimensions[0].primaryKey) {
                return this.$message({
                  type: 'info',
                  message: '当前维度为主键,请继续选择当前表的其他维度!'
                })
              }
              this.currentRow.dimensions = dimensions
              this.dialogFormVisible = false
            }
          })
        }
      },
      loadNode (node, resolve) {
        if (node.level === 0) {
          return resolve([{'name': '根目录', disabled: true}])
        }
        if (node.level > 3) return resolve([])
        if (node.level === 1) {
          this.$store.dispatch('table/getDimensionaList', {type: 'datasource'}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 2) {
          this.$store.dispatch('table/getDimensionaList', {type: 'table', uuid: node.data.uuid.slice(11)}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 3) {
          this.$store.dispatch('table/getDimensionaList', {type: 'column', uuid: node.data.uuid.slice(6)}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              let res_ = JSON.parse(res.data.data).map((item) => {
                if (item.dbid) {
                  item.disabled = false
                }
                return item
              })
              return resolve(res_)
            }
          })
        }
      }
    },
    mounted () {
      this.eventHub.$on('showDimensionTree', (val) => {
        // 重新进来 初始化默认选中标志
        this.defaultCheckFlag = true
        // 重新打开 重新渲染数据
        this.treeDataLoading = [{'name': '根目录', disabled: true}]
        this.dialogFormVisible = true
        this.currentRow = val
        if (val.dimensions && this.dialogFormVisible) {
          this.checkedData.length = 0
          // 默认第三等级 type = column 时才能默认勾上
          for (let j = 0; j < this.currentRow.dimensions.length; j++) {
            this.checkedData.push('column_' + this.currentRow.dimensions[j].dimensionColid)
          }
        } else {
          this.checkedData.length = 0
        }
      })
    }
  }
</script>

<style lang="scss" scoped>
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  .el-input {
    width: 300px;
  }
</style>
