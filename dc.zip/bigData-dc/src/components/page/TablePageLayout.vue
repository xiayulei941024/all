<template>
  <div class="component-page-table-layout">
    <div class="container-searchbar"  v-if="showSearch">
      <slot name="searchbar"></slot>
    </div>
    <div class="container-toolbar">
      <slot name="toolbar"></slot>
    </div>
    <div class="container-table" :class="{'user-page': userPage}">
      <div class="wrapper-table">
        <slot name="table"></slot>
      </div>
    </div>
    <div class="container-pager">
      <slot name="pager"></slot>
    </div>
    <!-- <div class="container-dialog">
      <slot name="dialog"></slot>
    </div> -->
  </div>
</template>

<script>
import DialogPanel from './common/DialogPanel'
export default {
  name: 'pageTableLayout',
  // computed: {
  //   isShowDialog () {
  //     return this.$store.state.isShowDialog
  //   }
  // },
  components: {
    DialogPanel
  },
  props: {
    // 是否展现配置搜索字段
    showSearch: {
      type: Boolean,
      default: false
    },
    // 如果是用户表，改变默认padding
    userPage: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
  .component-page-table-layout {
    $height_searchbar: 60px;
    $height_toolbar: 36px;
    $height_margin: 10px;
    $height_pager: 32px;

    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;

    .container-searchbar {
      position: relative;
      // top: 0;
      z-index: 99;
      width: 100%;
      min-height: 47px;
      padding-top: 5px;
    }
    .container-toolbar {
      position: relative;
      // top: $height_searchbar;
      z-index: 99;
      width: 100%;
      height: $height_toolbar;
      margin-top: $height_margin;
      white-space: nowrap;
    }

    .container-table {
       z-index: 0;
      position: absolute;
      left: 0px;
      bottom: 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      padding: 98px 0 ($height_pager + $height_margin * 2) 0;
      overflow: hidden;
      &.user-page {
        padding-top: ($height_toolbar + $height_margin * 2);
      }

      .wrapper-table {
        position: relative;
        height: 100%;
        width: 100%;
        overflow: auto;
      }
    }

    .container-pager {
      position: absolute;
      bottom: 0;
      z-index: 99;
      width: 100%;
      height: $height_pager;
      margin-bottom: $height_margin;
    }

    .container-dialog {
      position: absolute;
      z-index: 9999;
    }
  }
</style>

