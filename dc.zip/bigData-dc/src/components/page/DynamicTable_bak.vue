<template>
  <div class="component-dynamic-table">
    <h3>{{$route.params.uuid}}</h3>
    <!-- 工具栏 -->
    <div class="table-toolbar">
      <el-button type="primary" icon="plus" @click="openEditFrame">新增</el-button>
    </div>
    <!-- 表单列表 -->
    <div class="table-lsit">
      <el-table :data="tableModel.records">
        <el-table-column v-for="field of tableModel.fields" :key="field.name"
          :label="field.label" :prop="field.name">
        </el-table-column>
        <el-table-column label="编辑">
          <template scope="scope">
            <el-button type="warning" icon="edit" @click="openEditFrame(scope)"></el-button>
          </template>
        </el-table-column>
        <el-table-column label="删除">
          <template scope="scope">
            <el-button type="danger" icon="delete"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 新增编辑表单记录 -->
    <el-dialog title="编辑表单"
      size="large"
      :before-close="closeEditFrame"
      :visible.sync="showEditFrame">
      <el-form :model="editRecord">
        <el-form-item v-for="field of tableModel.fields" :key="field.name"
          :label="field.label">
          <el-input v-model="editRecord[field.name]"></el-input>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
  .component-dynamic-table {
    width: 100%;
    height: 100%;
  }
</style>

<script>
export default {
  name: 'dynamicTable',
  data () {
    let data = {}
    // 显示编辑表单框
    data.showEditFrame = false
    // 表单模型
    data.tableModel = {
      // 表单名称
      name: '用户',
      // 表单字段
      fields: [
        /* 用户名 */
        {
          name: 'name',
          label: '用户名',
          type: 'string',
          required: true
        },
        /* 年龄 */
        {
          name: 'age',
          label: '年龄',
          type: 'number',
          required: true
        },
        /* 生日 */
        {
          name: 'birthdate',
          label: '生日',
          type: 'date',
          required: true
        }
      ],
      // 表单记录
      records: [
        {
          name: 'lili',
          age: 24,
          birthdate: '1993-06-04'
        },
        {
          name: 'mike',
          age: 24,
          birthdate: '1993-06-04'
        }
      ]
    }
    // 构造表单记录模型
    let recordModel = data.recordModel = {}
    for (let field of data.tableModel.fields) { // 字段
      recordModel[field.name] = ''
    }
    // 当前编辑的表单记录, 默认为新增记录
    let editRecord = data.editRecord = recordModel
    console.log(editRecord)
    return data
  },
  methods: {
    closeEditFrame (done) {
      done()
    },
    openEditFrame (editRecord) {
      console.log(editRecord)
      if (!editRecord) {
        this.editRecord = this.recordModel
      } else {
        this.editRecord = editRecord
      }
      // this.showEditFrame = true
    }
  }
}
</script>

