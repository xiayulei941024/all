<template>
  <div class="component-user-admin">
    <table-page-layout id="userAdminId" v-loading="loading"
                       target="#userAdminId"
                       element-loading-text="拼命加载中"
                       :userPage="true">
      <tool-bar slot="toolbar"
        @create="create" @update="update" @delete="remove" @search="search"
        :textSearch="true" @textSearch="onSearch">
      </tool-bar>
      <el-table slot="table"
        ref="multipleTable"
        @row-click="rowClick"
        :data="userList"
        border
        tooltip-effect="dark"
        @selection-change="handleSelectionChange"
        style="width: 100%">
        <el-table-column
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column
          type="index"
          width="55">
        </el-table-column>
        <el-table-column width="200" v-for="col of columns"
          :key="col.colIndex" :label="addAnnotation(col.colName) || col.colName" :prop="col.colName" align="center">
        </el-table-column>
      </el-table>
      <pager slot="pager" :currentPage="pageNum" @sizeChange="sizeChange" :totalPage="pageCount" @switchPage="switchPage"></pager>
      <!-- <dialog-panel slot="dialog"></dialog-panel> -->
    </table-page-layout>
  </div>
</template>

<script>
import TablePageLayout from './TablePageLayout.vue'
import ToolBar from './common/ToolBar'
import Pager from './common/Pager'
import DialogPanel from './common/DialogPanel'
export default {
  name: 'userAdmin',
  data () {
    return {
      multipleSelection: [],
      loading: true,
      userAccount: '',
      pageNum: 1,
      rownum: 10
    }
  },
  computed: {
    userList () {
      console.log(this.$store.state.user.list)
      return this.$store.state.user.list
    },
    columns () {
      console.log(this.$store.state.user.columns)
      return this.$store.state.user.columns
    },
    pageCount () {
      return this.$store.state.pageTotalCount
    }
  },
  watch: {
    pageCount (newVal) {
      console.log('pageCount:' + newVal)
    },
    userList () {
      this.loading = false
    }
  },
  created () {
    // 获取用户列表
    this.$store.dispatch('user/getUserList')
  },
  methods: {
    create () {
      console.log('create')
      this.eventHub.$emit('showUserDialog')
    },
    update () {
      console.log('update')
      if (this.multipleSelection.length === 0) {
        return this.$message({
          type: 'info',
          message: '请选择!'
        })
      } else if (this.multipleSelection.length > 1) {
        return this.$message({
          type: 'info',
          message: '不支持多行修改!'
        })
      }
      this.eventHub.$emit('showUserDialogChange', this.multipleSelection[0])
    },
    remove () {
      console.log('remove')
      if (this.multipleSelection.length === 0) {
        return this.$message({
          type: 'info',
          message: '请选择'
        })
      }
      this.open2()
    },
    search (searchKey) {
      console.log(searchKey)
    },
    switchPage (pageNum) {
      this.pageNum = pageNum
      this.$store.dispatch('user/getUserList', {pageNum: this.pageNum, rownum: this.rownum, userAccount: this.userAccount})
    },
    sizeChange (size) {
      this.rownum = size
      this.$store.dispatch('user/getUserList', {pageNum: this.pageNum, rownum: size, userAccount: this.userAccount})
    },
    handleSelectionChange (val) { // select 事件
      this.multipleSelection = val
      console.log(val)
//      if (val.length > 1) {
//        this.$refs.multipleTable.clearSelection()
//        this.$refs.multipleTable.toggleRowSelection(val[1])
//        this.$message({
//          type: 'info',
//          message: '暂不支持多行操作!'
//        })
//      } else {
//        this.multipleSelection = val
//      }
    },
    changeTableRow (val) { // 修改行 只支持单行修改
      let form = {
        uu_id: val.uuid
      }
      this.$store.dispatch('user/delUserTableRow', form).then((res) => {
        if (res.status === 200) {
          this.$store.dispatch('user/getUserList')
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        } else {
          this.$message({
            type: 'info',
            message: '删除失败!'
          })
        }
      })
    },
    open2 () {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        for (let item of this.multipleSelection) {
          this.changeTableRow(item)
        }
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    rowClick (row, event, colum) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    addAnnotation (val) {
//      alert(val)
      let obj = {
        userAccount: '登录账号',
        userName: '姓名',
        userEmail: '邮箱',
        effStartDate: '开始时间',
        effEndDate: '结束时间',
        userMobileNo: '手机号',
        positionName: '岗位'
      }
      if (obj[val]) {
        return obj[val]
      } else {
        return ''
      }
    },
    onSearch (userAccount) {
      this.userAccount = userAccount
      this.pageNum = 1
      this.$store.dispatch('user/getUserList', {pageNum: this.pageNum, rownum: this.rownum, userAccount: this.userAccount})
    }
  },
  components: {
    TablePageLayout,
    ToolBar,
    Pager,
    DialogPanel
  }
}
</script>

<style lang="scss" scoped>
  .component-user-admin{
    position: relative;
    width: 100%;
    height: 100%;
  }
</style>


