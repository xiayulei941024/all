<!-- 表单list查询模块 -->
<template>
  <el-dialog :title="form_title" :visible.sync="dialogFormVisible" size="large" :close-on-click-modal="false">
    <el-row>
      <el-col :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 24}" :lg="{span: 24}" class="col-padding">
        <div class="transfer-container">
          <el-transfer
          v-model="selValue"
          :props="{key: 'uuid',label: 'formName'}"
          :data="tableHeader"
          :titles="['可选字段列表', '已选字段']"
          style="text-align: left; display: inline-block">
        </el-transfer>
        </div>
      </el-col>
    </el-row>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="setChosedTableColumn">确 定</el-button>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
  .component-dynamic-input {
    width: 100%;
    height: 100%;
  }
</style>

<script>
  import DynamicInput from './common/DynamicInput.vue'
  export default {
    name: 'DynamicTableSearchModel2',
    data () {
      return {
        dialogFormVisible: false,
        form_title: '新增表单内容',
        selValue: [] //
      }
    },
    computed: {
      // 所有参数
      tableHeader () {
        return this.$store.state.formTable.tableHeader
      },
      // 已选参数
      setSelTabelColumn () {
        return this.$store.state.formTable.setSelTabelColumn
      },
      formParams () {
        return this.$store.getters['formTable/accessTableHeader']
      },
      formSearchParams () {
        return this.$store.getters['formTable/tableSearchfrom']
      },
      routeUuid () {
        return this.$route.params.uuid
      }
    },
    watch: {
      routeUuid () {
        this.selValue = []
      }
    },
    methods: {
      open1 () {
        this.$notify({
          title: '配置成功',
          type: 'success'
        })
      },
      open2 () {
        this.$notify({
          title: '请选择搜索字段',
          type: 'error'
        })
      },
      setChosedTableColumn () {
        let params = {}
        let selCol = []
        this.selValue.forEach(el => {
          selCol.push({
            uuid: el
          })
        })
        params.tableColumns = selCol
        params.uuid = this.routeUuid
        console.log(params)
        this.$store.dispatch('formTable/updateUserSearchColumn', params).then((res) => {
          if (res.data && res.status === 200 && String(res.data.__statusCode) === '1') {
            this.$store.dispatch('formTable/getUserSearchColumn', {tableUuid: this.$route.params.uuid})
          }
        })
        if (!this.selValue.length) {
          this.open2()
        }
        let obj = []
        this.tableHeader.forEach(el => {
          this.selValue.forEach(el2 => {
            if (el.uuid === el2) {
              obj.push(el)
            }
          })
        })
        this.$store.commit('formTable/setSelTabelColumn', obj)
        this.open1()
        this.dialogFormVisible = false
      }
    },
    created () {
      this.eventHub.$on('DynamicTableSearchModel2', () => { // 筛选表单事件监听
        this.form_title = '配置搜索字段'
        this.dialogFormVisible = true
        this.selValue = this.setSelTabelColumn.map(item => {
          return item.uuid
        })
        console.log(this.selValue)
      })
    },
    components: {
      DynamicInput
    }
  }
</script>
<style lang="scss" scoped>
  .transfer-container {
    text-align: center;
  }
  .el-input {
    width: 150px;
  }
  .el-transfer-panel {
  }
  .col-padding {
    margin-bottom: 20px;
  }
</style>
