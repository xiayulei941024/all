<template>
  <!-- 菜单管理 -->
  <div class="component-menu-admin">
    <div class="container-table">
      <el-tree
        :data="treeData"
        :props="defaultProps"
        show-checkbox
        node-key="id"
        :expand-on-click-node="false"
        :render-content="renderContent">
      </el-tree>
    </div>
  </div>
</template>

<script>
import ToolBar from './common/ToolBar'
import { getTree } from '../../assets/js/util'

// function accessTreeData (data) {
//   let root = data.filter(node => {
//     return node.pId === 'null'
//   })
//   findChildren(root, data)
//   return root
// }

// function findChildren (nodes, tree) {
//   for (let node of nodes) {
//     node.children = tree.filter(item => {
//       return item.pId === node.id
//     })
//     if (node.children) {
//       findChildren(node.children, tree)
//     }
//   }
// }

let id = 1000

export default {
  name: 'menuAdmin',
  data () {
    return {
      data2: [{
        id: 1,
        label: '一级 1',
        children: [{
          id: 4,
          label: '二级 1-1',
          children: [{
            id: 9,
            label: '三级 1-1-1'
          }, {
            id: 10,
            label: '三级 1-1-2'
          }]
        }]
      }, {
        id: 2,
        label: '一级 2',
        children: [{
          id: 5,
          label: '二级 2-1'
        }, {
          id: 6,
          label: '二级 2-2'
        }]
      }, {
        id: 3,
        label: '一级 3',
        children: [{
          id: 7,
          label: '二级 3-1'
        }, {
          id: 8,
          label: '二级 3-2'
        }]
      }],
      defaultProps: {
        children: 'children',
        label: 'name'
      }
    }
  },
  computed: {
    treeList () {
      return this.$store.state.menu.treeList
    },
    treeData () {
      // return accessTreeData(this.treeList)
      return getTree({treeList: this.$store.state.menu.treeList})
    }
  },
  watch: {
    treeData (newVal) {
      console.log(newVal)
    }
  },
  methods: {
    append (store, data) {
      store.append({ id: id++, label: 'testtest', children: [] }, data)
    },
    remove (store, data) {
      store.remove(data)
    },
    renderContent (h, { node, data, store }) {
      return (
        <span>
          <span>
            <span>{node.label}</span>
          </span>
          <span style="float: right margin-right: 20px">
            <el-button size="mini" on-click={ () => this.append(store, data) }>Append</el-button>
            <el-button size="mini" on-click={ () => this.remove(store, data) }>Delete</el-button>
          </span>
        </span>)
    }
  },
  created () {
    // 获取目录树
//    this.$store.dispatch('menu/getTreeList')
//    this.$store.dispatch('menu/getMenuTree')
    this.$store.dispatch('menu/getMenuList')
  },
  components: {
    ToolBar
  }
}
</script>

<style lang="scss" scoped>
  .component-menu-admin {
    width: 100%;
    height: 100%;
  }
</style>


