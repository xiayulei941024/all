<!-- 表单list查询模块 -->
<template>
  <el-dialog :title="form_title" :visible.sync="dialogFormVisible" size="large" :close-on-click-modal="false">
    <el-row>
      <el-col :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 24}" :lg="{span: 11}" class="col-padding">
        <el-transfer
          v-model="selValue"
          :props="{key: 'uuid',label: 'formName'}"
          :data="tableHeader">
        </el-transfer>
      </el-col>
      <el-col :xs="{span: 24}"  :sm="{span: 24}" :md="{span: 24}" :lg="{span: 13}">
        <el-form :model="formParams_">
          <el-row>
            <el-col :xs="{span: 12}"  :sm="{span: 12}" :md="{span: 8}" :lg="{span: 12}" v-for="(item,index) in tableHeader" :key="index">
              <el-form-item v-if="matchUuidSearch(item.uuid)" :label="item.formName" :label-width="formLabelWidth">
                <el-date-picker
                  v-if="item.controlsType === 'TIMESTAMP' && !item.dimension"
                  v-model="formParams_[item.formAttributeName]"
                  type="datetime"
                  @change="formatDate"
                  @blur="changeCurrentDate(item.formAttributeName)"
                  placeholder="选择日期"
                  format="yyyy-MM-dd HH:mm:ss">
                </el-date-picker>
                <div v-else-if="item.dimension" @click="focus(item.uuid)">
                  <el-select v-model="formParams_[item.formAttributeName]"  filterable placeholder="请选择" :disabled="true">
                    <el-option
                      :label="formParams_des[item.formAttributeName + '_des']"
                      :value="formParams_[item.formAttributeName]">
                    </el-option>
                  </el-select>
                  <el-autocomplete
                    v-model="searchData[item.formAttributeName]"
                    :fetch-suggestions="querySearchAsync"
                    placeholder="请输入查询内容"
                    @select="handleSelect"
                  ></el-autocomplete>
                </div>
                <el-input width="150" v-else :type="upCaselowCase(item.controlsType)" v-model="formParams_[item.formAttributeName]"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-col>
    </el-row>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="commitAllForm">确 定</el-button>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
  .component-dynamic-input {
    width: 100%;
    height: 100%;
  }
</style>

<script>
  /*
   * "PASSWORD",
   "TEXT",
   "HIDDEN",
   "TEXTAREA",
   "CHECKBOX",
   "RADIO",
   "SELECT",
   "FILE"
   */
  import DynamicInput from './common/DynamicInput.vue'
  export default {
    name: 'DynamicTableSearchModel',
    data () {
      return {
        dialogFormVisible: false,
        formLabelWidth: '120px',
        formParams_: {},
        formParams_des: {},
        FORM_STATE: 0, // 表单状态 0提交,1修改,2删除,默认为0
        form_title: '新增表单内容',
        currentSelDate: '',
        restaurants: [], // 搜索结果
        currentColId: '',
        searchData: {},
        selValue: [] //
      }
    },
    computed: {
      tableHeader () {
        return this.$store.state.formTable.tableHeader
      },
      formParams () {
        return this.$store.getters['formTable/accessTableHeader']
      },
      formSearchParams () {
        return this.$store.getters['formTable/tableSearchfrom']
      },
      routeUuid () {
        return this.$route.params.uuid
      }
    },
    methods: {
      open1 () {
        this.$notify({
          title: '提交成功',
          type: 'success'
        })
      },
      open2 () {
        this.$notify({
          title: '提交失败',
          type: 'error'
        })
      },
      commitAllForm () { // 根据当前状态选择提交方式
        this.FORM_STATE === 1 ? this.commitForm() : this.commitForm()
      },
      commitForm () { // 提交新增表单
        let params = {}
        params.tableUUID = this.$route.params.uuid
        let colDtos = []
        for (let item of this.selValue) {
          colDtos.push(this.formSearchParams.filter((val) => {
            return val.uuid === item
          })[0])
        }
        colDtos.map((cal) => {
          console.log(222, cal)
          cal.formValue = this.formParams_[cal.colName]
        })
        this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, colDtos: colDtos}).then((res) => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.open1()
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.open2()
          }
        })
      },
      upCaselowCase (val) {
        return val.toLowerCase()
      },
      formatDate (val) {
        this.formParams_[this.currentSelDate] = val
      },
      changeCurrentDate (val) {
        this.currentSelDate = val
      },
      querySearchAsync (queryString, cb) {
        if (!queryString) {
          this.$message({
            type: 'info',
            message: '请输入内容!'
          })
          return cb([])
        }
        setTimeout(() => {
          this.$store.dispatch('formTable/searchDimeList', {collection: queryString, colId: this.currentColId}).then((res) => {
            console.log(res)
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.restaurants = res.data.data
            }
            cb(this.restaurants)
          })
        }, 300)
      },
      handleSelect (item) {
        console.log(item)
        console.log(this.searchData)
        // 关联查询结果
        for (let i in this.searchData) {
          if (this.searchData[i] === item.value) {
            this.formParams_[i] = item.key
            this.formParams_des[i + '_des'] = item.value
            return
          }
        }
      },
      focus (val) {
        console.log(val)
        this.currentColId = val
      },
      matchUuidSearch (val) { // 显示from控件方法
        let isShow = false
        for (let item of this.selValue) {
          if (item === val) {
            isShow = true
          }
        }
        return isShow
      }
    },
    watch: {
      routeUuid () {
        this.selValue = []
      }
    },
    created () {
      this.eventHub.$on('DynamicTableSearchModel', () => { // 筛选表单事件监听
        this.form_title = '筛选表单'
        this.FORM_STATE = 0
        this.dialogFormVisible = true
        this.formParams_ = this.formParams
      })
    },
    components: {
      DynamicInput
    }
  }
</script>
<style lang="scss" scoped>
  .el-input {
    width: 150px;
  }
  .el-transfer-panel {
  }
  .col-padding {
    margin-bottom: 20px;
  }
</style>
