<template>
  <el-dialog :title="form_title"  size="small" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
    <el-form :model="form" ref="userForm" :rules="rules">
      <el-form-item label="登录账号" prop="userAccount" :label-width="formLabelWidth">
        <el-input @change="verifyDisabled" :disabled="isDisabled" v-model="form.userAccount" placeholder="请输入后查询" auto-complete="off"></el-input>
        <el-button :loading="onSearchLoading" :disabled="isDisabled" type="primary" @click="onSearch">查询</el-button>
      </el-form-item>
      <el-form-item label="姓名" prop="userName" :label-width="formLabelWidth">
        <el-input :disabled="isDisabled" v-model="form.userName" auto-complete="off"></el-input>
      </el-form-item>
      <!--<el-form-item label="密码" prop="dsrcCode" :label-width="formLabelWidth">-->
        <!--<el-input type="passWord" v-model="form.passWord" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
      <!--<el-form-item label="用户ID" prop="dsrcCode" :label-width="formLabelWidth">-->
        <!--<el-input v-model="form.userId" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
      <el-form-item label="手机号" prop="userMobileNo" :label-width="formLabelWidth">
        <el-input v-model="form.userMobileNo"></el-input>
      </el-form-item>
      <el-form-item label="有效开始时间" prop="effStartDate" :label-width="formLabelWidth">
        <el-date-picker
          v-model="form.effStartDate"
          type="date"
          placeholder="选择日期"
          @change="formatStartDate"
          format="yyyy-MM-dd HH:mm:ss"
          :picker-options="pickerOptions0">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="有效结束时间" prop="effEndDate" :label-width="formLabelWidth">
        <el-date-picker
          v-model="form.effEndDate"
          type="date"
          @change="formatEndDate"
          format="yyyy-MM-dd HH:mm:ss"
          placeholder="选择日期"
          :picker-options="pickerOptions0">
        </el-date-picker>
      </el-form-item>
      <!--<el-form-item label="默认语言"  prop="dsrcCode":label-width="formLabelWidth">-->
        <!--<el-input v-model="form.languageCode" auto-complete="off"></el-input>-->
      <!--</el-form-item>-->
      <el-form-item label="岗位" prop="positionName" :label-width="formLabelWidth">
        <el-input v-model="form.positionName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="邮箱" prop="userEmail" :label-width="formLabelWidth">
      <el-input v-model="form.userEmail" auto-complete="off"></el-input>
      </el-form-item>
      <!--<el-form-item label="是否锁定" prop="dsrcCode" :label-width="formLabelWidth">-->
        <!--<el-radio v-model="form.userIsLock" label="N">锁定</el-radio>-->
        <!--<el-radio v-model="form.userIsLock" label="Y">解锁</el-radio>-->
      <!--</el-form-item>-->
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="commitForm('userForm')" :disabled="isCommit">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  export default {
    name: 'UserTableModel',
    data () {
      return {
        isDisabled: false,
        isCommit: true,
        dialogFormVisible: false,
        onSearchLoading: false,
        form: {
          effEndDate: '',
          effStartDate: '',
          languageCode: '',
          passWord: '',
          positionName: '',
          userAccount: '',
          userEmail: '',
          userMobileNo: '',
          userName: '',
          uuid: ''
        },
        formLabelWidth: '120px',
        rules: {
          effEndDate: [{ required: true, message: '内容不能为空', trigger: 'change' }],
          effStartDate: [{ required: true, message: '内容不能为空', trigger: 'change' }],
          positionName: [{ message: '内容不能为空', trigger: 'blur' }],
          userAccount: [{ required: true, message: '内容不能为空', trigger: 'change' }],
          userEmail: [{ message: '内容不能为空', trigger: 'change' }],
          userMobileNo: [{ message: '内容不能为空', trigger: 'change' }],
          userName: [{ required: true, message: '内容不能为空', trigger: 'change' }]
        },
        pickerOptions0: {
          disabledDate (time) {
            return time.getTime() < Date.now() - 8.64e7
          }
        },
        FORM_STATE: 0, // 表单状态 0提交,1修改,2删除,默认为0
        form_title: '新增用户'
      }
    },
    methods: {
      commitForm (userForm) { // 提交表单
        this.$refs[userForm].validate((valid) => {
          if (valid) {
            let params = this.form
            this.$store.dispatch('user/setUserTableRow', params).then((res) => {
              console.log('usrForm', res)
              if (res.status === 200 && res.data && res.data.__statusCode === '1') {
                this.$store.dispatch('user/getUserList')
                this.$message({
                  type: 'success',
                  message: '提交成功!'
                })
                setTimeout(() => {
                  this.dialogFormVisible = false
                }, 500)
              } else {
                this.$message({
                  type: 'info',
                  message: '提交失败!'
                })
              }
            })
          } else {
            return false
          }
        })
      },
      changeTableRow (val) { // 修改行 只支持单行修改
        console.log(11, val)
        this.form = {
          effEndDate: val.effEndDate,
          effStartDate: val.effStartDate,
          languageCode: val.languageCode,
          positionName: val.positionName,
          passWord: val.passWord,
          userAccount: val.userAccount,
          userEmail: val.userEmail,
          userMobileNo: val.userMobileNo,
          userName: val.userName,
          uuid: val.uuid
        }
      },
      onSearch () {
        let params = {}
        params.userAccount = this.form.userAccount
        if (!this.form.userAccount) {
          this.$message({
            type: 'info',
            message: '请输入账号'
          })
          return
        }
        this.onSearchLoading = true
        this.$store.dispatch('user/checkUser', params).then((res) => {
          console.log(res)
          // 全掉ldap查询, edit by chenqy9 at 2018-07-13
          this.onSearchLoading = false
          // 用户存在
          if (res.data.__statusCode === '0') {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          } else { // 用户不存在
            this.isCommit = false
            this.$message({
              type: 'success',
              message: '用户名可用'
            })
          }

          /* if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            let params = {}
            params.user_account = this.form.userAccount
            this.$store.dispatch('user/searchUser', params).then(res => {
              if (res.data && res.status === 200 && res.data.data && res.data.__statusCode === '1') {
                console.log('search2', res)
                let paseData = JSON.parse(res.data.data)
                this.form.userName = paseData.userName
                this.form.userAccount = paseData.userAccount
              } else {
                this.$message({
                  type: 'info',
                  message: res.data.__errorMessage + '可用'
                })
              }
              this.isCommit = false
              this.onSearchLoading = false
            })
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
            this.onSearchLoading = false
          } */
        })
      },
      formatEndDate (val) {
        console.log(val)
        this.form.effEndDate = val
      },
      formatStartDate (val) {
        console.log(val)
        this.form.effStartDate = val
      },
      verifyDisabled (val) {
        this.isCommit = true
//        this.onSearchLoading = false
      }
    },
    created () {
      this.eventHub.$on('showUserDialog', () => { // 新增用户事件监听
        this.form_title = '新增用户'
        this.isDisabled = false
        this.isCommit = true
        this.dialogFormVisible = true
        this.form = {
          effEndDate: '',
          effStartDate: '',
          languageCode: '',
          positionName: '',
          userAccount: '',
          userEmail: '',
          userId: '',
          userIsLock: 'N',
          userMobileNo: '',
          userName: ''
        }
      })
      this.eventHub.$on('showUserDialogChange', (val) => { // 新增用户事件监听
        this.form_title = '修改用户信息'
        this.dialogFormVisible = true
        this.isDisabled = true
        this.isCommit = false
        let params = val.uuid
        this.$store.dispatch('user/getUserDetail', params).then((res) => {
          if (res.status === 200 && res.data && res.data.data) {
            this.changeTableRow(res.data.data)
          } else {
            this.$message({
              type: 'info',
              message: '获取用户详情失败'
            })
          }
        })
      })
    }
  }
</script>

<style lang="scss" scoped>
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  .el-input {
    max-width: 200px;
  }
</style>
