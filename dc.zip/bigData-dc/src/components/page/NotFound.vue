<template>
  <div class="component-not-found">
    <div class="container-content">
      <h3>Oppos ! 404 NOT FOUND !</h3>
      <h3>糟糕 ，找不到对象 ！</h3>
      <router-link to="/">返回首页</router-link>
    </div>
  </div>
</template>

<style lang="scss" scoped>
  .component-not-found {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }
</style>

<script>
export default {
  name: 'notFound'
}
</script>


