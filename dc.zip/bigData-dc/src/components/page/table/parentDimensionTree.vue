<template>
  <div class="parent_dimension_wrap">
    <!-- <el-breadcrumb separator=">" style="line-height: 36px;">
      <el-breadcrumb-item>维表级联设置</el-breadcrumb-item>
      <el-breadcrumb-item>{{currentRow.dimensions && currentRow.dimensions[0].dbName}}</el-breadcrumb-item>
      <el-breadcrumb-item>{{currentRow.dimensions && currentRow.dimensions[0].tableName}}</el-breadcrumb-item>
      <el-breadcrumb-item>
        <span v-for="(item,i) in currentRow.dimensions">{{item.dimensionName}}&nbsp;&nbsp;</span>
      </el-breadcrumb-item>
      <el-button type="primary" @click="rightTreeShow" :disabled="isDisable">确认选择左表</el-button>
    </el-breadcrumb> -->

    <el-row :gutter="10">
      <el-col :span="12">
        <div class="selecText">
          <span>已选左表维度：</span>
          <span  v-show="this.leftCulumShow">
            <span>{{selectLeftDatasource}}</span>
            <span> >> </span>
            <span>{{selectLeftTable}}</span>
            <span> >> </span>
            <span class="">{{selectLeftCulum}}</span>
          </span>
        </div>
        <div class="grid-content bg-purple tree-wrap tree-left-wrap">
          <el-tree
            :data="treeDataLoading"
            :props="defaultProps"
            @current-change="leftNodeClickChange"
            :load="leftLoadNode"
            highlight-current
            node-key="uuid"
            lazy
            ref="leftParentDimentTreeLoading"
            :render-content="leftrenderContent">
          </el-tree>
        </div>
      </el-col>

      <el-col :span="12" v-show="this.rightShow">
        <div class="selecText">
          <span>已选右表维度：</span>
          <span v-if="hasChosed">{{chosedData}}</span>
          <span v-else v-show="this.rightCulumShow">
            <span class="">{{selectRightDatasource}}</span>
            <span> >> </span>
            <span class="">{{selectRightTable}}</span>
            <span> >> </span>
            <span class="">{{selectRightCulum}}</span>
          </span>
        </div>
        <div class="grid-content bg-purple-light tree-wrap tree-right-wrap">
          <el-tree
            :data="treeDataLoading"
            :props="defaultProps"
            highlight-current
            @current-change="rightNodeClickChange"
            :load="rightLoadNode"
            lazy
            ref="rightChildDimentTreeLoading"
            :render-content="rightrenderContent">
          </el-tree>
        </div>
      </el-col>
    </el-row>
    <div slot="footer" class="dialog-footer" style="margin-top: 20px!important;">
      <!-- <el-button @click="resetChecked">取 消</el-button> -->
      <el-button type="primary" @click="insertDimension" class="submit-btn" :disabled="commitDisable">确认设置</el-button>
    </div>
  </div>
</template>

<script>
  // import lodash from 'lodash'

  export default {
    name: 'parentDimensionTree',
    data () {
      return {
        form_title: '维表级联设置',
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        currentRow: {},
        currentTable: [], // 当前表id
        treeDataLoading: [{'name': '根目录', disabled: true}],
        flag: 1,
        leftCheckedParntId: '',
        leftCheckedNodesArray: [],
        rightCheckedParntId: [],
        rightCheckedNodesArray: [],
        rightShow: false,
        leftSelectColId: '', // 左表选中的ColId
        commitDisable: true,
        leftCulumShow: false,
        rightCulumShow: false,
        rightArrow: false, // 右表箭头
        selectLeftDatasource: '', // 左表选中数据源字段
        selectLeftTable: '', // 左表选中父级字段
        selectLeftCulum: '', // 左表选中子级字段
        selectRightDatasource: '', // 右表选中数据源字段
        selectRightTable: '', // 右表选中父级字段
        selectRightCulum: '', // 右表选中子级字段
        // 是否已设置
        hasChosed: true,
        chosedData: ''
      }
    },
    computed: {
      selDimensionList () {
      }
    },
    watch: {
    },
    methods: {
      leftNodeClickChange (data, checked, inde) {
      },
      rightNodeClickChange (data, checked, inde) {
      },
      leftSelectData (node, data, store) {
        if (data.type === 'column') {
          // 右表显示
          this.rightShow = true
          // 左表选中显示
          this.leftCulumShow = true
          this.selectLeftDatasource = data.name_export1
          this.selectLeftTable = data.name_export
          this.selectLeftCulum = data.name
          // other
          this.leftCheckedNodesArray[0] = data.uuid.slice(7)
          this.leftSelectColId = data.uuid.slice(7)
          this.leftCheckedParntId = data.parentid.slice(6)
          this.$store.dispatch('parentDimension/getContent', {colId: this.leftSelectColId}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              if (res.data.data === '') {
                this.hasChosed = false
              } else {
                this.hasChosed = true
                this.chosedData = res.data.data
                this.commitDisable = true
              }
            } else {
              console.log('left select data fault')
            }
          })
        }
      },
      rightSelectData (node, data, store) {
        if (data.type === 'column') {
          // 左表选中显示
          if (data.parentid.slice(6) === this.leftCheckedParntId) {
            this.commitDisable = true
            return this.$message({
              type: 'info',
              message: '不能选择同一张表!'
            })
          } else {
            this.hasChosed = false
            this.commitDisable = false
            this.rightCulumShow = true
            this.selectRightDatasource = data.name_export1
            this.selectRightTable = data.name_export
            this.selectRightCulum = data.name
            this.rightCheckedNodesArray[0] = data.uuid.slice(7)
            this.$store.dispatch('parentDimension/getContent', {colId: this.leftSelectColId}).then(res => {
              if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              } else {
                console.log('right select data fault')
              }
            })
          }
        } else {
          this.leftCheckedNodesArray.length = 0
          this.leftCheckedParntId = ''
          this.rightShow = false
        }
      },
      insertDimension () {
        this.$store.dispatch('parentDimension/postParentDimensionData', {columnId: this.leftCheckedNodesArray[0], parentColumnId: this.rightCheckedNodesArray[0]}).then(res => {
          if (res.data && res.status === 200 && res.data.__statusCode === '1') {
            this.$message({
              type: 'success',
              message: '提交成功!'
            })
          } else {
            this.$message({
              type: 'info',
              message: '提交失败!'
            })
          }
        })
        // }
      },
      resetChecked () {
      },
      // left加载数据
      leftLoadNode (node, resolve) {
        if (node.level === 0) {
          return resolve([{'name': '根目录', disabled: true}])
        }
        if (node.level > 3) return resolve([])
        if (node.level === 1) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'datasource', flag: 1}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.flag = 0
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 2) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'table', uuid: node.data.uuid.slice(11), flag: 1}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.flag = 0
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 3) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'column', uuid: node.data.uuid.slice(6), flag: 1}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.flag = 0
              let res_ = JSON.parse(res.data.data).map((item) => {
                if (item.dbid) {
                  item.disabled = false
                }
                return item
              })
              return resolve(res_)
            }
          })
        }
      },
      // right加载数据
      rightLoadNode (node, resolve) {
        let leftDataLen = this.leftCheckedNodesArray.length
        if (node.level === 0) {
          if (leftDataLen === 0 && !this.rightShow) {
            return resolve([{'name': '根目录', disabled: true}])
          }
        }
        if (node.level > 3) return resolve([])
        if (node.level === 1) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'datasource', flag: this.flag}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 2) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'table', uuid: node.data.uuid.slice(11), flag: this.flag}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              return resolve(JSON.parse(res.data.data))
            }
          })
        }
        if (node.level === 3) {
          this.$store.dispatch('parentDimension/getParentDimensionTree', {type: 'column', uuid: node.data.uuid.slice(6), colId: this.leftSelectColId, flag: this.flag}).then(res => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              let res_ = JSON.parse(res.data.data).map((item) => {
                if (item.dbid) {
                  item.disabled = false
                }
                return item
              })
              return resolve(res_)
            }
          })
        }
      },
      leftrenderContent (h, {node, data, store}) {
        if (node.level === 4) {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          <span style="float: right; margin-right: 20px">
            <el-button type="primary" size="mini" on-click={ () => this.leftSelectData(node, data, store) }>选择</el-button>
          </span>
          </span>)
        } else {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          </span>)
        }
      },
      rightrenderContent (h, {node, data, store}) {
        if (node.level === 4) {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          <span style="float: right; margin-right: 20px">
            <el-button type="primary" size="mini" on-click={ () => this.rightSelectData(node, data, store) }>选择</el-button>
          </span>
          </span>)
        } else {
          return (
            <span>
            <span>
            <span>{node.label}</span>
          </span>
          </span>)
        }
      }
    },
    mounted () {
      this.eventHub.$on('showDimensionTree', (val) => {
        this.currentRow = val
      })
    }
  }
</script>

<style lang="scss" scoped>
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  .el-input {
    width: 300px;
  }
  .selecText {
    color: red;
    line-height: 30px;
    font-size: 14px;
    width: 100%;
    box-sizing: border-box;
    margin: 10px auto;
  }
  .tree-wrap{
    height: 60vh;
    max-height: 400px;
    overflow-y: auto;
    border: 1px solid #d1dbe5;
    .el-tree-node__content {
      background-color: #eef1f6!important;
    }
    .el-tree {
      border: none!important;
    }
  }
  .submit-btn {
    // margin:10px 0;
  }
</style>
