<template>
  <div class="component-user-admin">
    <table-page-layout id="DynamicTableId" v-loading="loading"
                       target="#DynamicTableId"
                       :element-loading-text="$t('common.loadingText')"
                       :showSearch="true">
      <!--配置字段-->
      <search-bar @setColumn="setColumn" slot="searchbar" :setSelTabelColumn="setSelTabelColumn" @searchCache="searchCache"></search-bar>
      <!--表格头部-->
      <tool-bar ref="toolbar" slot="toolbar" :showDown="true" :isDisabled="isDurisdiction" :tableAlignAble="true"
                @create="create" @update="update" @delete="remove" @adjustAlign="adjustAlign"  @search="search"  @setColumn="setColumn" :colDtos="colDtos" >
        <el-upload class="upload-demo"
                   slot="importButton"
                   :show-file-list="false"
                   :on-error="upError"
                   :on-progress="upprogress"
                   :on-success="upSuccess"
                   :action="api.form_table.importExel + '?tableId=' + $route.params.uuid"
                   :on-preview="handlePreview"
                   :disabled="!isDurisdiction"
                   :on-remove="handleRemove">
          <!-- :file-list="fileList" -->
          <el-button :disabled="!isDurisdiction" type="primary">{{ $t('common.importData')}}</el-button>
          <!-- <div slot="tip" class="el-upload__tip">只能上excel文件</div> -->
        </el-upload>
      </tool-bar>
      <!--表格-->
      <!--
        @author chenqy9
        @description 固定表格头部，高度为100%
        @date 2018-08-23
        TODO: 固定头部，表格头部会多一个gutter，应该是
        element-ui为了预留位置给滚动条自动加上的，看是否
        需要美化处理
       -->
      <el-row slot="table"  v-show="tableMssList.length">
        <el-col :span="24">
          <el-tooltip class="item" effect="dark" :content="$t('common.refuseInfoList')" placement="top-start">
            <el-button type="primary" @click="refreshMssList">{{$t('common.refresh')</el-button>
          </el-tooltip>
        </el-col>
      </el-row>
      <el-table slot="table"
                v-show="tableMssList.length"
                v-loading="loadingMss"
                :element-loading-text="$t('common.hardRefresh')"
                border
                style="margin-bottom: 10px"
                :data="tableMssList"
                tooltip-effect="dark">
        <el-table-column
          type="index"
          width="55"
          header-align="center">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="调度组主题" prop="projectAlias">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="调度组状态" prop="mssState">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="操作" width="170">
          <template slot-slot-scope="scope">
            <el-button type="primary" size="mini" @click="reRun(scope.row)"><i class="fa fa-play" aria-hidden="true"></i></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-table slot="table"
                height="100%"
                border
                @row-click="rowClick"
                ref="multipleTable"
                :data="tableList"
                tooltip-effect="dark"
                @sort-change="sortChange"
                @selection-change="handleSelectionChange"
                @row-dblclick="rowDbclick"
                style="width: 100%; height: 100%;">
        <el-table-column
          type="selection"
          width="55"
          header-align="center">
        </el-table-column>
        <el-table-column
          type="index"
          width="55"
          header-align="center">
        </el-table-column>
        <el-table-column :width="(col.formName + '('+ col.colName +')').length * 10"
                         :show-overflow-tooltip="true"
                         v-for="(col,index) in tableHeader"
                         :key="index" :label="col.formName || col.colName "
                         :class-name="'className'"
                         :label-class-name="'label-class-name_' + col.colName"
                         :prop="col.dimension?col.colName+'_des':col.colName"
                         sortable="custom"
                         :align="colAlign"
                         header-align="center">
        </el-table-column>
      </el-table>
      <pager slot="pager" :currentSize="rownum" :currentPage="pagenum"  @sizeChange="sizeChange"  :totalPage="pageCount" @switchPage="switchPage"></pager>
    </table-page-layout>
  </div>
</template>

<script>
import SearchBar from './common/SearchBar'
import TablePageLayout from './TablePageLayout.vue'
import ToolBar from './common/ToolBar'
import Pager from './common/Pager'
import DialogPanel from './common/DialogPanel'
import API from '../../assets/js/api'
export default {
  name: 'dynamicTable',
  data () {
    return {
      multipleSelection: [],
      api: API,
      fileList: [],
      loading: true,
      loadingMss: false,
      fullscreenLoading: false,
//      box: false, // 进度条显示
      colName: '', // 排序name
      formValue: '', // 排序方式 升,降
      colDtos: [], // 搜索字段
      colAlign: 'center',  // 对齐方式
      tipsVisible: false,
      currentRowDetail: []
    }
  },
  computed: {
    userList () {
      return this.$store.state.user.list
    },
    columns () {
      return this.$store.state.user.columns
      // let list = []
      // for (let x in this.userList[0]) {
      //   list.push(x)
      // }
      // console.log(list)
      // return list
    },
    pageCount () {
      return this.$store.state.formTable.pageTotalCount
    },
    tableList () {
//      return this.$store.state.formTable.tableList
      return this.$store.getters['formTable/tableList_']
    },
    tableHeader () {
      return this.$store.state.formTable.tableHeader
    },
    routeParams () {
      return this.$route.params.uuid
    },
    handleRemove (file, fileList) {
      console.log(file, fileList)
    },
    handlePreview (file) {
      console.log(file)
    },
    isDurisdiction () {
      return this.$store.state.formTable.isDurisdiction
    },
    setSelTabelColumn () {
      return this.$store.state.formTable.setSelTabelColumn
    },
    pagenum () {
      return this.$store.state.formTable.pagenum
    },
    rownum () {
      return this.$store.state.formTable.rownum
    },
    sortCols () {
      return this.$store.state.formTable.sortCols
    },
    tableMssList () {
      return this.$store.state.formTable.tableMssList
    }
  },
  watch: {
    pageCount (newVal) {
      console.log('pageCount:' + newVal)
//      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, pagenum: newVal})
    },
    routeParams (newVal) {
      this.loading = true
      this.$store.dispatch('formTable/getTableHeader2', newVal)
      this.$store.dispatch('formTable/getTableList', {tableUUID: newVal}).then((res) => {
        if (res.data && res.status === 200 && res.data.__statusCode === '1') {
//          this.loading = false
        }
      })
      this.$store.dispatch('formTable/getDimeList', newVal)
      // 获取用户配置的搜索字段
      // 清空缓存
      this.$store.commit('formTable/setPagenum', 1)
      this.$store.commit('formTable/setRownum', 10)
      this.$store.commit('formTable/setSortCols', {})
      this.colDtos = []
      this.$store.dispatch('formTable/getUserSearchColumn', {tableUuid: this.$route.params.uuid})
      // 获取 tableMss 列表
      this.$store.dispatch('formTable/getTableMssList', this.$route.params.uuid)
    },
    tableList () {
      this.loading = false
    },
    setSelTabelColumn () {
      setTimeout(() => {
        this.adaptTbalePadding()
      }, 0)
    }
  },
  created () {
    // 获取用户列表
    this.$store.dispatch('user/getUserList')
    // 获取维度list
    this.$store.dispatch('formTable/getDimeList', this.$route.params.uuid)
    // 获取 table 列表
    this.$store.dispatch('formTable/getTableHeader2', this.$route.params.uuid)
    this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid}).then((res) => {
      if (res.data && res.status === 200 && res.data.__statusCode === '1') {
//        this.loading = false
      }
    })
    // 获取用户配置的搜索字段
    this.$store.dispatch('formTable/getUserSearchColumn', {tableUuid: this.$route.params.uuid})
    // 获取 tableMss 列表
    this.$store.dispatch('formTable/getTableMssList', this.$route.params.uuid)
  },
  mounted () {
    window.onresize = this.adaptTbalePadding
    this.adaptTbalePadding()
  },
  methods: {
    adaptTbalePadding () {
      let searchBarHeight = document.getElementsByClassName('container-searchbar')[0].offsetHeight
      let table = document.getElementsByClassName('container-table')[0]
      table.style.paddingTop = searchBarHeight + 46 + 10 + 'px'
    },
    create () {
      this.eventHub.$emit('showDynamicInput')
    },
    update () {
      if (this.multipleSelection.length === 0) {
        return this.open1()
      } else if (this.multipleSelection.length > 1) {
        return this.$message({
          type: 'info',
          message: '不支持多行修改!'
        })
      }
      this.eventHub.$emit('showDynamicInputChange', this.multipleSelection[0])
    },
    remove () {
      if (this.multipleSelection.length === 0) {
        return this.$message({
          type: 'info',
          message: '请选择!'
        })
      }
      this.open2()
//      this.eventHub.$emit('showDynamicInputDel', this.multipleSelection[0])
    },
    search () {
      this.eventHub.$emit('DynamicTableSearchModel')
    },
    setColumn () {
      this.eventHub.$emit('DynamicTableSearchModel2')
    },
    /*
    * 缓存搜索字段
    * ouzm1 20180820
    */
    searchCache (colDtos) {
      console.log('colDtos222', colDtos)
      this.$refs.toolbar.colDtos = colDtos
      this.colDtos = colDtos
    },
    switchPage (pageNum) {
      this.$store.commit('formTable/setPagenum', pageNum)
      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, pagenum: this.pagenum, rownum: this.rownum, sortCols: this.sortCols, colDtos: this.colDtos})
    },
    handleSelectionChange (val) { // select 事件
      console.log(val)
      this.multipleSelection = val
//      if (val.length > 1) {
//        this.$refs.multipleTable.clearSelection()
//        this.$refs.multipleTable.toggleRowSelection(val[0])
//        this.$message({
//          type: 'info',
//          message: '暂不支持多行操作!'
//        })
//      } else {
//        this.multipleSelection = val
//      }
    },
    // 双击显示行详情
    rowDbclick (row, event) {
      console.log(row, event, this.tableHeader)
      this.tipsVisible = true
      this.currentRowDetail.length = 0
      this.tableHeader.forEach((col, index) => {
        console.log(col.formName, col.colName)
        this.currentRowDetail.push({
          colName: col.formName || col.colName,
          value: row[col.dimension ? col.colName + '_des' : col.colName]
        })
      })
      this.eventHub.$emit('showRowDetailDialog', this.currentRowDetail)
    },
    changeTableRow (val) { // 删除行，支持多行修改  ouzm1 20180830
      let form = {}
      let length = this.tableHeader.length
      if (length === 0) return []
      for (let i = 0; i < length; i++) {
        form[this.tableHeader[i].formAttributeName] = val[this.tableHeader[i].colName]
      }
      form.id = val.id
      form.tableUUID = this.$route.params.uuid
      this.$store.dispatch('formTable/delTableRow', form).then((res) => {
        if (res.status === 200 && res.data.__statusCode === '1') {
          this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, rownum: this.rownum, pagenum: this.pagenum, sortCols: this.sortCols, colDtos: this.colDtos})
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        } else {
          this.$message({
            type: 'info',
            message: res.data ? res.data.__errorMessage : '删除失败'
          })
        }
      })
    },
    open1 () {
      this.$notify({
        title: '请选择需要修改的行',
        type: 'success'
      })
    },
    open2 () {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // ouzm1 20180331 删除接口改变
        let form = {}
        form.tableUUID = this.$route.params.uuid
        form.formList = JSON.stringify(this.multipleSelection)
        console.log(form)
        this.$store.dispatch('formTable/delTableRow', form).then((res) => {
          if (res.status === 200 && res.data && res.data.__statusCode === '1') {
            this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, rownum: this.rownum, pagenum: this.pagenum, sortCols: this.sortCols, colDtos: this.colDtos})
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          } else {
            this.$message({
              type: 'info',
              message: res.data ? res.data.__errorMessage : '删除失败'
            })
          }
        })
//        this.changeTableRow(this.multipleSelection[0])
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    rowClick (row, event, colum) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    upprogress (event, file, fileLis) { // 文件加载
      this.eventHub.$emit('isShow')
    },
    upError (res, file, fileList) {
      this.eventHub.$emit('ishidden')
      this.$message({
        type: 'info',
        message: '上传失败'
      })
    },
    upSuccess (res, file, fileList) {
      setTimeout(() => {
        this.eventHub.$emit('ishidden')
        if (res.__statusCode === '1') {
          this.$message({
            type: 'success',
            message: res.data
          })
        } else {
          console.warn(res)
          this.$notify.error({
            title: res.data || '上传失败',
            message: res.__errorMessage,
            duration: 0
          })
        }
      }, 500)
      // 获取用户列表
      this.$store.dispatch('user/getUserList')
      // 获取 table 列表
      this.$store.dispatch('formTable/getTableHeader2', this.$route.params.uuid)
      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid})
    },
    hoverTooltip () {
      console.log('dom', window.$('thead [class*=label-class-name_]'))
    },
    sizeChange (size) {
      this.$store.commit('formTable/setRownum', size)
      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, rownum: this.rownum, sortCols: this.sortCols, colDtos: this.colDtos})
    },
    sortChange ({column, prop, order}) {
      let sortObj = {
        colName: prop,
        formValue: order === 'descending' ? 'desc' : 'asc'
      }
      console.log('colDtos', this.colDtos)
      this.$store.commit('formTable/setSortCols', sortObj)
      this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid, pagenum: this.pagenum, rownum: this.rownum, sortCols: this.sortCols, colDtos: this.colDtos})
    },
    // 设置对齐方式
    adjustAlign (direction) {
      this.colAlign = direction
    },
    reRun (row) {
      this.$confirm('确定重启该组下启用的作业? 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$store.dispatch('formTable/reRun', {id: row.uuid}).then(res => {
          if (res.status === 200 && res.data && res.data.__statusCode === '1') {
            const result = res.data
            const data = result.data
            this.$message({
              type: 'success',
              message: data
            })
          } else {
            this.$message({
              type: 'info',
              message: res.data.__errorMessage
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消'
        })
      })
    },
    refreshMssList () {
      // 获取 tableMss 列表
      this.loadingMss = true
      this.$store.dispatch('formTable/getTableMssList', this.$route.params.uuid).then(() => {
        this.loadingMss = false
      })
    }
  },
  components: {
    TablePageLayout,
    ToolBar,
    Pager,
    DialogPanel,
    SearchBar
  }
}
</script>

<style lang="scss" >
.component-user-admin{
  position: relative;
  width: 100%;
  height: 100%;
  .el-popover {
    .tip-popover-title {
      font-size: 18px;
      color: #7b7a7a;
    }
    #popover{
      .el-table__row {
        height: 34px;
        .tips-cell {
          height: 34px;
          .cell {
            padding-left: 8px;
            padding-right: 8px;
          }
        }
        .tips-cell-label {
          .cell {
            font-weight: bold;
          }
        }
      }
    }
  }

  .el-loading-mask{
    background-color: rgba(0,0,0,0.5);
    width: 200px;
    height: 140px;
    z-index: 55;
    top:calc(50% - 70px);
    left: calc(50% - 100px);
    border-radius: 5px;
    .el-loading-spinner .path{
      stroke: #fff!important;
    }
    .el-loading-text{
      color: #fff!important;

    }
  }
}

</style>
