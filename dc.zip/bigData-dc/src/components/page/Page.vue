<template>
  <div class="component-page" id="my-scroll-page">
   <transition>
		  <router-view></router-view>
		 </transition>
	 
  </div>
</template>

<style lang="scss" scoped>
  .component-page {
    position: relative;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    padding: 10px 20px;
    overflow-y: auto;
		background: #fff;
  }
</style>

<script>
export default {
  name: 'page',
  created () {
    this.$router.push('/')
  }
}
</script>

