<template>
  <el-dialog title="新增数据库表" size="large" :visible.sync="dialogFormVisible" @close="shutdown" :close-on-click-modal="false">
    <!--表单-->
    <el-form ref="tableForm" :model="table">
      <el-form-item label="表名称"  prop="tableName"
                    :rules="{validator: myRules.tableName, required: true, trigger: 'change'}">
        <el-input v-model="table.tableName" placeholder="请输入表名称"></el-input>
      </el-form-item>
      <el-form-item label="表注释">
        <el-input v-model="table.tableComment" placeholder="请输入表注释"></el-input>
      </el-form-item>
      <el-form-item label="是否维表">
        <el-switch
          v-model="table.dimensionTable"
          on-text="是"
          @change="delDimension"
          off-text="否">
        </el-switch>
      </el-form-item>
      <!--<el-form-item label="有无权限">
        <el-switch
          v-model="table.jurisdiction"
          on-text="有"
          off-text="无">
        </el-switch>
      </el-form-item>-->
      <el-form-item label="表字段列表" prop="tableColumns">
        <el-button @click="addColumn" type="primary" size="mini" icon="plus"></el-button>
        <!--
        @author cehnqy9
        @description 增加操作提示
      -->
        <div class="msg msg-confirm">
          <p>
            <span class="el-icon-information"></span>
            <strong><em>“列名”</em></strong>、<strong><em>“控件标签”</em></strong>
            是必填项目
          </p>
        </div>
        <el-table
          class="reset"
          :data="table.tableColumns"
          style="width: 100%">
          <el-table-column
            fixed
            width="120"
            label="上移下移">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" class="el-icon-arrow-up" @click="moveUp(scope.$index)"></el-button>
              <el-button type="primary" size="mini" class="el-icon-arrow-down" @click="moveDown(scope.$index)"></el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="colName"
            fixed
            width="120"
            label="列名">
            <template slot-scope="scope">
              <el-form-item :prop="'tableColumns.' + scope.$index + '.colName'"
                            :rules="{required: true, message: ' ', trigger: 'change'}">
                <el-input placeholder="必填" v-model="table.tableColumns[scope.$index].colName" @blur="show(scope)"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="formName"
            fixed
            width="120"
            label="控件标签">
            <template slot-scope="scope">
              <el-form-item prop="requiredField"
                            :prop="'tableColumns.' + scope.$index + '.formName'"
                            :rules="{required: true, message: ' ', trigger: 'change'}">
                <el-input  placeholder="必填" v-model="scope.row.formName"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="primaryKey"
            width="120"
            label="是否主键">
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.primaryKey"
                on-text="是"
                @change="isMajor(scope.row)"
                off-text="否">
              </el-switch>
            </template>
          </el-table-column>
          <el-table-column
            prop="dimension"
            width="120"
            label="是否关联维度">
            <template slot-scope="scope">
              <el-switch
                :disabled="table.dimensionTable"
                v-model="scope.row.dimension"
                on-text="是"
                off-text="否">
              </el-switch>
            </template>
          </el-table-column>
          <el-table-column
            prop="colEmpty"
            width="120"
            label="允许为空">
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.colEmpty"
                on-text="是"
                off-text="否"
                @change="changeColEmpty(scope.row)">
              </el-switch>
            </template>
          </el-table-column>
          <el-table-column
            prop="colType"
            width="170"
            label="字段类型">
            <template slot-scope="scope">
              <el-form-item>
                <el-select v-model="scope.row.colType" :disabled="originTableColumns[scope.$index]&&originTableColumns[scope.$index].primaryKey === true">
                  <el-option
                    v-for="item in tableColumnTypes"
                    :key="item"
                    :label="item"
                    :value="item">
                  </el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colSize"
            width="120"
            label="字段长度">
            <template slot-scope="scope">
              <el-form-item
                :prop="'tableColumns.' + scope.$index + '.colSize'"
                :rules="{type: 'number', message: ' ', trigger: 'change'}">
                <el-input placeholder="必填(数字)" v-model.number="scope.row.colSize"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colDefaultValue"
            width="170"
            label="默认值">
            <template slot-scope="scope">
              <el-form-item>
                <el-input v-model="scope.row.colDefaultValue" :placeholder="scope.row.colType === 'TIMESTAMP' ? 'Y-M-D hh:mm:ss': ''"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colPointSize"
            width="120"
            label="浮点长度">
            <template slot-scope="scope">
              <el-form-item
                :prop="'tableColumns.' + scope.$index + '.colPointSize'"
                :rules="{type: 'number', message: ' ', trigger: 'change'}">
                <el-input placeholder="必填(数字)" v-model.number="scope.row.colPointSize"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="controlsType"
            width="170"
            label="控件类型">
            <template slot-scope="scope">
              <el-form-item>
                <!--<el-select v-model="scope.row.controlsType">-->
                <!--<el-option-->
                <!--v-for="item in tableControlsTypes"-->
                <!--:key="item"-->
                <!--:label="item"-->
                <!--:value="item">-->
                <!--</el-option>-->
                <el-select v-model="scope.row.controlsType">
                  <!--<el-option label="TEXT" value="TEXT"></el-option>-->
                  <!--<el-option label="TEXTAREA" value="TEXTAREA"></el-option>-->
                  <!--<el-option label="PASSWORD" value="PASSWORD"></el-option>-->
                  <!--<el-option label="TIMESTAMP" value="TIMESTAMP"></el-option>-->
                  <el-option :label="item" :value="item" v-for="(item, i) in inputLink(scope.row)" :key="i"></el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="regular"
            width="170"
            label="验证规则">
            <template slot-scope="scope">
              <el-form-item>
                <el-select  clearable v-model="scope.row.regular" placeholder="请选择(可为空)">
                  <el-option :label="item.value" :value="item.key" v-for="(item, i) in getRegularType" :key="i"></el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            v-if="false"
            prop="formAttributeName"
            width="120"
            label="控件名称">
            <template slot-scope="scope">
              <el-form-item prop="requiredField">
                <el-input v-model="scope.row.formAttributeName"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colComment"
            width="120"
            label="注释">
            <template slot-scope="scope">
              <el-form-item>
                <el-input v-model="scope.row.colComment"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colName"
            fixed="right"
            width="70"
            label="删除">
            <template slot-scope="scope">
              <el-button type="primary" @click="removeColumn(scope.$index)" size="mini" icon="close"></el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="dimension"
            fixed="right"
            width="100"
            label="关联维度">
            <template slot-scope="scope">
              <el-button type="primary" v-if="scope.row.dimension" @click="addDimension(scope.row)" size="mini" icon="plus"></el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="自定义调度组列表" prop="tableColumns" v-if="mssFunction">
        <el-button @click="addMssColumn" type="primary" size="mini" icon="plus"></el-button>
        <el-table
          class="reset"
          :data="table.tableMssList"
          style="width: 100%">
          <el-table-column
            prop="colName"
            label="调度组名称">
            <template slot-scope="scope">
              <el-form-item :prop="'tableMssList.' + scope.$index + '.projectName'"
                            :rules="{required: true, message: ' ', trigger: 'change'}">
                <el-input placeholder="必填" v-model="scope.row.projectName"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="formName"
            label="调度组主题">
            <template slot-scope="scope">
              <el-form-item prop="requiredField"
                            :prop="'tableMssList.' + scope.$index + '.projectAlias'"
                            :rules="{required: true, message: ' ', trigger: 'change'}">
                <el-input  placeholder="必填" v-model="scope.row.projectAlias"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column
            prop="colEmpty"
            width="120"
            label="是否开启">
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.enable"
                on-text="是"
                off-text="否">
              </el-switch>
            </template>
          </el-table-column>
          <el-table-column
            prop="colName"
            width="70"
            label="删除">
            <template slot-scope="scope">
              <el-button type="primary" @click="table.tableMssList.splice(scope.$index, 1)" size="mini" icon="close"></el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="shutdown">取 消</el-button>
      <!--<el-button type="primary" @click="commitTable">确 定</el-button>-->
      <el-button type="primary" @click="submitForm('tableForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import TableColumn from '../../assets/models/TableColumn'
  import axios from 'axios'
  import API from '../../assets/js/api'
  import qs from 'qs'
  import lodash from 'lodash'

  export default {
    name: 'tableDialog',
    // props: {
    //   params: {
    //     type: Object,
    //     default: () => {
    //       return {
    //         type: 'add',
    //         id: ''
    //       }
    //     }
    //   }
    // },
    // props: {
    //   table: {
    //     type: Object,
    //     default: {
    //       dbId: '',
    //       tableName: '',
    //       tableComment: '',
    //       tableColumns: [
    //       ]
    //     }
    //   }
    // },
    data () {
      var tableName = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('表名不能为空!'))
        } else if (!/^[a-zA-Z0-9_-]+$/.test(value)) {
          return callback('请输入正确格式(英文,数字,_,-)')
        } else {
          callback()
        }
      }
      return {
        table: {
          dbId: '',
          tableName: '',
          tableOldName: '',
          tableComment: '',
          tableColumns: [],
          dimensionTable: false,
          jurisdiction: true,
          tableMssList: []
        },
        /** 调度配置信息 */
        mssFunction: false,
        /** 调度配置信息END */
        originTableColumns: [],
        type: 'add',
        // tableColumn: {
        //   colName: '',
        //   colComment: '',
        //   colDefaultValue: '',
        //   colEmpty: true,
        //   colPointSize: 0,
        //   colSize: 255,
        //   colType: 'VARCHAR',
        //   controlsType: 'TEXT',
        //   formName: '',
        //   formAttributeName: '',
        //   primaryKey: false
        // },
        rules: {
          requiredField: [
            { required: true, message: '请输入内容', trigger: 'blur' }
          ],
          // colName: [
          //    { required: true, message: '请添加表字段', trigger: 'blur' }
          // ],
          tableColumns: [
            { required: true, message: '请添加表字段', trigger: 'blur' }
          ],
          tableName: [
            { required: true, message: '请输入表名称', trigger: 'blur' }
          ]
        },
        myRules: { // 之定义验证规则
          tableName: tableName
        },
        dialogFormVisible: false
      }
    },
    computed: {
      tableColumnTypes () {
        return this.$store.state.table.tableColumnTypes
      },
      tableControlsTypes () {
        return this.$store.state.table.tableControlsTypes
      },
      getRegularType () { // 获取验证规则list
        return this.$store.state.table.regularTypeList
      }
    },
    created () {
      this.eventHub.$on('showTableDialog', ({ type, id, dbType }) => {
        // 获取表字段类型
        this.$store.dispatch('table/getTableColumnType', dbType)
        console.log('showTableDialog')
        this.dialogFormVisible = true
        this.type = type
        let mssUuid = ''
        if (this.type === 'edit') {
          mssUuid = id
          axios.post(API.table.getTable, qs.stringify({ uuid: id })).then(response => {
            if (response.status === 200 && response.data.__statusCode === '1') {
              const result = response.data
              this.table = result.data
              this.table.tableOldName = result.data.tableName
              // let list = this.table.tableColumns
              this.originTableColumns = []
              for (let item of result.data.tableColumns) {
                item.colOldName = item.colName
                this.originTableColumns.push({primaryKey: item.primaryKey})
              }
              // this.originTableColumns = [{primaryKey: true}, {primaryKey: false}]
              console.log(response.data)
              axios.post(API.tableMss.configuration, qs.stringify({ uuid: mssUuid })).then(response => {
                if (response.status === 200 && response.data.__statusCode === '1') {
                  const result = response.data
                  this.table.tableMssList = result.data.tableMsslist || []
                  this.mssFunction = result.data.mssFunction
                } else {
                  this.$message({
                    type: 'info',
                    message: '获取调度信息失败'
                  })
                }
              }).catch(error => {
                this.$message({
                  type: 'info',
                  message: error
                })
              })
            } else {
              this.$message({
                type: 'info',
                message: '获取表数据失败'
              })
            }
          }).catch(error => {
            this.$message({
              type: 'info',
              message: error
            })
            console.error(error)
          })
        } else if (this.type === 'add') {
          this.table = {
            dbId: '',
            tableName: '',
            tableOldName: '',
            tableComment: '',
            tableColumns: [
            ],
            tableMssList: [],
            dimensionTable: false,
            jurisdiction: true
          }
          this.originTableColumns = []
          this.table.dbId = id
          axios.post(API.tableMss.configuration, qs.stringify({ uuid: mssUuid })).then(response => {
            if (response.status === 200 && response.data.__statusCode === '1') {
              const result = response.data
              this.table.tableMssList = result.data.tableMsslist || []
              this.mssFunction = result.data.mssFunction
            } else {
              this.$message({
                type: 'info',
                message: '获取调度信息失败'
              })
            }
          }).catch(error => {
            this.$message({
              type: 'info',
              message: error
            })
          })
        }
      })
      // if (this.params.type === 'edit') {
      //   axios.post(API.table.getTable, qs.stringify({ uuid: this.params.id })).then(response => {
      //     const result = response.data
      //     this.table = result.data
      //     console.log(response.data)
      //   }).catch(error => {
      //     console.error(error)
      //   })
      // } else if (this.params.type === 'add') {
      //   this.table.dbId = this.params.type
      // }
    },
    watch: {
      originTableColumns (val) {
        console.log(val)
      }
    },
    methods: {
      shutdown () {
        console.log('shutdown')
        this.dialogFormVisible = false
      },
      show (scope) { // 隐藏控件属性
        console.log(11, scope)
        scope.row.formAttributeName = scope.row.colName
      },
      resetTabel () {
        this.dialogFormVisible = false
        // this.$refs['tableForm'].resetFields()
      },
      commitTable () {
          /* 判断控件名是否重复 */
        let tableColumnsList = []
        for (let item of this.table.tableColumns) {
          tableColumnsList.push(item.formName)
        }
        let lodashList = lodash.uniq(tableColumnsList)
        if (lodashList.length < tableColumnsList.length) {
          return this.$message({
            type: 'info',
            message: '控件标签重复!'
          })
        }
        /* 判断控件名是否重复END */
        /* 判断主键是否重复
        let tableColumnsListKey = []
        for (let item of this.table.tableColumns) {
          tableColumnsListKey.push(item.primaryKey)
        }
        let num = 0
        for (let i of tableColumnsListKey) {
          if (i) {
            num = num + 1
            if (num > 1) {
              return this.$message({
                type: 'info',
                message: '主键重复!'
              })
            }
          }
        }
        console.log(num)
        判断主键是否重复 */
        let api = API.table.insert
        if (this.type === 'add') {
          api = API.table.insert
        } else if (this.type === 'edit') {
          api = API.table.update
        }
        axios.post(api, this.table).then(response => {
          const result = response.data
          if (result.__statusCode === '1') {
            this.$notify({
              title: '操作结果',
              message: result.data,
              type: 'success',
              duration: '5000'
            })
            this.$store.dispatch('table/getList').then(() => {
              this.dialogFormVisible = false
              this.$store.dispatch('menu/getFormList_for_user')
            })
          } else {
            this.$notify({
              title: '操作结果',
              message: result.__errorMessage,
              type: 'error',
              duration: '5000'
            })
          }
          console.log(response)
        }).catch(error => {
          console.log(error)
        })
        // this.$refs['tableForm'].validate((valid) => {
        //   if (valid) {
        //     alert('submit!')
        //   } else {
        //     console.log('error submit!!')
        //     return false
        //   }
        // })
        // this.$notify({
        //   title: '操作成功',
        //   type: 'success',
        //   duration: '1000'
        // })
      },
      removeColumn (index) {
        this.table.tableColumns.splice(index, 1)
      },
      addColumn () {
        let box = new TableColumn()
        box.colType = this.$store.state.table.tableColumnTypes[0]
        this.table.tableColumns.push(box)
      },
      addMssColumn () {
        console.log(111)
        let list = this.table.tableMssList || []
        list.push({
          projectName: '',
          projectAlias: '',
          enable: false
        })
        this.table.tableMssList = list
      },
      addDimension (val) {
        console.log('row', val)
        this.eventHub.$emit('showDimensionTree', val)
      },
      isMajor (val) { // 是否允许为空(根据主键判断)
        console.log(val)
        if (val.primaryKey) {
          val.colEmpty = true
        } else {
          val.colEmpty = false
        }
        console.log(val)
      },
      // 关联主键与允许为空
      changeColEmpty (val) {
        if (val.colEmpty === false) {
          val.primaryKey = false
        }
      },
      delDimension (val) { // 如果是维表控件'是否关联维度'为false
        if (val) {
          for (let item of this.table.tableColumns) {
            item.dimension = false
          }
        }
      },
      inputLink (row) {
        let obj = {
          TIMESTAMP: ['TIMESTAMP']
        }
        if (row.colType === 'TIMESTAMP' || row.colType === 'DATE' || row.colType === 'DATETIME') {
          row.controlsType = 'TIMESTAMP'
          return obj['TIMESTAMP']
        } else {
//          row.controlsType = 'TEXT'
          return ['TEXT', 'TEXTAREA', 'PASSWORD']
        }
      },
      submitForm (tableForm) {
        this.$refs[tableForm].validate((valid) => {
          if (valid) {
            this.commitTable()
          } else {
            return false
          }
        })
      },
      moveUp (index) {
        if (index !== 0) {
          this.table.tableColumns.splice(index - 1, 0, this.table.tableColumns.splice(index, 1)[0])
        }
      },
      moveDown (index) {
        if (index < this.table.tableColumns.length - 1) {
          this.table.tableColumns.splice(index + 1, 0, this.table.tableColumns.splice(index, 1)[0])
        }
      }
    }
  }
</script>

<style lang="scss">
  .component-dialog {
    width: 100%;
    height: 100%;
  }
  .reset .el-form-item__error {
    top: 25% !important;
  }
  /*
   * @author chenqy9
   * @descrition 操作提示样式
   */
  .msg.msg-confirm {
    text-align: left;
    color: #13CE66;
    font-size: 12px;
    line-height: 1.5em;
  }
</style>


