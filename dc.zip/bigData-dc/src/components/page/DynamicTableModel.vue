<template>
  <el-dialog :title="form_title" :visible.sync="dialogFormVisible" size="small" :close-on-click-modal="false" @close="cleanData">
    <el-form :model="formParams_" ref="BL" id="BL">
      <el-form-item :label="item.formName" :label-width="formLabelWidth" v-for="(item,index) in tableHeader" :key="index">
        <el-date-picker
          v-if="item.controlsType === 'TIMESTAMP' && !item.dimension"
          v-model="formParams_[item.formAttributeName]"
          type="datetime"
          @change="formatDate"
          @blur="changeCurrentDate(item.formAttributeName)"
          placeholder="选择日期"
          format="yyyy-MM-dd HH:mm:ss">
        </el-date-picker>
        <div v-else-if="item.dimension" @click="focus(item.uuid)">
          <el-select v-model="formParams_[item.formAttributeName]" filterable placeholder="请选择" :disabled="true">
            <el-option
              :key="formParams_[item.formAttributeName]"
              :label="formParams_des[item.formAttributeName + '_des']"
              :value="formParams_[item.formAttributeName]">
            </el-option>
          </el-select>
          <el-autocomplete
            v-model="searchData[item.formAttributeName]"
            :fetch-suggestions="querySearchAsync"
            placeholder="请输入查询内容"
            @select="handleSelect"
          ></el-autocomplete>
        </div>
        <!--<el-input v-if="item.controlsType === 'TIMESTAMP'" :type="upCaselowCase(item.controlsType)" v-model="formParams_[item.formAttributeName]"></el-input>-->
        <!--<el-input v-if="item.controlsType === 'TIMESTAMP'" type="date" v-model="formParams_[item.formAttributeName]"></el-input>-->
        <el-input width="150" v-else :type="upCaselowCase(item.controlsType)" v-model="formParams_[item.formAttributeName]"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('BL')">重置</el-button>
      <el-button @click="hiddenForm">取消</el-button>
      <el-button type="primary" @click="commitAllForm">确 定</el-button>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
  .component-dynamic-input {
    width: 100%;
    height: 100%;
  }
</style>

<script>
  /*
   * "PASSWORD",
   "TEXT",
   "HIDDEN",
   "TEXTAREA",
   "CHECKBOX",
   "RADIO",
   "SELECT",
   "FILE"
   */
  import DynamicInput from './common/DynamicInput.vue'
  export default {
    name: 'dynamicTableModel',
    data () {
      return {
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '150px',
        originalData: {}, // 初始的数据，用户提交
        formParams_: {},
        formParams_des: {},
        FORM_STATE: 0, // 表单状态 0提交,1修改,2删除,默认为0
        form_title: '新增表单内容',
        currentSelDate: '', // 当前日期
        currentSelTime: '', // 当前时间
        restaurants: [], // 搜索结果
        currentColId: '',
        searchData: {},
        org_val: '',
        user_paruuid: '',
        user_uuid: '',
        selectItem: [[0, 0]],
        firtVal: [],
        parentDimeValue: null,
        value: ''
      }
    },
    computed: {
      tableHeader () {
        return this.$store.state.formTable.tableHeader
      },
      formParams () {
        return this.$store.getters['formTable/accessTableHeader']
      },
      dimeListObj () {
        return this.$store.state.formTable.dimeList
      }
    },
    methods: {
      open1 () {
        this.$notify({
          title: '提交成功',
          type: 'success'
        })
      },
      open2 (message) {
        this.$notify({
          title: '提交失败:' + message,
          type: 'error'
        })
      },
      hiddenForm () {
        this.dialogFormVisible = false
      },
      resetForm () {
        window.$('#BL')[0].reset()
      },
      commitAllForm () { // 根据当前状态选择提交方式
        this.selectItem.length = 0
        this.selectItem[0] = [0, 0]
        this.FORM_STATE === 1 ? this.commitFormChange() : this.commitForm()
      },
      commitForm () { // 提交新增表单
        let params = this.formParams_
        params.datev = this.formParams_[this.currentSelDate]
        params.timev = this.formParams_[this.currentSelTime]
        params.tableUUID = this.$route.params.uuid
        // 时间转换
        this.$store.dispatch('formTable/setTableRow', params).then((res) => {
          if (res.status === 200 && res.data.data && res.data.__statusCode === '1') {
//            this.$store.dispatch('dataSource/getList')
            this.open1()
            this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid})
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.open2(res.data.__errorMessage)
          }
        })
      },
      commitFormChange () { // 提交修改表单
        let params = {}
        let recentData = {}
        params.originalData = JSON.stringify(this.originalData)
        params.tableUUID = this.$route.params.uuid
        params.recentData = JSON.stringify(this.formParams_)
        // 选择时间后，多一个空的属性名""，根据tableHeader来匹配要传的参数
        this.tableHeader.forEach(item => {
          recentData[item.formAttributeName] = this.formParams_[item.formAttributeName]
        })
        params.recentData = JSON.stringify(recentData)
        this.$store.dispatch('formTable/changeTableRow', params).then((res) => {
          if (res.status === 200 && res.data.data && res.data.__statusCode === '1') {
//            this.$store.dispatch('dataSource/getList')
            this.open1()
            this.$store.dispatch('formTable/getTableList', {tableUUID: this.$route.params.uuid})
            setTimeout(() => {
              this.dialogFormVisible = false
            }, 500)
          } else {
            this.open2(res.data.__errorMessage)
          }
        })
      },
      changeTableRow (val) { // 修改行 只支持单行修改 @等del接口测试完再改传的格式
        console.log('val', val)
        let form = {}
        let formDes = {}
        let length = this.tableHeader.length
        if (length === 0) return []
        for (let i = 0; i < length; i++) {
          form[this.tableHeader[i].formAttributeName] = val[this.tableHeader[i].colName]
          this.originalData[this.tableHeader[i].formAttributeName] = val[this.tableHeader[i].colName]
          if (this.tableHeader[i].dimension) {
            formDes[this.tableHeader[i].formAttributeName + '_des'] = val[this.tableHeader[i].formAttributeName + '_des']
          }
        }
        this.originalData.id = form.id = val.id
        this.formParams_ = form
        this.formParams_des = formDes
      },
      upCaselowCase (val) {
        return val.toLowerCase()
      },
      // 日期改变
      formatDate (val) {
        this.formParams_[this.currentSelDate] = val
        this.formParams_[this.currentSelTime] = val
      },
      changeCurrentDate (val) {
        this.currentSelDate = val
      },
      querySearchAsync (queryString, cb) {
        if (!queryString) {
          this.$message({
            type: 'info',
            message: '请输入内容!'
          })
          return cb([])
        }
        setTimeout(() => {
          this.$store.dispatch('formTable/searchDimeList', {collection: queryString, colId: this.currentColId, parentDimeValue: this.parentDimeValue}).then((res) => {
            if (res.data && res.status === 200 && res.data.__statusCode === '1') {
              this.restaurants = res.data.data
              console.log(res.data)
            }
            cb(this.restaurants)
          })
        }, 300)
      },
      handleSelect (item) {
        for (let i = 0; i < this.selectItem.length; i++) {
          this.firtVal.push(this.selectItem[i][0])
        }
        if (this.firtVal.indexOf(this.currentColId) === -1) {
          this.selectItem.push([this.currentColId, item.key])
        } else {
          for (let i = 0; i < this.selectItem.length; i++) {
            if (this.selectItem[i][0] === this.currentColId) {
              this.selectItem[i][1] === ''
              this.selectItem[i][1] === item.key
            }
          }
        }
        for (let j = 0; j < this.tableHeader.length; j++) {
          if (this.currentColId === this.tableHeader[j].uuid) {
            this.user_uuid = ''
            this.user_uuid = this.tableHeader[j].uuid
            if (this.tableHeader[j].parentDimensionUUID != null) {
              this.user_paruuid = ''
              this.user_paruuid = this.tableHeader[j].parentDimensionUUID
            }
          }
        }
        for (let j = 0; j < this.tableHeader.length; j++) {
          for (let k = 0; k < this.selectItem.length; k++) {
            if (this.user_paruuid === this.selectItem[k][0]) {
              this.org_val = this.selectItem[k][1]
            }
          }
        }
        for (let j = 0; j < this.tableHeader.length; j++) {
          if (this.currentColId === this.tableHeader[j].uuid) {
            this.tableHeader[j].parentDimensionValue = this.org_val
            this.parentDimeValue = this.org_val
          }
        }
        // 修改
        for (let j = 0; j < this.tableHeader.length; j++) {
          if (this.currentColId === this.tableHeader[j].parentDimensionUUID) {
            this.tableHeader[j].parentDimensionValue = item.key
            this.parentDimeValue = item.key
            // 清空对应的用户
            console.log(11111, this.formParams_)
            console.log(22222, this.searchData)
            this.formParams_[this.tableHeader[j].formAttributeName] = ''
            // this.formParams_.user_id = ''
            this.searchData[this.tableHeader[j].formAttributeName] = ''
          }
        }
        // 关联查询结果
        for (let i in this.searchData) {
          if (this.searchData[i] === item.value) {
            this.formParams_[i] = item.key
            this.formParams_des[i + '_des'] = item.value
            return
          }
        }
      },
      focus (val) {
        this.currentColId = val
      },
      // 新增清空上一次的数据
      cleanData () {
        this.tableHeader.forEach(item => {
          this.formParams_[item.formAttributeName] = ''
        })
      }
    },
    created () {
      this.eventHub.$on('showDynamicInput', () => { // 新增动态表单事件监听
        this.form_title = '新增表单内容'
        this.FORM_STATE = 0
        this.dialogFormVisible = true
        this.formParams_ = this.formParams
        this.cleanData()
      })
      this.eventHub.$on('showDynamicInputChange', (val) => { // 修改动态表单事件监听
        this.form_title = '修改表单内容'
        this.FORM_STATE = 1
        this.dialogFormVisible = true
        this.changeTableRow(val)
      })
    },
    components: {
      DynamicInput
    }
  }
</script>
<style scoped>
  .el-input {
    width: 200px;
  }
</style>




