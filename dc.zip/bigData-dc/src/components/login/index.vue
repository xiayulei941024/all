<template>
  <div class="login-container">
    <el-form>
      <el-form-item>
        <el-input placeholder="请输入账号">
          <template slot="prepend">  
            <i slot="prepend" class="fa fa-user fa-fw"></i>
          </template>
        </el-input>
      </el-form-item>
      <el-form-item>
        <el-input placeholder="请输入密码">
          <i slot="prepend" class="fa fa-key fa-fw"></i>
        </el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: 'login',
    data () {
      let data = {}
      data.loginForm = {
        email: '',
        password: ''
      }
      return data
    }
  }
</script>

<style lang="scss" scoped>
</style>



