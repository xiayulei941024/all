/* 引入vue相关模块 */
import Vue from 'vue'
import Router from 'vue-router'

// 主页
import home from '../components/page/Home.vue'
// 动态表单组件
import DynamicTable from '../components/page/DynamicTable.vue'
// 菜单管理组件
import MenuAdmin from '../components/page/MenuAdmin.vue'
// 用户管理组件
import UserAdmin from '../components/page/UserAdmin.vue'
// 权限管理组件
import RoleAdmin from '../components/page/role/RoleAdmin.vue'
// 权限管理组件
import RoleFormTree from '../components/page/role/RoleFormTree.vue'
// 权限管理组件
import RoleFormSet from '../components/page/role/RoleFormSet.vue'
// 404页面组件
import NotFound from '../components/page/NotFound.vue'
// 数据源管理组件
import DataSourceAdmin from '../components/page/DataSourceAdmin.vue'
// 外部数据源同步组件
import OutSyncAdmin from '../components/page/outSync/outSyncAdmin.vue'
// 维表级联设置
import ParentDimensionTree from '../components/page/table/parentDimensionTree.vue'
// 表分组管理
import formGroup from '../components/page/formGroup/formGroup.vue'

Vue.use(Router)

/* 路由配置 */
export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: home
    },
    {
      path: '/admin/dataSource',
      name: 'dataSourceAdmin',
      component: DataSourceAdmin
    },
    {
      path: '/table/:uuid',
      name: 'dynamicTable',
      component: DynamicTable
    },
    {
      path: '/admin/menu',
      name: 'menuAdmin',
      component: MenuAdmin
    },
    {
      path: '/admin/user',
      name: 'userAdmin',
      component: UserAdmin
    },
    {
      path: '/admin/role',
      name: 'roleAdmin',
      component: RoleAdmin
    },
    {
      path: '/outDataSource/dataTree',
      name: 'outDataSource',
      component: OutSyncAdmin
    },
    {
      path: '/admin/role/RoleFormTree',
      name: 'RoleFormTree',
      component: RoleFormTree
    },
    {
      path: '/admin/role/RoleFormSet',
      name: 'RoleFormSet',
      component: RoleFormSet
    },
    {
      path: '/admin/parentDimensionTree',
      name: 'ParentDimensionTree',
      component: ParentDimensionTree
    },
    {
      path: '/admin/formGroup',
      name: 'formGroup',
      component: formGroup
    },
    /* 找不到路由则重定向到首页 */
    {
      path: '*',
      nanem: 'notFound',
      component: NotFound
    }
  ]
})
