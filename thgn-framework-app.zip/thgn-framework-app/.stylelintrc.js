module.exports = {
  extends: [
    'stylelint-config-standard',
    'stylelint-config-recess-order',
    'stylelint-config-recommended-vue',
    // 'stylelint-config-prettier',
  ],
  plugins: ['stylelint-prettier', 'stylelint-order'],
  customSyntax: 'postcss-html',
  ignoreFiles: ['**/*.js', '**/*.jsx', '**/*.tsx', '**/*.ts', '**/*.json'],
  overrides: [
    {
      files: ['**/*.(html|vue)'],
      customSyntax: 'postcss-html',
    },
    {
      files: ['**/*.{scss,css,sass}'],
      customSyntax: 'postcss-scss',
    },
    {
      files: ['**/*.less'],
      customSyntax: 'postcss-less',
    },
  ],
  rules: {
    'selector-pseudo-element-no-unknown': [
      true,
      {
        ignorePseudoElements: ['v-deep', ':deep'],
      },
    ],
    'selector-pseudo-class-no-unknown': [
      true,
      { ignorePseudoClasses: ['global', 'deep'] },
    ],
    'at-rule-no-unknown': [
      true,
      {
        ignoreAtRules: [
          'extend',
          'at-root',
          'debug',
          'warn',
          'error',
          'if',
          'else',
          'for',
          'each',
          'while',
          'mixin',
          'include',
          'content',
          'return',
          'function',
        ],
      },
    ],
    'order/order': [
      'declarations',
      'custom-properties',
      'dollar-variables',
      'rules',
      'at-rules',
    ],
    'function-url-quotes': null, // 设置url(路径可不加引号)
    'selector-class-pattern': null, // 设置类名选择器不遵循 kebab-case
    'no-descending-specificity': null, //设置允许低优先级的选择器出现在高优先级的选择器之后
    'no-empty-source': null, // 允许文件内容为空
    'font-family-no-missing-generic-family-keyword': null, // 设置允许定义非"generic-family"风格字体
  },
}
