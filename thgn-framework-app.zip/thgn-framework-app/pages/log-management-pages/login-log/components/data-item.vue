<template>
  <div class="data-item">
    <div class="visit-data">
      <span>访问量：</span>
      <span class="data" style="font-size: 24px">{{ data.visit }}</span>
    </div>
    <div class="computed-data">
      <span>环比：</span>
      <span class="data" :class="dataColor(data.qoq)">{{ data.qoq }}%</span>
      <span style="margin-left: 24px">同比：</span>
      <span class="data" :class="dataColor(data.yoy)">{{ data.yoy }}%</span>
    </div>
  </div>
</template>
<script setup lang="ts">
import { dataColor } from '../utils/index'
import { DataItem } from '../types/interface'

interface Props {
  data: DataItem
}
defineProps<Props>()
</script>
<style lang="scss" scoped>
.data-item {
  border-bottom: 1px solid #e8e8e8;
  height: 46px;
  padding: 10px 28px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  > div {
    display: flex;
    align-items: center;
  }
  .data {
    font-size: 16px;
    font-weight: 600;
  }
}
</style>
