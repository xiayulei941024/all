<template>
  <div class="visit-sort">
    <MSTitle title="本月用户访问量" />
    <gl-radio-group class="sort-radio" v-model:value="sortType" @change="handleChange">
      <gl-radio-button :value="0">用户排名</gl-radio-button>
      <gl-radio-button :value="1">部门排名</gl-radio-button>
    </gl-radio-group>
    <ms-chart v-if="sortType === 0" class="chart" :option="visitSortData.userOption" autoresize />
    <ms-chart v-else class="chart" :option="visitSortData.departmentOption" autoresize />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsChart } from '@mysteel-standard/components'
import { computed } from 'vue'

interface Props {
  visitSortData: any
  type: number
}
const props = defineProps<Props>()

interface Emits {
  (e: 'change-sort-type', val: number): void
  (e: 'update:type', val: any): void
}
const emits = defineEmits<Emits>()

const sortType = computed({
  get() {
    return props.type
  },
  set(val: number) {
    emits('update:type', val)
  }
})

const handleChange = (e: any) => {
  emits('change-sort-type', e.target.value)
}
</script>
<style lang="scss" scoped>
.sort-radio {
  position: absolute;
  top: 7px;
  right: 12px;
}
</style>
