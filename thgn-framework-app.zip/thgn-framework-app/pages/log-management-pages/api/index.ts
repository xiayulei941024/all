/*
 * @Autor: zouchuanfeng
 * @Date: 2023-09-08 09:12:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-08 11:09:11
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: object = {
  // //用户活跃度排名
  // getUserActivityList: {
  //   method: 'post',
  //   url: '/framework/log/getUserActivityList'
  // },
  // //各部门上线次数
  // getDepartmentOnlineRateList: {
  //   method: 'post',
  //   url: '/framework/log/getDepartmentOnlineRateList'
  // },
  // //各功能使用率
  // getModuleRateList: {
  //   method: 'post',
  //   url: '/framework/log/getModuleRateList'
  // },
  // //账号登录明细
  // getUserLoginDetailList: {
  //   method: 'post',
  //   url: '/framework/log/getUserLoginDetailList'
  // },

  // 导出
  exportUserLoginDetail: {
    method: 'get',
    url: '/framework/log/exportUserLoginDetail'
  },
  // 部门列表
  departmentList: {
    method: 'get',
    url: '/framework/log/departmentList'
  },
  // 本月部门访问量
  departmentVisit: {
    method: 'get',
    url: '/framework/log/departmentVisit'
  },
  // 本月用户访问量
  userVisit: {
    method: 'get',
    url: '/framework/log/userVisit'
  },
  // 本月访问次数
  monthVisitTimes: {
    method: 'get',
    url: '/framework/log/monthVisitTimes'
  },
  // 累计访问次数
  totalVisitTimes: {
    method: 'post',
    url: '/framework/log/totalVisitTimes'
  },
  // 本月访问时长
  retentionTime: {
    method: 'get',
    url: '/framework/log/retentionTime'
  },
  // 活跃度用户排名
  activityUser: {
    method: 'post',
    url: '/framework/log/activityUser'
  },
  // 活跃度部门排名
  activityDepartment: {
    method: 'post',
    url: '/framework/log/activityDepartment'
  },
  // 活跃时间分布
  activityDistribution: {
    method: 'post',
    url: '/framework/log/activityDistribution'
  },
  // 账号登录明细明细列表
  getUserLoginDetailList: {
    method: 'post',
    url: '/framework/log/getUserLoginDetailList'
  },
  // 人员使用详情
  getUserUseDetail: {
    method: 'post',
    url: '/framework/log/getUserUseDetail'
  },
  // 人员使用详情--用户访问次数、停留时间曲线
  getUserUseTrend: {
    method: 'post',
    url: '/framework/log/getUserUseTrend'
  },
  // 各功能使用率
  getModuleRateList: {
    method: 'post',
    url: '/framework/log/getModuleRateList'
  },
  // 功能使用详情
  getModuleUseDetail: {
    method: 'post',
    url: '/framework/log/getModuleUseDetail'
  },
  // 用户访问次数、停留时间曲线
  getModuleUseDetailTrend: {
    method: 'post',
    url: '/framework/log/getModuleUseDetailTrend'
  },

  //操作日志分页查询
  getOperatePage: {
    method: 'post',
    url: '/framework/log/getOperatePage'
  },
  //模型推送历史查询
  modelHistory: {
    method: 'post',
    url: '/forecast/modelHistory'
  },
  //模型推送记录查询
  modelRecord: {
    method: 'post',
    url: '/forecast/modelRecord'
  }
}

export default request(apiMap)
