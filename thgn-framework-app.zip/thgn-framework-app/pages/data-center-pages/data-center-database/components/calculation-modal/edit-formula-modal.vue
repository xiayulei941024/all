<template>
  <div class="edit-formula">
    <gl-modal
      v-model:visible="visible"
      centered
      :title="visibleTitle"
      :width="900"
      @ok="handleSubmit"
      @cancel="cancel"
      wrapClassName="edit-formula"
    >
      <div class="formula-box">
        <div class="index-list">
          <div class="formula-title">指标列表</div>
          <ul style="margin-top: 10px">
            <li
              class="index-li"
              v-for="item in indexList"
              :key="item.indexCode"
              @click="handlerIndex(item)"
            >
              <gl-tooltip :title="item.indexName" placement="left">
                <p class="text-overflow">{{ item.indexName }}</p>
              </gl-tooltip>
            </li>
          </ul>
        </div>
        <div class="formula-content">
          <div class="formula-list">
            <div class="formula-title">函数和运算符号</div>
            <div
              class="tag"
              v-for="(item, index) in TAG_LIST"
              :key="index + item.name"
              :class="item.colorName"
              @click="handlerOperation(item)"
            >
              <span v-if="item.icon" :class="item.icon + '-icon'" class="formula-icon">{{
                item.name
              }}</span>
              <span>{{ item.nameCN }}</span>
            </div>
          </div>
          <div class="formula-show">
            <div class="formula-title">
              <span style="margin-right: 6px">编辑公式</span>
              <gl-popover trigger="hover" class="edit-helper-popover">
                <icon name="question-icon" />
                <template #content>
                  <p class="edit-helper">
                    <span>说明</span>
                    通过鼠标点击计算框内指标或运算符，选中对应的内容（再次点击可取消选中），按下键盘backspace(←)键，删除已选中的的内容，连续按下键盘backspace(←)键可连续删除
                  </p>
                </template>
              </gl-popover>
            </div>
            <gl-form
              :model="form"
              :rules="formRules"
              :label-col="labelCol"
              :wrapper-col="wrapperCol"
              ref="editFormRef"
            >
              <gl-form-item label="新指标名称:" prop="editFormulaName">
                <gl-input
                  v-model:value="form.editFormulaName"
                  style="width: 200px"
                  placeholder="请输入新指标名称"
                ></gl-input>
              </gl-form-item>
              <gl-form-item label="结果精度：" prop="scala">
                <gl-select
                  v-model:value="form.scala"
                  placeholder="请选择保留小数"
                  style="width: 200px"
                >
                  <gl-select-option
                    v-for="(item, index) in SCALA_List"
                    :key="index"
                    :title="item.name"
                    :value="item.id"
                  >
                    {{ item.name }}</gl-select-option
                  >
                </gl-select>
              </gl-form-item>
              <gl-form-item label="计算公式:">
                <div class="show-content">
                  <div
                    v-if="!showTagList.length"
                    style="color: #bbbbbb; position: absolute; top: 0; left: 6px"
                  >
                    请添加指标、函数和运算符号
                  </div>
                  <div
                    class="show-tag empty active"
                    v-if="tagIndex === -1 && showTagList.length"
                  ></div>
                  <div
                    class="show-tag"
                    :class="[item.colorName, tagIndex === index ? 'active' : '']"
                    v-for="(item, index) in showTagList"
                    :key="index"
                    @click="handleEditTag(index)"
                  >
                    <gl-tooltip class="item" :title="item.name" placement="bottom">
                      <div class="content-tag" style="cursor: text">
                        <span v-if="item.icon" :class="item.icon + '-icon'" class="formula-icon">
                          {{ item.name }}</span
                        >
                        <span v-else class="text-overflow">
                          {{ item.name }}
                        </span>
                      </div>
                    </gl-tooltip>
                    <icon
                      class="close"
                      name="icon-unselect_outlined"
                      size="10"
                      @click="deleteTag(index)"
                    />
                  </div>
                </div>
              </gl-form-item>
            </gl-form>
          </div>
        </div>
      </div>
    </gl-modal>
    <gl-modal
      :title="fucObj.isNum ? '输入数值' : '指标列表'"
      v-model:visible="indexVisible"
      width="500px"
      @ok="submitFuc"
      @cancel="cancelFuc"
    >
      <div class="dia-con">
        <ul class="index-list" v-if="!fucObj.isNum">
          <li
            class="index-li"
            v-for="(item, index) in indexDiaList"
            :key="item.indexCode"
            :class="{ active: item.active }"
            @click="handerDiaLi(item, index)"
          >
            <gl-tooltip :title="item.indexName" placement="bottom">
              <p class="text-overflow">{{ item.indexName }}</p>
            </gl-tooltip>
          </li>
        </ul>
        <div class="num" v-if="fucObj.isNum">
          <gl-input-number
            v-model:value="num"
            :controls="false"
            style="width: 150px"
          ></gl-input-number>
        </div>
      </div>
    </gl-modal>
  </div>
</template>

<script setup lang="ts">
import { TAG_LIST, SCALA_List } from '../constants/formula'
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'
import { message } from 'gl-design-vue'
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  tableSelection: any[]
}
interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object, isEditFormula: boolean): void
}

const props = defineProps<Props>()
const indexList = computed(() => props.tableSelection)
const emits = defineEmits<Emits>()
const visible = computed({
  get() {
    initData()
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
    reset()
  }
})
const editFormRef = ref()
const labelCol = { span: 4 }
const wrapperCol = { span: 20 }
const { dataState: form, resetDataState: resetForm } = useResetData({
  editFormulaName: '',
  scala: 2,
  editFormula: '',
  editFormulaFreStr: ''
})
const { dataState: fucObj, resetDataState: resetFucObj } = useResetData({})
const formRules = {
  editFormulaName: [{ required: true, message: '请输入新指标名称', trigger: 'blur' }],
  scala: [{ required: true, message: '请选择结果精度', trigger: 'change' }]
}
const showTagList: Ref = ref([])
const indexVisible = ref(false)
const tagIndex = ref(-2)
const num = ref(0)
const indexDiaList = ref<any>([])
const initData = () => {
  indexDiaList.value = indexList.value.map((item) => {
    return {
      ...item,
      active: false
    }
  })
}
const isTagActive = computed(
  () => tagIndex.value >= -1 && tagIndex.value < showTagList.value.length
)
// onMounted(() => {
//   window.addEventListener('keydown', this.keydownCallback)
// })
// onUnmounted(() => {
//   window.removeEventListener('keydown', this.keydownCallback)
// })
// const keydownCallback = (e) => {
//   if (!isTagActive.value) return
//   if (e.key === 'Backspace') {
//     deleteTag(tagIndex.value)
//   }
//   if (e.key === 'ArrowRight') {
//     tagIndex.value++
//   }
//   if (e.key === 'ArrowLeft') {
//     tagIndex.value--
//   }
// }
const handleEditTag = (index: number) => {
  // console.log(index)
  if (tagIndex.value === index) {
    tagIndex.value = -2
    return
  }
  tagIndex.value = index
}
const insetShowTagList = (obj: any) => {
  const arr = Array.isArray(obj) ? obj : [obj]
  if (tagIndex.value === -1 && showTagList.value.length) {
    showTagList.value = [...showTagList.value, ...arr]
    return
  }
  if (isTagActive.value) {
    showTagList.value.splice(tagIndex.value + 1, 0, ...arr)
    tagIndex.value += arr.length
  } else {
    showTagList.value = showTagList.value.concat(arr)
  }
}
// 点击运算符
const handlerOperation = (item: any) => {
  if (item.isFuc || item.isNum) {
    indexVisible.value = true
    Object.assign(fucObj, item)
    indexDiaList.value = indexDiaList.value.map((item: any) => {
      return {
        ...item,
        active: false
      }
    })
  } else {
    const obj = {
      ...item,
      editFormula: item.editName
    }
    insetShowTagList(obj)
  }
}
// 点击弹窗指标
const handerDiaLi = (data: any, index: number) => {
  if (!fucObj.mut) {
    indexDiaList.value.forEach((item: any) => {
      item.active = false
    })
  }
  indexDiaList.value.forEach((item: any, i: number) => {
    if (i === index) {
      item.active = !data.active
    }
  })
}
const submitFuc = () => {
  let obj = {}
  if (fucObj.isNum) {
    obj = {
      ...fucObj,
      name: Number(num.value),
      editFormula: `${num.value}`
    }
  } else {
    const indexNameList = indexDiaList.value.filter((item) => item.active).map((i) => i.indexName)
    // 频度
    const frequencyArr = indexDiaList.value.filter((item) => item.active).map((i) => i.frequency)
    if (!indexNameList.length) {
      message.error('请选择指标')
      return
    }
    const formulaList = indexDiaList.value
      .filter((item) => item.active)
      .map((i) => {
        let code = ''
        if (i.isDerive) {
          code = `(${i.indexCode})`
        } else {
          code = '$' + i.indexCode
        }
        return code
      })
    const indexName = indexNameList.join(';')
    const mark = fucObj.nameCN
    obj = {
      ...fucObj,
      name: `${mark}(${indexName})`,
      editFormula: '{' + fucObj.editName + formulaList.join('?') + '}',
      frequency: frequencyArr.join()
    }
  }
  insetShowTagList(obj)
  indexVisible.value = false
}
const cancelFuc = () => {
  resetFucObj()
  indexVisible.value = false
}
// 点击左侧指标
const handlerIndex = (item) => {
  const obj = {
    ...item,
    name: item.indexName,
    editFormula: item.isDerive ? item.indexCode : '$' + item.indexCode
  }
  if (item.isDerive) {
    try {
      const editFormula = item.editFormulaJson ? JSON.parse(item.editFormulaJson) : obj
      insetShowTagList(concatArr(editFormula))
    } catch (err) {}
  } else {
    insetShowTagList(obj)
  }
}
const concatArr = (arr) => {
  // console.log(obj)
  const obj1 = {
    name: '(',
    colorName: 'color1',
    isFuc: false,
    editName: '(',
    sign: true,
    editFormula: '('
  }
  const obj2 = {
    name: ')',
    colorName: 'color1',
    isFuc: false,
    editName: ')',
    sign: true,
    editFormula: ')'
  }
  const myArr = Array.isArray(arr) ? arr : [arr]
  return [obj1, ...myArr, obj2]
}
const deleteTag = (i: number) => {
  showTagList.value.splice(i, 1)
  tagIndex.value--
}
const cancel = () => {
  visible.value = false
  reset()
}
const handleSubmit = () => {
  if (!showTagList.value.length) {
    message.error('计算公式不能为空')
    return
  }
  // 验证公式
  let testForName = ''
  let str = ''
  showTagList.value.forEach((i) => {
    str += i.editFormula
    testForName = i.sign ? testForName + i.name + ' ' : testForName + 1 + ' '
  })
  try {
    eval(testForName) //eslint-disable-line
  } catch (error) {
    message.error('计算公式格式不正确！')
    return false //eslint-disable-line
  }
  form.editFormula = str
  form.editFormulaFreStr = showTagList.value
    .filter((item) => item.frequency)
    .map((i) => i.frequency)
    .join()
  form.editFormulaJson = JSON.stringify(showTagList.value)
  console.log('editFormRef.value', editFormRef.value)
  editFormRef.value
    .validate()
    .then(async () => {
      emits('submit', form, true)
      visible.value = false
    })
    .catch(() => {
      return false
    })
}
const reset = () => {
  showTagList.value = []
  resetForm()
}
</script>
<style lang="scss" scoped>
@import '../../style/edit-formula.scss';
</style>
