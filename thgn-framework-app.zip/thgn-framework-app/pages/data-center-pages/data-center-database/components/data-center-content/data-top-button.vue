<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-21 15:21:27
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-13 11:18:44
 * @Description: 
-->
<template>
  <gl-row class="data-bop-button">
    <gl-space>
      <div v-for="(button, index) in DATA_BUTTON_LIST" :key="index">
        <template v-if="button.name !== '数据工具'">
          <gl-button
            type="primary"
            ghost
            :disabled="disabled"
            v-if="checkPermit(button.permit)"
            @click="handleTool(button)"
          >
            <icon :name="button.icon" />
            <span>{{ button.name }}</span>
          </gl-button>
        </template>
        <gl-dropdown v-else type="primary" :trigger="['click']" :disabled="disabled">
          <gl-button type="primary" ghost>
            {{ button.name }} <icon class="down-icon" name="icon-arrow-down" />
          </gl-button>
          <template #overlay>
            <gl-menu>
              <template v-for="tool in toolMenu" :key="tool.id">
                <template v-if="!tool.icon">
                  <gl-menu-item v-if="checkPermit(tool.permit)" @click="handleTool(tool)">
                    {{ tool.name }}
                  </gl-menu-item>
                </template>
                <gl-sub-menu
                  v-else-if="checkPermit(tool.permit)"
                  :title="tool.name"
                  :key="tool.subId"
                >
                  <template v-for="item in tool.children" :key="item.id">
                    <gl-menu-item v-if="checkPermit(item.permit)" @click="handleTool(item)">
                      {{ item.name }}
                    </gl-menu-item>
                  </template>
                </gl-sub-menu>
              </template>
            </gl-menu>
          </template>
        </gl-dropdown>
      </div>
    </gl-space>
  </gl-row>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { DATA_BUTTON_LIST, TOOL_LIST } from '../constants/buttons'
import { ToolObject, DataToolObj } from '../../types/interface'
import { useResetData, checkPermit } from '@mysteel-standard/hooks'
interface Props {
  disabled: boolean
}
interface Emits {
  (e: 'data-tool-operation', type: string, dataTools: DataToolObj): void
  (e: 'extract'): void
  (e: 'export'): void
  (e: 'flex-col-width', isFlex: boolean): void
}
interface ToolOperationObj {
  [propsName: string]: { handle: Function }
}
defineProps<Props>()
const emits = defineEmits<Emits>()
const { dataState: toolMenu, resetDataState: resetMenuData } = useResetData(TOOL_LIST)
const dataTools = reactive<DataToolObj>({
  dataSettings: false,
  flexRow: false,
  statistical: false
})
// 导出数据
const handleExport = () => {
  emits('export')
}
// 还原数据
const resetData = () => {
  emits('extract')
}
//行列转置
const transData = (val: ToolObject) => {
  val.value = !val.value
}
// 舒展列宽
const flexColWidth = (val: ToolObject) => {
  /* 舒展列宽 */
  val.value = !val.value
  dataTools.flexRow = val.value
  val.name = val.value ? '收缩列宽' : '舒展列宽'
  emits('flex-col-width', val.value)
}
// 数据统计
const dataStat = (val: ToolObject) => {
  val.value = !val.value
  dataTools.statistical = val.value
  val.name = val.value ? '隐藏数据统计' : '数据统计'
}
const dataSet = (val: ToolObject) => {
  dataTools.dataSettings = val.value
}
const handleBlankLines = (val: ToolObject) => {
  val.value = !val.value
  val.name = val.value ? '隐藏空行' : '显示空行'
}
const toolOperationObj: ToolOperationObj = {
  Reset: { handle: resetData }, //数据还原
  Tran: { handle: transData }, //行列转置
  Flex: { handle: flexColWidth }, //舒展、收缩列宽
  Stat: { handle: dataStat }, //数据统计
  Set: { handle: dataSet }, //行、列计算
  Export: { handle: handleExport }, //导出
  ShowBlankLines: { handle: handleBlankLines } //显示、隐藏空行
}
//数据工具处理
const dataToolsOperation = (type: string, dataTools: DataToolObj) => {
  if (type === 'Flex' || type === 'Export' || type === 'Reset') {
    return
  }
  emits('data-tool-operation', type, dataTools)
}
const handleTool = (val: { type: any }) => {
  toolOperationObj[val.type].handle && toolOperationObj[val.type].handle(val)
  dataToolsOperation(val.type, dataTools)
}

defineExpose({ resetMenuData })
</script>
<style lang="scss" scoped>
$gap: 16px;
.data-bop-button {
  margin-bottom: $gap;
}
</style>
