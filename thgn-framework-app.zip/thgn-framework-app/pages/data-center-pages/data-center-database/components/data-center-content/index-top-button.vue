<template>
  <div class="index-button-top">
    <gl-form layout="inline">
      <gl-form-item>
        <gl-space>
          <div v-for="(button, index) in BUTTON_LIST" :key="index">
            <gl-button
              v-if="button.name !== '指标计算' && checkPermit(button.permit)"
              type="text"
              :disabled="!selections.length"
              @click="handleCalculation(button)"
            >
              <icon :name="button.icon" />
              <span>{{ button.name }}</span>
            </gl-button>
            <gl-dropdown v-else type="primary" :trigger="['click']" :disabled="!selections.length">
              <gl-button type="text" v-if="checkPermit(button.permit)">
                <icon :name="button.icon" />
                {{ button.name }}
                <icon class="down-icon" name="icon-arrow-down" />
              </gl-button>
              <template #overlay>
                <gl-menu>
                  <template v-for="itemConfig in deriveButton" :key="itemConfig.type">
                    <gl-menu-item
                      v-if="!itemConfig.children && checkPermit(itemConfig.permit)"
                      @click="handleCalculation(itemConfig)"
                      :disabled="itemConfig.disabled"
                    >
                      {{ itemConfig.name }}
                    </gl-menu-item>
                    <gl-sub-menu
                      v-else-if="checkPermit(itemConfig.permit)"
                      :title="itemConfig.name"
                    >
                      <template v-for="item in itemConfig.children" :key="item.type">
                        <gl-menu-item
                          :disabled="item.disabled"
                          v-if="checkPermit(item.permit)"
                          @click="handleCalculation(item)"
                        >
                          {{ item.name }}
                        </gl-menu-item>
                      </template>
                    </gl-sub-menu>
                  </template>
                </gl-menu>
              </template>
            </gl-dropdown>
          </div>
        </gl-space>
      </gl-form-item>
    </gl-form>
    <!-- 指标计算相关弹窗 -->
    <!-- 其他 -->
    <index-calculate-modal
      v-if="calculationVisible"
      v-model:calculationVisible="calculationVisible"
      :calculationForm="calculationForm"
      :calculationFormItem="CALCULATION_FORMITEMS[tabName]"
      :visibleTitle="calculationTitle"
      @submit="handleSubmit"
    />
    <!-- 新频率 -->
    <frequency-modal
      v-if="frequencyVisible"
      v-model:calculationVisible="frequencyVisible"
      :visibleTitle="calculationTitle"
      :calculationForm="calculationForm"
      :tableSelection="tableSelection"
      @submit="handleSubmit"
    />
    <!-- 标准化 -->
    <standardized-modal
      v-if="standardizedVisible"
      v-model:calculationVisible="standardizedVisible"
      :calculationForm="calculationForm"
      :visibleTitle="calculationTitle"
      @submit="handleSubmit"
    />
    <!-- 编辑公式 -->
    <edit-formula-modal
      v-if="editFormulaVisible"
      v-model:calculationVisible="editFormulaVisible"
      visibleTitle="编辑公式"
      :tableSelection="selections"
      @submit="handleSubmit"
    />
    <!-- 补充区间 -->
    <supplement-modal
      v-if="supplementVisible"
      v-model:calculationVisible="supplementVisible"
      :visibleTitle="calculationTitle"
      :calculationForm="calculationForm"
      @submit="handleSubmit"
    />
    <!-- 累计求和 -->
    <sum-modal
      v-if="sumVisible"
      v-model:calculationVisible="sumVisible"
      :visibleTitle="calculationTitle"
      :calculationForm="calculationForm"
      @submit="handleSubmit"
    />
    <!-- 同环比 -->
    <radio-modal
      v-if="radioVisible"
      v-model:calculationVisible="radioVisible"
      :visibleTitle="calculationTitle"
      :calculationForm="calculationForm"
      @submit="handleSubmit"
    />
    <!-- 修匀 -->
    <graduation-modal
      v-if="graduationVisible"
      v-model:calculationVisible="graduationVisible"
      :visibleTitle="calculationTitle"
      :calculationForm="calculationForm"
      @submit="handleSubmit"
    />
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import IndexCalculateModal from '../calculation-modal/index-calculate-modal.vue'
import StandardizedModal from '../calculation-modal/standardized-modal.vue'
import EditFormulaModal from '../calculation-modal/edit-formula-modal.vue'
import SupplementModal from '../calculation-modal/supplement-modal.vue'
import SumModal from '../calculation-modal/sum-modal.vue'
import RadioModal from '../calculation-modal/radio-modal.vue'
import GraduationModal from '../calculation-modal/graduation-modal.vue'
import FrequencyModal from '../calculation-modal/frequency-modal.vue'
import { BUTTON_LIST, CALCULATION_LIST } from '../constants/buttons'
import { useResetData } from '@mysteel-standard/hooks'
import { message } from 'gl-design-vue'
import { CALCULATION_FORMITEMS } from '../constants/calculation' //表单配置项
import { checkPermit } from '@mysteel-standard/hooks'
interface calculationConfigObj {
  [propsName: string]: any
}
interface Emits {
  (e: 'handle-calculation', form: Object, name: string, isEditFormula?: boolean): void
  (e: 'extract', params: string[]): void
  (e: 'edit-formula', params: string[]): void
}
const emits = defineEmits<Emits>()
const tabName = ref('')
interface Props {
  tableSelection: any
}
const props = defineProps<Props>()

const selections = computed(() => props.tableSelection)
const deriveButton = ref(CALCULATION_LIST)
const buttonName = ref('')
watch(
  () => props.tableSelection,
  (val) => {
    if (val.length) {
      // 判断成交价格按钮
      const index = val.findIndex((item) => {
        if (item.indexType !== '市场价格') {
          return true
        } else {
          if (!item.category.includes('盘螺') && !item.category.includes('螺纹钢')) {
            return true
          } else {
            return false
          }
        }
      })
      deriveButton.value.forEach((item) => {
        if (item.type === 15) {
          item.disabled = index !== -1
        }
      })
    }
  }
)
// 变频
const frequencyVisible = ref(false)
const handleFrequency = () => {
  frequencyVisible.value = true
}
//同环比
const radioVisible = ref(false)
const handleRadio = () => {
  radioVisible.value = true
}
//累计求和
const sumVisible = ref(false)
const handleSum = () => {
  sumVisible.value = true
}

//补充区间
const supplementVisible = ref(false)
const supplementArea = () => {
  supplementVisible.value = true
}
const isOnlyOne = (text: string) => {
  if (selections.value.length > 1) {
    message.warning(text)
    return false
  }
  return true
}
//标准化
const standardizedVisible = ref(false)
const standardized = () => {
  standardizedVisible.value = true
}
//季节性分析
const seasonAnalysis = () => {
  let params = [`{seasonalanalysis,$${selections.value[0].indexCode}}`]
  if (selections.value[0].isDerive === 1) {
    params = [`{seasonalanalysis,${selections.value[0].indexCode}}`]
  }
  emits('extract', params)
}

const calculationTitle = ref('')
const { dataState: calculationForm, resetDataState: resetCalculationForm } = useResetData({
  deriveOption: undefined,
  type: 1, //累计求和
  period: 3,
  checked: true,
  newFrequency: 1, //变频
  calWayLow: 'sum',
  calWayHigh: 'avg',
  changeType: 0, //同环比计算
  changeOption: 'yoy',
  seqPeriod: undefined,
  ignoreWeekend: false, //补充区间
  intervalType: 1,
  point: 1, //指数化
  date: '',
  lambdaPara: null, //HP滤波
  interval: 1,
  fromSmoothing: {
    //修匀
    type: '1',
    cycle: '1',
    index: '1',
    average: '3',
    seasonal: true
  },
  rangeInterval: 'week', //区间求和
  preData: '0', //后置
  postData: '0',
  standardType: 1, //标准化
  standardMinValue: 0,
  standardMaxValue: 0,
  //移动平均
  moveType: 0,
  moveValue: undefined,
  calPrice: false //成交价格测算
})
//成交价格测算
const priceCalculation = () => {
  calculationForm.calPrice = true
  emits('handle-calculation', calculationForm, buttonName.value)
}
//修匀
const graduationVisible = ref(false)
const handleGraduation = () => {
  selections.value.forEach((element) => {
    if (element.frequency.indexOf('月度') >= 0 || element.frequency.indexOf('季度') >= 0) {
      calculationForm.fromSmoothing.seasonal = false
    }
  })
  graduationVisible.value = true
}
//计算
const handleCalculation = (item: { name: string; type?: number }) => {
  const { name, type } = item
  buttonName.value = name
  if (calculationConfig[name]?.isValidate && !calculationConfig[name].isValidate()) {
    return
  }
  tabName.value = name
  calculationTitle.value = '参数设置'
  resetCalculationForm()
  calculationForm.deriveOption = type
  if (calculationConfig[name]?.handle) {
    //有交互类表单
    calculationConfig[name].handle()
  } else {
    //通用表单
    handleOtherCalculate()
  }
}
const calculationVisible = ref(false)
const handleOtherCalculate = () => {
  calculationVisible.value = true
}
//编辑公式
const editFormulaVisible = ref(false)
const editFormula = () => {
  editFormulaVisible.value = true
}
// 按钮配置
const calculationConfig: calculationConfigObj = {
  变频: {
    handle: handleFrequency
  },
  同环比计算: {
    handle: handleRadio
  },
  季节性分析: {
    handle: seasonAnalysis,
    isValidate: () => {
      return isOnlyOne('只能对一条指标进行季节性分析!')
    }
  },
  编辑公式: { handle: editFormula },
  累计求和: {
    handle: handleSum
  },
  修匀: {
    handle: handleGraduation
  },
  指数化: {
    isValidate: () => {
      return isOnlyOne('只能对一条指标进行指数化!')
    }
  },
  补充区间: {
    handle: supplementArea
  },
  标准化: {
    handle: standardized
  },
  成交价格测算: {
    handle: priceCalculation
  }
}
//计算
const handleSubmit = (form: any, isEditFormula = false) => {
  Object.assign(calculationForm, form)
  if (isEditFormula) {
    //编辑公式
    emits('handle-calculation', form, buttonName.value, isEditFormula)
  } else {
    emits('handle-calculation', calculationForm, buttonName.value)
  }
}
</script>
<style scoped lang="scss">
.index-button-top {
  background: #eff2f5;
}
</style>
