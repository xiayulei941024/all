<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-16 11:05:30
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-16 16:35:17
 * @Description: 
-->
<template>
  <gl-row>
    <gl-form layout="inline" :model="form">
      <gl-form-item>
        <gl-space>
          <gl-button
            v-if="checkPermit(['sjzx:sjk:tqsj'])"
            type="primary"
            :disabled="!selectRows.length"
            @click="extractData"
          >
            <icon name="icon-extract_outlined" />
            <span>提取数据</span>
          </gl-button>
          <gl-button type="primary" ghost :disabled="!selectRows.length" @click="removeData">
            <icon name="icon-unselect_outlined" />
            <span>移除所选</span>
          </gl-button>
          <gl-button type="primary" ghost :disabled="!selectRows.length" @click="collectData">
            <icon name="icon-collect_outlined" />
            <span>收藏数据</span>
          </gl-button>
        </gl-space>
      </gl-form-item>
      <gl-form-item>
        <calendar-picker :form="form" @change-time="changeTime"></calendar-picker>
      </gl-form-item>
    </gl-form>
  </gl-row>
</template>
<script setup lang="ts">
import CalendarPicker from './calendar-picker.vue'
import { Icon } from '@mysteel-standard/components'
import { checkPermit } from '@mysteel-standard/hooks'
import { message } from 'gl-design-vue'
interface Props {
  tableSelection: any
  dateForm: any
}

const props = defineProps<Props>()
interface Emits {
  (e: 'extract'): void
  (e: 'remove'): void
  (e: 'change-date', form: Object): void
  (e: 'collect', label: string, data: any[], isDirectory: boolean): void
}
const emits = defineEmits<Emits>()
const selectRows = computed(() => props.tableSelection)
const form = ref(props.dateForm)
const extractData = () => {
  emits('extract')
}
const removeData = () => {
  emits('remove')
}
const collectData = () => {
  emits('collect', '指标收藏', selectRows.value, true)
}
const changeTime = (data: Object) => {
  if (!selectRows.value.length) {
    message.warning('请勾选指标')
  }
  emits('change-date', data)
}
</script>
<style scoped lang="scss">
.gl-btn-text {
  color: #333;
}
</style>
