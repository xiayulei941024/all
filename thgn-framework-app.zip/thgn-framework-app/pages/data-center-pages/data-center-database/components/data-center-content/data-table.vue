<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 23:55:15
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:41:34
 * @Description: 
-->
<template>
  <gl-spin :spinning="loading">
    <vxe-table
      ref="detailTableRef"
      class="detailTable"
      stripe
      :height="isStatistical ? 160 : 'auto'"
      auto-resize
      show-overflow
      :data="dataTable"
      :show-header="!isStatistical"
      :column-config="{ resizable: true }"
      :row-config="{ isHover: true }"
      :scroll-x="{ enabled: true, gt: 10 }"
      :scroll-y="{ enabled: true, gt: 10 }"
    >
      <template #empty>
        <empty>
          <template v-slot:empty>
            <div class="empty-tip">请点击“提取数据”按钮，查看指标数据</div>
          </template>
        </empty>
      </template>
      <vxe-column type="seq" title="序号" width="80"></vxe-column>
      <vxe-column field="dataDate" width="100" show-header-overflow show-overflow="title" sortable>
        <template #header>
          <div style="display: inline-block">
            <p>指标名称</p>
            <p>频率</p>
            <p>单位</p>
            <p>时间</p>
          </div>
        </template>
        <template #default="{ row }">{{ solar2lunarStr(row.dataDate) }}</template>
      </vxe-column>
      <vxe-column
        v-for="(item, i) in moreColumns"
        :key="i"
        :field="item.indexCode"
        :width="item.width || 200"
        show-header-overflow="ellipsis"
      >
        <template #header>
          <gl-tooltip :title="item.indexShortName || item.indexName">
            {{ item.indexShortName || item.indexName }}
          </gl-tooltip>
          <br />

          {{ item.frequency }}
          <icon name="icon-tip" @click="openTip(item)" class="icon-tip" v-if="item.frequency" />
          <br />
          {{ item.unit }}<br />
          {{ item.dataDate }}<br />
        </template>
        <template #default="{ row }">{{ row[item.indexCode] || '-' }}</template>
      </vxe-column>
    </vxe-table>
  </gl-spin>
</template>
<script setup lang="ts">
import { Icon, Empty } from '@mysteel-standard/components'
import { calendar } from '@mysteel-standard/utils'
interface Props {
  loading: any
  tableData: any
  headList: any
  isStatistical?: boolean
  dataDetailHeight?: number
  dateForm: any
}

const props = withDefaults(defineProps<Props>(), {
  isStatistical: false
})
const dateInfo = computed(() => props.dateForm)
interface Emits {
  (e: 'update:tableData', val: any[]): void
  (e: 'view-index-info', record: any): void
  (e: 'sort-change', sorter: Object): void
}
const emits = defineEmits<Emits>()

const dataTable = computed({
  get() {
    return props.tableData
  },
  set(val: any[]) {
    emits('update:tableData', val)
  }
})
const moreColumns = computed(() => props.headList)
const openTip = (item: any) => {
  emits('view-index-info', item)
}
const detailTableRef = ref()
watch(
  () => props.headList,
  () => {
    // 表格从新计算
    nextTick(() => {
      detailTableRef.value.recalculate()
    })
  },
  { deep: true }
)
// 公历转农历-日期字符串
const solar2lunarStr = (date: string) => {
  // 设置的是公历，直接返回
  if (dateInfo.value.dateType === 0 || date?.indexOf('-') === -1) {
    return date
  }
  const [year, month, day] = date.split('-')
  const lunar = calendar.solar2lunar(year, month, day)
  return calendar.transYear(year) + lunar.IMonthCn + lunar.IDayCn // festival
}
</script>
<style lang="scss" scoped>
.empty-div {
  padding-top: 0;
}
.gl-spin-nested-loading {
  height: 100%;
  :deep(.gl-spin-container) {
    height: 100%;
  }
}
.icon-tip:hover {
  color: #2d5dc1;
}
.detailTable {
  width: 100%;
}
</style>
