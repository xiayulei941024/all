<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-18 22:09:50
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 17:54:32
 * @Description: 
-->
<template>
  <gl-spin :spinning="companyTreeLoading">
    <ms-tree
      v-model:selectedKeys="companySelectedKeys"
      v-model:expandedKeys="companyExpandedKeys"
      autoExpandParent
      block-node
      multiple
      :tree-data="companyTreeData"
      :fieldNames="companyFields"
      :node-menus="companyTreeMenu"
      @select="companyNodeClick"
      @db-click="companyDbClick"
      @menu-click="companyMenuClick"
      :load-data="companyTreeLoad"
      @expand="companyTreeExpand"
    />
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useCompanyTree from '../../composables/tree/use-company-tree'
import { MysteelDataType } from '../../types/interface'
interface Emits {
  (e: 'db-click-node', data: any[], isExtract: boolean, isAddExtract: boolean): void
  (e: 'collect-index', label: string, data: Object): void
  (e: 'extract-or-add-index', isExTract: boolean, nodes: MysteelDataType[]): void //添加提取指标
}
const emits = defineEmits<Emits>()
interface Props {
  frameIds: any[]
  indexIds: any[]
}
const props = defineProps<Props>()

const {
  treeData: companyTreeData,
  replaceFields: companyFields,
  selectedTreeKeys: companySelectedKeys,
  expandedKeys: companyExpandedKeys,
  treeLoading: companyTreeLoading,
  treeMenu: companyTreeMenu,
  nodeClick: companyNodeClick,
  menuClick: companyMenuClick,
  dbClick: companyDbClick,
  onLoadData: companyTreeLoad,
  getTreeData: getCompanyTree,
  treeExpand: companyTreeExpand
} = useCompanyTree(emits, props)

defineExpose({ getCompanyTree, companyTreeData })
</script>
