<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 13:34:28
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-05 17:31:46
 * @Description: 
-->
<template>
  <gl-modal v-model:visible="visible" :title="visibleTitle" @ok="handleOk">
    <gl-spin :spinning="collectionTreeLoading">
      <div class="collect-tree-wrap">
        <MsTree
          v-model:selectedKeys="myCollectionSelectedKeys"
          v-model:expandedKeys="myCollectionExpandedKeys"
          autoExpandParent
          block-node
          :tree-data="myCollectionTreeData"
          :fieldNames="myCollectionFields"
          :node-menus="myCollectionTreeMenu"
          @expand="myCollectionTreeExpand"
          @select="myCollectionNodeClick"
          @menu-click="myCollectionMenuClick"
        />
      </div>
      <div class="collect-tree-tip">
        说明：“指标收藏”，系统只保存您当前勾选的指标，不保存图形和日期设置
      </div>
    </gl-spin>
    <add-modify-menu-modal
      v-if="addModifyMenuVisible"
      :addModifyMenuForm="addModifyMenuForm"
      v-model:addModifyMenuVisible="addModifyMenuVisible"
      :visibleTitle="addModifyMenuTitle"
      @sure-add-modify-menu="sureAddModifyMenu"
    />
  </gl-modal>
</template>
<script setup lang="ts">
import { message } from 'gl-design-vue'
import { MsTree } from '@mysteel-standard/components'
import useMyCollectionTree from '../../composables/tree/use-my-collection-tree'
import useMyCollectionTreeMenu from '../../composables/tree/use-my-collection-tree-menu'
import AddModifyMenuModal from './add-modify-menu-modal.vue'
interface Props {
  collectionIndexVisible: boolean
  visibleTitle: string
  isDirectory: boolean //是否只显示目录
}
interface Emits {
  (e: 'update:collectionIndexVisible', val: boolean): void
  (e: 'sure-collect', selected: any[]): void
  (e: 'extract', data: any[]): void
  (e: 'add-index', data: any[]): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  collectionIndexVisible: false,
  visibleTitle: '',
  isDirectory: false
})
const visible = computed({
  get() {
    return props.collectionIndexVisible
  },
  set(val: boolean) {
    emits('update:collectionIndexVisible', val)
  }
})
// 我的收藏树
const {
  treeData: myCollectionTreeData,
  replaceFields: myCollectionFields,
  selectedTreeKeys: myCollectionSelectedKeys,
  expandedKeys: myCollectionExpandedKeys,
  getTreeData: getMyCollectionTree,
  treeLoading: collectionTreeLoading,
  nodeClick: myCollectionNodeClick,
  selectedTreeNodes: myCollectionSelectedNodes,
  treeExpand: myCollectionTreeExpand,
  allCollapse
} = useMyCollectionTree(emits, props.isDirectory)
//树操作
const {
  treeMenu: myCollectionTreeMenu,
  menuClick: myCollectionMenuClick,
  addModifyMenuTitle,
  addModifyMenuForm,
  addModifyMenuVisible,
  sureAddModifyMenu
} = useMyCollectionTreeMenu(
  getMyCollectionTree,
  emits,
  props.isDirectory,
  allCollapse,
  myCollectionSelectedNodes
)

const handleOk = () => {
  if (!myCollectionSelectedNodes.value.length) {
    message.warn('请选择收藏路径')
  }
  if (!myCollectionSelectedNodes.value[0].isEnd) {
    message.warn('请选择末级文件夹作为收藏路径')
    return
  }
  emits('sure-collect', myCollectionSelectedNodes.value)
}
onMounted(() => {
  getMyCollectionTree()
})
</script>
<style lang="scss" scoped>
.collect-tree {
  &-wrap {
    height: 460px;
    overflow-y: auto;
    border: 1px solid #e8e8e8;
  }
  &-tip {
    color: #a0a0a0;
    font-size: 12px;
    padding: 15px 0px;
  }
}
</style>
