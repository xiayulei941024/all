/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-21 14:47:31
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-19 14:36:20
 * @Description:
 */
//指标数据按钮
export const BUTTON_LIST = [
  {
    name: '变频',
    icon: 'icon-conversion',
    handle: 'handleCalculation',
    type: 1,
    permit: ['sjzx:sjk:bp']
  },
  {
    name: '同环比计算',
    icon: 'icon-ratio-calculation',
    handle: 'handleCalculation',
    type: 2,
    permit: ['sjzx:sjk:thbjs']
  },
  {
    name: '季节性分析',
    icon: 'icon-seasonal',
    handle: 'handleCalculation',
    id: 7,
    permit: ['sjzx:sjk:jjxfx']
  },
  {
    name: '后置',
    icon: 'icon-postposition',
    handle: 'handleCalculation',
    type: 8,
    permit: ['sjzx:sjk:hz']
  },
  {
    name: '编辑公式',
    icon: 'icon-formula',
    handle: 'handleCalculation',
    type: 2,
    permit: ['sjzx:sjk:bjgs']
  },
  {
    name: '指标计算',
    icon: 'icon-index-calculation',
    handle: 'handleCalculation',
    permit: [
      'sjzx:sjk:xy',
      'sjzx:sjk:zsh',
      'sjzx:sjk:ljqh',
      'sjzx:sjk:dzl',
      'sjzx:sjk:ydpj',
      'sjzx:sjk:cjjgcs',
      'sjzx:sjk:HPlb'
    ],
    type: 1
  }
]
//指标计算
export const CALCULATION_LIST = [
  { name: '累计求和', type: 4, disabled: false, permit: ['sjzx:sjk:ljqh'] },
  { name: '修匀', type: 5, disabled: false, permit: ['sjzx:sjk:xy'] },
  { name: '指数化', type: 6, disabled: false, permit: ['sjzx:sjk:zsh'] },
  {
    name: '调整列',
    type: 7,
    permit: ['sjzx:sjk:dzl'],
    children: [
      { name: '补充区间', type: 9, disabled: false, permit: ['sjzx:sjk:dzl'] },
      { name: '替换数据', type: 10, disabled: false, permit: ['sjzx:sjk:dzl'] },
      { name: '区间求和', type: 11, disabled: false, permit: ['sjzx:sjk:dzl'] },
      { name: '标准化', type: 12, disabled: false, permit: ['sjzx:sjk:dzl'] }
    ]
  },
  { name: '移动平均', type: 13, disabled: false, permit: ['sjzx:sjk:ydpj'] }
  // { name: '成交价格测算', type: 15, disabled: true, permit: ['sjzx:sjk:cjjgcs'] },
  // { name: 'HP滤波', type: 14, disabled: false, permit: ['sjzx:sjk:HPlb'] }
]
//数据详情按钮
export const DATA_BUTTON_LIST = [
  {
    name: '行列转置',
    icon: 'icon-transposition',
    type: 'Tran',
    value: false,
    id: 1,
    permit: ['sjzx:sjk:xlzz']
  },
  // {
  //   name: '数据定位',
  //   icon: 'icon-extract_outlined',
  //   id: 2
  // },
  {
    name: '导出数据',
    icon: 'icon-export-data',
    type: 'Export',
    value: '',
    id: 3,
    permit: ['sjzx:sjk:dcsj']
  },
  {
    name: '数据工具',
    icon: '',
    type: 'Tool',
    value: '',
    id: 4
  }
]
//数据工具
export const TOOL_LIST = [
  {
    type: 0,
    name: '行计算',
    icon: 'el-icon-arrow-right',
    permit: ['sjzx:sjk:xjs'],
    subId: 1,
    children: [
      { type: 'Set', name: '行求和', icon: '', value: 'rowSum', id: 2, permit: ['sjzx:sjk:xjs'] },
      { type: 'Set', name: '行平均', icon: '', value: 'rowAvg', id: 3, permit: ['sjzx:sjk:xjs'] },
      { type: 'Set', name: '行最大', icon: '', value: 'rowMax', id: 4, permit: ['sjzx:sjk:xjs'] },
      { type: 'Set', name: '行最小', icon: '', value: 'rowMin', id: 5, permit: ['sjzx:sjk:xjs'] },
      { type: 'Set', name: '行中位', icon: '', value: 'rowMedian', id: 6, permit: ['sjzx:sjk:xjs'] }
    ]
  },
  {
    type: 1,
    name: '列计算',
    permit: ['sjzx:sjk:ljs'],
    icon: 'el-icon-arrow-right',
    subId: 7,
    children: [
      { type: 'Set', name: '列求和', icon: '', value: 'lineSum', id: 8, permit: ['sjzx:sjk:ljs'] },
      { type: 'Set', name: '列平均', icon: '', value: 'lineAvg', id: 9, permit: ['sjzx:sjk:ljs'] }
    ]
  },
  { type: 'Flex', name: '舒展列宽', icon: '', value: false, id: 10, permit: '' },
  { type: 'Stat', name: '数据统计', icon: '', value: false, id: 11, permit: ['sjzx:sjk:sjtj'] },
  { type: 'ShowBlankLines', name: '显示空行', icon: '', value: false, id: 12, permit: '' },
  { type: 'Reset', name: '数据还原', icon: '', value: '', id: 13, permit: '' }
]
