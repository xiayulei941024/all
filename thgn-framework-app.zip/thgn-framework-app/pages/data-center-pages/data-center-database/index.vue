<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-18 01:39:48
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 10:03:59
 * @Description: 
-->
<template>
  <database-index ref="dataBaseRef" @collect-index="collectIndex">
    <template #side>
      <div class="data-center-directory" id="target-resize-div">
        <div
          ref="directoryRef"
          class="tree-directory"
          :style="{
            width: directoryWidth + 'px'
          }"
        >
          <div class="tab-group">
            <ms-tabs
              class="tab"
              v-model:value="tabIndex"
              :tabs="tabData"
              @change="(e: any) => tabClick(e)"
            />
          </div>
          <div class="search-box" v-if="tabIndex === TabList['公司数据库']">
            <input-search
              v-model:value="searchValue"
              placeholder="请输入搜索关键词，多个关键词以空格隔开"
              @search="searchIndex"
            />
          </div>
          <!-- Mysteel数据库 -->
          <div class="tree-wrap" :class="{ 'collect-tree': tabIndex !== TabList['Mysteel数据库'] }">
            <keep-alive>
              <component
                :is="components[tabName]"
                ref="treeRef"
                :frameIds="frameIdsTree"
                :indexIds="indexIdsTree"
                @collect-index="collectIndex"
                @db-click-node="extractOrAddIndex"
                @extract-or-add-index="extractOrAddIndex"
              ></component>
            </keep-alive>
          </div>
          <!-- 指标搜索弹窗 -->
          <index-search-modal
            v-if="indexSearchVisible"
            ref="searchIndexRef"
            v-model:indexSearchVisible="indexSearchVisible"
            :searchText="searchValue"
            :visibleTitle="indexSearchTitle"
            @extract-or-add-index="extractOrAddIndex"
          />
          <!-- 指标收藏 -->
          <collect-index-modal
            v-if="collectionIndexVisible"
            v-model:collectionIndexVisible="collectionIndexVisible"
            :visibleTitle="collectionIndexTitle"
            @sure-collect="sureCollectIndex"
            :isDirectory="isDirectory"
          />
        </div>
        <div id="resize-div" @mousedown="(e: any) => resizeEl(e, 'side')"></div>
        <div class="expand-wrap" @click.stop="expandSide">
          <div class="expand-icon">
            <icon :name="isExpand ? 'icon-s_fold' : 'icon-s_unfold'" color="#fff" />
          </div>
        </div>
      </div>
    </template>
  </database-index>
</template>
<script setup lang="ts">
import { Icon, MsTabs, InputSearch } from '@mysteel-standard/components'
import TreeComponents from './components/data-center-side'
import DatabaseIndex from './components/database-index.vue'
import IndexSearchModal from './components/data-center-side/index-search-modal.vue'
import CollectIndexModal from './components/data-center-side/collect-index-modal.vue'
import useSwitchTree from './composables/use-switch-tree'
import useCollectIndex from './composables/use-collection-index'
import { TabList } from './types/interface'
import useResize from './composables/use-resize'
import useIndexSearch from './composables/use-index-search'
import { useRoute } from 'vue-router'
import { ref, watch, nextTick } from 'vue'
const route = useRoute()
const components: any = TreeComponents
// 切换树
const { tabName, tabIndex, tabData, treeRef, tabClick } = useSwitchTree()
//指标搜索弹框
const {
  searchValue,
  indexSearchTitle,
  indexSearchVisible,
  searchIndex,
  searchIndexRef,
  dataBaseRef,
  extractOrAddIndex
} = useIndexSearch()
// 指标收藏弹窗
const {
  collectionIndexVisible,
  collectionIndexTitle,
  sureCollectIndex,
  collectIndex,
  isDirectory
} = useCollectIndex(treeRef, tabName)

//左侧宽度调整
const { directoryWidth, resizeEl, isExpand, expandSide, directoryRef } = useResize()

const frameIdsTree = ref([])
const indexIdsTree = ref([])
// 产业链跳转
watch(
  () => route.query,
  (val: any) => {
    // console.log('val', val)
    const { dbType, frameIds, indexCodes, isExtract, indexIds, deriveIndexes } = val
    if (indexCodes) {
      tabIndex.value = Number(dbType)

      frameIdsTree.value = frameIds
      indexIdsTree.value = indexIds
      const params = {
        indexCodes,
        deriveIndexes: deriveIndexes && JSON.parse(deriveIndexes)
      }

      nextTick(() => {
        indexCodes?.length && dataBaseRef.value.getIndexTableData(isExtract, false, params)
      })
    }
  },
  { immediate: true }
)
</script>
<style lang="scss" scoped>
@import './style/index.scss';
</style>
