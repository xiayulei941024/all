/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-03 15:44:46
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-07 10:05:13
 * @Description:
 */
import { useTreeExpand } from '@mysteel-standard/hooks'
import { onMounted } from 'vue'
export default (isDirectory?: boolean) => {
  //键盘按下事件
  const isCtrl = ref(false)
  const selectedTreeKeys = ref<number[]>([])
  const selectedTreeNodes = ref<any[]>([])
  const { expandedKeys, treeExpand, getItem } = useTreeExpand()
  const onkeydown = (e) => {
    // e.preventDefault();
    const ele = e || widow.event
    if (ele.keyCode === 17) {
      isCtrl.value = true
    }
  }
  //键盘抬起事件
  const onkeyup = (e) => {
    // e.preventDefault();
    const ele = e || widow.event
    if (ele.keyCode === 17) {
      isCtrl.value = false
    }
  }
  onMounted(() => {
    document.body.addEventListener('keydown', onkeydown)
    document.body.addEventListener('keyup', onkeyup)
  })

  // onDeactivated(() => {
  //   document.body.removeEventListener('keydown', onkeydown)
  //   document.body.removeEventListener('keyup', onkeyup)
  // })

  //树选中
  const nodeClick = (
    selectedKeys: number[],
    {
      node,
      selectedNodes
    }: {
      node: {
        expanded: boolean
        isLeaf: boolean
        key: number
        dataRef: any
        eventKey: number
        children: any[]
      }
      selectedNodes: any[]
    }
  ) => {
    const { isLeaf, key, dataRef, eventKey } = node
    // console.log('node', node)
    // console.log('selectedKeys', selectedKeys, selectedNodes)
    if (isLeaf) {
      if (isCtrl.value) {
        //多选按ctrl
        selectedTreeNodes.value = [...selectedNodes]
        selectedTreeKeys.value = [...selectedKeys]
      } else {
        selectedTreeKeys.value = [eventKey]
        selectedTreeNodes.value = [dataRef]
      }
    } else {
      selectedTreeKeys.value = [dataRef.id]
      selectedTreeNodes.value = [dataRef]
      nodeExpand(node)
    }
  }
  const nodeExpand = (node: any) => {
    const { expanded, key, children } = node
    if (!expanded) {
      expandedKeys.value = [...expandedKeys.value, key]
    } else {
      let childrenIds: number[] = []
      if (children) {
        childrenIds = getItem(node.children)
      }
      expandedKeys.value = expandedKeys.value.filter(
        (item: any) => item !== key && !childrenIds.includes(item)
      )
    }
    expandedKeys.value = [...expandedKeys.value]
  }
  //全部收起
  const allCollapse = (item: { label: string }, data: any) => {
    if (data.level === 1) {
      expandedKeys.value = expandedKeys.value.filter((item: any) => item !== data.id)
    } else {
      let childrenIds: number[] = []
      if (data.children) {
        childrenIds = getItem(data.children)
      }
      if (data.isLeaf && data.type === 2) {
        childrenIds.push(data.pid)
      }
      expandedKeys.value = expandedKeys.value.filter(
        (item: any) => item !== data.id && !childrenIds.includes(item)
      )
    }
  }

  return { selectedTreeKeys, selectedTreeNodes, expandedKeys, nodeClick, treeExpand, allCollapse }
}
