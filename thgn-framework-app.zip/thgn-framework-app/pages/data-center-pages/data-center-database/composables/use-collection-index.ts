/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-07 14:46:22
 * @Description:
 */
import api from '../api/index'
import { message } from 'gl-design-vue'
import { CollectTreeType } from '../types/interface'
export default (treeRef?: Ref, tabName?: Ref) => {
  const collectionIndexVisible = ref(false)
  const collectionIndexTitle = ref('')
  const nodeData = ref<any[]>([])
  const isDirectory = ref(false)
  const editFormulaForm = ref<any>({})
  const sureCollectIndex = async (selectedRow: CollectTreeType[]) => {
    const params = nodeData.value.map((item) => {
      const indexParams = {
        isDerive: item.isDerive || 0,
        unit: item.unit,
        frequency: item.frequency,
        sourceName: item.sourceName,
        resourceId: item.resourceId,
        decimalPlaces: item.decimalPlaces || null,
        editFormulaJson: editFormulaForm.value.editFormulaJson
      }
      return {
        pid: selectedRow[0].id,
        catalogName: selectedRow[0].catalogName,
        indexName: item.indexName || item.label,
        indexCode: item.indexCode || item.code,
        type: 2,
        indexShortName: item.indexShortName,
        indexParams: JSON.stringify(indexParams)
      }
    })
    const { err } = await api.collectIndexList(params)
    if (!err) {
      message.success('收藏成功')
      collectionIndexVisible.value = false
      tabName?.value === 'my-collection-tree' && treeRef?.value?.getMyCollectionTree()
    }
  }
  const collectIndex = async (title: string, data: any[], isMenu: boolean, form?: any) => {
    if (form) {
      editFormulaForm.value = form
    }
    isDirectory.value = isMenu
    nodeData.value = [...data]
    collectionIndexVisible.value = true
    collectionIndexTitle.value = title
  }

  return {
    collectionIndexVisible,
    collectionIndexTitle,
    sureCollectIndex,
    collectIndex,
    isDirectory
  }
}
