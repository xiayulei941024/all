/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 10:30:15
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-18 14:00:24
 * @Description:
 */
import api from '../../api/index'
import { message } from 'gl-design-vue'
import { useDownload } from '@mysteel-standard/hooks'
import dayjs from 'dayjs'
import { DataToolObj, DateType } from '../../types/interface'
import { useResetData } from '@mysteel-standard/hooks'
import { ref, Ref, nextTick, reactive } from 'vue'
export default (indexTableSelection: Ref, dateForm: DateType, dataTableHeight: Ref) => {
  const dataTableData: any = ref([])
  const dataTableLoading = ref(false)
  const lastResultKey = ref('')
  const detailTable = ref()
  const statisticalTableLoading = ref(false)
  const statisticalTableHeadList: any = ref([])
  const dataTableHeadList: any = ref([])
  const { dataState: dataToolsForm, resetDataState: dataToolsReset } = useResetData({
    dataSettings: false,
    flexRow: false,
    statistical: false
  })
  //统计数据
  const statisticalTableData: any = ref([])
  //导出
  const exportData = async () => {
    console.log(dateForm)

    const params = {
      beginTime:
        dateForm.date && dateForm.date.length && dateForm.date[0]
          ? dayjs(dateForm.date[0]).format('YYYY-MM-DD')
          : '',
      endTime:
        dateForm.date && dateForm.date.length && dateForm.date[1]
          ? dayjs(dateForm.date[1]).format('YYYY-MM-DD')
          : '',
      dateType: dateForm.dateType,
      indexCodeInfos: indexTableSelection.value,
      sortByDate: 1,
      titleEle: 'indexName,unit,frequency,quantumTime,indexCode,sourceName',
      timeCount: dateForm.timeCount,
      timeType: dateForm.timeType
    }
    console.log(params)

    const config = {
      responseType: 'arraybuffer'
    }
    const { res, err } = await api.exportIndexData(params, config)
    if (!err && res) {
      const config = {
        res,
        fileName: '指标数据明细.xls'
      }
      useDownload(config)
      message.success('下载成功')
    }
  }
  // 数据工具
  const dataToolsOperation = async (type: string, dataTools: DataToolObj) => {
    Object.assign(dataToolsForm, dataTools)
    if (type === 'Stat') {
      dataTableHeight.value = 257
      if (dataTools.statistical) {
        statisticalTableLoading.value = true
        dataTableHeight.value = dataTableHeight.value - 160
      }
    } else {
      dataToolsForm.statistical = false
      dataTableLoading.value = true
    }

    const params = {
      methodName: type,
      indexCodes: indexTableSelection.value,
      beginTime: dateForm.date && dateForm.date.length > 0 ? dateForm.date[0] : '',
      endTime: dateForm.date && dateForm.date.length > 0 ? dateForm.date[1] : '',
      sortOrder: -1,
      lastResultKey: lastResultKey.value,
      dataSettings: dataTools.dataSettings,
      timeCount: dateForm.timeCount,
      timeType: dateForm.timeType,
      dateType: dateForm.dateType,
      codeAndResourceIdList: indexTableSelection.value.map((item: any) => {
        return { indexCode: item.indexCode, resourceId: item.resourceId }
      })
    }
    const { res, err } = await api.indexDataTools(params)
    if (type === 'Stat') {
      statisticalTableLoading.value = false
    } else {
      dataTableLoading.value = false
    }

    if (!err && res) {
      const data = res.data
      const columns: any[] = []
      const heads: any[] = []
      data.columns.forEach((item: string) => {
        const headListItem: any = {}
        indexTableSelection.value.forEach((ele: any) => {
          if (item === ele.indexName) {
            headListItem.indexShortName = ele.indexShortName || ele.indexName
            headListItem.frequency = ele.frequency
            headListItem.unit = ele.unit
          }
        })
        headListItem.indexCode = item
        headListItem.indexName = item
        headListItem.width = 100
        if (item !== 'dataDate') {
          heads.push(headListItem)
        }
      })
      // console.log('heads', heads)
      if (type === 'Stat') {
        // 数据统计
        statisticalTableData.value = [...data.content]
        statisticalTableHeadList.value = [...heads]
        lastResultKey.value = data.lastResultKey
        return
      }
      dataTableData.value = [...data.content]
      dataTableHeadList.value = [...heads]
      lastResultKey.value = data.lastResultKey
    }
  }
  const flexColumnWidth = (str: string, flexRow: boolean) => {
    // 计算高度
    let flexWidth = 0
    for (const char of str) {
      if ((char > 'A' && char <= 'Z') || (char >= 'a' && char <= 'z')) {
        // 英文字符 分配10个单位
        flexWidth += 10
      } else if (char >= '\u4e00' && char <= '\u9fa5') {
        // 中文字符 分配 14个单位
        flexWidth += 16
      } else {
        // 其他种类字符 分配8个单位
        flexWidth += 16
      }
    }
    if (!flexRow) {
      return 200
    }
    return flexWidth >= 90 ? flexWidth : 90
  }
  //舒展、收缩列宽
  const flexColWidth = (flexRow: boolean) => {
    // 表格从新计算
    dataTableHeadList.value.forEach((item) => {
      item.width = flexColumnWidth(item.indexName, flexRow)
    })
  }
  //指标说明
  const indexInfoVisible = ref(false)
  const indexInfoTitle = ref('')
  const indexInfoForm = reactive({})
  const viewIndexInfo = (data: any) => {
    indexInfoTitle.value = `指标说明-${data.indexShortName}`
    indexInfoVisible.value = true
    nextTick(() => {
      Object.assign(indexInfoForm, data)
    })
  }
  return {
    dataTableData,
    dataTableLoading,
    dataToolsOperation,
    exportData,
    flexColWidth,
    viewIndexInfo,
    indexInfoVisible,
    indexInfoTitle,
    indexInfoForm,
    // 统计列表
    statisticalTableLoading,
    statisticalTableData,
    dataToolsForm,
    dataToolsReset,
    dataTableHeadList,
    statisticalTableHeadList,
    detailTable,
    lastResultKey
  }
}
