/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-26 11:54:02
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-10-20 14:29:42
 * @Description:
 */
import api from '../../api/index'
import { IndexType, DateType, FrequencyEnum } from '../../types/interface'
import _ from 'lodash-es'
import { message } from 'gl-design-vue'
import dayjs from 'dayjs'
import { ref, Ref, reactive, watch } from 'vue'
export default (
  emits: any,
  dataTableData: Ref,
  statisticalTableData: Ref,
  indexTableSelection: Ref,
  indexSelectedKeys: Ref,
  dateForm: DateType,
  dataTableLoading: Ref,
  dataTableHeadList: Ref,
  dataToolsReset: Function,
  dataTableHeight: Ref,
  lastResultKey: Ref,
  flexColWidth: Function,
  updateChartData: Function
) => {
  const indexTableData: any = ref([])
  const indexTableLoading = ref(false)
  const dataTopButtonRef = ref()
  const editFormulaForm = ref({})
  const collectDeriveIndexes = reactive<any[]>([])
  const indexCodes = reactive<any[]>([])
  //获取指标列表数据
  const getIndexTableData = async (
    isExTract = false, //提取（添加指标、不叠加）
    isAddExtract = false, //提取（添加指标、叠加指标）
    indexObj?: { indexCodes: any[]; deriveIndexes?: any[] }
  ) => {
    const params: any = { indexCodes: indexObj?.indexCodes || indexCodes } //产业链那边有传过来的指标编码
    if (indexObj && indexObj.deriveIndexes?.length) {
      //回显（产业链、图表）
      collectDeriveIndexes.length = 0
      collectDeriveIndexes.push(...indexObj.deriveIndexes)
    }
    if (collectDeriveIndexes && collectDeriveIndexes.length) {
      params.deriveIndexes = collectDeriveIndexes
    }
    indexTableLoading.value = true
    const { err, res } = await api.getIndexInfo(params)
    indexTableLoading.value = false
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        indexTableData.value = [...indexTableData.value, ...data]
        indexTableData.value = _.uniqBy(indexTableData.value, (item: IndexType) => item.indexCode)
        if (indexObj && indexObj.indexCodes.length) {
          //回显（产业链、图表、管理驾驶舱）
          indexTableSelection.value = indexTableData.value.filter(
            (item: any) =>
              indexObj.indexCodes?.includes(item.indexCode) ||
              indexObj.deriveIndexes?.includes(item.indexCode)
          )
          indexSelectedKeys.value = [...indexObj.indexCodes]
          if (indexObj.deriveIndexes && indexObj.deriveIndexes.length) {
            indexSelectedKeys.value = [...indexSelectedKeys.value, ...indexObj.deriveIndexes]
          }
        } else {
          setIndexTableCheck(data, isExTract) //设置选中项
        }
        ;(isExTract || isAddExtract) && exTractData() //提取
      }
    }
  }

  const setIndexTableCheck = (data: any[], isExTract = false) => {
    const selectedKeys = data.map((item) => {
      const obj = item.indexCode
      return obj
    })
    // 添加指标叠加，提取不用叠加
    indexSelectedKeys.value = isExTract
      ? [...selectedKeys]
      : [...indexSelectedKeys.value, ...selectedKeys]
    indexTableSelection.value = isExTract ? [...data] : [...indexTableSelection.value, ...data]
    indexSelectedKeys.value = [...new Set(indexSelectedKeys.value)]
    indexTableSelection.value = _.uniqBy(
      indexTableSelection.value,
      (item: IndexType) => item.indexCode
    )
    indexTableSelection.value = [...indexTableSelection.value]
    // console.log('indexTableSelection.value', indexTableSelection.value)
  }
  //添加指标
  const addIndex = (indexData: any[], isExTract = false, isAddExtract = false) => {
    console.log('indexData', indexData)
    collectDeriveIndexes.length = 0
    indexCodes.length = 0
    indexData.map((item: any) => {
      const code = item.code || item.indexCode
      const indexParams = (item.indexParams && JSON.parse(item.indexParams)) || ''
      if (indexParams && indexParams.isDerive) {
        collectDeriveIndexes.push(item.indexCode)
      } else {
        indexCodes.push(code)
      }
    })
    getIndexTableData(isExTract, isAddExtract)
  }

  //提取数据
  const exTractData = async (deriveIndexData?: string[], extractData?: any[]) => {
    const curSelections = extractData || indexTableSelection.value
    resetToolSet() //重置工具栏设置
    dataTopButtonRef.value?.resetMenuData() //重置数据工具菜单
    if (!curSelections.length) {
      message.error('请勾选指标')
      return
    }
    dataTableLoading.value = true
    const deriveIndex: string[] | string =
      deriveIndexData && deriveIndexData.length ? deriveIndexData[0] : ''
    const decimalPlaces: any = {}
    /* 重新排序 */
    curSelections.map((element: any) => {
      decimalPlaces[element.indexCode] = element.decimalPlaces
    })
    const indexCodes = curSelections
      .filter((i: IndexType) => !i.isDerive)
      .map((item: IndexType) => item.indexCode)
    const indexName = curSelections.map((item: IndexType) => item.indexShortName || item.indexName)
    const deriveIndexes =
      deriveIndexData && deriveIndexData.length
        ? deriveIndexData
        : curSelections
            .filter((i: IndexType) => i.isDerive)
            .map((item: IndexType) => item.indexCode)
    const codeAndResourceIdList = curSelections.map((item: IndexType) => {
      // console.log(deriveIndexData, item.indexCode)
      return {
        indexCode: deriveIndexData && deriveIndexData.length ? deriveIndex : item.indexCode
      }
    })
    const params = {
      indexName,
      indexCodes,
      deriveIndexes,
      frequency: deriveIndexData && deriveIndexData.length ? curSelections[0].frequency : '',
      beginTime: dateForm.date && dateForm.date.length ? dateForm.date[0] : '',
      endTime: dateForm.date && dateForm.date.length ? dateForm.date[1] : '',
      sortByDate: deriveIndexData && deriveIndexData.length ? 1 : -1,
      timeCount: dateForm.timeCount,
      timeType: dateForm.timeType,
      dateType: dateForm.dateType,
      codeAndResourceIdList,
      decimalPlaces
    }
    //
    const { res, err } = await api.getIndexData(params)
    dataTableLoading.value = false
    if (!err && res) {
      const { data } = res
      if (handleSeasonal(deriveIndexData, data)) {
        return
      } //季节性分析
      dataTableData.value = [...data]
      dataTableHeadList.value = curSelections ? [...curSelections] : [...indexTableSelection.value]
    }
  }
  // 季节性分析
  const handleSeasonal = (deriveIndexData: any, data: any[]) => {
    if (deriveIndexData && deriveIndexData.length && data.length > 0) {
      const headList: any[] = []
      Object.keys(data[0]).forEach((element) => {
        if (!(element === 'dataDate' || element === 'dataNo')) {
          headList.push({
            indexName: element + '年',
            indexCode: element,
            frequency: indexTableSelection.value[0].frequency,
            unit: indexTableSelection.value[0].unit,
            operation: 0,
            extractType: 'seasonal'
          })
        }
      })
      dataTableData.value = data.slice(1)
      dataTableHeadList.value = [...headList]
      return true
    }
  }
  //移除所选
  const removeCheck = () => {
    indexTableData.value = _.differenceWith(
      indexTableData.value,
      indexTableSelection.value,
      _.isEqual
    )
    indexTableSelection.value = []
    indexSelectedKeys.value = []
  }
  //删除行
  const deleteRow = (index: number, record: any) => {
    indexTableData.value = indexTableData.value.filter(
      (item: any) => item.indexCode !== record.indexCode
    )
    indexTableSelection.value = indexTableSelection.value.filter(
      (item: any) => item.indexCode !== record.indexCode
    )
    indexSelectedKeys.value = indexSelectedKeys.value.filter(
      (item: string) => item !== record.indexCode
    )
    // console.log(indexTableSelection.value, record)
  }
  const resetData = () => {
    dataTableData.value = []
    indexSelectedKeys.value = []
    indexTableSelection.value = []
    statisticalTableData.value = []
    dataTableHeadList.value = []
    dataTableHeight.value = undefined
  }
  const resetToolSet = () => {
    lastResultKey.value = ''
    dataToolsReset()
    flexColWidth()
  }
  watch(
    () => indexTableData.value,
    (val) => {
      if (!val.length) {
        resetToolSet()
        resetData()
      }
      updateChartData()
    },
    { deep: true }
  )
  //收藏指标
  const collectData = (title: string) => {
    emits('collect-index', title, indexTableSelection.value, true, editFormulaForm.value)
  }
  //反选
  const invertCheck = (checked: any[]) => {
    indexTableSelection.value = [...checked]
    indexSelectedKeys.value = checked.map((item: any) => {
      const obj = item.indexCode
      return obj
    })
    // console.log('indexSelectedKeys.value', indexSelectedKeys.value)
  }
  //获取计算参数
  const getParam = (name: string, form: any) => {
    const { type, cycle, index, average } = form.fromSmoothing
    // console.log('form', form)
    const obj: any = {
      变频: {
        newFrequency: form.newFrequency,
        calWayLow: form.calWayLow,
        calWayHigh: form.calWayHigh
      },
      同环比计算: {
        changeType: form.changeType,
        changeOption: form.changeOption,
        seqPeriod: form.seqPeriod
      },
      // accSumRequest
      累计求和: {
        accSumRequest: {
          type: form.type,
          period: form.type == 1 ? form.period : form.checked ? 1 : 0
        }
      },
      // smoothRequest
      修匀: {
        smoothRequest: {
          type: form.fromSmoothing.type,
          value:
            type === '1'
              ? String(cycle)
              : type === '2'
                ? String(index)
                : type === '3'
                  ? String(average)
                  : ''
        }
      },
      // indRequest
      指数化: {
        indRequest: {
          date: dayjs(form.date).format('YYYY-MM-DD'),
          point: form.point
        }
      },
      // adjustColRequest
      补充区间: {
        adjustColRequest: {
          supplementRangeReq: {
            type: form.intervalType,
            ignoreWeekend: form.ignoreWeekend
          }
        }
      },
      替换数据: {
        adjustColRequest: {
          replaceDataReq: {
            // 调整列--替换数据
            preData: form.preData,
            postData: form.postData
          }
        }
      },
      区间求和: {
        adjustColRequest: {
          rangeSumReq: {
            rangeInterval: form.rangeInterval
          }
        }
      },
      移动平均: {
        smoothRequest: {
          type: 3,
          value: String(form.moveType ? -form.moveValue : form.moveValue)
        }
      },
      标准化: {
        adjustColRequest: {
          standardizationReq: {
            type: form.standardType,
            minMaxValue: form.standardMinValue + '-' + form.standardMaxValue
          }
        }
      },
      后置: {
        adjustColRequest: {
          postPositionReq: {
            interval: form.interval
          }
        }
      },
      HP滤波: {
        lambdaPara: form.lambdaPara
      },
      成交价格测算: {
        calPrice: form.calPrice
      }
    }
    return obj[name]
  }
  // 指标计算
  const indexCalculation = (calculationForm: any, name: string, isEditFormula?: boolean) => {
    const dataSource = indexTableSelection.value
    editFormulaForm.value = calculationForm
    let params = {}
    const indexRequestList = dataSource.map((item: any) => {
      return {
        ...item,
        frequency: FrequencyEnum[item.frequency] ? FrequencyEnum[item.frequency] : item.frequency,
        isDerive: item.isDerive || 0
      }
    })
    /* 编辑公式 */
    if (isEditFormula) {
      params = {
        editFormula: calculationForm.editFormula,
        editFormulaName: calculationForm.editFormulaName,
        editFormulaFreStr: calculationForm.editFormulaFreStr,
        editFormulaJson: calculationForm.editFormulaJson,
        editFormulaScale: calculationForm.scala,
        indexRequestList
      }
    } else {
      params = {
        deriveOption: calculationForm.deriveOption,
        indexRequestList,
        ...getParam(name, calculationForm)
      }
    }
    submitCalFormula(params)
  }
  /* 衍生指标计算数据处理 */
  const disposeIndicators = (data: any) => {
    data.forEach((item: any) => {
      indexTableData.value.map((val: any) => {
        if (val.indexCode === item.indexCode) {
          message.error(val.indexName + '和该指标对应的指标编码或公式相同，请移除后再添加！')
        }
        return
      })
    })
    const newArr = data.filter((item: any) => {
      return !indexTableData.value.map((i: any) => i.indexCode).includes(item.indexCode)
    })
    indexTableData.value = [...indexTableData.value, ...newArr]
    indexTableSelection.value = [...indexTableSelection.value, ...newArr]
    const selectedKeys = indexTableSelection.value.map((item: any) => {
      const obj = item.indexCode
      return obj
    })
    indexSelectedKeys.value = [...selectedKeys]
  }
  // 编辑公式
  const submitCalFormula = async (params: any) => {
    const { res, err } = await api.getIndexCalFormula(params)
    indexTableLoading.value = false
    if (!err && res) {
      const { data } = res
      disposeIndicators(data)
    }
  }
  return {
    indexTableData,
    indexTableLoading,
    exTractData,
    removeCheck,
    collectData,
    addIndex,
    invertCheck,
    indexCalculation,
    deleteRow,
    dataTopButtonRef,
    getIndexTableData
  }
}
