<template>
  <div class="relevant-data">
    <gl-spin :spinning="loading">
      <div class="buttons">
        <gl-checkbox
          v-model:checked="checkAll"
          :indeterminate="isIndeterminate"
          @change="handleCheckAll"
          :disabled="dataList.length <= 0"
          style="margin-right: 16px"
        >
          全选
        </gl-checkbox>
        <gl-button type="primary" :disabled="checkedList.length <= 0" @click="handleAddIndex('')">
          <icon name="icon-add" />
          添加指标
        </gl-button>
        <gl-button
          type="primary"
          :disabled="checkedList.length <= 0"
          @click="handleAddIndex('1')"
          style="margin-left: 8px"
        >
          <icon name="icon-extract_outlined" />
          提取数据
        </gl-button>
      </div>
      <div v-if="dataList.length > 0" class="data-list">
        <list-item
          v-for="item in dataList"
          :key="item.indexCode"
          :data="item"
          @handle-checked="handleChecked"
          @handle-expand="handleExpand"
        ></list-item>
      </div>
      <div v-else class="nodata">
        <img src="../../assets/empty.png" alt="" />
        <span>暂无数据</span>
      </div>
    </gl-spin>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import ListItem from './list-item.vue'
import api from '../../api'
import { checkPermit } from '@mysteel-standard/hooks'
import { message } from 'gl-design-vue'
import { useRouter } from 'vue-router'
import { reactive, computed, watch, toRefs } from 'vue'
interface Props {
  breed: any
}
const props = defineProps<Props>()

//emits
interface Emits {
  (e: 'closeDetails'): void
}
const emits = defineEmits<Emits>()

const state = reactive({
  loading: false,
  checkAll: false,
  dataList: []
})
const { loading, checkAll, dataList }: { [key: string]: any } = toRefs(state)

const checkedList: any = computed(() => {
  return state.dataList.filter((item: any) => item.checked)
})
const isIndeterminate = computed(() => {
  return checkedList.value.length > 0 && checkedList.value.length < state.dataList.length
})

watch(
  () => checkedList.value,
  (val) => {
    if (val.length === 0) {
      state.checkAll = false
    } else if (val.length === state.dataList.length) {
      state.checkAll = true
    }
  }
)
watch(
  () => props.breed,
  async (val) => {
    if (val.indexList[0].indexCode) {
      const indexCodes = val.indexList.map((item: any) => item.indexCode)
      if (indexCodes.length > 0) {
        const params = {
          configId: val.configId,
          nodeId: val.nodeId,
          indexCodes
        }
        state.loading = true
        const { res, err } = await api.getIndexInfoList(params)
        state.loading = false
        if (res && !err) {
          state.dataList = res.data.map((item: any, i: number) => {
            if (i === 0) {
              return {
                ...item,
                checked: false,
                expanded: true,
                isDefault: true,
                frameIdPath: val.indexList[i].frameIdPath
              }
            }
            return {
              ...item,
              checked: false,
              expanded: false,
              isDefault: false,
              frameIdPath: val.indexList[i].frameIdPath
            }
          })
        }
      }
    } else {
      dataList.value = []
    }
  },
  {
    deep: true,
    immediate: true
  }
)

const router = useRouter()
const handleAddIndex = async (isExtract: string) => {
  const permit = checkPermit(['sjzx:sjk']) // 数据库菜单权限
  if (permit) {
    // 指标编码
    let indexCodes = checkedList.value.map((item: any) => item.indexCode)
    const frameIdPaths = checkedList.value.map((item: any) => {
      return item.frameIdPath && item.frameIdPath.split('|')
    })
    // 指标路径
    let frameIds: any[] = []
    frameIdPaths.forEach((item: any) => {
      frameIds = frameIds.concat(item)
    })
    let dbTypes: any = []
    let indexIds: any[] = []
    indexCodes.forEach((item: any) => {
      for (let i = 0; i < props.breed.indexList.length; i++) {
        const element = props.breed.indexList[i]
        if (element.indexCode === item) {
          dbTypes.push(element.dbType)
          indexIds.push(element.indexId)
          break
        }
      }
    })
    // 数据类型：mysteel数据库/企业数据库
    let dbType = 0
    if (!dbTypes.includes(0) && dbTypes.includes(1)) {
      dbType = 1
    }
    // 查询指标权限
    const { res, err } = await api.getAuthIndexCodes(indexCodes)
    if (res && !err) {
      indexCodes = res.data || []
      res.message && message.success(res.message)

      router.push({
        path: '/home/dataCenter/database',
        query: {
          indexCodes,
          frameIds,
          isExtract,
          dbType: dbType + 1,
          indexIds
        }
      })
      emits('closeDetails')
    }
  } else {
    message.warn('暂无数据库权限，请联系管理员！')
  }
}

const handleCheckAll = (val: any) => {
  if (val.target.checked) {
    state.dataList.forEach((item: any) => {
      item.checked = true
    })
  } else {
    state.dataList.forEach((item: any) => {
      item.checked = false
    })
  }
}
const handleChecked = (val: boolean, indexCode: string) => {
  state.dataList.forEach((item: any) => {
    if (item.indexCode === indexCode) {
      item.checked = val
    }
  })
}
const handleExpand = (val: boolean, indexCode: string) => {
  state.dataList.forEach((item: any) => {
    if (item.indexCode === indexCode) {
      item.expanded = val
    }
  })
}
</script>
<style lang="scss" scoped>
.relevant-data {
  height: 100%;

  .gl-spin-nested-loading,
  :deep(.gl-spin-container) {
    height: 100%;
  }

  .buttons {
    height: 64px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #e8e8e8;
  }
  .data-list {
    height: calc(100% - 64px);
    overflow: auto;
  }
  .nodata {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 14px;

    > img {
      display: inline-block;
      height: 172px;
      width: 400px;
    }
  }
}
</style>
