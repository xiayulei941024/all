export { default as IndustrialChain } from './index.vue'
