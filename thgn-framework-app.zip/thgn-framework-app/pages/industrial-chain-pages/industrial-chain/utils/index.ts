export const dataFilters = (n: any) => {
  if (!n && n !== 0) {
    return '-'
  }
  return n
}
export const upDownClass = (n: number | string) => {
  if (!n && n !== 0) {
    return ''
  }
  if (n === '-') {
    return ''
  }
  if (n > 0) {
    return ['red', '+']
  }
  if (n === 0) {
    return ['', '']
  }
  if (n < 0) {
    return ['green', '']
  }
  return ''
}

export const indexListOption = (
  data: any[],
  time: any[],
  legend: any,
  unit: string,
  frequency: string
) => {
  // 年度：全部、季度：近3年、月度：近1年、周度：近3个月、日度：近1个月；
  const frequencyMap: any = {
    年度: 0,
    季度: 100 - (12 / data.length) * 100,
    月度: 100 - (12 / data.length) * 100,
    周度: 100 - (12 / data.length) * 100,
    日度: 100 - (30 / data.length) * 100
  }
  const toolTipFormatter = function (params: any) {
    return `${params[0].axisValue}<br/>${params[0].marker}  <span style='font-weight:600;font-size:16px'>${params[0].data}</span>`
  }
  const option = {
    backgroundColor: '#ffffff',
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        crossStyle: {
          color: '#999'
        }
      },
      formatter: toolTipFormatter
    },
    legend: {
      // data: legend,
      left: 'center',
      top: 20,
      textStyle: {
        fontSize: 14,
        fontFamily: '微软雅黑',
        color: '#333333'
      }
    },
    grid: {
      // left: '4%',
      // right: '4%',
      top: 80
      // bottom: '15%',
      // containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: time,
      axisPointer: {
        type: 'shadow'
      },
      splitLine: {
        show: false
      },
      axisLabel: {
        color: '#666666'
      },
      axisLine: {
        onZero: false,
        lineStyle: {
          color: '#E8E8E8'
        }
      }
    },
    yAxis: [
      {
        min: function (value: any) {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          }
          return (value.min + 0.1 * value.min).toFixed(2)
        },
        type: 'value',
        name: unit || '',
        nameTextStyle: {
          color: '#666666'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          show: true,
          lineStyle: {
            color: '#E8E8E8'
          }
        }
      }
    ],
    dataZoom: [
      {
        type: 'inside',
        start: frequencyMap[frequency],
        end: 100
      },
      {
        type: 'slider',
        start: frequencyMap[frequency],
        end: 100,
        brushSelect: false,
        left: 80,
        right: 80,
        height: 20,
        backgroundColor: '#ffffff',
        fillerColor: '#F0F2F5',
        borderColor: 'rgba(206, 212, 217, 0.2)',
        textStyle: {
          color: '#333333'
        },
        handleStyle: {
          color: '#CED4D9',
          borderColor: '#CED4D9'
        }
      }
    ],
    color: [
      '#0090ff',
      '#f42743',
      '#f69332',
      '#6c41ff',
      '#b62ca1',
      '#2933ff',
      '#ff563f',
      '#edff57',
      '#38f8ff',
      '#1ac131'
    ],
    series: [
      {
        type: 'line',
        symbol: 'none',
        connectNulls: true,
        data: data,
        name: legend
        // color: '#F42743',
      }
    ]
  }
  return option
}
