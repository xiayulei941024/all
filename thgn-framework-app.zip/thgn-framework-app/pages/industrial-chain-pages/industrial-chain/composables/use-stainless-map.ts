/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-12-22 09:59:41
 * @Description:
 */
import { positionMap, iconNameMap } from '../types/interface'
import { ref, computed } from 'vue'

export default (props: any, emits: Function) => {
  const positionMapRef = ref<any>(positionMap)
  const iconNameMapRef = ref<any>(iconNameMap)

  const mapData1 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 1 && item.nodeId <= 5)
  })
  const mapData2 = computed(() => {
    return props.mapData.filter((item: any) => parseInt(item.nodeId) === 6)
  })
  const mapData3 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 7 && item.nodeId <= 12)
  })
  const mapData4 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 13 && item.nodeId <= 14)
  })
  const mapData5 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 15 && item.nodeId <= 21)
  })
  const mapData6 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 22 && item.nodeId <= 27)
  })
  const mapData7 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 28 && item.nodeId <= 30)
  })

  const mapData8 = computed(() => {
    return props.mapData.filter((item: any) => item.nodeId >= 31 && item.nodeId <= 37)
  })

  const showDetails = (data: any) => {
    emits('show-details', data)
  }

  return {
    positionMapRef,
    iconNameMapRef,
    mapData1,
    mapData2,
    mapData3,
    mapData4,
    mapData5,
    mapData6,
    mapData7,
    mapData8,
    showDetails
  }
}
