/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-02 17:12:13
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-30 15:57:02
 * @Description:
 */
import { ref } from 'vue'
export default (emits: any) => {
  //节点信息
  const nodeList: any = ref([])
  //连线信息
  const linkList: any = ref([])
  //虚线框
  const dashedNodeList: any = ref([])

  const linkStyle = () => {
    return {
      color: '#0149AA', // 连线颜色
      hover: '#FF0000' // 连线 hover 时颜色
    }
  }
  return { nodeList, linkStyle, linkList, dashedNodeList }
}
