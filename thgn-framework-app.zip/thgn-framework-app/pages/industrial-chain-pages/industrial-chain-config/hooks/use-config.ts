import { message } from 'gl-design-vue'
import { uniqBy } from 'lodash-es'
import Sortable from 'sortablejs'
import { ref, Ref } from 'vue'

//设为默认(指标配置、图表配置)
export const useSetDefault = (tableData: Ref) => {
  const setDefault = (row: any, index: number) => {
    tableData.value.splice(0, 0, tableData.value.splice(index, 1)[0])
    tableData.value[0].isDefault = 1
    message.success('操作成功')
  }
  return {
    setDefault
  }
}
//移除(指标配置、图表配置)
export const useMove = (tableData: Ref) => {
  const move = (index: number) => {
    tableData.value.splice(index, 1)
    message.success('移除成功')
  }
  return {
    move
  }
}
//添加、替换(指标配置、图表配置)
export const useAddOrChange = (tableData: any, type: string) => {
  const curIndex = ref<any>('')
  const addVisible = ref(false)
  const tableLoading = ref(false)
  const indexList = ref<any>([])
  const addOrChange = (index: number | string) => {
    addVisible.value = true
    curIndex.value = ''
    if (typeof index === 'number') {
      curIndex.value = index
    }
  }

  const getAddList = (dataList: any) => {
    let addItem: any = []
    let newData: any = []
    if (tableData.value && tableData.value.length) {
      newData = [...tableData.value]
    }
    if (type === 'chart') {
      addItem = dataList.map((item: any) => {
        const obj = {
          chartId: item.id, //tableKey
          config: JSON.stringify(item),
          chartName: item.name,
          isDefault: 0
        }
        return obj
      })
    } else {
      addItem = dataList.map((item: any) => {
        const obj = {
          ...item,
          isDefault: 0
        }
        return obj
      })
    }
    if (typeof curIndex.value === 'number') {
      //替换
      newData.splice(curIndex.value, 1)
      addItem.forEach((item: any) => {
        newData.splice(curIndex.value, 0, item)
      })
    } else {
      //新增
      newData.push(...addItem)
    }
    const key = type === 'chart' ? 'chartId' : 'indexCode'
    tableData.value = uniqBy(newData, key)
    tableData.value.forEach((item: any, index: number) => {
      if (index === 0) {
        item.isDefault = 1
      }
      item.sort = index
    })
  }
  return {
    addVisible,
    addOrChange,
    getAddList,
    tableLoading,
    indexList
  }
}
//编辑指标、图表
export const useEditName = (tableData: any, type?: string) => {
  const editVisible = ref(false)
  const indexForm = ref<any>({ indexName: '' })
  const chartForm = ref<any>({ chartName: '' })
  const curIndex = ref(0)
  const nameKey = type ? 'chartName' : 'indexName'
  const showEdit = (data: any, index: number) => {
    data.showEdit = false
    editVisible.value = true
    curIndex.value = index
    if (type) {
      chartForm.value[nameKey] = data[nameKey]
    } else {
      indexForm.value[nameKey] = data[nameKey]
    }
  }
  const changeName = (value: string) => {
    tableData.value[curIndex.value][nameKey] = value
  }
  return {
    editVisible,
    showEdit,
    changeName,
    indexForm,
    chartForm
  }
}
//拖拽排序
export const useTableSort = (dom: string, tableData: any, emits?: any) => {
  const tableSortable = () => {
    if (dom) {
      const tbody = document.querySelector(dom)
      // console.log('tbody', tbody)
      Sortable.create(tbody, {
        animation: 60,
        handle: '.move-icon',
        onEnd: ({ newIndex, oldIndex }: { newIndex: number; oldIndex: number }) => {
          newIndex--
          oldIndex--
          //获取移动列的id
          if (emits) {
            //调接口：配置列表拖拽
            const params = {
              id: Number(tableData[oldIndex].id),
              sort: Number(tableData[newIndex].sort),
              moveType: newIndex > oldIndex ? 2 : 1
            }
            emits('drag', params)
          } else {
            console.log('else')
            // 图表、指标配置
            tableData.value.splice(newIndex, 0, tableData.value.splice(oldIndex, 1)[0])
            message.success('移动成功')
          }
        }
      })
    }
  }
  return {
    tableSortable
  }
}
