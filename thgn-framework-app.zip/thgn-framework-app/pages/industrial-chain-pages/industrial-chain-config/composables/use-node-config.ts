/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-31 13:34:49
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-18 14:09:28
 * @Description:
 */
import api from '../api/index'
import { message } from 'gl-design-vue'
import { ref } from 'vue'
import { useResetData } from '@mysteel-standard/hooks'
export default (emits: any, industrialFlowRef: any) => {
  const nodeConfigVisible = ref(false)
  const nodeConfigLoading = ref(false)
  const nodeConfigRef = ref()
  const { dataState: nodeConfigForm, resetDataState: nodeConfigFormReset } = useResetData({
    configId: undefined,
    nodeId: undefined,
    chartConfig: [],
    indexConfig: [],
    infoConfig: '',
    reportConfig: ''
  })
  const curNodeData = ref({ configId: undefined, nodeId: undefined, nodeName: '', nodeIcon: '' })
  //编辑节点
  const editNode = (node: any) => {
    nodeConfigFormReset()
    nodeConfigVisible.value = true
    curNodeData.value = { ...node }
    nodeConfigLoading.value = true
    initData(curNodeData.value)
  }
  //回显数据
  const initData = async (data: any) => {
    nodeConfigFormReset()
    const params = {
      configId: data.configId,
      nodeId: data.nodeId
    }

    const { err, res } = await api.getNodeDetail(params)
    nodeConfigLoading.value = false
    if (!err && res) {
      const { data } = res
      data && Object.assign(nodeConfigForm, data)
      nodeConfigRef.value.initData(data)
    }
  }
  // 保存节点配置
  const sureNodeConfig = async (data: any) => {
    const { chartConfig, indexConfig, infoConfig, reportConfig, varietyname } = data
    const { configId, nodeId } = curNodeData.value
    const params = {
      configId,
      chartConfig,
      indexConfig,
      infoConfig,
      reportConfig,
      nodeId,
      varietyname
    }
    const { err, res } = await api.updateNodeDetail(params)
    if (!err && res) {
      message.success('保存成功！')
      nodeConfigVisible.value = false
      emits('reload-detail', industrialFlowRef?.value?.getFlowConfig())
    }
  }

  return {
    nodeConfigVisible,
    editNode,
    sureNodeConfig,
    nodeConfigForm,
    nodeConfigLoading,
    curNodeData,
    nodeConfigRef
  }
}
