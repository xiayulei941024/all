/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 10:45:30
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-28 13:49:08
 * @Description:
 */
export { default as IndustrialChainConfig } from './index.vue'
