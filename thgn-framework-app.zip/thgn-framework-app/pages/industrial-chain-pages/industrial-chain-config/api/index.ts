/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 11:55:21
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-12-15 15:40:57
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  // 产业链配置列表
  getConfigList: {
    method: 'post',
    url: '/database/panoramagram/getConfigList'
  },
  //新增修改配置
  addOrUpdateConfig: {
    method: 'post',
    url: '/database/panoramagram/addOrUpdateConfig'
  },
  //删除配置
  deleteConfig: {
    method: 'get',
    url: '/database/panoramagram/delete'
  },
  //复制配置
  copyConfig: {
    method: 'get',
    url: '/database/panoramagram/copy'
  },
  // 移动
  moveConfig: {
    method: 'post',
    url: ' /database/panoramagram/move'
  },
  //启用禁用配置
  enableConfig: {
    method: 'post',
    url: ' /database/panoramagram/disable'
  },
  //产业链配置查询
  getPanoramagramDetail: {
    method: 'get',
    url: '/database/panoramagram/getConfigNode'
  },
  //产业链配置保存
  addOrUpdateNode: {
    method: 'post',
    url: '/database/panoramagram/addOrUpdateNode'
  },
  //节点配置查询
  getNodeDetail: {
    method: 'post',
    url: '/database/panoramagram/getNodeDetail'
  },
  //节点配置保存
  updateNodeDetail: {
    method: 'post',
    url: '/database/panoramagram/updateNodeDetail'
  },
  // 获取指标详情
  getIndexInfo: {
    method: 'post',
    url: '/database/datacatalog/getIndexInfo'
  },
  // 图表缩略图列表
  queryChartsList: {
    method: 'post',
    url: '/database/chart/list'
  },
  // 删除节点相关信息
  deleteNode: {
    method: 'post',
    url: '/database/panoramagram/deleteNode'
  },
  // 获取资讯分类
  getTagClassifyList: {
    method: 'get',
    url: '/info/information/getTagClassifyList'
  },
  // 查询二级品种标签分类
  getTwoMultipleChoiceTagList: {
    method: 'get',
    url: '/info/information/getTwoMultipleChoiceTagList'
  },
  //编辑：用户详情
  getMenuList: {
    method: 'get',
    url: '/framework/menu/getMenuList'
  },
  //根据种类获取左侧栏目
  getInfoColumn: {
    method: 'get',
    url: '/info/information/getInfoColumn/1'
  },
  // 产业链数据(解析前)
  getIndexParseInfo: {
    method: 'get',
    url: '/database/panoramagram/getIndexParseInfoNew'
  },
  // 产业链数据(解析后)
  getIndexDataInfos: {
    method: 'post',
    url: '/database/panoramagram/getIndexDataInfos'
  },
  //获取资讯报告标签
  queryTagList: {
    method: 'get',
    url: '/info/information/queryTagList'
  }
}
export default request(apiMap)
