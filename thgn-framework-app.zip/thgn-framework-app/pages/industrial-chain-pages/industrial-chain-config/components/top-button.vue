<template>
  <gl-button type="primary" @click="handleAdd()"> <icon name="icon-add" /> 新增配置 </gl-button>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
interface Emits {
  (e: 'add-config'): void
}
const emits = defineEmits<Emits>()
const handleAdd = () => {
  emits('add-config')
}
</script>
<style lang="scss" scoped></style>
