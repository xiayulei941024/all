<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-31 11:33:54
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-08 11:33:25
 * @Description: 
-->
<template>
  <div class="flex-ac edit-bar">
    <icon name="icon-left_outlined" @click="back" size="22" color="#333" v-if="showReturn" />
    <slot name="icon" />
    <div class="flex-ac edit-bar-input" v-if="showEdit">
      <gl-input size="small" style="width: 162px" v-model:value="text" maxlength="22" />
      <icon name="icon-comform_outlined" color="#023985" @click="sureEdit" size="14" />
      <icon name="icon-unselect_outlined" color="#023985" @click="cancelEdit" />
    </div>
    <div class="flex-ac text" v-else>
      <span>{{ text }}</span>
      <icon name="icon-edit" @click="showInput" size="16" />
    </div>
  </div>
</template>
<script setup lang="ts">
import { message } from 'gl-design-vue'
import { ref, computed } from 'vue'
import { Icon } from '@mysteel-standard/components'
interface Props {
  name: string
  showReturn?: boolean
  tip: string
}
interface Emits {
  (e: 'back'): void
  (e: 'sure-edit', value: string): void
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const text = ref(props.name)
const rawText = computed(() => props.name)
const showEdit = ref(false)
const showInput = () => {
  showEdit.value = true
}
const sureEdit = () => {
  if (text.value.trim()) {
    emits('sure-edit', text.value)
    showEdit.value = false
  } else {
    message.warning(props.tip)
  }
}
const cancelEdit = () => {
  text.value = rawText.value
  showEdit.value = false
}
const back = () => {
  emits('back')
}
</script>
<style lang="scss" scoped>
$themeColor: #023985;
.edit-bar {
  // position: absolute;
  // top: 20px;
  // left: 20px;
  // z-index: 100;
  height: 32px;
  display: flex;
  align-items: center;
  .edit-bar-input {
    .el-input {
      margin: 0 6px;
    }
    .anticon {
      margin: 0 6px;
    }
  }
  .text {
    height: 100%;
    font-size: 14px;
    line-height: 32px;
    span {
      margin: 0 12px;
    }
  }
  .svg-icon {
    &:hover {
      color: $themeColor;
    }
  }
}
</style>
