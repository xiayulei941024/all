/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-02 17:12:13
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-13 19:01:19
 * @Description:
 */
import { message } from 'gl-design-vue'
import { ref } from 'vue'
export default (emits: any) => {
  //节点信息
  const nodeList: any = ref([])
  //连线信息
  const linkList: any = ref([])
  //节点菜单
  const nodeMenu = [
    [
      {
        label: '编辑',
        selected: (node: any) => {
          emits('edit-node-info', node)
        }
      },
      {
        label: '删除节点',
        selected: (node: any) => {
          if (node.graph.nodeList.length === 1) {
            message.warn('至少一个节点')
            return
          }
          node.remove()
        }
      }
    ]
  ]

  //连线菜单
  const linkMenuList = [
    [
      {
        label: '删除连线',
        disable: false,
        selected: (link: any) => {
          link.remove()
        }
      }
    ]
  ]

  const linkStyle = () => {
    return {
      color: '#0149AA', // 连线颜色
      hover: '#FF0000' // 连线 hover 时颜色
    }
  }
  return { nodeList, nodeMenu, linkStyle, linkMenuList, linkList }
}
