<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 12:00:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 09:30:32
 * @Description: 
-->
<template>
  <gl-form ref="formRef" layout="inline" :model="query" style="margin-bottom: 8px">
    <gl-form-item label="指标名称">
      <gl-input
        v-model:value="query.keywords"
        :disabled="!curMenuData?.isEnd"
        placeholder="请输入指标名称"
      ></gl-input>
    </gl-form-item>
    <gl-form-item label="指标频率">
      <gl-select
        v-model:value="query.frequency"
        :options="frequencyOptions"
        style="width: 120px"
        :disabled="!curMenuData?.isEnd"
      />
    </gl-form-item>
    <gl-form-item label="指标来源">
      <gl-select
        v-model:value="query.sourceName"
        :options="sourceOptions"
        style="width: 120px"
        :disabled="!curMenuData?.isEnd"
      />
    </gl-form-item>
    <gl-form-item label="分类">
      <gl-select
        v-model:value="query.category"
        :options="categoryOptions"
        :showSearch="true"
        style="width: 220px"
        :disabled="!curMenuData?.isEnd"
      />
    </gl-form-item>

    <gl-button type="primary" @click="tableSearch" :disabled="!curMenuData?.isEnd">
      <icon name="icon-search" />
      搜索
    </gl-button>
    <gl-button style="margin: 0 8px" @click="reset" :disabled="!curMenuData?.isEnd">
      <icon name="icon-reset" />
      重置
    </gl-button>
  </gl-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'

interface Props {
  curMenuData: any
  frequencyOptions: any
  sourceOptions: any
  categoryOptions: any
}
defineProps<Props>()
const { dataState: query, resetDataState: queryReset } = useResetData({
  keywords: '',
  frequency: '',
  sourceName: '',
  category: ''
})
interface Emits {
  (e: 'search', params: any): void
}
const emits = defineEmits<Emits>()

const tableSearch = () => {
  emits('search', query)
}
const reset = () => {
  queryReset()
  tableSearch()
}

defineExpose({ queryReset })
</script>
<style lang="scss"></style>
