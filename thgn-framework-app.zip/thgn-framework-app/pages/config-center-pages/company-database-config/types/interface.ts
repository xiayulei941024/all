/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-13 15:53:17
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-30 14:07:28
 * @Description:
 */
export interface DataBaseTreeType {
  label: string //目录名称	string
  children: DataBaseTreeType[] //子目录列表	array	IndexCollectVO
  isEnable: boolean
  isEnd: number //是否为末级目录 0:否 1：是
  id: number //  主键id	integer(int64)
  isLeaf: boolean //  true叶子节点 false非叶子节点	boolean
  pid: number // 	父节点id	integer(int64)
  sort: number //   排序字段	integer(int32)
  type: number // 类型，1：目录，2：指标	integer(int32)
  level: number
  hasChildIndex: boolean //	框架下是否有指标
}
//新增编辑目录
export interface MenuFormType {
  id?: number
  isLeaf: boolean
  pid: number
  label: string
  type?: number
  [propsName: string]: any //自定义类型
}
//树操作菜单
export interface OperationMenuType {
  [propsName: string]: any //自定义类型
}
