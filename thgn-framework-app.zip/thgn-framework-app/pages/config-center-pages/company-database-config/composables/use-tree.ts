/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 17:30:22
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
import { ref } from 'vue'

export default (emits: any, isEnable?: any) => {
  const treeLoading = ref(false)
  const selectedTreeKeys = ref([])
  const treeData = ref([
    {
      id: 0,
      label: '公司数据库',
      pid: 0,
      type: 1,
      children: [],
      isPublish: 1
    },
    {
      id: -1,
      label: '未分配指标',
      pid: 0,
      type: 1,
      isPublish: 1,
      isEnd: 1,
      hideMenus: true
    }
  ])
  const replaceFields = ref({
    children: 'children',
    title: 'name',
    key: 'id'
  })
  const setRootEnable = (data: any) => {
    if (!data && !data.length) return
    //设置根节点启用停用
    const isEnableItems = data.filter((item: any) => item.isPublish === 0)
    treeData.value[0].isPublish = 1
    if (isEnableItems.length && isEnableItems.length === data.length) {
      treeData.value[0].isPublish = 0
    }
  }
  const filterTree = (data: any) => {
    if (!data) return
    if (data.length) {
      data.forEach((item: any) => {
        if (item.isEnd) {
          item.isLeaf = true
        }
        if (item.children) {
          filterTree(item.children)
        }
      })
    }
  }
  //点击展开收起、多选
  const getTreeData = async () => {
    treeLoading.value = true
    const params = {
      parentId: 0,
      isEnable: isEnable || undefined
    }
    const { err, res } = await api.getDatabaseTree(params)
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      filterTree(data)
      treeData.value[0].children = data || []
      setRootEnable(data)
    }
  }

  const nodeClick = (selectedKeys: number[], { node }: { node: any }) => {
    emits('choose-node', node)
    if (!node.isEnd) {
      nodeExpand(node)
    }
  }

  const { expandedKeys, treeExpand, nodeExpand } = useTreeExpand()

  return {
    treeData,
    replaceFields,
    selectedTreeKeys,
    expandedKeys,
    getTreeData,
    treeLoading,
    nodeClick,
    treeExpand,
    nodeExpand
  }
}
