/*
 * @Autor: zouchuanfeng
 * @Date: 2024-07-10 16:39:11
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-29 15:50:52
 * @Description:
 */
import { nextTick, ref } from 'vue'
import { message } from 'gl-design-vue'
import api from '../api/index'
import { useResetData } from '@mysteel-standard/hooks'
export default (curMenuData: any, getIndexList: Function) => {
  const addIndexVisible = ref(false)
  const addIndexTitle = ref('')
  const isEdit = ref(false)
  const sureAddModifyLoading = ref(false)
  const { dataState: addModifyIndexForm, resetDataState: resetIndexForm } = useResetData({
    oldIndexName: '',
    indexName: '',
    priority: undefined,
    frequency: '日度',
    unit: '',
    sourceName: '',
    decimalPlaces: 0,
    isPublish: 1,
    relevanceIndex: undefined,
    varieties: undefined,
    parentId: undefined
  })
  const handleAdd = () => {
    addIndexVisible.value = true
    addIndexTitle.value = '新增指标'
    isEdit.value = false
    resetIndexForm()
  }
  const initForm = async (row: any) => {
    const params = {
      id: row.id
    }
    const { res, err } = await api.getIndexDetail(params)
    if (!err && res) {
      const { data } = res
      data && Object.assign(addModifyIndexForm, data)
    }
  }
  const handleModify = async (row: any) => {
    isEdit.value = true
    addIndexVisible.value = true
    addIndexTitle.value = '编辑指标'
    resetIndexForm()
    initForm(row)
  }
  //新增指标
  const sureAddIndex = async (formIndex: any) => {
    const params = { ...formIndex, parentId: Number(curMenuData.value.id), isEnable: 1 }
    sureAddModifyLoading.value = true
    const saveApi = isEdit.value ? api.editIndexInfo(params) : api.addIndex(params)
    const { err, res } = await saveApi
    sureAddModifyLoading.value = false
    if (!err && res) {
      getSourceNameList()
      getFrequencyList()
      addIndexVisible.value = false
      message.success(isEdit.value ? '编辑指标成功！' : '新增指标成功！')
      isEdit.value = false
      getIndexList(curMenuData.value)
    }
  }
  //批量新增指标
  const sureBatchAddIndex = async (file: any) => {
    sureAddModifyLoading.value = true
    const formData: any = new FormData()
    formData.append('file', file)
    formData.append('parentId', Number(curMenuData.value.id))
    const config = {
      headers: { 'Content-Type': 'multipart/form-data' }
    }
    const { err, res } = await api.importIndexInfo(formData, config)
    sureAddModifyLoading.value = false
    if (!err && res) {
      getFrequencyList()
      getSourceNameList()
      addIndexVisible.value = false
      message.success('导入成功')
      getIndexList(curMenuData.value)
    }
  }
  const frequencyOptions = ref([])
  const sourceOptions = ref([])

  // 指标来源枚举
  const getSourceNameList = async () => {
    const { res, err } = await api.sourceNameList()
    if (!err && res) {
      sourceOptions.value = [{ label: '全部', value: '' }]
      sourceOptions.value.push(
        ...res.data.map((item: any) => {
          return {
            label: item,
            value: item
          }
        })
      )
    }
  }

  // 指标频率枚举
  const getFrequencyList = async () => {
    const { res, err } = await api.frequencyList()
    if (!err && res) {
      frequencyOptions.value = [{ label: '全部', value: '' }]
      frequencyOptions.value.push(
        ...res.data.map((item: any) => {
          return {
            label: item,
            value: item
          }
        })
      )
    }
  }
  onMounted(() => {
    getSourceNameList()
    getFrequencyList()
  })

  return {
    addIndexVisible,
    addIndexTitle,
    isEdit,
    addModifyIndexForm,
    sureAddModifyLoading,
    handleAdd,
    handleModify,
    sureAddIndex,
    sureBatchAddIndex,
    frequencyOptions,
    sourceOptions
  }
}
