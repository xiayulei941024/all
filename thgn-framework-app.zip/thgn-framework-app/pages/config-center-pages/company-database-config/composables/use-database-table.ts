/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-29 11:12:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-29 15:42:05
 * @Description:
 */
import api from '../api/index'
import { message } from 'gl-design-vue'
import { nextTick, ref, reactive } from 'vue'
import { createVNode } from 'vue'
import { Modal } from 'gl-design-vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
export default () => {
  const moveIndexVisible = ref(false)
  const moveIndexTitle = ref('')
  const curMenuData = ref({})
  const moveIndexRef = ref()
  const databaseTableData = reactive([])
  const databaseTableLoading = ref(false)
  const sureMoveLoading = ref(false)
  const tableSelectedKeys = ref([])
  const tableSelectedRows = ref([])
  const searchFormRef = ref()
  const oldConfigList = reactive({})
  const checkedNodeName = ref('')
  let formTemp = ''
  //移动指标
  const handleMove = () => {
    moveIndexVisible.value = true
    moveIndexTitle.value = '移动指标'
    nextTick(() => {
      moveIndexRef.value.getCompanyTree()
    })
  }
  const sureMoveIndex = async (data: any) => {
    sureMoveLoading.value = true
    const params = {
      ids: tableSelectedKeys.value,
      newPid: data.id
    }
    const { err, res } = await api.moveIndex(params)
    sureMoveLoading.value = false
    if (!err && res) {
      moveIndexVisible.value = false
      message.success('移动成功!')
      getIndexList(curMenuData.value)
    }
  }
  //导出
  const handleExport = async (selectedIds: any) => {
    const params = {
      ids: selectedIds.join(',')
    }
    const url = `/database/api/database/config/exportIndexInfo?ids=${params.ids}`
    window.location.href = url
  }
  //刷新
  const refreshFlag = ref(false)
  const handleRefresh = async () => {
    refreshFlag.value = true
    const { res } = await api.refreshIndexCode()
    refreshFlag.value = false
    if (res) {
      message.success('编码刷新成功')
      getIndexList(curMenuData.value)
    }
  }
  const removeSelected = () => {
    tableSelectedKeys.value = []
    tableSelectedRows.value = []
  }
  //翻页
  const handlePageChange = (val: { pageNum: number; pageSize: number }) => {
    page.pageNum = val.pageNum
    page.pageSize = val.pageSize
    databaseSearch(formTemp)
  }

  //目录点击获取指标列表
  const getIndexList = async (data: any) => {
    checkedNodeName.value = data.label
    curMenuData.value = data
    searchFormRef.value?.queryReset()
    const params = {
      parentId: Number(data.id),
      type: 2,
      pageSize: page.pageSize,
      pageNum: 1
    }
    removeSelected()
    getCategoryOptions(data.id)
    databaseTableLoading.value = true
    const { err, res } = await api.getDatabaseList(params)
    databaseTableLoading.value = false
    if (!err && res) {
      databaseTableData.length = 0
      const { data } = res
      const filterData =
        data &&
        data.list?.length &&
        data.list.map((item: any) => {
          return {
            showInput: false,
            showEdit: false,
            ...item,
            indexName: item.label,
            indexCode: item.code
          }
        })
      Object.assign(databaseTableData, filterData)
      Object.assign(oldConfigList, JSON.parse(JSON.stringify(databaseTableData)))
      page.total = data.total
    }
  }

  //搜索
  const databaseSearch = async (form?: any) => {
    formTemp = form || {}
    databaseTableLoading.value = true
    const params = {
      parentId: Number(curMenuData.value.id),
      ...form,
      pageSize: page.pageSize,
      pageNum: page.pageNum
    }
    const { err, res } = await api.searchIndexInfo(params)
    databaseTableLoading.value = false
    if (!err && res) {
      databaseTableData.length = 0
      const { data } = res
      if (data?.list?.length) {
        const filterData =
          data &&
          data.list?.length &&
          data.list.map((item: any) => {
            return {
              showInput: false,
              showEdit: false,
              ...item
            }
          })
        Object.assign(databaseTableData, filterData)
        Object.assign(oldConfigList, JSON.parse(JSON.stringify(databaseTableData)))
        page.total = data.total
      }
    }
  }
  //排序
  const databaseTableSort = async (data: any) => {
    const params = {
      id: data.id,
      newPriority: data.newPriority,
      type: 2
    }
    databaseTableLoading.value = true
    const { err, res } = await api.dragCatalog(params)
    databaseTableLoading.value = false
    if (!err && res) {
      message.success('修改排序成功！')
      databaseSearch()
    }
  }
  const deleteIndex = async (params: any) => {
    const { err, res } = await api.deleteCatalog(params)
    if (!err && res) {
      message.success('删除成功！')
    }
    databaseSearch()
  }
  const handleDelete = (params: any, isConfirm = true) => {
    if (isConfirm) {
      Modal.confirm({
        title: '是否删除?',
        icon: createVNode(ExclamationCircleOutlined),
        onOk: () => {
          deleteIndex(params)
        }
      })
    } else {
      deleteIndex(params)
    }
  }
  //启用禁用
  const switchChange = async (params: { isEnable: number; id: string }) => {
    databaseTableLoading.value = true
    const { err, res } = await api.enableCatalog(params)
    if (!err && res) {
      message.success(params.isEnable ? '启用成功！' : '禁用成功！')
      databaseSearch()
    }
  }
  const onSelectChange = (selectedRowKeys: [], selectedRows: any[]) => {
    tableSelectedKeys.value = [...selectedRowKeys]
    tableSelectedRows.value = [...selectedRows]
  }
  const changePriority = async (params: any) => {
    databaseTableLoading.value = true
    const { res, err } = await api.dragCatalog(params)
    databaseTableLoading.value = false
    if (!err && res) {
      message.success('编辑成功！')
      databaseSearch()
    }
  }

  //重置翻页
  interface Page {
    total: number
    pageNum: number
    pageSize: number
  }
  const getInitPage = (): Page => ({
    total: 0,
    pageNum: 1,
    pageSize: 10
  })
  const page = reactive(getInitPage())
  const resetPage = () => {
    page.pageNum = 1
  }

  // 分类枚举
  const categoryOptions = ref([])
  const getCategoryOptions = async (frameId: string) => {
    const { res, err } = await api.getCategoryList({ frameId })
    if (!err && res) {
      categoryOptions.value = [{ label: '全部', value: '' }]
      categoryOptions.value.push(
        ...res.data.map((item: any) => {
          return {
            label: item,
            value: item
          }
        })
      )
    }
  }

  return {
    moveIndexVisible,
    moveIndexTitle,
    curMenuData,
    moveIndexRef,
    databaseTableData,
    databaseTableLoading,
    sureMoveLoading,
    handleMove,
    handleExport,
    handleRefresh,
    refreshFlag,
    sureMoveIndex,
    getIndexList,
    databaseSearch,
    databaseTableSort,
    handleDelete,
    switchChange,
    onSelectChange,
    tableSelectedKeys,
    tableSelectedRows,
    changePriority,
    searchFormRef,
    oldConfigList,
    checkedNodeName,
    resetPage,
    handlePageChange,
    page,
    categoryOptions
  }
}
