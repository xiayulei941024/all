/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-30 15:57:00
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-07 18:43:53
 * @Description:
 */
import { message } from 'gl-design-vue'
import { ref } from 'vue'
export default () => {
  const fileForRule = [{ required: true, message: '请选择文件', trigger: 'blur' }]
  const formIndexFile: any = ref({
    file: []
  })
  // 上传之前
  const onBeforeUpload = (file: any) => {
    if (formIndexFile.value.file.length) {
      message.warning(`当前限制选择 1 个文件`)
      return false
    }
    const type = file.name.substring(file.name.lastIndexOf('.') + 1)
    const isExcel = type === 'xlsx' || type === 'xls'
    const isLt2M = file.size / 1024 / 1024 < 10
    if (!isExcel) {
      message.warning('上传文件只能是 Excel格式!')
    } else {
      if (!isLt2M) {
        message.warning('上传文件大小不能超过 10MB!')
      }
    }
    return isExcel && isLt2M
  }
  const customRequest = (options: any) => {
    const { file } = options
    if (!file) {
      return false
    }
    formIndexFile.value.file = [file]
  }
  const handleRemove = () => {
    formIndexFile.value.file = []
  }
  return {
    formIndexFile,
    fileForRule,
    onBeforeUpload,
    customRequest,
    handleRemove
  }
}
