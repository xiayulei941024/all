/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 10:42:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-22 15:58:48
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: object = {
  // 新增接口
  add: {
    method: 'post',
    url: '/datafilling/typeConfig/config/add'
  },
  // 启禁用接口
  enable: {
    method: 'post',
    url: '/datafilling/typeConfig/config/enable'
  },
  // 删除接口
  delete: {
    method: 'post',
    url: '/datafilling/typeConfig/config/delete'
  },
  // 编辑接口
  update: {
    method: 'post',
    url: '/datafilling/typeConfig/config/update'
  },
  // 分类下拉查询接口
  typeList: {
    method: 'get',
    url: '/datafilling/typeConfig/config/typeList'
  },
  // 列表分页查询接口
  getListByPage: {
    method: 'post',
    url: '/datafilling/typeConfig/config/getListByPage'
  }
}

export default request(apiMap)
