/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 14:24:51
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-09 16:00:08
 * @Description:
 */
import api from '../api/index'
import { reactive, ref } from 'vue'
import { message } from 'gl-design-vue'
export default (getList: any) => {
  const modalVisible = ref(false)
  const modalLoading = ref(false)
  const modalTitle = ref('新建分类')

  const formItems = [
    {
      label: '分类名称',
      name: 'name',
      rules: [
        { required: true, message: '请输入分类名称' },
        { max: 25, message: '长度限制为25个字符', trigger: 'blur' }
      ]
    },
    {
      label: '应用模块',
      name: 'type',
      type: 'select',
      options: [
        { name: '数据填报', value: '1' },
        { name: '研报目录', value: '2' },
        { name: '研报分类', value: '3' }
      ],
      rules: [{ required: true, message: '请选择应用模块' }]
    }
  ]

  const formState = reactive({
    id: '',
    name: '',
    type: '1'
  })

  const submit = async () => {
    modalLoading.value = true
    let request = api.add
    if (modalTitle.value === '编辑分类') {
      request = api.update
    }
    const { res, err } = await request(formState)
    modalLoading.value = false
    if (res && !err) {
      if (res.code === '200') {
        message.success(`${modalTitle.value}成功`)
        modalVisible.value = false
        getList()
      }
    }
  }

  const showModal = (type: string, data: any) => {
    modalVisible.value = false
    modalTitle.value = type
    if (type === '新建分类') {
      formState.id = ''
      formState.name = ''
      formState.type = '1'
    } else {
      const { id, name, type } = data
      formState.id = id
      formState.name = name
      formState.type = type.toString()
    }
    modalVisible.value = true
  }
  return { modalVisible, modalTitle, modalLoading, submit, formItems, formState, showModal }
}
