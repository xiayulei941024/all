<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-09 15:37:18
 * @Description: 
-->
<template>
  <gl-form ref="formRef" layout="inline" :model="dataState">
    <gl-form-item label="最后修改时间">
      <gl-range-picker
        format="YYYY-MM-DD"
        value-format="YYYY-MM-DD"
        v-model:value="dataState.dateRange"
        separator="~"
        style="width: 280px"
      />
    </gl-form-item>
    <gl-form-item label="分类名称">
      <gl-input v-model:value="dataState.name" placeholder="请输入表单分类"></gl-input>
    </gl-form-item>
    <gl-button type="primary" @click="handleSearch">
      <icon name="icon-search" />
      搜索
    </gl-button>
    <gl-button style="margin: 0 8px" @click="reset">
      <icon name="icon-reset" />
      重置
    </gl-button>
  </gl-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'
const { dataState, resetDataState } = useResetData({
  dateRange: [],
  name: ''
})

interface Emits {
  (e: 'search', val: object): void
}

const emits = defineEmits<Emits>()
const handleSearch = () => {
  const [startTime, endTime] = dataState.dateRange
  dataState.startTime = startTime
  dataState.endTime = endTime
  emits('search', dataState)
}

const reset = () => {
  resetDataState()
  dataState.startTime = ''
  dataState.endTime = ''
  emits('search', dataState)
}
</script>
<style lang="scss"></style>
