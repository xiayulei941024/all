/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-08 22:21:41
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
import { onMounted, ref } from 'vue'

export default (emits: any) => {
  const treeLoading = ref<boolean>(false)
  const selectedTreeKeys = ref([])
  const treeData = ref([
    {
      id: 0,
      label: '公司数据库',
      pid: 0,
      type: 1,
      children: [],
      isEnable: 1
    }
  ])
  const replaceFields = ref({
    children: 'children',
    title: 'name',
    key: 'id'
  })
  const filterTree = (data: any) => {
    if (!data) return
    if (data.length) {
      data.forEach((item: any) => {
        if (item.isEnd) {
          item.isLeaf = true
        }
        if (item.children) {
          filterTree(item.children)
        }
      })
    }
  }
  //点击展开收起、多选
  const getTreeData = async () => {
    treeLoading.value = true
    const { err, res } = await api.getDatabaseTree({
      isEnable: 1
    })
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      filterTree(data)
      treeData.value[0].children = data || []
    }
  }

  const nodeClick = (selectedKeys: number[], { node }: { node: any }) => {
    if (node.isEnd) {
      emits('choose-node', node.id)
    } else {
      nodeExpand(node)
    }
  }

  const { expandedKeys, treeExpand, nodeExpand } = useTreeExpand()

  return {
    treeData,
    replaceFields,
    selectedTreeKeys,
    expandedKeys,
    getTreeData,
    treeLoading,
    nodeClick,
    treeExpand,
    nodeExpand
  }
}
