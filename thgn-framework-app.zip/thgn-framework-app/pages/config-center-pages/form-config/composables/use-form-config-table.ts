/*
 * @Autor: zouchuanfeng
 * @Date: 2023-09-04 09:20:51
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-14 16:10:43
 * @Description:
 */
import { message } from 'gl-design-vue'
import api from '../api/index'
export default (getList: Function) => {
  //复制
  const copyFormConfig = async (record: any) => {
    const params = {
      id: record.id,
      name: record.name
    }
    const { err, res } = await api.copyFormConfig(params)
    if (!err && res) {
      message.success('复制成功！')
      getList()
    }
  }
  return {
    copyFormConfig
  }
}
