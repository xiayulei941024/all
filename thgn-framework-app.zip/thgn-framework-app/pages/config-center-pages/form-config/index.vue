<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-04 15:07:33
 * @Description: 
-->
<template>
  <div class="form-config-wrap">
    <div class="search-container">
      <div class="search-form">
        <search-form @search="formConfigSearch" :typeList="typeList" />
      </div>
      <div class="table-btn-right">
        <top-button @add-form-config="() => showConfigModal(true, undefined)" />
      </div>
    </div>
    <div class="table-container">
      <form-config-table
        :loading="formConfigTableLoading"
        :data="formConfigTableData"
        @delete="handleDelete"
        @switch-change="switchChange"
        @copy="copyFormConfig"
        @sort-change="sortChange"
        @modify="(data) => showConfigModal(false, data)"
      />
    </div>
    <div class="pagination" v-if="configPage.total">
      <Pagination v-model:page="configPage" @page-change="formConfigPageChange" />
    </div>
    <!-- 新增表单 -->
    <add-modify-form-full-modal
      v-if="addModifyFormVisible"
      :loading="addModifyFormLoading"
      v-model:form="addModifyForm"
      v-model:addModifyFormVisible="addModifyFormVisible"
      :typeList="typeList"
      :processesList="processesList"
      :visibleUsers="visibleUsers"
      ref="addModifyRef"
      @sure-add-form-config="sureAddFormConfig"
    />
  </div>
</template>
<script setup lang="ts">
import { Pagination } from '@mysteel-standard/components'
import { useTableData } from '@mysteel-standard/hooks'
import api from './api/index'
import SearchForm from './components/search-form.vue'
import TopButton from './components/top-button.vue'
import FormConfigTable from './components/form-config-table.vue'
import AddModifyFormFullModal from './components/add-modify-form-full-modal.vue'
import useAddModifyForm from './composables/use-add-modify-form'
import useFormConfigTable from './composables/use-form-config-table'
//表格复用逻辑
const {
  getList,
  handlePageChange: formConfigPageChange,
  handleSearch: formConfigSearch,
  tableData: formConfigTableData,
  tableLoading: formConfigTableLoading,
  page: configPage,
  sortChange,
  switchChange,
  handleDelete
} = useTableData({
  tableApi: api.getFormConfigList,
  switchApi: api.enableFormConfig,
  deleteApi: api.deleteFormConfig
})
const { copyFormConfig } = useFormConfigTable(getList)

//编辑新增配置
const {
  addModifyFormVisible,
  addModifyFormLoading,
  addModifyForm,
  typeList,
  processesList,
  visibleUsers,
  sureAddFormConfig,
  showConfigModal,
  addModifyRef
} = useAddModifyForm(getList)
</script>
<style lang="scss" scoped>
@import './style/index.scss';
</style>
