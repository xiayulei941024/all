<template>
  <ms-table
    class="form-table"
    :columns="columns"
    :loading="loading"
    row-key="id"
    :data="tableData"
    @change="tableChange"
    @switch-change="handleSwitchChange"
  >
    <template #action="{ record }">
      <div class="operation-buttons">
        <gl-button type="text" @click.stop="handleCopy(record)"> 复制 </gl-button>
        <gl-button type="text" @click.stop="handleEdit(record)"> 编辑 </gl-button>
        <gl-popconfirm
          v-if="tableData.length"
          title="是否删除对应表单配置?"
          :disabled="record.isEnable === 1"
          @confirm="handleDelete(record.id, record.name)"
        >
          <gl-button type="text" :disabled="record.isEnable === 1"> 删除</gl-button>
        </gl-popconfirm>
      </div>
    </template>
  </ms-table>
</template>
<script setup lang="ts">
import { FormListType } from '../types/interface'
import { MsTable } from '@mysteel-standard/components'
import { computed } from 'vue'
interface Props {
  data: FormListType[]
  loading: boolean
}
const props = defineProps<Props>()
interface Emits {
  (e: 'modify', record: FormListType): void
  (e: 'sort-change', sorter: Object): void
  (e: 'switch-change', params: any): void
  (e: 'delete', params: { id: number }): void
  (e: 'copy', val: FormListType): void
}
const emits = defineEmits<Emits>()
//列表

onMounted(()=>{
  console.log(tableData)
})
const columns = [
  {
    title: '序号',
    dataIndex: 'index',
    key: 'index',
    align: 'center',
    width: 100
  },
  {
    title: '表单名称',
    dataIndex: 'name',
    key: 'name',
    ellipsis: true,
    width: 520
  },
  {
    title: '表单分类',
    dataIndex: 'typeName',
    key: 'typeName',
    ellipsis: true
  },
  {
    title: '修改人',
    dataIndex: 'updateName',
    key: 'updateName',
    ellipsis: true
  },

  {
    title: '修改时间',
    dataIndex: 'updateTime',
    key: 'updateTime',
    sorter: (a: any, b: any) => Date.parse(a.updateTime) - Date.parse(b.updateTime)
  },
  {
    title: '状态',
    dataIndex: 'isEnable',
    key: 'isEnable',
    type: 'switch',
    sorter: (a: any, b: any) => a.isEnable - b.isEnable
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 220
  }
]
const tableData = computed(() => props.data)
//状态切换
const handleSwitchChange = (record: any) => {
  const { id, isEnable } = record
  const params = {
    isEnable,
    id
  }
  emits('switch-change', params)
}
//删除
const handleDelete = (id: number, name: string) => {
  const params = { id, name }
  emits('delete', params)
}
//编辑
const handleEdit = (record: FormListType) => {
  emits('modify', record)
}
//复制
const handleCopy = (record: FormListType) => {
  emits('copy', record)
}
const tableChange = (page: Object, filters: Object, sorter: Object) => {
  emits('sort-change', sorter)
}
</script>
<style lang="scss" scoped></style>
