<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-01 17:37:25
 * @Description: 
-->
<template>
  <gl-spin :spinning="companyTreeLoading">
    <MsTree
      v-model:selectedKeys="companySelectedKeys"
      v-model:expandedKeys="companyExpandedKeys"
      autoExpandParent
      block-node
      draggable
      :tree-data="companyData"
      :fieldNames="companyFields"
      @select="companyNodeClick"
      @expand="treeExpand"
    />
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useCompayTree from '../../composables/use-company-tree'
interface Emits {
  (e: 'choose-node', data: any): void
}
const emits = defineEmits<Emits>()
// 公司数据库树
const {
  treeData: companyData,
  replaceFields: companyFields,
  selectedTreeKeys: companySelectedKeys,
  expandedKeys: companyExpandedKeys,
  getTreeData: getCompanyTree,
  treeLoading: companyTreeLoading,
  nodeClick: companyNodeClick,
  treeExpand
} = useCompayTree(emits)
defineExpose({ getCompanyTree })
</script>
