<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-01 15:04:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-09 23:43:23
 * @Description:指标配置列表
-->
<template>
  <ms-table
    class="index-config-table"
    :columns="columns"
    :loading="loading"
    row-key="indexCode"
    :data="tableData"
    :pagination="{
      size: 'large',
      showQuickJumper: true,
      showSizeChanger: true
    }"
    :row-selection="{
      selectedRowKeys: tableSelectedKeys,
      onChange: onSelectChange
    }"
  >
    <template #action="{ index }">
      <div class="operation-buttons">
        <gl-popconfirm v-if="tableData.length" title="是否移除该指标?" @confirm="handleMove(index)">
          <gl-button type="text"> 移除</gl-button>
        </gl-popconfirm>
      </div>
    </template>
  </ms-table>
</template>
<script setup lang="ts">
import { FormListType } from '../../types/interface'
import { MsTable } from '@mysteel-standard/components'
import { computed } from 'vue'
interface Props {
  data: FormListType[]
  loading: boolean
  tableSelectedKeys: any[]
}
const props = defineProps<Props>()
interface Emits {
  (e: 'remove', index: number): void
  (e: 'select-change', val: any[]): void
}
const emits = defineEmits<Emits>()
//列表
const columns = [
  {
    title: '序号',
    dataIndex: 'index',
    key: 'index',
    align: 'center',
    width: 100
  },
  {
    title: '指标编码',
    dataIndex: 'indexCode',
    key: 'indexCode',
    ellipsis: true
  },
  {
    title: '指标名称',
    dataIndex: 'indexName',
    key: 'indexName',
    ellipsis: true,
    width: 520
  },
  {
    title: '添加人',
    dataIndex: 'createUserName',
    key: 'createUserName',
    ellipsis: true,
    type: 'function',
    callback: (record: any) => {
      return record.createUserName ? record.createUserName : '-'
    }
  },

  {
    title: '添加时间',
    dataIndex: 'createTime',
    key: 'createTime',
    type: 'function',
    callback: (record: any) => {
      return record.createTime ? record.createTime : '-'
    }
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 220
  }
]
const tableData = computed(() => props.data)

//删除
const handleMove = (index: number) => {
  emits('remove', index)
}

const onSelectChange = (selectedRowKeys: []) => {
  emits('select-change', selectedRowKeys)
}
</script>
<style lang="scss" scoped>
:deep(.gl-pagination) {
  height: 72px;
  justify-content: center;
  align-items: center;
}
</style>
