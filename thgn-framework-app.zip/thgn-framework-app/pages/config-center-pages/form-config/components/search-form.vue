<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 12:00:05
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-08 09:18:43
 * @Description: 表单管理搜索
-->
<template>
  <ms-form
    v-model:formParams="formQuery"
    :formItems="formItems"
    layout="inline"
    labelAlign="left"
    ref="msFormRef"
    :label-col="labelCol"
  >
    <template #typeId>
      <gl-select
        v-model:value="formQuery.typeId"
        placeholder="请选择表单分类"
        :options="typeOptions"
        allowClear
        style="width: 200px"
      />
    </template>
    <template #action>
      <gl-button type="primary" @click="formConfigSearch">
        <icon name="icon-search" />
        搜索
      </gl-button>
      <gl-button style="margin: 0 8px" @click="reset">
        <icon name="icon-reset" />
        重置
      </gl-button>
    </template>
  </ms-form>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon, MsForm } from '@mysteel-standard/components'
import { FormListType } from '../types/interface'
import { computed } from 'vue'
import dayjs from 'dayjs'
const { dataState: formQuery, resetDataState: formQueryReset } = useResetData({
  date: [],
  name: '',
  typeId: undefined,
  updateName: ''
})
interface Props {
  typeList: any[]
}
const props = defineProps<Props>()
interface Emits {
  (e: 'search', query: FormListType): void
}
const emits = defineEmits<Emits>()

const labelCol = { style: { width: 'auto' } }

const typeOptions = computed(() => props.typeList)
const formItems = [
  {
    label: '表单名称',
    name: 'name',
    type: 'input'
  },
  {
    label: '表单分类',
    name: 'typeId',
    slotName: 'typeId'
  },
  {
    label: '修改人',
    name: 'updateName',
    type: 'input'
  },
  {
    label: '修改时间',
    name: 'date',
    type: 'date-range',
    style: { width: '240px' }
  },
  {
    label: '',
    slotName: 'action'
  }
]

const formConfigSearch = () => {
  const startTime =
    formQuery.date && formQuery.date[0] && dayjs(formQuery.date[0]).format('YYYY-MM-DD')
  const endTime =
    formQuery.date && formQuery.date[1] && dayjs(formQuery.date[1]).format('YYYY-MM-DD')
  const params = {
    endTime,
    startTime,
    name: formQuery.name,
    typeId: formQuery.typeId,
    updateName: formQuery.updateName
  }
  emits('search', params)
}
const reset = () => {
  formQueryReset()
  formConfigSearch()
}
</script>
<style lang="scss">
.gl-form-item {
  padding-right: 0 !important;
}
</style>
