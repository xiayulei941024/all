<template>
  <div class="index-config-wrap">
    <div class="index-table-btn">
      <index-config-top-button
        @add-index="addIndex"
        @remove-index="removeIndex"
        :formConfigTableData="formConfigTableData"
        :tableSelectedKeys="tableSelectedKeys"
      />
    </div>
    <div class="table-container">
      <index-config-table
        :loading="indexConfigTableLoading"
        :data="formConfigTableData"
        :tableSelectedKeys="tableSelectedKeys"
        @remove="handleMove"
        @select-change="selectedChange"
      />
    </div>
    <add-index-modal
      v-if="addIndexVisible"
      v-model:visible="addIndexVisible"
      :title="addIndexTitle"
      :loading="addIndexLoading"
      @sure-add-index="sureAddIndex"
    />
  </div>
</template>
<script setup lang="ts">
import IndexConfigTopButton from './index-config/index-config-top-button.vue'
import IndexConfigTable from './index-config/index-config-table.vue'
import AddIndexModal from './index-config/add-index-modal.vue'
import { computed } from 'vue'
import useIndexConfig from '../composables/use-index-config'

interface Props {
  indexCodesConfig: any
  id: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:indexCodesConfig', val: any): void
}
const emits = defineEmits<Emits>()
const formConfigTableData = computed({
  get() {
    return props.indexCodesConfig || []
  },
  set(val: any) {
    emits('update:indexCodesConfig', val)
  }
})
const {
  addIndexVisible,
  addIndexTitle,
  addIndexLoading,
  indexConfigTableLoading,
  addIndex,
  sureAddIndex,
  removeIndex,
  handleMove,
  tableSelectedKeys,
  selectedChange
} = useIndexConfig(formConfigTableData, props)
</script>
<style scoped lang="scss">
$table-layout-radius: 4px;
$pagination-height: 72px;
.index-config-wrap {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  height: calc(100vh - 220px);
  background: #fff;
  border-radius: $table-layout-radius;
  .index-table-btn {
    margin-bottom: 16px;
  }
  .table-container {
    flex: 1 1 auto;
    :deep(.operation-buttons) {
      margin-left: -10px;
      .gl-btn-text {
        padding: 4px 9px;
        &:hover {
          background: none;
        }
      }
    }
  }
  .pagination {
    height: $pagination-height;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>
