<!--
 * @Autor: zouchuanfeng
 * @Date: 2024-07-10 16:39:11
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-19 14:37:59
 * @Description: 
-->
<template>
  <div class="base-config">
    <ms-form v-model:formParams="baseConfigForm" :formItems="formItems" ref="msFormRef">
      <template #visibleUsers>
        <gl-select
          v-model:value="baseConfigForm.visibleUsers"
          mode="multiple"
          placeholder="请选择填报人"
          :options="visibleUsers"
          :filterOption="filterOption"
          style="width: 600px"
        ></gl-select>
      </template>
    </ms-form>
  </div>
</template>
<script setup lang="ts">
import { MsForm } from '@mysteel-standard/components'
import { computed, ref } from 'vue'
interface Props {
  typeList: any[]
  processesList: any[]
  form: any
  visibleUsers: any[]
}
interface Emits {
  (e: 'update:form', val: any): void
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const typeOptions = computed(() => props.typeList)
const processesOptions = computed(() => props.processesList)
const visibleUsers = computed(() => props.visibleUsers)
const baseConfigForm = computed({
  get() {
    return props.form
  },
  set(val: any) {
    emits('update:form', val)
  }
})
const formItems = [
  {
    label: '表单名称',
    name: 'name',
    type: 'input',
    style: { width: '600px' },
    rules: [
      { required: true, message: '请输入表单名称' },
      { max: 25, message: '长度限制为25个字符', trigger: 'blur' }
    ]
  },
  {
    label: '表单分类',
    name: 'typeId',
    type: 'select-default',
    options: typeOptions.value,
    style: { width: '600px' }
  },
  {
    label: '表单说明',
    name: 'remark',
    type: 'textarea',
    style: { width: '600px', height: '120px' }
  },
  {
    label: '设置填报人',
    name: 'visibleUsers',
    slotName: 'visibleUsers',
    rules: [{ required: true, message: '请选择填报人', trigger: 'blur' }]
  }
  // {
  //   label: '设置审批流',
  //   name: 'procId',
  //   type: 'select-default',
  //   options: processesOptions.value,
  //   allowClear: true,
  //   style: { width: '600px' }
  // }
]

const filterOption = (input: any, option: any) => {
  return option?.label?.includes(input)
}
const msFormRef = ref()
const isValidate = () => {
  return msFormRef.value.validate()
}
defineExpose({ isValidate })
</script>
<style scoped lang="scss">
:deep(.gl-select-multiple) {
  .anticon-close {
    display: flex;
    align-items: center;
    height: 100%;
  }
}
</style>
