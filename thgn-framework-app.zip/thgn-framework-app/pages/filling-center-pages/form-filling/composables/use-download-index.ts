/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-30 15:57:00
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-06 19:51:12
 * @Description:
 */
import { message } from 'gl-design-vue'
import { ref } from 'vue'
import Cookies from 'js-cookie'
export default () => {
  const fileList = ref([])
  const action = '/datafilling/form/uploadFile'
  const headers = ref({ accessToken: Cookies.get('accessToken') })
  const uploadLoading = ref(false)
  const fileForRule = [{ required: true, message: '请选择文件', trigger: 'blur' }]
  const uploadFile = ref(null)
  // 上传之前
  const onBeforeUpload = (file: any) => {
    const type = file.name.substring(file.name.lastIndexOf('.') + 1)
    const isExcel = type === 'xlsx' || type === 'xls'
    const isLt2M = file.size / 1024 / 1024 < 10
    if (!isExcel) {
      message.warning('上传文件只能是 Excel格式!')
    } else {
      if (!isLt2M) {
        message.warning('上传文件大小不能超过 10MB!')
      }
    }
    return isExcel && isLt2M
  }
  const handleChange = (info: any) => {
    uploadLoading.value = true
    if (info.file.status === 'done') {
      uploadLoading.value = false
      message.success(`${info.file.name} 文件上传成功`)
      const { data } = info.file.response
      uploadFile.value = data
    } else if (info.file.status === 'error') {
      uploadLoading.value = false
      message.error(`${info.file.name} 文件上传失败`)
    }
  }
  return {
    fileList,
    action,
    headers,
    fileForRule,
    onBeforeUpload,
    handleChange,
    uploadLoading,
    uploadFile
  }
}
