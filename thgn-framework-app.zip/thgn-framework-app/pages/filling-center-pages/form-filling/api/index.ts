/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-23 11:01:01
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-07 10:30:29
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: any = {
  //表单填报查询
  queryConfigByNameGroup: {
    url: '/datafilling/form/queryConfigByNameGroup',
    method: 'post'
  },
  //表单填报指标查询
  getFormIndexPreValue: {
    url: '/datafilling/form/getFormIndexPreValue',
    method: 'get'
  },
  //表单申请
  apply: {
    url: '/datafilling/form/apply',
    method: 'post'
  }
}
export default request(apiMap)
