<template>
  <div style="padding: 16px">
    <div class="form-filling">
      <div class="search-container">
        <div class="search-form">
          <gl-form ref="formRef" layout="inline" :model="form">
            <gl-form-item label="表单名称">
              <gl-input v-model:value="form.name" placeholder="请输入表单名称"></gl-input>
            </gl-form-item>
            <gl-button type="primary" @click="search">
              <icon name="icon-search" />
              搜索
            </gl-button>
          </gl-form>
        </div>
      </div>
      <div class="collapse-container">
        <gl-collapse v-model:activeKey="activeKey" :expandIconPosition="'right'" :ghost="true">
          <gl-collapse-panel v-for="(item, index) in formConfig" :header="item.name" :key="index">
            <ul class="list">
              <li
                class="form-item"
                v-for="list in item.formList"
                @click="queryList(list)"
                :key="list.id"
              >
                <img src="./assets/form.png" />
                <p :title="list.name">{{ list.name }}</p>
              </li>
            </ul>
          </gl-collapse-panel>
        </gl-collapse>
      </div>
      <!--  编辑查看表单弹窗 -->
      <add-modify-modal
        v-if="modalVisible"
        :configId="configId"
        v-model:modalVisible="modalVisible"
        @toBack="modalVisible = false"
      ></add-modify-modal>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import AddModifyModal from './components/add-modify-modal.vue'
import { onMounted, ref } from 'vue'
import api from './api/index'
//搜索
const form = ref({ name: '' })

//表单展示
const activeKey = ref([0])

const formConfig: any = ref([])
const search = async () => {
  const { res, err } = await api.queryConfigByNameGroup(form.value)
  if (res && !err) {
    formConfig.value = res.data
    activeKey.value = res.data.map((item: any, index: number) => index)
  }
}

//表单弹窗
const modalVisible = ref(false)
const configId = ref()
// 编辑查看表单
const queryList = (list: any) => {
  configId.value = list.id
  modalVisible.value = true
}

onMounted(() => {
  search()
})
</script>

<style lang="scss" scoped>
.form-filling {
  padding: 16px;
  height: calc(100vh - 126px);
  background: #fff;
  border-radius: 4px;
  padding: 16px;
  overflow: auto;
  .search-container {
    display: flex;
    justify-content: space-between;
    margin-bottom: 22px;
    .search-form {
      margin: 0 10px;
    }
  }
  .list {
    display: flex;
    flex-wrap: wrap;
  }
  .form-item {
    cursor: pointer;
    width: 120px;
    height: 112px;
    border-radius: 6px;
    border: solid 1px #cfd6dc;
    margin-left: 20px;
    margin-bottom: 20px;
  }

  .form-item img {
    margin: 16px 0 0 33px;
  }

  .form-item p {
    text-align: center;
    font-size: 14px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  :deep(.gl-collapse-header) {
    font-size: 16px;
    font-weight: 600;
    border-bottom: 1px solid #dddd;
    ::before {
      content: '';
      width: 4px;
      height: 16px;
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      background-color: #0149aa;
    }
  }
}
</style>
