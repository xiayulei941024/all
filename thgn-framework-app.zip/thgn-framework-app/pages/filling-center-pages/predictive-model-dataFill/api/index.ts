import request from '@mysteel-standard/apis'
const apiMap: object = {
  moduleSearch: {
    url: '/forecast/getModuleList?type=3',
    method: 'get',
  
  },
  getExpertForecastList: {
    url: '/forecast/getExpertForecastList',
    method: 'post',
  
  },
  getExpertForecastLogicList: {
    url: '/forecast/getExpertForecastLogicList',
    method: 'post',
  
  },
  getExpertForecastListSubmit: {
    url: '/forecast/getExpertForecastListSubmit',
    method: 'post',
  
  },
  // searchExpertScoreConfigDetail: {
  //   url: '/pricing/web/forecast/searchExpertScoreConfigDetail',
  //   method: 'post',
  // },
}
export default request(apiMap)
