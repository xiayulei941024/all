<template>
  <div class="forecoast-table" :loading="loading">
    <gl-row>
      <gl-form class="formModel" size="mini" :model="formModel" :label-col="labelCol">
        <gl-form-item label="频度 ：">
          <gl-radio-group
            v-model:value="formModel.type"
            @change="paramsChange"
            button-style="solid"
          >
            <gl-radio-button v-for="item in typeArr" :key="item.key" :value="item.key">
              {{ item.label }}
            </gl-radio-button>
          </gl-radio-group>
        </gl-form-item>
        <gl-form-item label="品种 ：">
          <gl-radio-group
            v-model:value="formModel.breedName"
            @change="paramsChange"
            button-style="solid"
          >
            <gl-radio-button v-for="item in breedArr" :key="item.key" :value="item.label">{{
              item.label
            }}</gl-radio-button>
          </gl-radio-group>
        </gl-form-item>
        <gl-form-item label="时间 ：">
          <gl-date-picker
            size="mini"
            v-show="formModel.type === 'week'"
            v-model:value="formModel.weekValue"
            picker="week"
            :allowClear="false"
            format="YYYY第ww周"
            valueFormat="YYYY-MM-DD"
            placeholder="选择周"
            :disabledDate="pickerOptionsWeek"
            @change="paramsChange"
          ></gl-date-picker>
          <gl-date-picker
            size="mini"
            v-show="formModel.type === 'month'"
            v-model:value="formModel.monthValue"
            picker="month"
            :allowClear="false"
            valueFormat="YYYY-MM-DD"
            placeholder="选择月"
            :disabledDate="pickerOptions"
            @change="paramsChange"
          ></gl-date-picker>
        </gl-form-item>
      </gl-form>
    </gl-row>
    <gl-row>
      <gl-table
        ref="tableDataRef"
        :columns="columns"
        :pagination="false"
        :data-source="tableData"
        :scroll="{ y: 450 }"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.dataIndex === 'expectForecastPriceTemp'">
            <slot name="expectForecastPriceTemp" v-bind="{ column, record }">
              <gl-input-number
                size="small"
                v-model:value="record.expectForecastPriceTemp"
                :controls="false"
                :max="999999"
                :min="-999999"
              ></gl-input-number>
            </slot>
          </template>
          <template v-else-if="column.dataIndex === 'forecastTrend'">
            <slot name="forecastTrend" v-bind="{ column, record }"
              ><span style="margin-right: 20px">
                {{ record.forecastTrend !== null ? trend[record.forecastTrend] : '--' }}
              </span>
            </slot>
          </template>

          <template v-else-if="column.dataIndex === 'forecastCommentTemp'">
            <slot name="forecastCommentTemp" v-bind="{ column, record }"
              ><gl-input v-model:value="record.forecastCommentTemp"></gl-input>
            </slot>
          </template>
          <template v-else>
            {{ fieldFormatter(record, column) }}
          </template>
        </template>
      </gl-table>
    </gl-row>
  </div>
</template>

<script setup lang="ts">
import moment from 'moment'
import { debounce } from 'lodash'
import { model, breed, forcastTableDataModel } from '../types/interface'
import api from '../api/index'
import { message } from 'gl-design-vue'
import { typeArr, columns } from '../constant/index'
interface Props {
  breedNameArr: Array<breed>
  trend: Object | any
}
const props = defineProps<Props>()

interface Emits {
  (e: 'afterSubmit', val: boolean): void
}
const emits = defineEmits<Emits>()
const labelCol = reactive({ style: { width: '83px' } })

const formModel = reactive<model>({
  type: 'week',
  breedName: '全部',
  weekValue: moment().startOf('week').add(5, 'd').format('YYYY-MM-DD'),
  monthValue: moment().endOf('month').format('YYYY-MM-DD')
})

const pickerOptionsWeek = (current: any) => {
  return (
    (current && current > moment().startOf('week').add(14, 'd')) ||
    (current && current <= moment().startOf('week'))
  )
}
const pickerOptions = (current: any) => {
  return (
    (current &&
      current < moment(moment().format('YYYY-MM-DD')).subtract(1, 'months').endOf('month')) ||
    (current && current > moment(moment().format('YYYY-MM-DD')).add(1, 'months').endOf('month'))
  )
}
const loading = ref<boolean>(false)

const tableDataRef = ref<any>(null)
const tableData = reactive<Array<forcastTableDataModel>>([])
const breedArr: any = computed(() => {
  if (props.breedNameArr.length > 0) {
    const breedNameList = [{ label: '全部', key: '' }]
    props.breedNameArr.forEach((item) => {
      breedNameList.push({ label: item.moduleName, key: item.moduleName })
    })

    return breedNameList
  }
  return []
})

const fieldFormatter = (row: any, column: any) => {
  return row[column.dataIndex] !== undefined &&
    row[column.dataIndex] !== null &&
    row[column.dataIndex] !== ''
    ? row[column.dataIndex]
    : '--'
}

const paramsChange = debounce(() => {
  getTableList()
}, 300)

watch(
  () => formModel.weekValue,
  (val) => {
    formModel.weekValue = moment(val).startOf('week').add(5, 'd').format('YYYY-MM-DD')
  }
)
watch(
  () => formModel.monthValue,
  (val) => {
    formModel.monthValue = moment(val).endOf('month').format('YYYY-MM-DD')
  }
)
onMounted(() => getTableList())
const getTableList = async () => {
  let date = moment().format('YYYY-MM-DD')
  if (formModel.type === 'week') {
    date = formModel.weekValue
  } else if (formModel.type === 'month') {
    date = formModel.monthValue
  }

  const params = {
    date: date,

    type: formModel.type,
    breedName: formModel.breedName === '全部' ? '' : formModel.breedName
  }

  loading.value = true
  const { res, err } = await api.getExpertForecastLogicList(params)
  loading.value = false
  tableData.length = 0
  if (!err) {
    const { data } = res
    data.map((v: any) => {
      v.forecastCommentTemp = v.forecastComment
      v.expectForecastPriceTemp = v.expectForecastPrice || undefined
      v.expertScoreResultTemp = v.expertScoreResult

      return null
    })
    tableData.push(...data)
  }
}

const submitList = async () => {
  const dataList = tableData.filter((v: any) => {
    const priceTemp =
      v.expectForecastPriceTemp &&
      (v.expectForecastPriceTemp !== v.expectForecastPrice ||
        v.forecastCommentTemp !== v.forecastComment ||
        v.expertScoreResultTemp !== v.expertScoreResult)
    return priceTemp
  })
  const params = dataList.map((v: any) => ({
    id: v.id, // 新增无需传， 更新需要传
    expectForecastPrice: v.expectForecastPriceTemp,
    breedName: v.breedName,
    areaName: v.areaName,
    dataDate: v.dataDate,
    forecastType: formModel.type === 'week' ? 2 : 3, // 频度： 周 2  月 3
    forecastComment: v.forecastCommentTemp, // 预测说明
    expertScoreResult: v.expertScoreResultTemp
  }))
  if (params.length === 0) {
    message.warning('您没有进行编辑！')
    emits('afterSubmit', true)
    return
  }
  const { res, err } = await api.getExpertForecastListSubmit(params)

  if (!err) {
    if (Number(res.code) === 200) {
      message.success('编辑成功！')
      emits('afterSubmit', false)
    }
  }
}

defineExpose({ submitList })
</script>
<style lang="scss" scoped>
.gl-input-number {
  width: 100%;
}
:deep(.gl-radio-button-wrapper) {
  padding: 0 5px;
}
</style>
