<template>
  <div class="chart-list-item">
    <div class="chart-name">
      <div class="chart-name-input">
        <template v-if="isEdit">
          <gl-input
            v-model:value="chartName"
            style="width: 180px"
            placeholder="修改名称"
            :maxlength="20"
          />
          <icon name="icon-comform_outlined" @click="handleEditFinished(item)" />
          <icon name="icon-unselect_outlined" @click="isEdit = false" />
        </template>
        <template v-else>
          <span class="view-name ellipsis" :title="item.name">{{ item.name }}</span>
          <icon
            v-if="item.myCreate && checkPermit(['sjzx:tbk:gstbkbj'])"
            name="icon-edit"
            @click="handleEditName(item)"
            title="编辑名称"
          />
        </template>
      </div>
      <div class="contextmenu-info">
        <icon
          v-if="!item.myCreate && selectItem.tabValue === 2"
          style="color: #ffca28"
          name="icon-star"
          @click="handleCollect(item.id)"
          title="取消收藏"
        />
        <icon
          v-if="item.myCreate && checkPermit(['sjzx:tbk:gstbkfz'])"
          name="icon-copy"
          @click="handleCopy(item.id)"
          title="复制"
        />
        <icon
          v-if="item.myCreate && checkPermit(['sjzx:tbk:gstbksc'])"
          name="icon-del"
          @click="handleDel(item.id)"
          title="删除"
        />
        <gl-dropdown
          v-if="
            !(selectItem.tabValue === 1 && item.myCreate && !checkPermit(['sjzx:tbk:gstbkydd']))
          "
          :trigger="['click']"
          @visible-change="onVisibleChange($event, item)"
        >
          <icon name="icon-drop_menu" />
          <template #overlay>
            <gl-menu @click="({ key: menuKey }: any) => menuClick(item, menuKey)">
              <div v-for="menuItem in menuData" :key="menuItem.key + menuItem.disabled">
                <gl-menu-item :key="menuItem.key" :disabled="menuItem.disabled">
                  {{ menuItem.name }}
                </gl-menu-item>
              </div>
            </gl-menu>
          </template>
        </gl-dropdown>
      </div>
    </div>
    <div class="chart-info">
      <div class="chart-img">
        <div
          class="img"
          :style="{
            backgroundImage: item.imageUrl ? `url(${item.imageUrl})` : false
          }"
        ></div>
      </div>
      <div class="chart-edit">
        <div
          v-if="item.myCreate && checkPermit(['sjzx:tbk:gstbkbj'])"
          class="btn btn-edit"
          @click="handleEdit(item)"
        >
          <Icon name="icon-edit" /><span class="text">编辑图表</span>
        </div>
        <div class="btn btn-preview" @click="handlePreview(item)">
          <Icon name="icon-preview" /><span class="text">预览图表</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { MenuData } from '../types/interface'
import { message } from 'gl-design-vue'
// import { BUTTON_LIST } from '../constants/buttons'
import { checkPermit } from '@mysteel-standard/hooks'

interface Props {
  item: any
  selectItem: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'handle-preview', item: any): void
  (e: 'handle-edit', item: any): void
  (e: 'menu-click', item: any, menuKey: number): void
  (e: 'update-name', item: any): void
  (e: 'handle-del', id: number): void
  (e: 'handle-copy', id: number): void
  (e: 'cancel-collect', id: number): void
}
const emits = defineEmits<Emits>()

const menuData = ref<any>([
  {
    name: '收藏图表',
    key: 1,
    disabled: false,
    permit: true
  },
  {
    name: '申请至公司图表库',
    key: 2,
    disabled: false,
    permit: checkPermit(['sjzx:tbk:sqzgstbk'])
  },
  {
    name: '从公司图表库移除',
    key: 3,
    disabled: false,
    permit: checkPermit(['sjzx:tbk:cgstbkyc'])
  },
  {
    name: '移动到',
    key: 4,
    disabled: false,
    // permit: checkPermit(['sjzx:tbk:gstbkydd'])
    permit: true
  }
])

const state = reactive({
  isEdit: false,
  chartName: ''
})
const { isEdit, chartName }: { [key: string]: any } = toRefs(state)

const onVisibleChange = (visible: boolean, item: any) => {
  let menuIndex: number[] = []
  if (props.selectItem.tabValue === 1) {
    /* 公司图表库 */
    menuIndex = item.myCreate ? [4] : [1, 3]
    if (!checkPermit(['sjzx:tbk:gstbkydd'])) {
      menuIndex = menuIndex.filter((el: number) => el !== 4)
    }
  }
  if (props.selectItem.tabValue === 2) {
    /*我的图表库*/
    menuIndex = item.myCreate === 1 ? [2, 4] : [4]
  }

  menuData.value = menuData.value
    .filter((el: MenuData) => menuIndex.includes(el.key) && el.permit)
    .map((data: MenuData) => {
      let isDis = false
      if (data.key === 2) {
        isDis = item.approvalStatus === 1 || item.approvalStatus === 2
      }
      return {
        ...data,
        disabled: isDis
      }
    })
}

const menuClick = (item: any, menuKey: number) => {
  emits('menu-click', item, menuKey)
}
const handleEdit = (item: any) => {
  emits('handle-edit', item)
}
const handlePreview = (item: any) => {
  emits('handle-preview', item)
}

//编辑名称
const handleEditFinished = (item: any) => {
  if (!state.chartName || !state.chartName.replace(/\s/g, '')) {
    message.error('图表名称不能为空')
    return
  }
  state.isEdit = false
  emits('update-name', { id: item.id, name: state.chartName })
}
const handleEditName = (item: any) => {
  state.isEdit = true
  state.chartName = item.name
}
// 删除
const handleDel = (id: number) => {
  emits('handle-del', id)
}
// 复制
const handleCopy = (id: number) => {
  emits('handle-copy', id)
}
// 收藏
const handleCollect = (id: number) => {
  emits('cancel-collect', id)
}
</script>
