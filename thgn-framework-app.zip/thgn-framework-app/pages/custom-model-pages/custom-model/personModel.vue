<template>
  <div class="system-management-company-wrap search-index-wrap">
    <div class="search-container">
      <div class="search-form">
        <openSearchForm @search="handleSearch" :isPublic="0" @getFormControl="getControl" />
      </div>

      <gl-row type="flex" justify="end">
        <gl-button type="primary" @click="addConfig()">
          <icon name="icon-add" /> 新增配置
        </gl-button>
      </gl-row>
    </div>
    <div class="table-container">
      <gl-table
        :loading="tableLoading"
        :data-source="tableData"
        :columns="columns"
        :pagination="false"
        row-key="id"
        :row-selection="{
          selectedRowKeys: tableSelectedKeys,
          onChange: onSelectChange,
          getCheckboxProps: onCheckChange
        }"
      >
        <template v-slot:bodyCell="{ column, record }">
          <template v-if="column.dataIndex === 'action'">
            <gl-button
              v-if="record.runState !== 1 && record.status === 1"
              type="text"
              @click="runBatch(record)"
            >
              立即执行
            </gl-button>
            <gl-button
              v-if="record.runState !== 1 && record.status === 0"
              type="text"
              @click="editConfig(record)"
            >
              编辑
            </gl-button>
            <gl-button type="text" @click="detail(record)">查看详情</gl-button>
            <gl-popconfirm
              title="确定删除吗?"
              @confirm="deleteConfig(record)"
              v-if="record.runState !== 1 && record.status === 0"
            >
              <gl-button type="text">删除</gl-button>
            </gl-popconfirm>
          </template>
          <template v-if="column.dataIndex === 'successRate'">
            <span>{{ record.successRate ? record.successRate + '%' : '-' }}</span>
          </template>
          <template v-if="column.dataIndex === 'status'">
            <div class="switch-status">
              <gl-switch
                v-model:checked="record.status"
                :checked-value="1"
                :un-checked-value="0"
                :disabled="record.runState === 1"
                @change="forbidden(record)"
              />
              <span class="text">{{ record.status ? '已开启' : '已禁用' }}</span>
            </div>
          </template>
          <template v-if="column.dataIndex === 'executeMechanism'">
            <!-- <span>{{ EXECUTE_MECHANISM.getDescFromValue(record.executeMechanism) }}</span> -->
            <span>{{
              record.executeMechanism === 0
                ? '单次执行'
                : record.forecastType === 2
                  ? '每周执行'
                  : '每月执行'
            }}</span>
          </template>

          <template v-if="column.dataIndex === 'runState'">
            <span>{{ RUN_STATE_TEXT.getDescFromValue(record.runState) }}</span>
          </template>
          <template v-if="column.dataIndex === 'isPublic'">
            <span>{{ IS_PUBLIC.getDescFromValue(record.isPublic) }}</span>
          </template>
          <template v-if="column.dataIndex === 'lastTime'">
            <span>{{ record.lastTime ? record.lastTime : '-' }}</span>
          </template>
          <template v-if="column.dataIndex === 'forecastType'">
            <span>{{ record.forecastType === 2 ? '周度' : '月度' }}</span>
          </template>
        </template>
      </gl-table>
    </div>
    <div class="pagination" style="justify-content: space-between">
      <div>
        <gl-button :disabled="!tableSelectedKeys.length" type="primary" @click="handleAllEnable(1)"
          >批量启用</gl-button
        >
        <gl-button
          :disabled="!tableSelectedKeys.length"
          type="primary"
          style="margin: 0 8px"
          @click="handleAllEnable(0)"
          >批量禁用</gl-button
        >
      </div>
      <Pagination v-model:page="page" @page-change="handlePageChange" />
    </div>

    <PublicModelDetail
      v-if="detailVisible"
      v-model:visible="detailVisible"
      :configDetail="configDetail"
      :calculateLoading="calculateLoading"
    />
    <customEdit
      v-model:visible="configVisible"
      :modelDetail="modelDetail"
      :data="formControls"
      :saveLoading="state.saveloading"
      @submit="submit"
    />
  </div>
</template>
<script setup lang="ts">
// import {} from './interface'
import { Pagination } from '@mysteel-standard/components'
import api from './api/index'
import openSearchForm from './components/open-search-form.vue'
import PublicModelDetail from './components/public-model-detail.vue'
import customEdit from './components/custom-edit.vue'
import { useTableData } from '@mysteel-standard/hooks'
import { RUN_STATE_TEXT, STATUS, EXECUTE_MECHANISM, IS_PUBLIC } from './enum/index'
import { message } from 'gl-design-vue'
import { Icon } from '@mysteel-standard/components'

const columns = reactive([
  {
    title: '计算状态',
    dataIndex: 'runState',
    width: '80px'
  },

  {
    title: '配置名称',
    dataIndex: 'name',
    ellipsis: true
  },

  {
    title: '品种',
    dataIndex: 'parentBreedName',
    ellipsis: true
  },

  {
    title: '细分品种',
    dataIndex: 'breedName',
    ellipsis: true
  },

  {
    title: '区域',
    dataIndex: 'areaName',
    ellipsis: true
  },

  {
    title: '频度',
    dataIndex: 'forecastType',
    ellipsis: true
  },

  {
    title: '固定因子数',
    dataIndex: 'constantIndexNum'
  },

  {
    title: '执行机制',
    dataIndex: 'executeMechanism',
    width: '80px'
  },
  {
    title: '是否公开',
    dataIndex: 'isPublic',
    width: '80px'
  },
  {
    title: '状态',
    dataIndex: 'status',
    width: '120px'
  },
  {
    title: '最后执行时间',
    dataIndex: 'lastTime',
    width: '170px'
  },

  {
    title: '操作',
    dataIndex: 'action',
    width: '200px'
  }
])
const state = reactive({
  saveLoading: false,
  formControl: []
})
const detailVisible = ref(false)
const configDetail = reactive<any>({})

const modelDetail = ref<any>({})
const configVisible = ref(false)
const tableSelectedKeys = reactive<Array<string>>([])
const { getList, handlePageChange, handleSearch, tableData, tableLoading, page } = useTableData({
  tableApi: api.selectConfigListByPage
})
const detail = async (record: any) => {
  const { res, err } = await api.configDetail({ configId: record.id })
  if (!err) {
    const { data } = res
    Object.assign(configDetail, data)
    detailVisible.value = true
    queryCalculateCompletes(record)
  }
}
const calculateLoading = ref(false)
const queryCalculateCompletes = async (record: any) => {
  const { res, err } = await api.queryCalculateComplete({ configId: record.id })
  if (!err) {
    calculateLoading.value = !res.data.complete
  }
}

const onSelectChange = (selectedRowKeys: any, selectedRows: any) => {
  tableSelectedKeys.length = 0
  tableSelectedKeys.push(...selectedRowKeys)
}
const onCheckChange = (record: any) => ({
  disabled: record.runState === 1 // Column configuration not to be checked
})
// 立即执行
const runBatch = (row: any) => {
  const list = [row.id]
  const status = row.status
  runBatchPost(list, status)
}
// 立即执行 接口
const runBatchPost = async (list: any, status: any) => {
  const params = {
    configIdList: list,
    status: status
  }
  const { res, err } = await api.runBatch(params)
  if (!err) {
    getList()
  }
}

// 启动/停止
const forbidden = (row: any) => {
  const list = [row.id]

  startOrStop(list, row.status)
}
// 启动/停止接口
const startOrStop = async (list: any, status: any) => {
  const params = {
    configIdList: list,
    status: status
  }
  const { res, err } = await api.configBatchStartStop(params)
  if (!err) {
    getList()
  }
}
const handleAllEnable = (status: any) => {
  const list = [...tableSelectedKeys]
  startOrStop(list, status)
}
// 删除
const deleteConfig = async (row: any) => {
  const { res, err } = await api.deleteCustomConfig({ configId: row.id })
  if (!err) {
    message.success('删除成功')
    getList()
  }
}

const editConfig = async (row: any) => {
  const { res, err } = await api.configDetail({ configId: row.id })
  if (!err) {
    const { data } = res
    Object.assign(modelDetail.value, data)
    configVisible.value = true
  }
}
const addConfig = () => {
  modelDetail.value = {}
  configVisible.value = true
}
const formControls = reactive<any[]>([])
const getControl = (val: any[]) => {
  formControls.length = 0
  formControls.push(...val)
}
const saveLoading = ref(false)
const submit = async (form: any, list: any, configId: any) => {
  // console.log(form)
  saveLoading.value = true
  const params = {
    isPublic: form.isPublic,
    id: configId,
    name: form.name,
    parentBreedName: form.parentBreedName,
    breedName: form.breedName,
    areaName: form.areaName,
    executeMechanism: form.executeMechanism,
    forecastType: form.forecastType,
    indexList: list
  }
  if (configId) {
    const { res, err } = await api.updateCustomConfig(params)
    saveLoading.value = false
    if (!err) {
      if (res.success) {
        configVisible.value = false
        nextTick(() => {
          handleSearch()
        })
      }
    }
  } else {
    const { res, err } = await api.saveCustomConfig(params)
    saveLoading.value = false
    if (!err) {
      if (res.success) {
        configVisible.value = false
        nextTick(() => {
          handleSearch()
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import './style/index.scss';
</style>
