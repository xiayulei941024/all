export const getMultiChartOption= (title:any, legend:any, time:any, unit:any, data:any, types:any, yA:any, id?:any) => {
  const formatNum=(value:any)=> {
    if (!value && value !== 0) return ''

    const str = value.toString()
    const reg =
      str.indexOf('.') > -1 ? /(\d)(?=(\d{3})+\.)/g : /(\d)(?=(?:\d{3})+$)/g
    return str.replace(reg, '$1,')
  }
  const title1 = title.length > 25 ? title.substring(0, 25) + '...' : title
    
  const initSeries = {
      line: {
        data: [], // data
        name: '', // legend
        smooth: true,
        connectNulls: true,
        type: 'line',
        smoothMonotone: 'x',
        symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
        // symbolSize: 5,
        showAllSymbol: true,
        itemStyle: {
          lineStyle: {
            width: 3 // 设置线条粗细
          }
        }
      },
      dottedLine: {
        data: [],
        name: '',
        type: 'line',
        symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
        // symbolSize: 5,
        showAllSymbol: true,
        connectNulls: true,
        smoothMonotone: 'x',
        smooth: true, // 为true是不支持虚线，实线就用true
        lineStyle: {
          type: 'dotted', // 'dotted'虚线 'solid'实线
          width: 3 // 设置线条粗细
        }
      },
      bar: {
        data: [],
        name: '',
        type: 'bar',
        itemStyle: {},
        markLine: {
          silent: true,
          data: [{ yAxis: 0, name: '' }],
          label: {
            show: false
          },
          symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
          // symbolSize: 5,
          showAllSymbol: true,
          lineStyle: {
            color: '#000'
          }
        }
      }
    }
    const series = data.map((v, k) => {
      const type = types[k]
      const item = JSON.parse(JSON.stringify(initSeries[type]))
      item.data = v
      item.name = legend[k]
      if (yA) {
        item.yAxisIndex = yA[k]
      }
      return item
    })
    let yAxis
    let dataZoom
    if (yA && yA.length > 1) {
      yAxis = [
        {
          min: value => {
            if (value.min >= 0) {
              return (value.min - 0.1 * value.min).toFixed(2)
            } else {
              return (value.min + 0.1 * value.min).toFixed(2)
            }
          },
          type: 'value',
          name: unit,
          nameTextStyle: {
            color: '#666666'
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            color: '#666666'
          },
          axisLine: {
            onZero: false,
            lineStyle: {
              color: '#DDDDDD'
            }
          }
        },
        {
          min: value => {
            if (value.min >= 0) {
              return (value.min - 0.1 * value.min).toFixed(2)
            } else {
              return (value.min + 0.1 * value.min).toFixed(2)
            }
          },
          type: 'value',
          name: unit,
          nameTextStyle: {
            color: '#666666'
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            color: '#666666'
          },
          axisLine: {
            onZero: false,
            lineStyle: {
              color: '#DDDDDD'
            }
          }
        }
      ]
      let len = time.length - 1 || 0
      const endValue = time[len]
      const allSeconds = 365 * 24 * 3600 * 1000
      let startValue = time[0]
      while (len >= 0) {
        const element = time[len]
        if (new Date(endValue) - new Date(time[0]) < allSeconds) {
          break
        }
        if (new Date(endValue) - new Date(element) > allSeconds) {
          break
        } else {
          startValue = element
        }
        len--
      }
      // console.log('=>start', startValue)
      // for (let index = time.length - 1; index < 0; index--) {
      // }
      // console.log('----')
      // console.log(startValue)
      // console.log(endValue)
      dataZoom = [
        {
          show: true,
          startValue,
          endValue,
          height: 20,
          brushSelect: false
        },
        {
          type: 'inside',
          start: 0,
          end: 100
        },
        {
          type: 'slider',
          start: 0,
          end: 100,
          height: 20,
          brushSelect: false,
          backgroundColor: '#fff',
          fillerColor: '#F0F2F5',
          borderColor: '#E8E8E8',
          textStyle: {
            color: '#333'
          },
          handleStyle: {
            color: '#CED4D9',
            borderColor: '#CED4D9'
          }
        }
      ]
    } else {
      yAxis = [
        {
          min: value => {
            if (value.min >= 0) {
              return (value.min - 0.1 * value.min).toFixed(2)
            } else {
              return (value.min + 0.1 * value.min).toFixed(2)
            }
          },
          type: 'value',
          name: unit,
          nameTextStyle: {
            color: '#666666'
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            color: '#666666'
          },
          axisLine: {
            onZero: false,
            lineStyle: {
              color: '#DDDDDD'
            }
          }
        }
      ]
      dataZoom = [
        {
          show: true,
          start: 0,
          end: 100,
          height: 20,
          brushSelect: false
        },
        {
          type: 'inside',
          start: 0,
          end: 100
        },
        {
          type: 'slider',
          start: 0,
          end: 100,
          height: 20,
          brushSelect: false,
          backgroundColor: '#fff',
          fillerColor: '#F0F2F5',
          borderColor: '#E8E8E8',
          textStyle: {
            color: '#333'
          },
          handleStyle: {
            color: '#CED4D9',
            borderColor: '#CED4D9'
          }
        }
      ]
    }
    const toolTipFormatter = (params:any) => {
      const line1 = { ...params[0] } || {}
      const line2 = params[1] || {}
      const line3 = params[2] || {}
      const title = line1.axisValue || line2.axisValue

      const { data, marker, seriesName } = line1

      const data1 = line1.data
        ? `${marker}${seriesName}: 
        ${formatNum(data)}<br />`
        : ''
      const data3 = line3.data
        ? `${line3.marker}${line3.seriesName}: 
        ${formatNum(line3.data)}<br />`
        : ''
      // const data3 =
      //   line3.data && !data
      //     ? `
      //       ${line3.marker}${line3.seriesName}
      //       : ${data ? '' : formatNum(line3.data)}
      //       <br />`
      //     : ''
      let data2 = ''
      if (id === 'comprehensiveChart') {
        data2 = line2.data
          ? `
            ${line2.marker}${line2.seriesName}:
            ${formatNum(line2.data)}
            <br />`
          : ''
      } else {
        data2 =
          line2.data && !data
            ? `
              ${line2.marker}${line2.seriesName}
              :${data ? '' : formatNum(line2.data)}
              <br />`
            : ''
      }
      return `
          ${title}<br />
          ${data1}
          ${data2}
          ${data3}
          `
    }
    const option = {
      backgroundColor: '#fff',
      title: {
        text: title1,
        left: 'center',
        textStyle: {
          color: '#333', // 颜色
          // fontStyle:'normal',     //风格
          fontWeight: 'bold', // 粗细
          fontFamily: '微软雅黑', // 字体
          fontSize: 16 // 大小
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999'
          }
        },
        formatter: yA ? '' : toolTipFormatter
      },
      legend: {
        data: legend,
        left: 'center',
        top: 30,
        textStyle: {
          fontSize: 14,
          fontFamily: '微软雅黑',
          color: '#333'
        }
      },
      grid: {
        left: '2%',
        right: '2%',
        bottom: '15%',
        top: '25%',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: time,
          axisPointer: {
            // type: 'shadow'
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            color: '#666666'
          },
          axisLine: {
            onZero: false,
            lineStyle: {
              color: '#DDDDDD'
            }
          }
        }
      ],
      yAxis,
      dataZoom,
      color: [
        '#0090ff',
        '#f42743',
        '#f69332',
        '#6c41ff',
        '#b62ca1',
        '#2933ff',
        '#ff563f',
        '#edff57',
        '#38f8ff',
        '#1ac131'
      ],
      series
    }
    // console.log({ option })
    return option
  
}