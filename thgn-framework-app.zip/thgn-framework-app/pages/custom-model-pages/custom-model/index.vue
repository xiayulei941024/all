<template>
  <div>
    <template v-if="isPublicState === 1">
      <publicModel></publicModel>
    </template>
    <template v-else>
      <personModel></personModel>
    </template>
  </div>
</template>
<script setup lang="ts">
import publicModel from './publicModel.vue'
import personModel from './personModel.vue'
interface Props {
  isPublic: number
}
const props = defineProps<Props>()
const isPublicState = computed(() => {
  return props.isPublic
})
</script>

<style lang="scss" scoped></style>
