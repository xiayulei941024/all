<template>
  <gl-layout>
    <gl-layout-sider>
      <side-bar @childSec="childSec" :modelTreeid="isPublic"></side-bar>
    </gl-layout-sider>
    <gl-layout-content>
      <div class="view-container">
        <CustomModel :isPublic="isPublic"></CustomModel>
      </div>
    </gl-layout-content>
  </gl-layout>
</template>
<script setup lang="ts">
import SideBar from './components/side-bar.vue'
import CustomModel from './custom-model/index.vue'
import { useBoardJump } from '@mysteel-standard/utils/store'
const isPublic = ref(1) //0 个人 1 公开

const childSec = (item: any) => {
  if (item.id === '2') {
    isPublic.value = 1
  } else {
    isPublic.value = 0
  }
}
onMounted(() => {})
</script>
<style lang="scss" scoped>
.gl-layout {
  height: calc(100vh - 96px);
}
</style>
