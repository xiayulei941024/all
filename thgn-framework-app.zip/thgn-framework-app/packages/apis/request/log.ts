/*
 * @Autor: zouchuanfeng
 * @Date: 2023-09-07 14:53:46
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 11:49:00
 * @Description:
 */
// 操作日志记录
import axios from './http'
import { cloneDeep } from 'lodash-es'
export default ({ url, params }: any) => {
  const logParams: any = cloneDeep(paramsList.find((item) => item.url === url))
  if (logParams === undefined) return
  logParams.operateContent = logParams.operateContent(params)
  if (
    url === '/database/panoramagram/addOrUpdateConfig' ||
    url === '/framework/user/insertOrUpdate' ||
    url === '/framework/role/insertOrUpdate'
  ) {
    logParams.operateAction = logParams.operateAction(params)
  }
  axios({
    method: 'post',
    url: '/framework/log/addOperateLog',
    data: logParams
  })
}

const paramsList = [
  {
    url: '/database/indexCollect/collectIndexList',
    operateModule: '数据中心-数据库',
    operateType: '数据',
    operateAction: '收藏指标',
    operateContent: (params: any) => params.map((item: any) => item.indexName)
  },
  {
    url: '/database/datacatalog/getIndexData',
    operateModule: '数据中心-数据库',
    operateType: '数据',
    operateAction: '提取数据',
    operateContent: (params: any) => params.indexName
  },
  {
    url: '/database/datacatalog/exportIndexData',
    operateModule: '数据中心-数据库',
    operateType: '数据',
    operateAction: '导出数据',
    operateContent: (params: any) => params.indexCodeInfos.map((item: any) => item.indexName)
  },
  {
    url: '/database/api/database/config/saveIndexInfo',
    operateModule: '配置中心-企业数据库配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增指标${params.indexName}`]
  },
  {
    url: '/database/api/database/config/saveFrameworkNode',
    operateModule: '配置中心-企业数据库配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增目录${params.label}`]
  },
  {
    url: '/database/api/database/config/editIndexInfo',
    operateModule: '配置中心-企业数据库配置',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑指标${params.indexName}`]
  },
  {
    url: '/database/api/database/config/editFrameworkNode',
    operateModule: '配置中心-企业数据库配置',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑目录${params.label}`]
  },
  {
    url: '/database/api/database/config/deleteNodeBatch',
    operateModule: '配置中心-企业数据库配置',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => {
      if (params.type === 2) {
        return params.indexNames.map((item: any) => `删除指标${item}`)
      }
      if (params.type === 1) {
        return params.labels.map((item: any) => `删除目录${item}`)
      }
    }
  },
  {
    url: '/datafilling/config/save',
    operateModule: '配置中心-表单配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增表单${params.name}`]
  },
  {
    url: '/datafilling/config/copy',
    operateModule: '配置中心-表单配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增表单${params.name}`]
  },
  {
    url: '/datafilling/config/edit',
    operateModule: '配置中心-表单配置',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑表单${params.name}`]
  },
  {
    url: '/datafilling/config/delete',
    operateModule: '配置中心-表单配置',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => [`删除表单${params.name}`]
  },
  {
    url: '/database/panoramagram/addOrUpdateConfig',
    operateModule: '配置中心-产业链配置',
    operateType: '系统',
    operateAction: (params: any) => `${params.id !== undefined ? '编辑' : '新增'}`,
    operateContent: (params: any) => [
      `${params.id !== undefined ? '编辑' : '新增'}产业链${params.panoramagramName}`
    ]
  },
  {
    url: '/database/panoramagram/copy',
    operateModule: '配置中心-产业链配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增产业链${params.panoramagramName}`]
  },
  {
    url: '/database/panoramagram/addOrUpdateNode',
    operateModule: '配置中心-产业链配置',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑产业链${params.panoramagramName}`]
  },

  {
    url: '/database/panoramagram/delete',
    operateModule: '配置中心-产业链配置',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => [`删除产业链${params.panoramagramName}`]
  },
  {
    url: '/database/varietyResearch/addCatalog',
    operateModule: '配置中心-品种研究配置',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => {
      if (params.type === 1) {
        return [`新增目录${params.name}`]
      } else {
        return [`新增页面${params.name}`]
      }
    }
  },
  {
    url: '/database/varietyResearch/updateCatalog',
    operateModule: '配置中心-品种研究配置',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => {
      if (params.type === 1) {
        return [`编辑目录${params.name}`]
      } else {
        return [`编辑页面${params.name}`]
      }
    }
  },
  {
    url: '/database/varietyResearch/deleteCatalog',
    operateModule: '配置中心-品种研究配置',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => {
      if (params.type === 1) {
        return [`删除目录${params.name}`]
      } else {
        return [`删除页面${params.name}`]
      }
    }
  },
  {
    url: '/approve/approvalProcess/addApprovalProcess',
    operateModule: '系统管理-审批流管理',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增审批流${params.processName}`]
  },
  {
    url: '/approve/approvalProcess/updateApprovalProcess',
    operateModule: '系统管理-审批流管理',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑审批流${params.processName}`]
  },
  {
    url: '/approve/approvalProcess/delete',
    operateModule: '系统管理-审批流管理',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => [`删除审批流${params.processName}`]
  },
  {
    url: '/datafilling/typeConfig/config/add',
    operateModule: '配置中心-分类管理',
    operateType: '系统',
    operateAction: '新增',
    operateContent: (params: any) => [`新增分类${params.name}`]
  },
  {
    url: '/datafilling/typeConfig/config/update',
    operateModule: '配置中心-分类管理',
    operateType: '系统',
    operateAction: '编辑',
    operateContent: (params: any) => [`编辑分类${params.name}`]
  },
  {
    url: '/datafilling/typeConfig/config/delete',
    operateModule: '配置中心-分类管理',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => [`删除分类${params.name}`]
  },
  {
    url: '/framework/user/insertOrUpdate',
    operateModule: '系统管理-用户管理',
    operateType: '系统',
    operateAction: (params: any) => `${params.id !== undefined ? '编辑' : '新增'}`,
    operateContent: (params: any) => [
      `${params.id !== undefined ? '编辑' : '新增'}用户${params.userName}`
    ]
  },
  {
    url: '/framework/user/delete',
    operateModule: '系统管理-用户管理',
    operateType: '系统',
    operateAction: '删除',
    operateContent: (params: any) => [`删除用户${params.userName}`]
  },
  {
    url: '/framework/role/insertOrUpdate',
    operateModule: '系统管理-角色管理',
    operateType: '系统',
    operateAction: (params: any) => `${params.id !== undefined ? '编辑' : '新增'}`,
    operateContent: (params: any) => [
      `${params.id !== undefined ? '编辑' : '新增'}角色${params.roleName}`
    ]
  },
  {
    url: '/framework/role/delete',
    operateModule: '系统管理-角色管理',
    operateType: '删除',
    operateAction: '删除',
    operateContent: (params: any) => [`删除角色${params.roleName}`]
  }
]
