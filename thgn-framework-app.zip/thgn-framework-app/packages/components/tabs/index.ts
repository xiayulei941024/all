/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-13 15:40:37
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-06-13 15:47:48
 * @Description:
 */
export { default as MsTabs } from './index.vue'
