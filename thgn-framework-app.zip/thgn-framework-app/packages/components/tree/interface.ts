/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-12 16:31:10
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-28 15:56:29
 * @Description:
 */
export interface NodeType {
  label: string
  id: number
  isLeaf: boolean
  leafIcon?: string
  level?: number
  type: number
  [propName: string]: any
}
export interface NodeMenuType {
  label: string
  condition?: Function
  disabled?: boolean
  handle?: Function
}
export enum NodeIconType {
  '专题' = 'zhuanti',
  '下游' = 'xiayouzhongduan',
  '期货' = 'qihuo',
  '黑色' = 'heise',
  '螺纹钢' = 'luowengang',
  '盘螺' = 'panluo',
  '电煤' = 'dianmei',
  '废钢' = 'feigang',
  '钢材' = 'gangcai',
  '钢铁' = 'gangtie',
  '宏观' = 'hongguan',
  '焦煤' = 'jiaomei',
  '焦炭' = 'jiaotan',
  '兰炭' = 'lantan',
  '建材' = 'jiancai',
  '耐材' = 'naicai',
  '喷吹煤' = 'penchuimei',
  '动力煤' = 'donglimei',
  '铁矿石' = 'tiekuangshi',
  '线材' = 'gongyexiancai',
  '煤炭' = 'meitan',
  '铁合金' = 'tiehejin',
  '不锈钢' = 'buxiugang',
  '高线' = 'gaoxian',
  '热轧板卷' = 'reyabanjuan',
  '中厚板' = 'zhonghouban',
  '金融' = 'jinrong',
  '淀粉' = 'dianfen',
  '混凝土' = 'hunningtu',
  '水泥' = 'shuini',
  '能化' = 'nenghua',
  '有色' = 'hasColor',
  '农产品' = 'nongchanpin',
  '农林牧渔' = 'nonglinmuyu',
  '新能源' = 'xinnengyuan'
}
