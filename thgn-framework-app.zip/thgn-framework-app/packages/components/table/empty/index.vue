<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-04 11:17:46
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-03 16:18:59
 * @Description: 
-->
<template>
  <div class="empty-div">
    <img v-if="emptyImg" src="../assets/images/empty.png" alt="" />
    <div class="empty-text">{{ emptyText }}</div>
    <slot name="empty" />
  </div>
</template>
<script lang="ts" setup>
interface Props {
  emptyText?: string
  emptyImg?: boolean
}
withDefaults(defineProps<Props>(), {
  emptyText: '暂无数据',
  emptyImg: true
})
</script>

<style scoped lang="scss">
.empty-div {
  color: #999999;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding-top: 10%;
  img {
    width: 17.83vw;
    height: 6.95vw;
  }
  :deep(.empty-tip) {
    font-size: 12px;
  }
  .empty-text {
    font-size: 14px;
    text-align: center;
  }
}
</style>
