<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-04 17:02:49
 * @Description: 
-->
<template>
  <gl-table
    :data-source="dataSource"
    :columns="tableColumns"
    v-bind="$attrs"
    :pagination="false"
    :scroll="{ y: height }"
    :size="size"
    @resizeColumn="handleResizeColumn"
  >
    <template #headerCell="{ column }">
      <slot name="header" v-bind="{ column }" />
    </template>
    <template #emptyText>
      <Empty :emptyImg="emptyImg" :empty-text="emptyText" />
    </template>
    <template #bodyCell="{ column, record, index }">
      <template v-if="column.dataIndex === 'drag' && column.slotName !== 'drag'">
        <div class="move-icon"><icon name="icon-move_outlined2" /></div>
      </template>
      <template v-if="column.dataIndex === 'index'">
        <div>
          {{ index + 1 }}
        </div>
      </template>
      <!-- type分类名称： type:function, switch=> type: switch -->
      <slot
        v-if="column.slotName"
        :name="column.slotName"
        v-bind="{ column, record, index }"
      ></slot>
      <component
        v-if="column.type"
        :is="components[column.type]"
        :record="record"
        :column="column"
        v-model:value="record[column.dataIndex]"
        @switch-change="tableSwitch"
        @handle-click="handleClick"
      ></component>
      <template v-if="column.dataIndex === 'action'">
        <slot name="action" v-bind="{ column, record, index }" />
      </template>
    </template>
  </gl-table>
</template>
<script setup lang="ts">
import { Icon } from '../Icon'
import tableComponents from './components'
import Empty from './empty/index.vue'
const components: any = tableComponents
import { computed } from 'vue'
interface Props {
  data: any[]
  columns: any[]
  height?: number
  size?: string
  emptyImg?: boolean
  emptyText?: string
}
const props = withDefaults(defineProps<Props>(), {
  height: 540,
  size: 'small',
  emptyImg: true
})
interface Emits {
  (e: 'switch-change', record: Object): void
  (e: 'resize-column', val: number, column: { dataIndex: string }): void
  (e: 'handle-click', record: Object): void
}
const emits = defineEmits<Emits>()
const tableColumns = computed(() => props.columns)
const dataSource = computed(() => props.data)
//switch
const tableSwitch = (record: Object) => {
  emits('switch-change', record)
}
//可伸缩列
const handleResizeColumn = (w: number, column: { dataIndex: string }) => {
  tableColumns.value.forEach((item) => {
    if (item.dataIndex === column.dataIndex) {
      item.width = w
    }
  })
}
const handleClick = (record: Object) => {
  emits('handle-click', record)
}
</script>
<style lang="scss" scoped>
.move-icon {
  cursor: move;
}

:deep(.gl-table-placeholder) .gl-table-cell {
  padding: 0 !important;
}
:deep(.gl-table-tbody) > tr > td {
  border-bottom: none;
}
:deep(.operation-buttons) {
  margin-left: -10px;
  .gl-btn-text {
    padding: 4px 9px;
    &:hover {
      background: none;
    }
  }
}
:deep(.switch-status) {
  span.text {
    margin-left: 8px;
  }
}
</style>
