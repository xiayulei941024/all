/*
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-05 10:37:10
 * @Description:
 */
export { default as MsTable } from './index.vue'
