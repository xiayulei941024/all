<template>
  <div class="gl-divider-title">
    <div class="line" :style="lineStyleObject"></div>
    <div class="title-text" :style="styleObject">{{ title }}</div>
  </div>
</template>
<script setup lang="ts">
interface Props {
  title: string
  size?: number | string
  color?: string
}
const props = withDefaults(defineProps<Props>(), {
  title: '',
  size: 16,
  color: '#333333'
})
const styleObject = reactive({
  color: props.color,
  fontSize: props.size + 'px'
})
const lineStyleObject = reactive({
  width: props.size / 3.5 + 'px',
  height: props.size / 0.7 + 'px'
})
</script>
<style lang="scss" scoped>
.gl-divider-title {
  font-size: 16px;
  display: flex;
  align-items: center;
  padding-bottom: 16px;
  border-bottom: 1px solid #e8e8e8;

  .line {
    margin-right: 8px;
    height: 20px;
    width: 4px;
    background-color: #023985;
  }
}
</style>
