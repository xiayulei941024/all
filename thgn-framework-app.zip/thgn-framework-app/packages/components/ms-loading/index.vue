<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-11 09:54:59
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-12 09:57:50
 * @Description: 
-->
<template>
  <div class="loading">
    <div class="loading-content">
      <LoadingOutlined style="font-size: 32px" />
    </div>
  </div>
</template>

<script setup>
import { LoadingOutlined } from '@ant-design/icons-vue'
</script>

<style scoped lang="scss">
.loading {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: #fff;
  z-index: 1000;
  opacity: 0.6;
  .loading-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate3d(-50%, -50%, 0);
    text-align: center;
    color: #333;
  }
}
</style>
