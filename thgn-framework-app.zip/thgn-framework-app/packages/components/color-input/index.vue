<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-08-22 11:22:53
 * @Description: 颜色选择组件
-->
<template>
  <div ref="colorpicker" class="color-picker">
    <div v-if="showInput">
      <gl-input v-model:value="colorValue" :disabled="disabled" />
      <div class="color-input">
        <gl-color-picker
          v-model:value="colorValue"
          :modes="['hex']"
          :show-alpha="false"
          :swatches="[
            '#ff0000',
            '#2e75b6',
            '#a6a6a6',
            '#292929',
            '#00aff0',
            '#ffafaf',
            '#e46c0a',
            '#0606eb',
            '#19DD2D'
          ]"
          size="small"
        />
        <!-- <input
          v-model="colorValue"
          :disabled="disabled"
          type="color"
          style="border: none; background: transparent; cursor: pointer"
          list="presetColors"
        />
        <datalist id="presetColors">
          <option>#2E75B6</option>
          />
          <option>#FF0000</option>
          <option>#A6A6A6</option>
          <option>#292929</option>
          <option>#5B9BD5</option>
          <option>#FFAFAF</option>
          <option>#E46C0A</option>
          <option>#0606EB</option>
        </datalist> -->
      </div>
    </div>
    <div v-else>
      <div class="ant-input-container">
        <input
          v-model="colorValue"
          :disabled="disabled"
          type="color"
          style="border: none; background: transparent; cursor: pointer"
          list="presetColors"
        />
        <datalist id="presetColors">
          <option>#2E75B6</option>
          />
          <option>#FF0000</option>
          <option>#A6A6A6</option>
          <option>#292929</option>
          <option>#5B9BD5</option>
          <option>#FFAFAF</option>
          <option>#E46C0A</option>
          <option>#0606EB</option>
        </datalist>
        <div class="color-mask">
          <icon name="down_outlined" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '../Icon'
import { computed } from 'vue'
interface Props {
  value: string
  showInput?: boolean
  disabled?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  value: '',
  showInput: true,
  disabled: false
})

interface Emits {
  (e: 'update:value', val: string): void
  (e: 'change-color', val: string): void
}

const emits = defineEmits<Emits>()

const colorValue = computed({
  get() {
    return props.value
  },
  set(val: string) {
    emits('update:value', val)
    emits('change-color', val)
  }
})
</script>

<style lang="scss" scoped>
.color-picker {
  position: relative;
  .color-input {
    position: absolute;
    right: 0;
    top: 2px;
    width: 80px;
    :deep(.gl-color-picker-trigger) {
      border: none !important;
    }
    :deep(.gl-color-picker-trigger_value) {
      display: none;
    }
  }
}
</style>
