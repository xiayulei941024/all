export { default as Pagination } from './index.vue'
