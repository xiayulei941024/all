/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-26 19:37:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-26 19:58:42
 * @Description:
 */
import { createVNode, render } from 'vue'
import ContextmenuComponent from './index.vue'

const CTX_CONTEXTMENU_HANDLER = 'CTX_CONTEXTMENU_HANDLER'

const contextmenuListener = (
  el: { classList: { remove: (arg0: string) => void; add: (arg0: string) => void } },
  event: { stopPropagation: () => void; preventDefault: () => void; x: any; y: any },
  binding: { value: (arg0: any) => any }
) => {
  event.stopPropagation()
  event.preventDefault()

  const menus = binding.value(el)
  if (!menus?.value) return

  let container: any = null

  // 移除右键菜单并取消相关的事件监听
  const removeContextmenu = () => {
    if (container) {
      document.body.removeChild(container)
      container = null
    }
    el.classList.remove('contextmenu-active')
    document.body.removeEventListener('scroll', removeContextmenu)
    window.removeEventListener('resize', removeContextmenu)
  }

  // 创建自定义菜单
  const options = {
    axis: { x: event.x, y: event.y },
    el,
    menus: menus.value,
    removeContextmenu
  }
  container = document.createElement('div')
  const vm = createVNode(ContextmenuComponent, options, null)
  render(vm, container)
  document.body.appendChild(container)

  // 为目标节点添加菜单激活状态的className
  el.classList.add('contextmenu-active')

  // 页面变化时移除菜单
  document.body.addEventListener('scroll', removeContextmenu)
  window.addEventListener('resize', removeContextmenu)
}

const ContextmenuDirective = {
  mounted(el: any, binding: { value: (arg0: any) => any }) {
    el[CTX_CONTEXTMENU_HANDLER] = (event: any) => contextmenuListener(el, event, binding)
    el.addEventListener('contextmenu', el[CTX_CONTEXTMENU_HANDLER])
  },

  unmounted(el: { [x: string]: any; removeEventListener: (arg0: string, arg1: any) => void }) {
    if (el && el[CTX_CONTEXTMENU_HANDLER]) {
      el.removeEventListener('contextmenu', el[CTX_CONTEXTMENU_HANDLER])
      delete el[CTX_CONTEXTMENU_HANDLER]
    }
  }
}

export default ContextmenuDirective
