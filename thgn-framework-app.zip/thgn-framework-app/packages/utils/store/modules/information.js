import { defineStore } from 'pinia'
const useInformation = defineStore('infoParam', {
  state: () => ({
    activeModuleName: '热点快讯',
    leftInfoMenu: []
  }),
  actions: {
    changeActiveModuleName(flag) {
      this.activeModuleName = flag
    },
    changeLeftInfoMenu(menu) {
      this.leftInfoMenu = menu
    }
  },
  getters: {
    getActiveModuleName() {
      return this.activeModuleName
    }
  }
})
export default useInformation
