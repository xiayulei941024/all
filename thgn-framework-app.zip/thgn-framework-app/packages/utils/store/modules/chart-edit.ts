/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-19 10:04:43
 * @Description:
 */
import { defineStore } from 'pinia'
import editorProjectConfig from '../composables/data-model'
import { cloneDeep } from 'lodash-es'
const useChartEdit = defineStore('chart', {
  state: () => ({
    isEdit: false,
    // 指定敏感词距离容器顶部的距离
    top: undefined,
    fullscreen: true,
    layout: 2,
    // 当前编辑器编辑工程项目数据
    projectData: {},
    // 当前正在编辑的页面uuid
    activePageUUID: '',
    // 画板中选中的元素uuid
    activeElementUUID: '',
    // 历史操作数据用于undo redo
    historyCache: [],
    // redo undo 指针
    currentHistoryIndex: -1,
    activeAttrUUID: '',
    showSetting: true,
    templateID: 0,
    pdfDOC: null,
    dragElement: {},
    currentHoverUUID: null,
    showPagination: false,
    isFocus: false
  }),
  actions: {
    emptyHistoryCache() {
      this.currentHistoryIndex = -1
      this.historyCache = []
    },
    //记入历史纪录
    addHistoryCache() {
      if (this.currentHistoryIndex + 1 < this.historyCache.length) {
        this.historyCache.splice(this.currentHistoryIndex + 1)
      }
      this.historyCache.push({
        projectData: cloneDeep(this.projectData),
        activePageUUID: this.activePageUUID,
        activeElementUUID: this.activeElementUUID
      })
      // 限制undo 纪录步数，最多支持100步操作undo
      this.historyCache.splice(100)
      this.currentHistoryIndex++
    },
    setData(data: any) {
      this.projectData = data
    },
    // 初始化编辑项目数据
    setProjectData(data: any) {
      const oneProject = data || editorProjectConfig.getProjectConfig(this.layout)
      const projectData = reactive(oneProject)
      this.setData(projectData)

      if (!this.projectData.pages || !this.projectData.pages.length) {
        this.addPage()
      }
      this.setActivePageUUID(this.projectData.pages[0].uuid)
    },
    addPage(uuid: any) {
      const data = reactive(editorProjectConfig.getPageConfig())
      let index = false
      if (uuid) {
        index = this.projectData.pages.findIndex((v) => v.uuid === uuid)
      }
      this.insetPage(data, index)
      this.addHistoryCache()
    },
    insetPage(data: any, index: any) {
      if (index || index === 0) {
        this.projectData.pages.splice(index, 0, data)
      } else {
        this.projectData.pages.push(data)
      }
    },
    // 修改拖动标识
    setDragElement(data: Object) {
      this.dragElement = data
    },
    setCurrentHoverUUID(data: any) {
      // console.log('setCurrentHoverUUID', data)
      this.currentHoverUUID = data
    },
    setActivePageUUID(data: string) {
      // console.log('setActivePageUUID', data)
      this.activePageUUID = data
    },
    setActiveElementUUID(data: string) {
      this.activeElementUUID = data
    },
    addElement(data: Object) {
      // console.log('addElement')
      const activePageData = this.activePage
      const elData = editorProjectConfig.getElementConfig(data, {
        zIndex: activePageData.elements.length + 1
      })
      // console.log('this.currentPageIndex', this.currentPageIndex)
      let index = this.currentPageIndex
      index = index === -1 ? 0 : index
      this.projectData.pages[index].elements.push(elData)
      // console.log('elData', elData)
      this.setActiveElementUUID(elData.uuid)
      this.activeAttrUUID = elData.attrs.length ? elData.attrs[0].uuid : elData.uuid
      this.showSetting = true
      this.addHistoryCache()
    },
    deleteElement(uuid: string) {
      // 如果删除选中元素则取消元素选中
      if (uuid === this.activeElementUUID) {
        this.setActiveElementUUID(uuid)
      }
      const activePage = this.activePage
      const elementIndex = activePage.elements.findIndex((v) => v.uuid === uuid)
      activePage.elements.splice(elementIndex, 1)
    },
    deletePage(uuid: string) {
      // 如果删除最后一页
      if (this.projectData.pages.length === 1 && this.activePageUUID === uuid) {
        return
      }
      // 删除页是第一页且选中也是第一页时 先将选中uuid置为下一页再删除当前页
      if (this.projectData.pages[0] === uuid && this.activePageUUID === uuid) {
        this.setActivePageUUID(this.projectData.pages[1].uuid)
      }
      const index = this.projectData.pages.findIndex((v) => v.uuid === uuid)
      this.projectData.pages.splice(index, 1)
      this.addHistoryCache()
    },
    setSetting() {
      if (!this.activeElementUUID) {
        return
      }
      const settingState = this.showSetting
      this.showSetting = !settingState
    },
    //设置属性面板
    setActiveAttrUUID(data: string) {
      this.activeAttrUUID = data
    },
    // 布局方式
    setLayoutType(data: number) {
      this.layout = data
    },
    //改变画布属性
    changeProjectConfig(data: any) {
      for (const key in data) {
        this.projectData[key] = data[key]
      }
    },
    replaceEditState(data: any) {
      this.projectData = cloneDeep(data.projectData)
      this.activePageUUID = data.activePageUUID
      this.activeElementUUID = data.activeElementUUID
    },
    editorUndo() {
      if (!this.canUndo) {
        return
      }
      if (this.currentHistoryIndex - 1 > 0) {
        const prevState = this.historyCache[this.currentHistoryIndex - 1]
        this.replaceEditState(cloneDeep(prevState))
      }
      this.currentHistoryIndex--
    },
    editorRedo() {
      if (!this.canRedo) {
        return
      }
      const nextState = this.historyCache[this.currentHistoryIndex + 1]
      this.replaceEditState(cloneDeep(nextState))
      this.currentHistoryIndex++
    },
    //显示页码
    setPagination(data: boolean) {
      this.showPagination = data
    },
    insertPage({ data, index }: any) {
      if (index || index === 0) {
        this.projectData.pages.splice(index, 0, data)
      } else {
        this.projectData.pages.push(data)
      }
    },
    // 添加空白页面
    addDefaultPage(type: number) {
      const data = reactive(editorProjectConfig.getPageConfig(type))
      const index = false
      this.insertPage({ data, index })
      this.setActivePageUUID(data.uuid)
      this.addHistoryCache()
    },
    //复制页面
    copyPage(uuid: string) {
      const pageData = this.projectData.pages.find((v) => v.uuid === uuid)
      const data = reactive(editorProjectConfig.copyPage(pageData))
      const index = this.projectData.pages.findIndex((v) => v.uuid === uuid)
      this.insertPage({ data, index })
      this.addHistoryCache()
    },
    //设置元素属性
    setElementPropsValue(valueObj: any) {
      const activeElement: any = this.activeElement
      Object.assign(activeElement.propsValue, valueObj)
    },
    //重置元素样式
    resetElementCommonStyle(style: any) {
      const activeElement = this.activeElement
      Object.assign(activeElement.commonStyle, style)
      this.addHistoryCache()
    },
    setFocusState(data: any) {
      this.isFocus = data
    }
  },
  getters: {
    //当前选中的页面index
    currentPageIndex(): number {
      // console.log('state.activePageUUID', this.activePageUUID)
      const index = this.projectData.pages.findIndex((v) => v.uuid === this.activePageUUID)
      // console.log('state.index', index)
      return index || 0
    },
    //当前选中的页面index
    activeElementIndex(state): number {
      const currentPage = this.activePage
      const index = currentPage.elements.findIndex((v) => v.uuid === this.activeElementUUID) || 0
      return index
    },
    //当前选中的页面
    activePage(): any {
      const onePage = { commonStyle: {}, config: {}, elements: [] }
      if (!this.projectData || !this.projectData.pages) {
        return onePage
      }
      const index = this.currentPageIndex
      if (index === -1) {
        return onePage
      }
      const currentPage = this.projectData.pages[index] || onePage
      return reactive(currentPage)
    },
    // 当前选中元素
    activeElement(): Object {
      const currentPage = this.activePage
      const oneElement = { commonStyle: {}, propsValue: {}, attrs: [] }
      const currentElement =
        currentPage.elements.find((v) => v.uuid === this.activeElementUUID) || oneElement
      return reactive(currentElement)
    },
    activeAttrIndex(): number {
      const currentElement = this.activeElement
      const index = currentElement.attrs.findIndex((v) => v.uuid === this.activeAttrUUID)
      return index
    },
    activeElementAttrs() {
      if (this.showSetting && this.activeElementUUID) {
        return true
      }
      return false
    },
    canUndo(): boolean {
      return this.currentHistoryIndex > 0
    },
    canRedo(): boolean {
      return this.historyCache.length > this.currentHistoryIndex + 1
    }
  }
})

export default useChartEdit
