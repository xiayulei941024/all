import { defineStore } from 'pinia'
const useEditorMenu = defineStore('editorMenu', {
  state: () => ({
    visible: false,
    selection: null,
    editorRef: null
  }),
  actions: {
    changeVisible(data: boolean) {
      this.visible = data
    },
    setSelection(data: any) {
      this.selection = data
    },
    setEditorRef(data: any) {
      this.editorRef = data
    }
  }
})
export default useEditorMenu
