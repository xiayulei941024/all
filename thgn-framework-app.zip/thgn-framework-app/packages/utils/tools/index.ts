/*
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-09-05 13:49:23
 * @Description:工具
 */
//随机色
import html2canvas from 'html2canvas'
import moment from 'moment'
import RasterizeHtml from 'rasterizehtml'
import { geoCoordMap } from './mapData'
export const getRandomColor = () =>
  `#${`00000${((Math.random() * 0x1000000) << 0).toString(16)}`.substr(-6)}`
//无数据
export const getNullOption = (type: string) => {
  let option = {}
  if (type == 'pie') {
    option = {
      title: {
        text: '暂无数据',
        left: 'center',
        textStyle: {
          color: '#333333', //颜色
          fontWeight: 'bold', //粗细
          fontFamily: '微软雅黑', //字体
          fontSize: 14 //大小
        }
      },
      grid: {
        // top: '8%',
        // left: '15%',
        // right: '15%',
        // bottom: '15%'
      },
      series: []
    }
  } else if (type == 'radar') {
    option = {
      title: {
        text: '暂无数据',
        left: 'center',
        textStyle: {
          color: '#333333', //颜色
          fontWeight: 'bold', //粗细
          fontFamily: '微软雅黑', //字体
          fontSize: 14 //大小
        }
      },
      grid: {
        // top: '8%',
        // left: '15%',
        // right: '15%',
        // bottom: '15%'
      },
      radar: {
        // shape: 'circle',
        indicator: []
      }
    }
  } else {
    option = {
      title: {
        text: '暂无数据',
        left: 'center',
        textStyle: {
          color: '#333333', //颜色
          fontWeight: 'bold', //粗细
          fontFamily: '微软雅黑', //字体
          fontSize: 14 //大小
        }
      },
      grid: {
        // top: '8%',
        // left: '15%',
        // right: '15%',
        // bottom: '15%'
      },
      xAxis: {
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#DDDDDD'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      },
      yAxis: {
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#DDDDDD'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      },
      series: []
    }
  }

  return option
}
//将base64转换blob
export const base64ToBlob = (baseUrl: string) => {
  const img = baseUrl
  const parts = img.split(';base64,')
  const contentType = parts[0].split(':')[1]
  const raw = window.atob(parts[1])
  const rawLength = raw.length
  const uInt8Array = new Uint8Array(rawLength)
  for (let i = 0; i < rawLength; ++i) {
    uInt8Array[i] = raw.charCodeAt(i)
  }
  return new Blob([uInt8Array], {
    type: contentType
  })
}
//下载echart图片
export const downloadEchart = (baseUrl: string, title: string) => {
  const time = moment().format('YYYYMMDD')
  const aLink = document.createElement('a')
  const blob = base64ToBlob(baseUrl)
  const evt = document.createEvent('HTMLEvents')
  evt.initEvent('click', true, true)
  aLink.download = title + time //下载图片的名称
  aLink.href = URL.createObjectURL(blob)
  aLink.click()
}
// canvas截图
export const canvasImage = async (selector: any, width: any, height: any, scale = 100, coe = 2) => {
  const canvas = await html2canvas(selector, {
    scale: coe,
    width: width || (selector && selector.offsetWidth * scale) / 100, // 按照当前缩放比截取
    height: height || (selector && selector.offsetHeight * scale) / 100,
    useCORS: true,
    allowTaint: false,
    taintTest: true,
    backgroundColor: '#ffffff'
  })
  const dataUrl = canvas.toDataURL('image/png', 1.0)
  return dataUrl
}
// svg截图
export const rasterizeImage = async (selector: any, width: any, height: any, scale = 100) => {
  // drawURL()加载的URL必须是同域名URL或支持跨域的URL
  // 下面的URL是随便写的，记得换成同域名URL或支持跨域的URL
  const canvas = document.createElement('canvas')
  width = width || (selector && selector.offsetWidth * scale) / 100 || 895
  height = height || (selector && selector.offsetHeight * scale) / 100 || 365
  console.log(width, height)
  const opts = {
    executeJs: true,
    height,
    width
  }
  const res = await RasterizeHtml.drawDocument(selector, canvas, opts)
  const base64 = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(res.svg)))
  const pngBase64 = await svgBase64ToPngBase64(base64, width, height)
  return pngBase64
}
export const svgBase64ToPngBase64 = async (imageBase64: any, width: any, height: any) => {
  const img = new Image() // 创建图片容器
  img.src = imageBase64 // imageBase64 为svg+xml的Base64 文件流
  const promise = new Promise((resolve) => {
    img.onload = function () {
      // 图片创建后再执行，转Base64过程
      const canvas = document.createElement('canvas')
      canvas.width = width || 660 // 设置好 宽高  不然图片 不完整
      canvas.height = height || 300
      const context: any = canvas.getContext('2d')
      context.drawImage(img, 0, 0)
      const pngBase64 = canvas.toDataURL('image/png')
      resolve(pngBase64)
    }
  })
  return await promise
}
//截图
export const generateImage = async (
  selector: any,
  width: any,
  height: any,
  scale = 100,
  coe = 2
) => {
  // let dataUrl
  // try {
  //   dataUrl = await rasterizeImage(selector, width, height, scale)
  //   console.log('svg')
  // } catch (err) {
  //   console.log(err)
  //   dataUrl = await canvasImage(selector, width, height, scale, coe)
  // }
  const dataUrl = await canvasImage(selector, width, height, scale, coe)
  return dataUrl
}
/**
 * @description: 判断空
 * @return {*}
 */
export const isEmpty = (data: any) => {
  if (data === null) return true
  if (data === undefined) return true
  if (Object.prototype.toString.call(data) === '[object Array]') {
    return data.length === 0
  }
  if (Object.prototype.toString.call(data) === '[object Object]') {
    return Object.keys(data).length === 0
  }
  if (typeof data === 'string') return data.trim() === ''
  return false
}
// 千分符
export const numberSeparator = (num: number | string) => {
  const tag = (num || 0).toString().split('.')
  tag[0] = tag[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  return tag.join('.')
}

export const formatNum = (value: any) => {
  if (!value && value !== 0) return ''

  const str = value.toString()
  const reg = str.indexOf('.') > -1 ? /(\d)(?=(\d{3})+\.)/g : /(\d)(?=(?:\d{3})+$)/g
  return str.replace(reg, '$1,')
}
export const getMultiChartOption = (
  title: string,
  legend: any,
  time: any,
  unit: string,
  data: any,
  types: any,
  yA?: any,
  id?: string
) => {
  const title1 = title.length > 25 ? title.substring(0, 25) + '...' : title
  const initSeries: any = {
    line: {
      data: [], // data
      name: '', // legend
      smooth: true,
      connectNulls: true,
      type: 'line',
      smoothMonotone: 'x',
      symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
      // symbolSize: 5,
      showAllSymbol: true,
      lineStyle: {
        width: 3 // 设置线条粗细
      }
    },
    dottedLine: {
      data: [],
      name: '',
      type: 'line',
      symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
      // symbolSize: 5,
      showAllSymbol: true,
      connectNulls: true,
      smoothMonotone: 'x',
      smooth: true, // 为true是不支持虚线，实线就用true
      lineStyle: {
        type: 'dotted', // 'dotted'虚线 'solid'实线
        width: 3 // 设置线条粗细
      }
    },
    bar: {
      data: [],
      name: '',
      type: 'bar',
      itemStyle: {},
      markLine: {
        silent: true,
        data: [{ yAxis: 0, name: '' }],
        label: {
          show: false
        },
        symbol: id === 'comprehensiveChart' ? 'emptyCircle' : 'none',
        // symbolSize: 5,
        showAllSymbol: true,
        lineStyle: {
          color: '#000'
        }
      }
    }
  }
  const series = data.map((v: any, k: number) => {
    const type = types[k]
    const item = JSON.parse(JSON.stringify(initSeries[type]))
    item.data = v
    item.name = legend[k]
    if (yA) {
      item.yAxisIndex = yA[k]
    }
    return item
  })
  let yAxis
  let dataZoom
  if (yA && yA.length > 1) {
    yAxis = [
      {
        min: (value: any) => {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          } else {
            return (value.min + 0.1 * value.min).toFixed(2)
          }
        },
        type: 'value',
        name: unit,
        nameTextStyle: {
          color: '#666666'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      },
      {
        min: (value: any) => {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          } else {
            return (value.min + 0.1 * value.min).toFixed(2)
          }
        },
        type: 'value',
        name: unit,
        nameTextStyle: {
          color: '#666666'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      }
    ]
    let len = time.length - 1 || 0
    const endValue: any = time[len]
    const allSeconds: number = 365 * 24 * 3600 * 1000
    let startValue = time[0]
    while (len >= 0) {
      const element: any = time[len]
      if (new Date(endValue) - new Date(time[0]) < allSeconds) {
        break
      }
      if (new Date(endValue) - new Date(element) > allSeconds) {
        break
      } else {
        startValue = element
      }
      len--
    }
    dataZoom = [
      {
        show: true,
        startValue,
        endValue,
        height: 20,
        brushSelect: false
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      },
      {
        type: 'slider',
        start: 0,
        end: 100,
        height: 20,
        brushSelect: false,
        backgroundColor: '#EEF4F9',
        fillerColor: '#F0F2F5',
        borderColor: '#E8E8E8',
        textStyle: {
          color: '#333333'
        },
        handleStyle: {
          color: '#CED4D9',
          borderColor: '#CED4D9'
        }
      }
    ]
  } else {
    yAxis = [
      {
        min: (value: any) => {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          } else {
            return (value.min + 0.1 * value.min).toFixed(2)
          }
        },
        type: 'value',
        name: unit,
        nameTextStyle: {
          color: '#666666'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      }
    ]
    dataZoom = [
      {
        show: true,
        start: 0,
        end: 100,
        height: 20,
        brushSelect: false
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      },
      {
        type: 'slider',
        start: 0,
        end: 100,
        height: 20,
        brushSelect: false,
        backgroundColor: '#EEF4F9',
        fillerColor: '#F0F2F5',
        borderColor: '#E8E8E8',
        textStyle: {
          color: '#333333'
        },
        handleStyle: {
          color: '#CED4D9',
          borderColor: '#CED4D9'
        }
      }
    ]
  }
  const toolTipFormatter = (params: any) => {
    const line1 = { ...params[0] } || {}
    const line2 = params[1] || {}
    const line3 = params[2] || {}
    const title = line1.axisValue || line2.axisValue

    const { data, marker, seriesName } = line1

    const data1 = line1.data
      ? `${marker}${seriesName}: 
      ${formatNum(data)}<br />`
      : ''
    const data3 = line3.data
      ? `${line3.marker}${line3.seriesName}: 
      ${formatNum(line3.data)}<br />`
      : ''
    let data2 = ''
    if (id === 'comprehensiveChart') {
      data2 = line2.data
        ? `
          ${line2.marker}${line2.seriesName}:
          ${formatNum(line2.data)}
          <br />`
        : ''
    } else {
      data2 =
        line2.data && !data
          ? `
            ${line2.marker}${line2.seriesName}
            :${data ? '' : formatNum(line2.data)}
            <br />`
          : ''
    }
    return `
        ${title}<br />
        ${data1}
        ${data2}
        ${data3}
        `
  }
  const option = {
    backgroundColor: '#ffffff',
    title: {
      text: title1,
      left: 'center',
      textStyle: {
        color: '#333333', // 颜色
        // fontStyle:'normal',     //风格
        fontWeight: 'bold', // 粗细
        fontFamily: '微软雅黑', // 字体
        fontSize: 16 // 大小
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        crossStyle: {
          color: '#999'
        }
      },
      formatter: yA ? '' : toolTipFormatter
    },
    legend: {
      data: legend,
      left: 'center',
      top: 30,
      textStyle: {
        fontSize: 14,
        fontFamily: '微软雅黑',
        color: '#333333'
      }
    },
    grid: {
      left: '2%',
      right: '2%',
      bottom: '15%',
      top: '25%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: time,
        axisPointer: {
          // type: 'shadow'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      }
    ],
    yAxis,
    dataZoom,
    color: [
      '#0090ff',
      '#f42743',
      '#f69332',
      '#6c41ff',
      '#b62ca1',
      '#2933ff',
      '#ff563f',
      '#edff57',
      '#38f8ff',
      '#1ac131'
    ],
    series
  }
  return option
}

// 管理驾驶舱市场预测图
export const getManageChartOption = (data: any, legend: any, time: any, unit: any) => {
  const noUnit = ''
  const series = []
  const initSeries = {
    line: {
      data: [], // data
      name: '', // legend
      smooth: true,
      connectNulls: true,
      // symbol: 'none',
      type: 'line',
      smoothMonotone: 'x',
      itemStyle: {
        normal: {
          lineStyle: {
            width: 3 // 设置线条粗细
          }
        }
      }
    },
    dottedLine: {
      data: [],
      name: '',
      type: 'line',
      connectNulls: true,
      // symbol: 'none',
      smoothMonotone: 'x',
      smooth: true, // 为true是不支持虚线，实线就用true
      itemStyle: {
        normal: {
          lineStyle: {
            type: 'dotted', // 'dotted'虚线 'solid'实线
            width: 3 // 设置线条粗细
          }
        }
      }
    }
  }
  for (const key in data) {
    const dataList = data[key]

    for (let index = 0; index < dataList.length; index++) {
      let serie: any = {}
      const type = index === 0 ? 'line' : 'dottedLine'
      serie = JSON.parse(JSON.stringify(initSeries[type]))
      serie.data = dataList[index]
      serie.name = legend[key]
      series.push(serie)
    }
  }

  const toolTipFormatter = (params: any) => {
    const paramList = []
    for (let i = 0, len = params.length; i < len; i += 2) {
      paramList.push(params.slice(i, i + 2))
    }
    let toolMark = params[0].axisValue + '<br/>'
    for (const key in paramList) {
      paramList[key][1].data =
        paramList[key][0].data === paramList[key][1].data ? '-' : paramList[key][1].data
      let data1 = ''
      let data2 = ''
      let mark = ''
      if (paramList[key][0].data && paramList[key][0].data !== '-') {
        data1 = `实际价格：
        ${formatNum(paramList[key][0].data)} 
        ${unit[key] || noUnit}
        <br/>`
      }
      if (paramList[key][1].data && paramList[key][1].data !== '-') {
        data2 = `预测价格：
        ${formatNum(paramList[key][1].data)} 
        ${unit[key] || noUnit}
        <br/>`
      }
      if (data1 || data2) {
        mark = `<i style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:${paramList[key][0].color};"></i>`
        toolMark += `${mark}${paramList[key][0].seriesName} ${data1}${data2}`
      }
    }
    return toolMark
  }
  const option = {
    backgroundColor: '#ffffff',
    title: {
      text: '价格走势图',
      left: 'center',
      textStyle: {
        color: '#333333', // 颜色
        // fontStyle:'normal',     //风格
        fontWeight: 'bold', // 粗细
        fontFamily: '微软雅黑', // 字体
        fontSize: 14 // 大小
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        crossStyle: {
          color: '#999'
        }
      },
      formatter: toolTipFormatter
    },
    legend: {
      data: legend,
      left: 'center',
      top: 30,

      textStyle: {
        fontSize: 14,
        fontFamily: '微软雅黑',
        color: '#333333'
      }
    },
    grid: {
      left: '2%',
      right: '80px',
      bottom: '15%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: time,

        axisPointer: {
          type: 'shadow'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      }
    ],
    yAxis: [
      {
        min: (value: { min: number }) => {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          } else {
            return (value.min + 0.1 * value.min).toFixed(2)
          }
        },

        type: 'value',
        name: unit[0] || noUnit,
        nameTextStyle: {
          color: '#666666'
        },
        splitLine: {
          show: false
        },
        axisLabel: {
          color: '#666666'
        },
        axisLine: {
          onZero: false,
          lineStyle: {
            color: '#DDDDDD'
          }
        }
      }
    ],
    dataZoom: [
      {
        show: true,
        start: 0,
        end: 100,
        height: 20,
        brushSelect: false
      },
      {
        type: 'inside',
        start: 0,
        end: 100
      },
      {
        type: 'slider',
        start: 0,
        end: 100,
        height: 20,
        brushSelect: false,
        backgroundColor: '#EEF4F9',
        fillerColor: '#F0F2F5',
        borderColor: '#E8E8E8',
        textStyle: {
          color: '#333333'
        },
        handleStyle: {
          color: '#CED4D9',
          borderColor: '#CED4D9'
        }
      }
    ],
    series: series,
    color: [
      '#0090ff',
      '#f42743',
      '#f69332',
      '#6c41ff',
      '#b62ca1',
      '#2933ff',
      '#ff563f',
      '#edff57',
      '#38f8ff',
      '#1ac131'
    ]
  }
  return option
}
/**
 * 生成uuid方法
 * @returns {string}
 */
export const createUUID = function () {
  let d = new Date().getTime()
  if (window.performance && typeof window.performance.now === 'function') {
    d += performance.now() // use high-precision timer if available
  }
  const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (d + Math.random() * 16) % 16 | 0
    d = Math.floor(d / 16)
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16)
  })
  return uuid
}

// 指标走势图
export const getKeyIndicatorsChartOption = (data: any, time: string[]) => {
  const option = {
    backgroundColor: '#fff',
    xAxis: [
      {
        type: 'category',
        data: time,
        show: false,
        boundaryGap: false
      }
    ],
    yAxis: [
      {
        min: (value: { min: number }) => {
          if (value.min >= 0) {
            return (value.min - 0.1 * value.min).toFixed(2)
          } else {
            return (value.min + 0.1 * value.min).toFixed(2)
          }
        },
        max: (value: { max: number }) => {
          if (value.max >= 0) {
            return (value.max + 0.3 * value.max).toFixed(2)
          } else {
            return (value.max - 0.3 * value.max).toFixed(2)
          }
        },
        show: false,
        type: 'value',
        splitLine: {
          show: false
        }
      }
    ],
    grid: {
      height: '50px',
      bottom: '0'
    },
    series: [
      {
        data: data,
        type: 'line',
        symbol: 'none', // 去掉折线图中的节点
        smooth: true // true 为平滑曲线，false为直线
      }
    ]
  }
  return option
}
export const weatherChartOption = (rangeColor: any) => {
  const option = {
    // backgroundColor: 'transparent',
    tooltip: {
      show: false
    },
    geo: {
      map: 'china',
      label: {
        emphasis: {
          show: false
        }
      },
      roam: false,
      itemStyle: {
        normal: {
          areaColor: '#fff',
          borderColor: '#0147af'
        },
        emphasis: {
          areaColor: '#fff'
        }
      }
    },
    visualMap: {
      min: 0,
      max: 6000,
      type: 'continuous',
      hoverLink: true,
      inRange: {
        color: rangeColor || ['#14824b', '#14a880', '#de5b79', '#ad3250']
      },
      itemHeight: 250,
      itemWidth: 15,
      bottom: '20',
      left: '160',
      calculable: false,
      orient: 'horizontal',
      textStyle: {
        color: '#fff'
      }
    },

    series: []
  }
  return option
}
const convertData = (data) => {
  const res = []
  for (let i = 0; i < data.length; i++) {
    const geoCoord = geoCoordMap[data[i].city]
    if (geoCoord) {
      // var difference = data[i].price - 100;
      if (data[i].price != null || data[i].upDown !== '-') {
        res.push({
          city: data[i].city,
          value: geoCoord.concat(data[i].upDown),

          spread: data[i].spread || '-',
          // flowIntoSpread: data[i].flowIntoSpread || '-',
          price: data[i].price || '-',
          province: data[i].province
        })
      }
    }
  }
  return res
}
export const chinaMapOption = (seriesData: any, regionsAreaColor: any) => {
  const option = {
    tooltip: {
      padding: 0,
      enterable: true,
      transitionDuration: 1,
      position: (point, params, dom, rect, size) => {
        const x = point[0] //
        const y = point[1]
        // var viewWidth = size.viewSize[0];
        // var viewHeight = size.viewSize[1];
        const boxWidth = size.contentSize[0]
        const boxHeight = size.contentSize[1]
        let posX = 0
        let posY = 0

        if (x < boxWidth) {
          posX = 5
        } else {
          posX = x - boxWidth
        }

        if (y < boxHeight) {
          posY = 5
        } else {
          posY = y - boxHeight
        }

        return [posX, posY]
      },
      textStyle: {
        fontSize: 12,
        color: '#FFFFFF',
        decoration: 'none'
      },
      formatter: (params) => {
        const { data } = params
        if (typeof params.value[2] === 'undefined') {
          return ''
        } else {
          const richPrice = data.richPrice == null ? '-' : data.richPrice
          const trip = data.trip == null ? '-' : data.trip
          const factoryPrice = data.factoryPrice == null ? '-' : data.factoryPrice
          const tipHtml =
            '<div style="width:200px;border-radius:5px;background:#fff;box-shadow:0 0 10px 5px #aaa">' +
            '    <div style="height:50px;width:100%;border-radius:5px;background:#F8F9F9;border-bottom:1px solid #F0F0F0">' +
            '        <span style="line-height:50px;margin-left:18px">' +
            data.city +
            '市' +
            '</span>' +
            '    </div>' +
            '    <div style="height:130px;width:100%;background:#fff">' +
            '        <div style="padding-left:18px;padding-top:14px">' +
            '            <span style="display:inline-block;margin-right:5px;width:10px;height:10px;background-color:rgba(92,169,235,1)"></span> ' +
            '            <span>城市的理计价格</span>' +
            '            <span style="float:right;margin-right:18px">' +
            richPrice +
            '</span>' +
            '        </div>' +
            '        <div style="padding-left:18px;padding-top:14px">' +
            '            <span style="display:inline-block;margin-right:5px;width:10px;height:10px;background-color:rgba(92,169,235,1)"></span> ' +
            '            <span>运费</span>' +
            '            <span style="float:right;margin-right:18px">' +
            trip +
            '</span>' +
            '        </div>' +
            '        <div style="padding-left:18px;padding-top:14px">' +
            '            <span style="display:inline-block;margin-right:5px;width:10px;height:10px;background-color:rgba(92,169,235,1)"></span> ' +
            '            <span>理计价格-运费数值</span>' +
            '            <span style="float:right;margin-right:18px">' +
            factoryPrice +
            '</span>' +
            '        </div>' +
            '    </div>' +
            '</div>'
          return tipHtml
        }
      }
    },
    legend: {
      selectedMode: false,
      orient: 'vertical',
      bottom: '-1000px',
      right: '30px',
      data: ['价格'],
      textStyle: {
        color: '#fff',
        fontSize: 12
      }
    },
    grid: {
      left: 0,
      top: 0,
      right: 0,
      bottom: 0
    },
    geo: {
      map: 'china',
      top: 0,
      center: [106, 42],
      zoom: 1,
      roam: true,
      scaleLimit: {
        min: 0.5,
        max: 10
      },
      label: {
        emphasis: {
          show: false
        }
      },
      silent: true,
      itemStyle: {
        normal: {
          areaColor: 'transparent',
          borderColor: '#0147af'
        },
        emphasis: {
          areaColor: '#2a333d'
        }
      },
      regions: regionsAreaColor
    },
    // backgroundColor: "rgb(241,241,241)",
    backgroundColor: 'transparent',
    series: [
      {
        name: '价格',
        type: 'scatter', // 气泡
        coordinateSystem: 'geo',
        data: convertData(seriesData),
        symbolSize: 6,
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 14,
              color: '#333',
              fontFamily: '微软雅黑'
            },
            formatter: (params) => {
              const { city, spread, price } = params.data
              // var price =
              //   params.data.price == null ? "-" : params.data.price;
              // var upDown =
              //   params.data.upDown == null ? "-" : params.data.upDown;
              return `${city + '  '}\n${price + '  '}${spread}`
            },
            position: 'right'
          },
          emphasis: {
            show: false
          }
        },
        itemStyle: {
          emphasis: {
            borderColor: '#FFFFFF',
            borderWidth: 1
          },
          color: '#FFFFFF'
        }
      },
      {
        name: '价格',
        type: 'effectScatter',
        coordinateSystem: 'geo',
        symbolSize: 20,
        showEffectOn: 'render',
        rippleEffect: {
          brushType: 'stroke'
        },
        hoverAnimation: true,
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12
            },
            formatter: () => {
              return ''
            },
            position: 'right'
          },
          emphasis: {
            show: false
          }
        },
        itemStyle: {
          emphasis: {
            borderColor: '#fff',
            borderWidth: 1
          }
        }
      }
    ]
  }
  return option
}
export const genWeekSegment = (v) => {
  const weekFirstDayFormat = v && moment(v).startOf('week').add(1, 'd').format('YYYY-MM-DD')
  const weekLastDayFormat = v && moment(v).startOf('week').add(7, 'd').format('YYYY-MM-DD')
  return (v && `${weekFirstDayFormat}~${weekLastDayFormat}`) || ''
}
export const base64toFile = (dataUrl: any, filename?: string) => {
  const arr = dataUrl.split(',')
  const mime = arr[0].match(/:(.*?);/)[1]
  const suffix = mime.split('/')[1]
  const bstr = atob(arr[1])
  let n = bstr.length
  const u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  return new File([u8arr], `${filename}.${suffix}`, {
    type: mime
  })
}
const padStart = (value, count = 2) => {
  return String(value).padStart(count, 0)
}
export const formatTime = (timeStamp: any, format = 'yyyy-mm-dd', deltaYear = 0) => {
  const time = new Date(timeStamp)
  const year = time.getFullYear() + deltaYear
  const month = padStart(time.getMonth() + 1)
  const day = padStart(time.getDate())
  const hour = padStart(time.getHours())
  const minute = padStart(time.getMinutes())
  const sec = padStart(time.getSeconds())
  if (format === 'yyyy-mm-dd hh:mm:ss') {
    return `${year}-${month}-${day} ${hour}:${minute}:${sec}`
  } else if (format === 'hh:mm') {
    return `${hour}:${minute}`
  } else if (format === 'yyyy-mm-dd hh:mm') {
    return `${year}-${month}-${day} ${hour}:${minute}`
  } else {
    return `${year}-${month}-${day}`
  }
}
export const formatNumber = (number: any, symbol = false) => {
  if (!number && number !== 0) {
    return '--'
  } else {
    if (number > 0 && symbol) {
      return '+' + number.toLocaleString()
    } else {
      return number.toLocaleString()
    }
  }
}
