/*
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-18 16:17:42
 * @Description:
 */
/**
 * 枚举定义工具
 * 示例：
 * const STATUS = createEnum({
 *     ACTIVE: [1, 'active'],
 *     INACTIVE: [2, 'inactive']
 * })
 * 通过枚举值列表：STATUS.list
 * 获取枚举值：STATUS.ACTIVE
 * 获取枚举描述：STATUS.getDesc('ACTIVE')
 * 通过枚举值获取描述：STATUS.getDescFromValue(STATUS.INACTIVE)
 */
interface EnumObject {
  [propsName: string]: any //自定义类型
}

export const createEnum = (definition: EnumObject) => {
  const strToValueMap: EnumObject = {}
  const numToDescMap: EnumObject = {}
  const numToEnumMap: EnumObject = {}
  const list: EnumObject[] = []
  const listNotEmpty: EnumObject[] = []
  for (const enumName of Object.keys(definition)) {
    const [value, desc] = definition[enumName]
    strToValueMap[enumName] = value
    numToDescMap[value] = desc
    numToEnumMap[value] = enumName
    list.push({ label: desc, value })
  }
  listNotEmpty.push(...list.filter((item) => item.value !== ''))
  return Object.freeze({
    list,
    listNotEmpty,
    ...strToValueMap,
    getDesc(enumName: number | string) {
      return (definition[enumName] && definition[enumName][1]) || ''
    },
    getDescFromValue(value: number | string) {
      return numToDescMap[value] || ''
    },
    getEnumFromValue(value: number | string) {
      return numToEnumMap[value] || ''
    }
  })
}

export const enumToArray = (enumData: { label: string | number; value: any; name: any }) => {
  const data: { label: string | number; value: any; name: any }[] = []
  const regPos = /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/
  for (const key in enumData) {
    if (!regPos.test(key)) {
      data.push({ value: enumData[key] as any, label: key, name: key })
    }
  }
  return data
}
