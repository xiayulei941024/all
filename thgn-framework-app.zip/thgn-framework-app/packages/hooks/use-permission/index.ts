/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-05 10:39:55
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-31 10:02:18
 * @Description:
 */
export const checkPermit = (value: string[]) => {
  if (!value || !value.length) {
    return true
  }
  const all_permission = '*'
  const menuPermissions = window.localStorage.getItem('menuPermissions')
  const permissions: any[] = menuPermissions && JSON.parse(menuPermissions)
  return permissions.some((permission: string) => {
    return all_permission === permission || value.includes(permission)
  })
}
