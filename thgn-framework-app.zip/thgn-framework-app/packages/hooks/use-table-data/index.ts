import { message } from 'gl-design-vue'
import { reactive, ref, onMounted } from 'vue'
export const useTableData = ({
  tableApi,
  switchApi,
  deleteApi,
  extraTableParams,
  form,
  isInit = true
}: {
  tableApi: Function
  switchApi?: Function
  deleteApi?: Function
  extraTableParams?: any
  form?: Object
  isInit?: boolean
}) => {
  interface Query {
    order?: string
    [propsName: string]: any //自定义类型
  }
  const query = reactive<Query>({ ...form })
  const tableData = reactive<any[]>([])
  const tableLoading = ref<boolean>(false)
  const allData = reactive({})
  const tableSelection = ref<any[]>([])
  const tableSelectedKeys = ref<any[]>([])

  //重置翻页
  interface Page {
    total: number
    pageNum: number
    pageSize: number
  }
  const getInitPage = (): Page => ({
    total: 0,
    pageNum: 1,
    pageSize: 10
  })
  const page = reactive(getInitPage())
  const resetPage = () => {
    // const initPage = getInitPage()
    // delete initPage.total
    // Object.assign(page, initPage)
    page.pageNum = 1
  }

  //获取table数据
  const getList = async () => {
    if (!tableApi) return
    tableLoading.value = true
    let queryParams = {
      ...query,
      pageSize: page.pageSize,
      pageNum: page.pageNum
    }
    if (extraTableParams) {
      queryParams = {
        ...extraTableParams,
        ...query,
        pageSize: page.pageSize,
        pageNum: page.pageNum
      }
    }
    const { res, err } = await tableApi(queryParams)
    tableLoading.value = false
    if (!err) {
      tableData.length = 0
      const { data } = res
      Object.assign(allData, data) //获取接口返回所有数据
      if (data?.list?.length > 0) {
        tableData.push(...data.list)
      }
      page.total = data.total
    }
  }
  //翻页
  const handlePageChange = (val: { pageNum: number; pageSize: number }) => {
    page.pageNum = val.pageNum
    page.pageSize = val.pageSize
    getList()
  }
  const sortChange = (column: any, params: Object) => {
    query.order = column.order === 'ascend' ? 'asc' : column.order === 'descend' ? 'desc' : ''
    Object.assign(query, params)
    getList()
  }
  //搜索
  const handleSearch = (val: Object) => {
    resetPage()
    Object.assign(query, val)
    getList()
  }
  // 切换状态
  const switchChange = async (params: { isEnable: number; id: number }) => {
    if (!switchApi) return
    const { err } = await switchApi(params)
    if (!err) {
      message.success(params.isEnable ? '启用成功！' : '禁用成功！')
    }
    getList()
  }
  //删除
  const handleDelete = async (params: { id: number }) => {
    if (!deleteApi) return
    const { err } = await deleteApi(params)
    if (!err) {
      message.success('删除成功！')
      if (
        page.total !== 1 &&
        page.total % page.pageSize === 1 &&
        Math.ceil(page.total / page.pageSize) === page.pageNum // 最后一页时才向前翻页
      ) {
        page.pageNum--
      }
      getList()
    }
  }
  const onSelectChange = (selectedRowKeys: [], selectedRows: any[]) => {
    tableSelection.value = [...selectedRows]
    tableSelectedKeys.value = [...selectedRowKeys]
  }

  onMounted(() => {
    if (isInit) {
      getList()
    }
  })
  return {
    getList,
    handlePageChange,
    handleSearch,
    tableData,
    tableLoading,
    page,
    sortChange,
    switchChange,
    handleDelete,
    allData,
    onSelectChange,
    tableSelection,
    tableSelectedKeys
  }
}
