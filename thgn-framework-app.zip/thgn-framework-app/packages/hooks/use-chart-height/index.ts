/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-19 16:23:58
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-21 13:35:01
 * @Description:
 */
export const useChartHeight = (r: number, d: any): any => {
  const domId = d || '#page-preview-wrapper'
  const setWrapperHeight = (): number => {
    const pageWrapper = typeof domId === 'string' ? document.querySelector(domId) : domId
    const contentHeight = pageWrapper && pageWrapper.offsetWidth / (r || 3.61)
    return contentHeight
  }
  const resetWrapperHeight = (pages: any[]) => {
    const wrapperHeight = setWrapperHeight()
    if (pages && pages.length) {
      pages.forEach((val) => {
        const hasChart =
          val.elements.length &&
          val.elements.some((item: any) => {
            const { elName } = item
            return elName === 'chart' || elName === 'table'
          })
        const isTable =
          val.elements.length &&
          val.elements.every((item: any) => {
            const { elName } = item
            return elName === 'table'
          })
        if (!val.elements.length || !hasChart || isTable) {
          val.height = 'unset'
          val.elements.forEach((v: any) => {
            v.commonStyle.position = 'unset'
          })
        } else {
          val.height = wrapperHeight
        }
      })
    }
  }
  const resetReportHeight = (pages: any[]) => {
    const wrapperHeight = setWrapperHeight()
    if (pages && pages.length) {
      // console.log('pages', pages)
      pages.forEach((val) => {
        const hasChart =
          val.elements.length &&
          val.elements.some((item: any) => {
            const { elName } = item
            return elName === 'rchart' || elName === 'template'
          })
        const isTable =
          val.elements.length &&
          val.elements.every((item: any) => {
            const { propsValue } = item
            return propsValue.param?.componentName === 'table'
          })
        const isTemplate =
          val.elements.length &&
          val.elements.every((item: any) => {
            const { elName } = item
            return elName === 'template'
          })
        if (!val.elements.length || !hasChart || isTable || isTemplate) {
          val.height = 'unset'
          val.elements.forEach((v: any) => {
            v.commonStyle.position = 'unset'
          })
        } else {
          val.height = wrapperHeight + 60
        }
      })
    }
  }
  const setElementHeight = (param: any) => {
    const wrapperHeight = setWrapperHeight()
    const isChart = param.diagramType !== 1
    param.height = isChart ? wrapperHeight : 'unset'
  }

  return {
    setWrapperHeight,
    resetWrapperHeight,
    resetReportHeight,
    setElementHeight
  }
}
