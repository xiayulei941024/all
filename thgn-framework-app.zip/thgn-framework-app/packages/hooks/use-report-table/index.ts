/*
 * @Autor: zhouwanwan
 * @Date: 2023-08-21 15:36:23
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-29 13:41:51
 * @Description:
 */
import { ref, reactive, nextTick } from 'vue'
export const useReportTable = () => {
  const INIT_ITEM = (bgColor: string) => ({
    editable: false,
    rowSpan: 1,
    colSpan: 1,
    text: '',
    itemStyle: {
      backgroundColor: bgColor
    }
  })

  const matrixTitle = reactive([
    { name: '标题' },
    { name: '单位' },
    { name: '数据来源：我的钢铁网' }
  ])

  const matrixData = reactive([])

  const selectedCells = ref([])

  // table画布宽度
  const colTotalWidth = ref(0)
  // 默认边框及样式
  const outline = reactive({
    color: 'rgb(232, 232, 232)',
    style: 'solid',
    width: 1
  })
  const EditTableWrapper = ref()

  const formatTableData = (row: any, columns: any, isMatrix?: any) => {
    matrixData.length = 0
    for (let i = 0; i < row; i++) {
      const obj = {}
      Object.defineProperty(obj, 'key', {
        value: String(i),
        writable: true
      })
      const arr: any = []
      columns.forEach((item: any) => {
        Object.defineProperty(obj, item, {
          value: '',
          writable: true
        })
        let p = {}
        if (i === 0) {
          p = { ...INIT_ITEM('#F4F4F4') }
        } else {
          p = { ...INIT_ITEM('') }
        }
        arr.push(p)
      })
      if (!isMatrix) matrixData.push(arr)
    }
  }

  const formState = reactive({
    col: 3,
    row: 4
  })
  const initTable = () => {
    // 清空标题
    matrixTitle.length = 0
    matrixTitle.push({ name: '标题' }, { name: '单位' }, { name: '数据来源：我的钢铁网' })
    const columns = []
    for (let i = 0; i < formState.col; i++) {
      columns.push(`col${i}`)
    }

    formatTableData(formState.row, columns)

    nextTick(() => {
      if (EditTableWrapper.value) {
        colTotalWidth.value = EditTableWrapper.value.clientWidth
      }
    })
  }

  initTable()

  return {
    matrixTitle,
    matrixData,
    selectedCells,
    colTotalWidth,
    EditTableWrapper,
    outline,
    initTable
  }
}
