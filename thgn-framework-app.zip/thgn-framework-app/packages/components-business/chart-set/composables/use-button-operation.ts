/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-09 14:59:47
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-14 16:10:50
 * @Description:
 */
import { generateImage, downloadEchart } from '@mysteel-standard/utils'
import useCollect from '../composables/use-collect'
export default (state: any) => {
  const extractData = ref<any>({})
  const editVisible = ref(false)
  const chartId = ref<any>('')
  const getExtractData = (data: any) => {
    extractData.value = { ...data, ...state.extractParam }
  }
  //编辑
  const handleEdit = (data: any) => {
    editVisible.value = true
    chartId.value = data.propsValue.param.id || data.id
  }
  //收藏
  const { collectVisible, treeTitle, handleCollect, handleSubmit } = useCollect()
  //下载
  const handleDownload = async (element: any, elementName: string) => {
    if (elementName === 'table') {
      const DOM = document.querySelector(`.element-wrapper-cht${element.uuid} .theme`)
      const w = DOM.offsetWidth + 24
      const h = DOM.offsetHeight + 14
      const baseUrl = await generateImage(DOM, w, h)
      downloadEchart(baseUrl, element.propsValue?.param.name || element.name)
    } else {
      document.querySelector(`.element-wrapper-cht${element.uuid} canvas`).toBlob((blob) => {
        const a = document.createElement('a')
        document.body.append(a)
        a.download = `${element.propsValue?.param.name || element.name}.png`
        a.href = URL.createObjectURL(blob)
        a.click()
        a.remove()
      })
    }
  }
  //全屏
  const elementVisible = ref(false)
  const chartSetItem = ref({})
  const enlargeClick = (element: any) => {
    chartSetItem.value = element
    elementVisible.value = true
  }
  return {
    //编辑图表
    getExtractData,
    extractData,
    chartId,
    editVisible,
    //图表收藏
    collectVisible,
    treeTitle,
    handleCollect,
    handleSubmit,
    handleEdit,
    handleDownload,
    //全屏
    enlargeClick,
    elementVisible,
    chartSetItem
  }
}
