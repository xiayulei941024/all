<template>
  <div class="date-input" @click="dateClick">
    <gl-input v-model:value="dateText" readonly placeholder="请选择时间范围">
      <template #prefix>
        <icon name="icon-date_picker" color="#bfbfbf" />
      </template>
      <template #suffix>
        <close-circle-outlined v-if="dateText" @click.stop="clearValue" style="color: #bfbfbf" />
      </template>
    </gl-input>
  </div>
  <div class="hidden_box">
    <gl-range-picker
      v-model:value="indexTimeForm.date"
      class="range_picker"
      format="YYYY-MM-DD"
      value-format="YYYY-MM-DD"
      :open="calendarOpen"
      dropdown-class-name="calendar-lunar"
      @open-change="openChange"
      @change="panelChange"
    >
      <template #renderExtraFooter>
        <!-- <div class="calendar-help-box">
          <div class="date-list">
            <gl-button type="text" @click="quickSelectDate(6, 'month', '最近半年')"
              >最近半年</gl-button
            >
            <gl-button type="text" @click="quickSelectDate(1, 'years', '最近一年')"
              >最近一年</gl-button
            >
            <gl-button type="text" @click="quickSelectDate(3, 'years', '最近三年')"
              >最近三年</gl-button
            >
            <gl-button type="text" @click="quickSelectDate(5, 'years', '最近五年')"
              >最近五年</gl-button
            >
          </div>
           <div class="date-list">
            <gl-button type="primary" size="small" @click="highSet()" style="margin-left: 10px"
              >高级设置</gl-button
            >
          </div> 
        </div> -->
        <div class="date-footer-bottom">
          <gl-button type="text" @click="clearDate()" style="margin-left: 10px">清空</gl-button>
          <gl-button
            type="primary"
            :disabled="!indexTimeForm.date?.length"
            ghost
            size="small"
            @click="sureSelectDate()"
            style="margin-left: 10px"
            >确定</gl-button
          >
        </div>
      </template>
    </gl-range-picker>
  </div>
  <!-- <date-set-modal
    v-if="dateSetVisible"
    :dateSetForm="calendarState"
    v-model:dateSetVisible="dateSetVisible"
    dateSetTitle="设置日期"
    @set-date-ok="saveDateSet"
  /> -->
</template>

<script setup lang="ts">
// import dayjs from 'dayjs'
import { Icon } from '@mysteel-standard/components'
// import { useResetData } from '@mysteel-standard/hooks'
// import { DateSetModal } from '@mysteel-standard/components-business'
import { CloseCircleOutlined } from '@ant-design/icons-vue'
interface Props {
  form: DateSetFormType
}
export interface DateSetFormType {
  date?: any[]
  dateType: number //时间类型 0:公立 1:农历
  beginTime?: string
  endTime?: string
  frequency?: string //指标的频度类型（日度， 周度，月度）
  intervalType?: number //日期区间：0、全部日期，1、最后观察值，2、日期选择
  timeCount: number | null //时间计数：（后多少日、周、月、年）
  timeType: string | null //时间描述类型字符串（日， 周，月，年）
}
const props = defineProps<Props>()
interface Emits {
  (e: 'change-time', form: DateSetFormType): void
}
const emits = defineEmits<Emits>()
//日期设置
// const { dataState: calendarState, resetDataState: resetCalendarState } = useResetData({
//   date: [],
//   dateType: 0, //时间类型 0:公立 1:农历
//   beginTime: '',
//   endTime: '',
//   frequency: '', //指标的频度类型（日度， 周度，月度）
//   intervalType: 0, //日期区间：0、全部日期，1、最后观察值，2、日期选择
//   timeCount: 1, //日期区间 最后：（日、周、月、年）
//   timeType: '观察值' //时间描述类型字符串（日， 周，月，年）
// })
const indexTimeForm = ref<DateSetFormType>(props.form)
// 快捷操作
const calendarOpen = ref(false)
// const dateSetVisible = ref(false)
const dateText = ref<string>('')
const getDateText = () => {
  const { intervalType, date, timeCount, timeType } = indexTimeForm.value
  if (timeType) {
    dateText.value = timeType
  }
  if (date && (date[0] || date[1])) {
    dateText.value = `${date[0]}~${date[1]}`
  }
  if (intervalType === 1 && timeCount && timeType) {
    dateText.value = '最后' + timeCount + timeType
  }
  if (intervalType === 2) {
    if (date && (date[0] || date[1])) {
      dateText.value =
        date[0] + (!date[0] || !date[1] ? ' 至 ' : ' ~ ') + (date[1] ? date[1] : '至今')
    }
  }
}
// const dateSet = (dateNumber: number, datetype: any, text: string) => {
//   indexTimeForm.value.date = [
//     dayjs().subtract(dateNumber, datetype).format('YYYY-MM-DD'),
//     dayjs().format('YYYY-MM-DD')
//   ]
//   getDateText()
//   calendarState.intervalType = 2
//   calendarState.timeType = text
//   calendarState.beginTime = ''
//   calendarState.endTime = ''
// }
// const highSet = () => {
//   calendarOpen.value = false
//   dateSetVisible.value = true
// }
// const quickSelectDate = (dateNumber: number, dateType: string, text: string) => {
//   resetCalendarState()
//   resetHightSet()
//   dateSet(dateNumber, dateType, text)
//   calendarOpen.value = false
//   indexTimeForm.value.date = []
//   indexTimeForm.value.timeCount = -1
//   indexTimeForm.value.timeType = text
//   dateText.value = text
//   emits('change-time', indexTimeForm.value)
// }
const panelChange = () => {
  dateText.value = indexTimeForm.value.date?.join('~') || ''
  emits('change-time', indexTimeForm.value)
}

//时间范围组件显示
const openChange = (open: boolean) => {
  calendarOpen.value = open
}
const dateClick = () => {
  calendarOpen.value = true
}
//时间范围组件-确定
const sureSelectDate = () => {
  resetHightSet()
  getDateText()
  calendarOpen.value = false
  emits('change-time', indexTimeForm.value)
}
//时间范围组件-清空
const clearDate = () => {
  resetHightSet()
  indexTimeForm.value.date = []
}
const resetHightSet = () => {
  indexTimeForm.value.timeCount = null
  indexTimeForm.value.timeType = null
}
//清除 时间框显示内容
const clearValue = () => {
  dateText.value = ''
  // resetHightSet()
  // resetCalendarState()
  clearDate()
  emits('change-time', indexTimeForm.value)
}
// 保存高级设置
// const saveDateSet = (data: DateSetFormType) => {
//   const { intervalType, dateType, beginTime, endTime, timeCount, timeType } = data
//   indexTimeForm.value = {
//     date: [beginTime, endTime],
//     dateType,
//     timeCount,
//     timeType,
//     intervalType
//   }
//   if (beginTime || endTime) {
//     dateText.value = `${beginTime}~${endTime}`
//   }
//   if (intervalType === 1) {
//     dateText.value = '最后' + timeCount + timeType
//   }
//   if (intervalType === 2) {
//     if (beginTime || endTime) {
//       dateText.value =
//         beginTime + (!beginTime || !endTime ? ' 至 ' : ' ~ ') + (endTime ? endTime : '至今')
//     }
//   }
//   emits('change-time', indexTimeForm.value)
// }
watch(
  () => props.form,
  () => {
    getDateText()
  },
  {
    deep: true
  }
)
</script>

<style lang="scss" scoped>
@import './calendar-picker.scss';
</style>
