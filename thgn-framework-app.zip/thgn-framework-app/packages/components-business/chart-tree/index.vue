<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-03 10:56:04
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-14 17:31:15
 * @Description: 
-->
<template>
  <ms-tree
    :key="tabItem.value"
    v-model:selected-keys="selectedKeys"
    v-model:expanded-keys="expandedKeys"
    block-node
    show-icon
    :tree-data="treeData"
    :auto-expand-parent="false"
    :field-names="replaceFields"
    :node-menus="treeMenu"
    isMenu
    :draggable="checkPermit(['sjzx:tbk:gstbkmlpx']) || tabItem.value === 2"
    @select="selectClick"
    @drop="handleDropTree"
  >
  </ms-tree>

  <gl-modal
    :title="isEdit ? '重命名' : '新建文件夹'"
    :visible="folderVisible"
    @ok="confirmFolderBtn"
    @cancel="cancelBtn"
  >
    <gl-form
      ref="formRef"
      :model="folderForm"
      :rules="rules"
      :label-col="{ span: 6 }"
      :wrapper-col="{ span: 18 }"
      label-align="right"
    >
      <gl-form-item label="文件夹名称" name="folder">
        <gl-input v-model:value.trim="folderForm.folder" :maxlength="50" style="width: 300px" />
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useCompanyChartTree from './composables/use-chart-tree'
import { checkPermit } from '@mysteel-standard/hooks'

interface Props {
  tabItem: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'get-catalogue-item', val: boolean): void
  (e: 'update-loading', val: boolean): void
}
const emits = defineEmits<Emits>()

const {
  treeData,
  expandedKeys,
  selectedKeys,
  replaceFields,
  treeMenu,
  selectClick,
  handleDropTree,
  getTree,
  cancelBtn,
  isEdit,
  confirmFolderBtn,
  folderVisible,
  folderForm,
  formRef,
  rules
} = useCompanyChartTree(props, emits)

defineExpose({ getTree })
</script>
<style lang="scss" scoped>
// .ms-tree :deep(.gl-tree) {
//   .gl-tree-node-content-wrapper {
//     overflow: hidden;
//   }
// }
</style>
