/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-19 14:21:05
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-10 20:04:05
 * @Description: 饼图option设置
 */
import { cloneDeep } from 'lodash-es'
import style from '../constants/style'
import { LEGEND_POSITION } from '../constants'
export default (chartOption: any, props: any, imgUrl: any) => {
  //初始化数据
  const initPieOption = style['chart-pie']()
  //设置饼图series
  const setPieSeries = () => {
    const { contentOption } = props.curEl
    const { series } = initPieOption
    const sery = cloneDeep(series[0])
    const data = contentOption.indexOptionsPie
      .filter((ser: { checked: boolean }) => ser.checked)
      .map((item: { data: number; legendName: string; itemColor: string }) => ({
        value: Math.abs(item.data),
        name: item.legendName,
        itemStyle: { color: item.itemColor }
      }))
    sery.data = data
    sery.label = {
      ...sery.label,
      formatter: contentOption.pieLabel.formatter.join('  '),
      ...contentOption.pieLabel.textStyle,
      backgroundColor: {
        image:
          contentOption.pieLabel.textStyle.textDecoration === 'underline'
            ? imgUrl.value
            : 'transparent'
      },
      position: contentOption.pieLabel.position
    }
    sery.radius = [contentOption.pieSettings.radiusIn, contentOption.pieSettings.radiusOut]
    sery.startAngle = contentOption.pieSettings.startAngle || 0
    chartOption.value.series[0] = sery
  }
  //设置饼图:legend
  const setPieLegend = () => {
    const { legend } = initPieOption
    const { contentOption } = props.curEl
    chartOption.value.legend = {
      ...legend,
      data: contentOption.indexOptionsPie
        .filter((sery: { checked: boolean }) => sery.checked)
        .map((item: { legendName: string }) => item.legendName),
      textStyle: {
        ...contentOption.legendLayoutPie.textStyle,
        backgroundColor: {
          image:
            contentOption.legendLayoutPie.textStyle.textDecoration === 'underline'
              ? imgUrl.value
              : 'transparent'
        }
      },
      ...LEGEND_POSITION[contentOption.legendLayoutPie.position]
    }
  }

  return { setPieSeries, setPieLegend }
}
