/* 图相关配置 */
import _ from 'lodash-es'
import series from './series'

const base = {
  color: ['#ff0000', '#2e75b6', '#a6a6a6', '#292929', '#00aff0', '#ffafaf', '#e46c0a', '#0606eb'],
  visualMap: null,
  title: {
    text: '',
    left: 'center',
    textStyle: {
      color: '#333333', //颜色
      fontWeight: 'bold', //粗细
      fontFamily: '微软雅黑', //字体
      fontSize: 14 //大小
    }
  },
  tooltip: {
    show: true,
    trigger: 'axis',
    backgroundColor: 'rgba(0, 0, 0, .4)',
    borderColor: 'rgba(0, 0, 0, .4)',
    textStyle: {
      color: '#fff'
    }
  },
  grid: {
    top: '8%',
    left: '2%',
    right: '5%',
    bottom: '16%',
    containLabel: true
  },
  legend: {
    show: true,
    itemGap: 10,
    orient: 'horizontal',
    align: 'auto',
    type: 'scroll',
    textStyle: {
      color: '#333333',
      fontSize: 14,
      fontFamily: '微软雅黑',
      fontWeight: 'normal',
      overflow: 'truncate'
    },
    padding: [10, 10],
    z: -1
  },
  xAxis: {
    type: 'category',
    boundaryGap: true,
    name: '',
    nameTextStyle: {
      fontFamily: '微软雅黑',
      color: '#333333',
      fontSize: 12,
      fontWeight: 'normal',
      fontStyle: 'normal'
    },
    axisLine: {
      lineStyle: {
        type: 'solid',
        width: 1,
        color: '#DDDDDD'
      }
    },
    splitLine: {
      show: false,
      lineStyle: {
        color: '#DDDDDD',
        width: 1,
        type: 'solid'
      }
    },
    axisLabel: {
      show: true,
      fontSize: 12,
      fontFamily: '微软雅黑',
      fontWeight: 'normal',
      rotate: 0,
      color: '#333333'
    }
  },
  yAxis: [
    {
      type: 'value',
      name: '',
      position: 'left',
      nameTextStyle: {
        fontFamily: '微软雅黑',
        color: '#cccccc',
        fontSize: 12,
        fontWeight: 'normal',
        fontStyle: 'normal'
      },
      axisLine: {
        show: true,
        lineStyle: {
          type: 'solid',
          width: 1,
          color: '#333333'
        }
      },

      splitLine: {
        show: false,
        lineStyle: {
          color: '#DDDDDD',
          width: 1,
          type: 'solid'
        }
      },
      axisLabel: {
        show: true,
        fontSize: 12,
        fontFamily: '微软雅黑',
        fontWeight: 'normal',
        rotate: 0,
        color: '#333333'
      }
    }
  ]
}

// 折线图
const defaultLineOption = () => {
  return _.merge({}, base, {
    xAxis: {
      data: []
    },
    series: [
      {
        data: [],
        ...series['line-simple']()
      }
    ]
  })
}

// 柱状图
// const defaultOption = () => {
//   return _.merge({}, base, {
//     xAxis: {
//       type: 'category',
//       data: []
//     },
//     series: [
//       {
//         data: [],
//         ...series['bar-simple']()
//       }
//     ]
//   })
// }

// 饼图
const pieSimple = () => {
  return {
    color: ['#2e75b6', '#ff0000', '#a6a6a6', '#292929', '#00aff0', '#ffafaf', '#e46c0a', '#0606eb'],
    legend: {
      show: true,
      itemGap: 10,
      textStyle: {
        color: '#333333',
        fontSize: 14,
        fontFamily: '微软雅黑',
        fontWeight: 'normal'
      },
      padding: 20,
      x: 'center',
      y: 'top',
      align: 'left'
    },
    series: [
      {
        ...series['pie-simple'](),
        data: []
      }
    ]
  }
}

const radarSimple = () => {
  return {
    color: [],
    grid: {
      top: '20%',
      left: '8%',
      right: '8%',
      bottom: '6%'
    },
    visualMap: null,
    legend: {
      data: [],
      show: true,
      itemGap: 10,
      orient: 'horizontal',
      align: 'auto',
      textStyle: {
        fontSize: 12,
        fontFamily: '微软雅黑',
        fontWeight: 'normal',
        overflow: 'truncate'
      },
      padding: [10, 10],
      z: -1
    },
    tooltip: {
      trigger: 'item'
    },
    radar: {
      indicator: [
        {
          name: '',
          max: '',
          axisLabel: {
            show: true
          }
        }
      ],
      axisName: {
        color: '#ccc',
        fontFamily: '微软雅黑',
        fontSize: 12,
        fontWeight: 'bold',
        fontStyle: 'normal'
      },
      axisLine: {
        lineStyle: {
          type: 'solid',
          width: 1,
          color: ''
        }
      }
    },
    series: [
      {
        name: '',
        type: 'radar',
        data: [
          {
            value: [],
            name: '',
            lineStyle: {
              width: 1,
              type: 'solid'
            },
            itemStyle: {
              color: ''
            }
          }
        ]
      }
    ]
  }
}
//散点图
const scatterSimple = function () {
  return {
    color: [],
    xAxis: {
      type: 'value',
      name: '',
      nameTextStyle: {
        fontFamily: '微软雅黑',
        color: '#333333',
        fontSize: 12,
        fontWeight: 'normal',
        fontStyle: 'normal'
      },
      axisLine: {
        lineStyle: {
          type: 'solid',
          width: 1,
          color: '#333333'
        },
        onZero: false
      },
      splitLine: {
        show: false,
        lineStyle: {
          color: '#DDDDDD',
          width: 1,
          type: 'solid'
        }
      },
      axisLabel: {
        show: true,
        fontSize: 12,
        fontFamily: '微软雅黑',
        fontWeight: 'normal',
        rotate: 0,
        color: '#333333'
      }
    },
    yAxis: {
      type: 'value',
      // boundaryGap: ['5%', '5%'],
      name: '',
      position: 'left',
      nameTextStyle: {
        fontFamily: '微软雅黑',
        color: '#cccccc',
        fontSize: 12,
        fontWeight: 'normal',
        fontStyle: 'normal'
      },
      axisLine: {
        show: true,
        lineStyle: {
          type: 'solid',
          width: 1,
          color: '#333333'
        }
      },

      splitLine: {
        show: false,
        lineStyle: {
          color: '#DDDDDD',
          width: 1,
          type: 'solid'
        }
      },
      axisLabel: {
        show: true,
        fontSize: 12,
        fontFamily: '微软雅黑',
        fontWeight: 'normal',
        rotate: 0,
        color: '#333333'
      }
    },
    tooltip: {
      trigger: 'item',
      axisPointer: {
        type: 'cross'
      }
    },
    grid: {},
    series: [
      {
        name: '',
        type: 'scatter',
        data: [
          // {
          //   value: [],
          //   name: '',
          //   label: {
          //     position: 'right',
          //     show: true,
          //   },
          //   itemStyle: {
          //     color: '',
          //   },
          // },
        ],
        symbolSize: '',
        itemStyle: {
          color: ''
        },
        label: {
          position: 'top',
          show: true
        }
      }
    ]
  }
}

export default {
  'bar-line': defaultLineOption,
  'chart-pie': pieSimple,
  'chart-radar': radarSimple,
  'scatter-plot': scatterSimple
}
