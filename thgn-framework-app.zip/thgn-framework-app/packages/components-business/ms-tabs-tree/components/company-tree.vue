<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-14 14:06:16
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 19:34:58
 * @Description: 
-->
<template>
  <gl-spin :spinning="companyTreeLoading" style="margin-top: 50px">
    <ms-tree
      v-model:expandedKeys="companyExpandedKeys"
      autoExpandParent
      block-node
      :tree-data="companyTreeData"
      :fieldNames="companyFields"
      :load-data="companyTreeLoad"
      @select="companyNodeClick"
      @expand="companyTreeExpand"
    >
    </ms-tree>
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useCompanyTree from '../composables/use-company-tree'

//props
interface Props {
  frequency?: string
}
const props = defineProps<Props>()

interface Emits {
  (e: 'emits', node: any): void
}
const emits = defineEmits<Emits>()

const {
  treeData: companyTreeData,
  replaceFields: companyFields,
  treeLoading: companyTreeLoading,
  onLoadData: companyTreeLoad,
  getTreeData: getCompanyTree,
  expandedKeys: companyExpandedKeys,
  treeExpand: companyTreeExpand,
  nodeClick: companyNodeClick
} = useCompanyTree(emits, props)

defineExpose({ getCompanyTree })
</script>
