/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-13 15:53:17
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-25 10:37:43
 * @Description:
 */
export enum TabList {
  // Mysteel数据库 = 1,
  公司数据库 = 2,
  我的收藏 = 3
}
export enum FrequencyEnum {
  日度 = 1,
  周度 = 2,
  月度 = 3,
  季度 = 4,
  半年度 = 5,
  年度 = 6
}
export interface CollectTreeType {
  catalogName: string //目录名称	string
  children: CollectTreeType[] //子目录列表	array	IndexCollectVO
  createId: string //创建人id	string
  creatorTime: string //	创建时间	string(date-time)
  frequency: string //  频度	string
  id: number //  主键id	integer(int64)
  indexCode: string //  指标编码	string
  indexName: string // 指标名称	string
  indexParams: string //	指标相关参数	string
  isLeaf: boolean //  true叶子节点 false非叶子节点	boolean
  pid: number // 	父节点id	integer(int64)
  sort: number //   排序字段	integer(int32)
  type: number // 类型，1：目录，2：指标	integer(int32)
  updateId: string //修改人ID	string
  updateName: string //修改人名称	string
  updateTime: string //修改时间
  isEnd: number
}
//新增编辑目录
export interface MenuFormType {
  catalogName: string
  id?: number
  isLeaf: boolean
  pid: number
}
//树操作菜单
export interface OperationMenuType {
  [propsName: string]: any //自定义类型
}
// 指标搜索
export interface IndexQuery {
  varietyList: string[]
  searchWord?: string
  cityList: string[]
  companyList: string[]
  indexList: string[]
  [propsName: string]: any
}
// 指标数据列表
export interface IndexType {
  area: string //地区	string
  beginDate: string //开始时间	string
  category: string //类别	string
  city: string //城市	string
  country: string //国家	string
  cpShortName: string //企业简称	string
  decimalPlaces: number //精确度	integer(int32)
  description: string //描述	string
  editFormulaJson: string //指标公式Json	string
  endDate: string //结束时间	string
  frequency: string //频度	string
  id: string //id	string
  indexCode: string //指标编码	string
  indexName: string //指标名称	string
  indexShortName: string //指标简称	string
  indexType: string //指标类型	string
  isDerive: number //是否衍生 0否 1是	integer(int32)
  isStop: number //是否停更 0否 1是	integer(int32)
  newestDate: number //最新值	number(double)
  oldIndexCode: string //旧指标编码	string
  oldIndexName: string //旧指标名称	string
  port: string //港口	string
  province: string //省份	string
  scala: string //保留小数位	string
  sourceName: string //来源	string
  unit: string //单位	string
  updateDate: string //更新日期	string
  updateStatus: string //更新状态	string
  updateTime: string //	更新时间	string(date-time)
  varieties: string //品种
}
//指标详情列表
export interface IndexData {
  beginTime: string //	起始时间(yyyy-MM-dd)
  dateType: number // 时间类型 0:公立 1:农历
  dbType: number //数据库类型 // 0:mysteel数据库， 1：企业数据库
  decimalPlaces: Object // {指标编码:保留小位数}
  deriveIndexes: any[] // 	衍生指标公式
  endTime: string // 截止时间(yyyy-MM-dd)
  frequency: string // 指标的频度类型（日度， 周度，月度）
  indexCodes: any[] //指标集合
  isCut: boolean //	是否需要截断
  rows: number //行数		false
  scala: number //保留小数位		false
  size: number //数据大小		false
  sortByDate: number //时间排序		false
  sortOrder: number //排序		false
  tableName: string //表名		false
  timeCount: number //时间计数（后多少日、周、月、年）		false
  timeType: string //时间描述类型字符串（日， 周，月，年）
  valueType: number
}

export interface MysteelDataType {
  children: MysteelDataType[] //子目录节点集合	array	CataLogNodeResponse
  code: string //节点编码	string
  createTime: string //创建时间	string(date-time)
  createUserId: number //创建人id	integer(int64)
  description: string //描述	string
  frameIdPath: string //框架路径	string
  frequency: string //频度	string
  id: number //节点id	string
  indexLastUpdateTime: string //最后更新时间	string
  isDelete: string //是否删除,0：否 1：是	string
  isLeaf: boolean //true叶子节点 false非叶子节点	boolean
  isPublish: number //是否发布	integer(int32)
  isStop: number //是否停更	integer(int32)
  isUpdate: number //是否更新最新数据	integer(int32)
  label: string //节点名称	string
  latestDateValue: string //最新值	string
  level: number //框架层级	integer(int64)
  pid: string //父节点id	string
  priority: number //排序	integer(int32)
  relevanceIndex: string //关联指标	string
  type: number //节点类型 1：框架 2：指标	integer(int32)
  updateTime: string //更新时间	string(date-time)
  updateUserId: number //更新人id
}
interface ExportIndex {
  //   decimalPlaces	保留位数		false
  // integer
  // frequency	频度		false
  // string
  // indexCode	指标编码		false
  // string
  // indexName	指标名称		false
  // string
  // sourceName	来源		false
  // string
  // unit	单位
}
//日期设置表单
export interface DateSetFormType {
  date?: any[]
  dateType: number //时间类型 0:公立 1:农历
  beginTime?: string
  endTime?: string
  frequency?: string //指标的频度类型（日度， 周度，月度）
  intervalType?: number //日期区间：0、全部日期，1、最后观察值，2、日期选择
  timeCount: number | null //时间计数：（后多少日、周、月、年）
  timeType: string | null //时间描述类型字符串（日， 周，月，年）
}
export interface ToolObject {
  type: string
  value: boolean | string
  name: string
  id: number
  icon: string
}
export interface DataToolObj {
  dataSettings: boolean | string
  flexRow: boolean
  statistical: boolean
}
export interface DateType {
  date: string[]
  dateType: number //时间类型 0:公立 1:农历
  timeCount: number | null //日期区间 最后：（日、周、月、年）
  timeType: string | null //时间描述类型字符串（日， 周，月，年）
}
export interface EditFormulaForm {
  // editFormula,
  // editFormulaName:
  // editFormulaFreStr
  // editFormulaJson:
  // editFormulaScale:
}
