/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-25 13:53:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-18 09:44:50
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
import { ref } from 'vue'
export default (emits: any, props: any) => {
  const treeData = ref([])
  const replaceFields = ref({
    children: 'children',
    title: 'label',
    key: 'id'
  })

  const treeLoading = ref(false)
  const companySelectedNodes = ref<any>([])
  const getTreeData = async () => {
    treeLoading.value = true
    const { err, res } = await api.getCatalogTree({
      dbType: 1
    })
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      data?.length &&
        data.forEach(
          (item: { isLeaf: boolean; isEnd: number; type: number; hasChildIndex: boolean }) =>
            (item.isLeaf = !!item.isEnd)
        )
      treeData.value = data || []
    }
  }

  const onLoadData = (treeNode: any, isLazyLoad = true) => {
    const { dataRef } = treeNode
    if (dataRef.isEnd && isLazyLoad) return
    return new Promise((resolve: any) => {
      const params = {
        dbType: 1,
        frameId: Number(dataRef.id)
      }
      if (props.frequency) {
        Object.assign(params, {
          frequency: props.frequency
        })
      }
      api.getCatalogNode(params).then((data: { err: any; res: any }) => {
        const { err, res } = data
        if (!err && res) {
          const { data } = res
          data.forEach((item: any) => (item.isLeaf = !!item.isEnd))
          //判断目录和指标
          if (data.length > 0 && data[0].type === 2) {
            resolve()
            const addData = data.map((item: any) => {
              const obj = {
                ...item,
                dbType: 1
              }
              return obj
            })
            emits('extract-index', addData, companySelectedNodes.value)
          } else {
            dataRef.children = data || []
            treeData.value = [...treeData.value]
            resolve()
          }
        }
      })
    })
  }

  const { expandedKeys, treeExpand, nodeExpand } = useTreeExpand()
  //树选中
  const nodeClick = (
    selectedKeys: number[],
    {
      node,
      selectedNodes
    }: {
      node: {
        isLeaf: boolean
        isEnd: boolean
      }
      selectedNodes: any[]
    }
  ) => {
    companySelectedNodes.value = [...companySelectedNodes.value, node]
    const { isEnd } = node
    if (isEnd) {
      onLoadData(node, false)
    } else {
      nodeExpand(node)
    }
  }
  return {
    treeData,
    replaceFields,
    treeLoading,
    onLoadData,
    getTreeData,
    expandedKeys,
    nodeClick,
    treeExpand
  }
}
