/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-13 16:02:32
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-11 14:40:43
 * @Description: 常量
 */
// 图表编辑页-图表类型配置
export const DIAGRAM_LIST = [
  {
    id: 'bar-line',
    componentName: 'chart',
    title: { name: '柱状折线图' },
    configTabs: [
      { key: 'indexOptionsBarLine', title: '指标' },
      { key: 'legendLayout', title: '图例&布局' },
      { key: 'xAxis', title: '横坐标' },
      { key: 'yAxis', title: '纵坐标' }
    ],
    contentOption: {
      indexOptionsBarLine: [
        {
          checked: true,
          dateList: [],
          data: [],
          legendName: '',
          indexCode: '',
          type: 'line',
          lineStyleType: 'solid',
          lineStyleWidth: 2,
          barWidth: 10,
          itemColor: '#2e75b6',
          yAxisIndex: 0,
          isSeason: false,
          isLabel: false,
          labelPosition: 'top'
        }
      ],
      legendLayout: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },
        textStyle: {
          fontFamily: '微软雅黑',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        position: 'top',
        xSplitLine: {
          show: false,
          lineStyle: {
            color: '#e7e6e6',
            width: 1,
            type: 'dashed'
          }
        },
        ySplitLine: {
          show: false,
          lineStyle: {
            color: '#e7e6e6',
            width: 1,
            type: 'dashed'
          }
        }
      },
      xAxis: {
        name: '',
        nameTextStyle: {
          fontFamily: '微软雅黑',
          color: '#000000',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        axisLine: {
          lineStyle: {
            type: 'solid',
            width: 1,
            color: '#e7e6e6'
          }
        },
        rangeDate: {
          dateType: 0,
          intervalType: 'all',
          timeCount: null,
          timeType: null,
          beginTime: '',
          endTime: ''
        },
        dataFormat: 'slash',
        dataFrequency: 'YM'
      },
      yAxis: [
        {
          show: true,
          name: '轴1',
          unit: '',
          nameTextStyle: {
            fontFamily: '微软雅黑',
            color: '#000000',
            fontSize: 12,
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none'
          },
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: 1,
              color: '#e7e6e6'
            }
          },
          offset: 0,
          inverse: false,
          min: '',
          max: '',
          interval: '',
          position: 'left'
        },
        {
          show: true,
          name: '轴2',
          unit: '',
          nameTextStyle: {
            fontFamily: '微软雅黑',
            color: '#000000',
            fontSize: 12,
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none'
          },
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: 1,
              color: '#e7e6e6'
            }
          },
          offset: 10,
          inverse: false,
          min: '',
          max: '',
          interval: '',
          position: 'left'
        },
        {
          show: true,
          name: '轴3',
          unit: '',
          nameTextStyle: {
            fontFamily: '微软雅黑',
            color: '#000000',
            fontSize: 12,
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none'
          },
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: 1,
              color: '#e7e6e6'
            }
          },
          offset: 20,
          inverse: false,
          min: '',
          max: '',
          interval: '',
          position: 'left'
        },
        {
          show: true,
          name: '轴4',
          unit: '',
          nameTextStyle: {
            fontFamily: '微软雅黑',
            color: '#000000',
            fontSize: 12,
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none'
          },
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: 1,
              color: '#e7e6e6'
            }
          },
          offset: 30,
          inverse: false,
          min: '',
          max: '',
          interval: '',
          position: 'left'
        }
      ],
      seasonOptions: {},
      seasonIndexCode: '',
      seasonChecked: false
    }
  },
  {
    id: 'chart-pie',
    componentName: 'chart',
    title: { name: '饼图' },
    configTabs: [
      { key: 'indexOptionsPie', title: '指标' },
      { key: 'legendLayoutPie', title: '图例&布局' },
      { key: 'pieLabel', title: '数据标签' },
      { key: 'pieSettings', title: '图形设置' }
    ],
    contentOption: {
      indexOptionsPie: [
        {
          checked: true,
          disabled: false,
          data: '',
          legendName: '',
          indexCode: '',
          itemColor: '#2e75b6'
        }
      ],
      legendLayoutPie: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },
        textStyle: {
          fontFamily: '微软雅黑',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        position: 'top'
      },
      pieLabel: {
        formatter: ['{b}', '{c}'],
        textStyle: {
          fontFamily: '微软雅黑',
          fontSize: 12,
          color: '#000000',
          fontWeight: 'normal',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        position: 'outside'
      },
      pieSettings: {
        radiusIn: 0,
        radiusOut: 50,
        startAngle: ''
      }
    }
  },
  {
    id: 'scatter-plot',
    componentName: 'chart',
    title: { name: '散点图' },
    configTabs: [
      { key: 'indexOptionsScatter', title: '指标' },
      { key: 'legendLayoutScatter', title: '图例&布局' },
      { key: 'scatterXAxis', title: '横坐标' },
      { key: 'scatterYAxis', title: '纵坐标' }
    ],
    contentOption: {
      indexOptionsScatter: [
        {
          checked: true,
          legendName: '',
          labelName: '',
          data: '',
          indexCode: '',
          symbolSize: 10,
          itemColor: '#2e75b6',
          relatedIndexCode: '',
          axis: 'x'
        }
      ],
      legendLayoutScatter: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },

        xSplitLine: {
          show: false,
          lineStyle: {
            color: '#e7e6e6',
            width: 1,
            type: 'dashed'
          }
        },
        ySplitLine: {
          show: false,
          lineStyle: {
            color: '#e7e6e6',
            width: 1,
            type: 'dashed'
          }
        }
      },
      scatterXAxis: {
        name: '',
        nameTextStyle: {
          fontFamily: '微软雅黑',
          color: '#000000',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        axisLine: {
          lineStyle: {
            type: 'solid',
            width: 1,
            color: '#e7e6e6'
          }
        },
        min: '',
        max: '',
        interval: ''
      },
      scatterYAxis: {
        show: true,
        unit: '',
        nameTextStyle: {
          fontFamily: '微软雅黑',
          color: '#000000',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        },
        axisLine: {
          lineStyle: {
            type: 'solid',
            width: 1,
            color: '#e7e6e6'
          }
        },
        min: '',
        max: '',
        interval: ''
      }
    }
  },
  {
    id: 'chart-radar',
    componentName: 'chart',
    title: { name: '雷达图' },
    configTabs: [
      { key: 'indexOptionsRadar', title: '指标' },
      { key: 'legendLayoutRadar', title: '图例&布局' },
      { key: 'radarAxisLine', title: '轴线' },
      { key: 'radarSettings', title: '图形设置' }
    ],
    contentOption: {
      colors: [
        '#ff0000',
        '#2e75b6',
        '#a6a6a6',
        '#292929',
        '#5b9bd5',
        '#ffafaf',
        '#e46c0a',
        '#0606eb'
      ],
      data: [],
      originData: [],
      dateList: [],
      indexOptionsRadar: {
        list: [
          {
            checked: true,
            indicatorName: '名称',
            indexCode: ''
          }
        ],
        textStyle: {
          fontFamily: '微软雅黑',
          color: '#666666',
          fontSize: 12,
          fontWeight: 'bold',
          fontStyle: 'normal',
          textDecoration: 'none'
        }
      },
      legendLayoutRadar: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },
        legend: {
          autoChecked: false,
          updateRuleType: 'newDate',
          dates: [],
          newDate: '',
          qoQDate: '',
          yoYDate: '',
          textStyle: {
            fontFamily: '微软雅黑',
            fontSize: 12,
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none'
          },
          position: 'top'
        }
      },
      radarAxisLine: {
        lineStyleType: 'solid',
        lineStyleWidth: 1,
        color: '#ccc',
        min: '',
        max: '',
        splitNumber: 5,
        mark: '1'
      },
      radarSettings: [
        {
          checked: true,
          xAxisValue: '',
          lineStyleType: 'solid',
          lineStyleWidth: 1,
          itemColor: '#2e75b6',
          dataFormat: 'slash',
          dataFrequency: 'YMD'
        }
      ]
    }
  },
  {
    id: 'sequence-table',
    componentName: 'table',
    title: { name: '序列表' },
    configTabs: [
      { key: 'indexOptionsTable', title: '指标' },
      { key: 'layoutTable', title: '布局' }
    ],
    contentOption: {
      indexOptionsTable: [
        {
          checked: false,
          disabled: false,
          data: [],
          dateList: [],
          legendName: '',
          indexCode: ''
        }
      ],
      layoutTable: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },
        showTranspose: false, //行列转置
        textStyle: {
          fontFamily: '微软雅黑',
          color: '#000000',
          fontSize: 14,
          fontWeight: 'normal',
          fontStyle: 'normal',
          textDecoration: 'none',
          textAlign: 'center',
          whiteSpace: 'normal',
          lineHeight: 14,
          backgroundColor: ''
        }
      },
      filters: [],
      isTimeFilter: false
    },
    tableData: []
  },
  {
    id: 'free-table',
    componentName: 'table',
    title: { name: '自由表' },
    configTabs: [
      { key: 'indexOptionsTable', title: '指标' },
      { key: 'layoutTable', title: '布局' }
    ],
    contentOption: {
      indexOptionsTable: [
        {
          checked: false,
          disabled: false,
          data: [],
          dateList: [],
          legendName: '',
          frequency: '',
          isDerive: '',
          decimalPlaces: ''
        }
      ],
      layoutTable: {
        titleFont: {
          headerTitle: {
            show: true,
            name: '单位',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          },
          footerTitle: {
            show: true,
            name: '数据来源：',
            fontFamily: '微软雅黑',
            fontWeight: 'bold',
            fontStyle: 'normal',
            textDecoration: 'none',
            textAlign: 'left',
            fontSize: 12
          }
        },
        showTranspose: false, //行列转置
        textStyle: {
          fontFamily: '微软雅黑',
          color: '#000000',
          fontSize: 12,
          fontWeight: 'normal',
          fontStyle: 'normal',
          textDecoration: 'none',
          textAlign: 'center',
          whiteSpace: 'normal',
          lineHeight: 14,
          backgroundColor: ''
        }
      },
      filters: [],
      isTimeFilter: false
    },
    tableData: []
  }
]

//图表选择图标icon
export const DIAGRAM_ICON_LIST = [
  [
    { id: 'bar-line', iconName: 'icon-bar-line', permit: 'sjzx:sjk:zxt' },
    { id: 'chart-pie', iconName: 'icon-chart-pie', permit: 'sjzx:sjk:bt' },
    { id: 'chart-radar', iconName: 'icon-chart-radar', permit: 'sjzx:sjk:ldt' },
    { id: 'scatter-plot', iconName: 'icon-scatter-plot', permit: 'sjzx:sjk:sdt' }
  ],
  [
    { id: 'sequence-table', iconName: 'icon-sequence-table', permit: 'sjzx:sjk:xlb' },
    { id: 'free-table', iconName: 'icon-free-table', permit: 'sjzx:sjk:zyb' }
  ]
]
//图例颜色
export const COLORS: any = [
  '#ff0000',
  '#2e75b6',
  '#a6a6a6',
  '#292929',
  '#5b9bd5',
  '#ffafaf',
  '#e46c0a',
  '#0606eb'
]
// 日期格式类型
export const DATA_FORMAT_LIST = [
  { label: '2022/01/01', value: 'slash' },
  { label: '2022-01-01', value: 'cross' },
  { label: '2022年01月01日', value: 'word' }
]
// 数据频度类型
export const DATA_FREQUENCY_LIST = [
  { label: '年-月-日', value: 'YMD' },
  { label: '年-月', value: 'YM' },
  { label: '月-日', value: 'MD' },
  { label: '年', value: 'Y' },
  { label: '月', value: 'M' }
]

//雷达图更新规则
export const RADAR_OPTIONS = [
  {
    value: 'newDate',
    label: '最新值'
  },
  {
    value: 'newDate,qoQDate',
    label: '最新值、环比'
  },
  {
    value: 'newDate,qoQDate,yoYDate',
    label: '最新值、环比、同比'
  }
]
//坐标轴枚举
export const AXIS_ARR = [
  {
    label: '横轴',
    value: 'x'
  },
  {
    label: '纵轴',
    value: 'y'
  }
]

//折线柱状图chart类型切换
export const CHART_TYPE_ARR = [
  { type: 'line', name: '折线图' },
  { type: 'area', name: '面积图' },
  { type: 'bar', name: '柱状图' },
  { type: 'stacking', name: '堆积图' },
  { type: 'percentageStacking', name: '百分比堆积图' }
]
//字体类型
export const FONT_FAMILY_LIST = ['微软雅黑', '楷体', '宋体', '黑体', '思源黑体CN', 'Tw Cen MT']

// border 类型
export const BORDER_TYPE = [
  { label: '实线', value: 'solid' },
  { label: '虚线', value: 'dashed' }
]

//图例位置
export const LEGEND_POSITION: any = {
  top: {
    orient: 'horizontal',
    x: 'center',
    y: 'top'
  },
  bottom: {
    orient: 'horizontal',
    x: 'center',
    y: 'bottom'
  },
  left: {
    orient: 'vertical',
    x: 'left',
    y: 'center'
  },
  right: {
    orient: 'vertical',
    x: 'right',
    y: 'center'
  }
}
export const MULTIPLE_LABEL = [
  { type: 'name', label: '名称', format: '{b}' },
  { type: 'data', label: '数值', format: '{c}' },
  { type: 'proportion', label: '占比', format: '{d}%' }
]
export const INIT_OBJ: any = {
  'bar-line': {
    checked: true,
    data: [],
    legendName: '',
    indexCode: '',
    type: 'line',
    lineStyleType: 'solid',
    lineStyleWidth: 2,
    barWidth: 10,
    itemColor: '#2e75b6',
    yAxisIndex: 0,
    isSeason: false,
    isLabel: false,
    labelPosition: 'top'
  },
  'chart-pie': {
    checked: true,
    disabled: false,
    data: 1048,
    legendName: '',
    indexCode: '',
    itemColor: '#2e75b6'
  },
  'scatter-plot': {
    checked: true,
    legendName: '',
    labelName: '',
    data: '',
    indexCode: '',
    symbolSize: 10,
    itemColor: '#2e75b6',
    relatedIndexCode: '',
    axis: 'x'
  },
  'chart-radar': {
    list: [
      {
        checked: true,
        indicatorName: '名称',
        indexCode: ''
      }
    ],
    textStyle: {
      fontFamily: '微软雅黑',
      color: '#666666',
      fontSize: 12,
      fontWeight: 'bold',
      fontStyle: 'normal',
      textDecoration: 'none'
    }
  },
  'sequence-table': {
    checked: false,
    disabled: false,
    data: [],
    legendName: '',
    indexCode: '',
    calculation: {}
  },
  'free-table': {
    checked: false,
    disabled: false,
    data: [],
    legendName: '',
    indexCode: '',
    calculation: {}
  },
  yAxis: {
    show: true,
    name: '',
    unit: '',
    nameTextStyle: {
      fontFamily: '微软雅黑',
      color: '#000000',
      fontSize: 12,
      fontWeight: 'bold',
      fontStyle: 'normal',
      textDecoration: 'none'
    },
    axisLine: {
      lineStyle: {
        type: 'solid',
        width: 1,
        color: '#e7e6e6'
      }
    },
    offset: 0,
    inverse: false,
    min: '',
    max: '',
    interval: '',
    position: 'left'
  }
}
//layoutType
export const LAYOUT_TYPE: any = {
  'bar-line': 'legendLayout',
  'chart-pie': 'legendLayoutPie',
  'sequence-table': 'layoutTable',
  'free-table': 'layoutTable',
  'scatter-plot': 'legendLayoutScatter',
  'chart-radar': 'legendLayoutRadar'
}

export const changeTypeArr = [
  {
    name: '百分比变化',
    val: 0
  },
  {
    name: '数值变化',
    val: 1
  }
]

export const changeOptionArr = [
  {
    name: '同比',
    val: 'yoy'
  },
  {
    name: '环比',
    val: 'qoq'
  }
]

export const typeArr = [
  {
    name: '滚动求和',
    val: 1
  },
  {
    name: '累计值',
    val: 2
  },
  {
    name: '累计平均值',
    val: 3
  }
]
