/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 14:51:55
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-04 14:35:09
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  /* 获取多个指标数据曲线图 */
  diagramMultiData: {
    method: 'post',
    url: '/database/data/diagramMultiData'
  },
  /* 获取多个指标的最新一条数据即 散点图、饼状图 */
  diagramMultiNewestData: {
    method: 'post',
    url: '/database/data/diagramMultiNewestData'
  },
  /* 获取多个指标的最新一条数据即雷达图 */
  diagramMultiDataRadar: {
    method: 'post',
    url: '/database/data/diagramMultiData2'
  },
  /* 获取单个指标的季节性分析 */
  diagramGroupYearData: {
    method: 'post',
    url: '/database/data/diagramGroupYearData'
  },
  // 自由表或序列表计算公式
  getTableIndexData: {
    method: 'post',
    url: '/database/data/getIndexData'
  },
  // 新增图表
  addChart: {
    method: 'post',
    url: '/database/chart/addChart'
  },
  // 新增图表
  updateChart: {
    method: 'post',
    url: '/database/chart/updateChart'
  },
  // 查询图表
  queryChart: {
    method: 'post',
    url: '/database/chart/info'
  }
}

export default request(apiMap)
