/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-26 16:26:03
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-13 17:09:42
 * @Description:表格功能
 */
import { bus } from '@mysteel-standard/utils'
import { cloneDeep } from 'lodash-es'
export default () => {
  //添加右侧数据筛选器
  const addFilters = (filter: any) => {
    bus.emit('update-content-option', {
      filter: [filter]
    })
    bus.emit('change-table-filters', [filter])
  }

  //添加时间筛选器
  const addTimeFilter = (isTimeFilter: boolean, contentOption: any) => {
    let obj = {}
    if (isTimeFilter) {
      // 覆盖数据刷选器和计算公式
      const indexOptionsTable = cloneDeep(contentOption.indexOptionsTable || [])
      indexOptionsTable.forEach((item: { checked: any; calculation: {} }) => {
        if (item.checked) {
          item.calculation = {}
        }
      })
      obj = {
        isTimeFilter,
        filters: [],
        indexOptionsTable
      }
    } else {
      obj = { isTimeFilter }
    }
    bus.emit('update-content-option', obj)
    bus.emit('change-table-timeFilter', isTimeFilter)
  }

  //选中单元格右侧属性返显
  const updateLayoutTable = ({
    indexItem,
    itemStyle,
    filters,
    isTimeFilter,
    contentOption
  }: any) => {
    const indexOptionsTable = cloneDeep(contentOption.indexOptionsTable || [])
    indexOptionsTable.forEach((item: any) => {
      if (!indexItem.indexCode) {
        item.checked = false
      } else {
        if (item.indexCode == indexItem.indexCode) {
          item.checked = true
          item.calculation = indexItem.calculation
          item.calculationParams = indexItem.calculationParams
        } else {
          item.checked = false
        }
      }
    })
    bus.emit('update-content-option', {
      indexOptionsTable,
      filters,
      isTimeFilter,
      layoutTable: {
        ...contentOption.layoutTable,
        textStyle: itemStyle
      }
    })
  }

  //指标删除
  const handleDeleteIndex = (contentOption: any) => {
    const list = cloneDeep(contentOption.indexOptionsTable || [])
    list.forEach((item: { checked: boolean }) => (item.checked = false))
    //移除指标信息
    bus.emit('change-table-data', null)
    bus.emit('update-content-option', {
      indexOptionsTable: list
    })
  }
  //指标计算删除
  const handleDeleteCal = (contentOption: any) => {
    const indexOptionsTable = cloneDeep(contentOption.indexOptionsTable || [])
    indexOptionsTable.map((item: { checked: any; calculation: {}; calculationParam: {} }) => {
      if (item.checked) {
        item.calculation = {}
        item.calculationParam = {}
        bus.emit('change-table-data', cloneDeep(item))
      }
    })
    bus.emit('update-content-option', {
      indexOptionsTable
    })
  }
  //时间选择器移除
  const handleDeleteTime = () => {
    bus.emit('update-content-option', {
      isTimeFilter: false
    })
    bus.emit('change-table-timeFilter', false)
  }
  // 更新数据源回调
  const updateTableCells = (data: any[], matrixData: any) => {
    if (!Array.isArray(data) || !data.length) return
    const cloneData = cloneDeep(data)
    matrixData.splice(0, matrixData.length, ...cloneData)
    bus.emit('update-table-data', matrixData)
  }
  //转置
  const transformTable = (matrixData: any) => {
    if (matrixData.length) {
      const cloneData = cloneDeep(matrixData)
      let transData = []
      transData = cloneData[0].map((col: any, i: number) => [
        ...cloneData.map((row: { [x: string]: any }) => row[i])
      ])
      matrixData.splice(0, matrixData.length, ...cloneDeep(transData))
    }
  }

  //表格插入指标数据 修改表格的时间筛选器
  const changeTableData = (
    { indexData, matrixData, selectedCells, isTimeFilter }: any,
    flag: boolean
  ) => {
    const indexItem = cloneDeep(indexData)
    const dateList = indexData?.dateList || []
    const data = indexData?.data || []
    selectedCells.value.forEach((cell: string) => {
      const rowIndex = cell.split('_')[0]
      const colIndex = cell.split('_')[1]
      const cellData = matrixData[rowIndex][colIndex]
      cellData.isTimeFilter = isTimeFilter
      if (indexData === null) {
        cellData.indexItem = {}
      } else {
        indexItem.data = []
        indexItem.dateList = []
        //判断添加指标还是时间筛选器
        if (flag) cellData.indexItem = indexItem
        //覆盖数据刷选器和计算公式
        if (isTimeFilter) {
          //只有包含指标的单元格可以刷新时间
          if (cellData.indexItem && cellData.indexItem.indexCode !== '') {
            cellData.filters = []
            const lastNum = dateList.length - 1
            //多选时填充数据
            cellData.text = dateList.length ? dateList[lastNum] || '--' : cellData.text
          }
        } else {
          //移除时间筛选器 文本还原
          const calculationData = indexItem.calculation.value
          const allData = calculationData !== undefined ? calculationData : data || []
          const lastNum = allData.length - 1
          cellData.text = allData[lastNum] || '--'
        }
      }
    })
  }

  //修改表格的数据筛选器
  const changeTableFilters = ({ filters, matrixData, selectedCells }: any) => {
    selectedCells.value.forEach((cell: string) => {
      const rowIndex = cell.split('_')[0]
      const colIndex = cell.split('_')[1]
      if (filters.length) {
        matrixData[rowIndex][colIndex].filters = filters
      } else {
        matrixData[rowIndex][colIndex].filters = []
      }
    })
  }

  //修改表格的样式
  const changeTableStyle = ({ itemStyle, matrixData, selectedCells }: any) => {
    selectedCells.value.forEach((cell: string) => {
      const rowIndex = cell.split('_')[0]
      const colIndex = cell.split('_')[1]
      matrixData[rowIndex][colIndex].itemStyle = {
        ...matrixData[rowIndex][colIndex].itemStyle,
        ...itemStyle
      }
    })
  }
  return {
    addFilters,
    addTimeFilter,
    updateLayoutTable,
    handleDeleteIndex,
    handleDeleteTime,
    handleDeleteCal,
    updateTableCells,
    transformTable,
    changeTableData,
    changeTableFilters,
    changeTableStyle
  }
}
