export default () => {
  const handleReverse = ({
    matrixData,
    indexData: { data, dateList, calculation },
    selectedCells: [row, col],
    isTimeFilter,
    showTranspose
  }: any) => {
    // 回显需截取数据 0
    const newData = data.slice(-matrixData.length)
    const newDateList = dateList.slice(-matrixData.length)
    const x = Number(row)
    const y = Number(col)
    const length = showTranspose ? matrixData[0].length : matrixData.length
    const startNum = showTranspose ? y : x
    let _row, _col
    for (let i = startNum; i < length; i++) {
      // 行列转置坐标轴需调整
      _row = showTranspose ? x : i
      _col = showTranspose ? i : y
      if (isTimeFilter) {
        matrixData[_row][_col].text = newDateList[i] || '--'
      } else {
        const text = newData[i] ? String(newData[i]) : '--'
        let calculationVal = null
        if (calculation.value) {
          calculationVal = calculation.value[i] == null ? '--' : calculation.value[i]
        }
        matrixData[_row][_col].text =
          calculation.value && calculationVal ? String(calculationVal) : text
      }
    }
  }

  // Transpose
  const setTransposeSequence = ({
    matrixData,
    indexData: { data, dateList, calculation },
    selectedCells: [row, col],
    isTimeFilter,
    direction
  }: any) => {
    const startNum = +col + 1
    const len = data.length
    if (direction === 'descend') {
      // 倒序排列
      handleReverse({
        matrixData,
        indexData: { data, dateList, calculation },
        selectedCells: [row, col],
        isTimeFilter,
        showTranspose: true
      })
    } else {
      for (let i = startNum, lastNum = len - 2; i < matrixData[row].length; i++) {
        if (isTimeFilter) {
          matrixData[row][i].text = dateList[lastNum] || '--'
        } else {
          const text = data[lastNum] ? String(data[lastNum]) : '--'
          let calculationVal = null
          if (calculation.value) {
            const calculationIndex = calculation.value.length - (len - lastNum)
            calculationVal =
              calculation.value[calculationIndex] == null
                ? '--'
                : calculation.value[calculationIndex]
          }

          matrixData[row][i].text =
            calculation.value && calculationVal ? String(calculationVal) : text
        }
        lastNum--
      }
    }
  }
  const setUnTransposeSequence = ({
    matrixData,
    indexData: { data, dateList, calculation },
    selectedCells: [row, col],
    isTimeFilter,
    direction
  }: any) => {
    const startNum = +row + 1
    const len = data.length
    if (direction === 'descend') {
      // 倒序
      handleReverse({
        matrixData,
        indexData: { data, dateList, calculation },
        selectedCells: [row, col],
        isTimeFilter,
        showTranspose: false
      })
    } else {
      for (let i = startNum, lastNum = len - 2; i < matrixData.length; i++) {
        if (isTimeFilter) {
          matrixData[i][col].percent = false
          matrixData[i][col].text = dateList[lastNum] || '--'
        } else {
          const text = data[lastNum] ? String(data[lastNum]) : '--'
          let calculationVal = null
          if (calculation.value) {
            const calculationIndex = calculation.value.length - (len - lastNum)
            calculationVal =
              calculation.value[calculationIndex] == null
                ? '--'
                : calculation.value[calculationIndex]
          }
          matrixData[i][col].text =
            calculation.value && calculationVal ? String(calculationVal) : text
          matrixData[i][col].dataValue = matrixData[i][col].text
        }
        lastNum--
      }
    }
  }

  const judgeSequenceParams = (params: any) => {
    const { data } = params.indexData || {}
    if (!Array.isArray(params.matrixData) || !Array.isArray(data)) return
    return (fn: Function) => {
      fn(params)
    }
  }

  const updateSequenceTable = (
    curEl: any,
    { matrixData, indexData, selectedCells, isTimeFilter }: any
  ) => {
    if (curEl.id === 'sequence-table') {
      const setSequenceBefore = judgeSequenceParams({
        matrixData,
        indexData,
        selectedCells,
        isTimeFilter,
        direction: curEl.direction || ''
      })
      if (typeof setSequenceBefore !== 'function') return
      if (curEl.contentOption.layoutTable.showTranspose) {
        setSequenceBefore(setTransposeSequence)
      } else {
        setSequenceBefore(setUnTransposeSequence)
      }
    }
  }

  return {
    updateSequenceTable
  }
}
