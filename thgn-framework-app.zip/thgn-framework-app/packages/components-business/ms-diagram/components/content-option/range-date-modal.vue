<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-01 13:31:03
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-08 18:42:56
 * @Description: 数据范围选择弹窗
-->
<template>
  <gl-input
    v-model:value="calendarDesc"
    placeholder="请选择时间范围"
    class="wid-240"
    @click="openCalendarSetting"
  >
    <template #prefix>
      <icon name="icon-date_picker" class="icon" />
    </template>
  </gl-input>
  <!-- 日历组件 日期设置 -->
  <date-set-modal
    v-if="dateSetVisible"
    :dateSetForm="calendarState"
    v-model:dateSetVisible="dateSetVisible"
    dateSetTitle="设置日期"
    @set-date-ok="saveDateSet"
    :disabledDate="disabledDate"
  />
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { DateSetModal } from '../../../index'
import { useResetData } from '@mysteel-standard/hooks'
import moment from 'moment'
import { bus } from '@mysteel-standard/utils'
//props
interface Props {
  contentOption: any
  seasonChecked: boolean
}
const props = withDefaults(defineProps<Props>(), {
  seasonChecked: false
})

//默认数据范围
const rangeDate = computed(() => {
  return props.contentOption.xAxis.rangeDate
})

//打开数据范围选择弹窗
const dateSetVisible = ref(false)
//日期设置
const { dataState: calendarState } = useResetData(rangeDate.value)

const disabledDate = (current: any) => {
  if (props.seasonChecked) {
    const timeYear = current.get('year') //当前年
    const currentYear = moment().format('YYYY') //今年
    return timeYear != currentYear
  }
  return false
}

const openCalendarSetting = () => {
  dateSetVisible.value = true
}

// 保存高级设置
const calendarDesc = ref('')
const setClendarDesc = (data: any) => {
  const { intervalType, beginTime, endTime } = data
  const timeCount = intervalType === 1 ? data.timeCount : ''
  const timeType = intervalType === 1 ? data.timeType : ''
  if (beginTime || endTime) {
    calendarDesc.value = `${beginTime}~${endTime}`
  }
  if (intervalType === 1) {
    calendarDesc.value = '最后' + timeCount + timeType
  }
  if (intervalType === 2) {
    if (beginTime || endTime) {
      calendarDesc.value =
        beginTime + (!beginTime || !endTime ? ' 至 ' : ' ~ ') + (endTime ? endTime : '至今')
    }
  }
}

const saveDateSet = (data: any) => {
  setClendarDesc(data)
  dateChange({
    intervalType: data.intervalType,
    dateType: data.dateType,
    timeCount: data.timeCount,
    timeType: data.timeType,
    beginTime: data.beginTime,
    endTime: data.endTime
  })
}

const dateChange = (rangeDate: any) => {
  const xAxis = { ...props.contentOption.xAxis, rangeDate }
  bus.emit('update-content-option', { ...props.contentOption, xAxis })
  bus.emit('date-update', rangeDate)
}

onMounted(() => {
  setClendarDesc(rangeDate.value)
})
</script>

<style lang="scss" scoped></style>
