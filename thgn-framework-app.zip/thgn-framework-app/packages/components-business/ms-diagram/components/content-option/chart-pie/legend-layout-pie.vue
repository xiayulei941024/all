<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-06-27 14:58:24
 * @Description: 指标chart配置
-->
<template>
  <div class="legend-layout-pie">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="标题" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.headerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="页脚" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.footerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="字体">
        <font-collection v-model:font="form.textStyle" :show-color="false" />
      </gl-form-item>
      <gl-form-item label="位置">
        <position-radio v-model:value="form.position" />
      </gl-form-item>
    </gl-form>
  </div>
</template>
<script lang="ts" setup>
import FontCollection from '../font-collection.vue'
import PositionRadio from '../position-radio.vue'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const form = computed(() => props.contentOption.legendLayoutPie)
</script>
<style lang="scss" scoped>
.legend-layout-pie {
  padding-left: 44px;
}
</style>
