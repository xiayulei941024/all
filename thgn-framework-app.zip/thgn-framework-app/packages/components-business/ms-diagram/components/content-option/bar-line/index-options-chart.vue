<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-13 17:24:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-16 10:07:30
 * @Description:图表模块-图形指标模块配置内容
-->
<template>
  <div class="index-options-chart">
    <gl-collapse expand-icon-position="left" :bordered="false" v-model:activeKey="collapseKey">
      <template #expandIcon="{ isActive }">
        <caret-right-outlined :rotate="isActive ? 90 : 0" />
      </template>
      <gl-collapse-panel v-for="(item, index) in indexList" :key="index" v-show="!disabledAll">
        <template #header>
          <span @click.stop="() => {}">
            <gl-checkbox v-model:checked="item.checked" :disabled="disabledAll"></gl-checkbox>
          </span>
          <gl-tooltip placement="top" :title="item.legendName" trigger="hover">
            <span class="option-collapse-title ellipsis"> {{ item.legendName }}</span>
          </gl-tooltip>
        </template>
        <gl-form
          :model="item"
          :colon="false"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 18 }"
          label-align="left"
        >
          <gl-form-item label="图例名称">
            <gl-input
              v-model:value="item.legendName"
              placeholder="请输入图例名称"
              :disabled="disabledAll"
            />
          </gl-form-item>
          <gl-form-item label="图例类型">
            <gl-select
              v-model:value="item.type"
              placeholder="请选择图例类型"
              :disabled="disabledAll"
              @change="changeChartType($event, item)"
            >
              <gl-select-option
                v-for="typeItem in typeArr"
                :key="typeItem.type"
                :value="typeItem.type"
                >{{ typeItem.name }}</gl-select-option
              >
            </gl-select>
          </gl-form-item>
          <gl-form-item
            v-if="
              item.type !== 'bar' || item.type !== 'stacking' || item.type !== 'percentageStacking'
            "
            label="线型"
          >
            <gl-select
              v-model:value="item.lineStyleType"
              placeholder="请选择线型"
              :disabled="disabledAll"
            >
              <gl-select-option
                v-for="styleItem in lineStyleTypeArr"
                :key="styleItem.value"
                :value="styleItem.value"
                >{{ styleItem.label }}</gl-select-option
              >
            </gl-select>
          </gl-form-item>
          <gl-form-item
            v-show="
              item.type !== 'bar' || item.type !== 'stacking' || item.type !== 'percentageStacking'
            "
            label="宽度"
          >
            <gl-input-number
              v-model:value="item.lineStyleWidth"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入数字"
              :disabled="disabledAll"
            />
          </gl-form-item>
          <gl-form-item
            v-show="
              item.type === 'bar' || item.type === 'stacking' || item.type === 'percentageStacking'
            "
            label="宽度"
          >
            <gl-input-number
              v-model:value="item.barWidth"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入数字"
              :disabled="disabledAll"
              style="width: 100%"
            />
          </gl-form-item>
          <gl-form-item label="颜色">
            <color-input v-model:value="item.itemColor" :disabled="disabledAll" />
          </gl-form-item>
          <gl-form-item label="坐标轴">
            <gl-select
              v-model:value="item.yAxisIndex"
              placeholder="请选择图坐标轴"
              :disabled="disabledAll || item.isDisabledForPercentageStack"
            >
              <gl-select-option
                v-for="IndexItem in yAxisIndexArr"
                :key="IndexItem.id"
                :value="IndexItem.id"
                >{{ IndexItem.name }}</gl-select-option
              >
            </gl-select>
          </gl-form-item>
          <gl-form-item>
            <gl-checkbox v-model:checked="item.isSeason" @change="changeSeason($event, item, index)"
              >季节性分析</gl-checkbox
            >
          </gl-form-item>
          <gl-form-item>
            <gl-checkbox v-model:checked="item.isLabel" @change="changeLabel(item, index)">
              显示数据标签</gl-checkbox
            >
            <gl-select
              v-model:value="item.labelPosition"
              style="width: 80px"
              :disabled="
                !item.isLabel || item.type == 'stacking' || item.type == 'percentageStacking'
              "
              @change="changeLabel(item, index)"
            >
              <gl-select-option value="top">顶部</gl-select-option>
              <gl-select-option value="inside">居中</gl-select-option>
              <gl-select-option v-if="item.type === 'bar'" value="insideBottom"
                >底部</gl-select-option
              >
              <gl-select-option v-else value="bottom">底部</gl-select-option>
            </gl-select>
          </gl-form-item>
        </gl-form>
      </gl-collapse-panel>
    </gl-collapse>
    <div v-show="disabledAll" class="season-options">
      <gl-checkbox
        :checked="true"
        style="margin-bottom: 10px; margin-left: 20px"
        @click="closeSeason()"
        >季节性分析</gl-checkbox
      >
      <gl-collapse
        v-model:activeKey="seasonCollapseKey"
        accordion
        expand-icon-position="left"
        :bordered="false"
        class="my-collapse"
      >
        <template #expandIcon="{ isActive }">
          <caret-right-outlined :rotate="isActive ? 90 : 0" />
        </template>
        <gl-collapse-panel key="seasonOptions" header="年度设置">
          <gl-collapse
            v-for="(item, index) in indexDataSeasonReverse"
            :key="index"
            v-model:activeKey="seasonListCollapseKey"
            accordion
            expand-icon-position="left"
            :bordered="false"
          >
            <template #expandIcon="{ isActive }">
              <caret-right-outlined :rotate="isActive ? 90 : 0" />
            </template>
            <gl-collapse-panel :key="index">
              <template #header>
                <span @click.stop="() => {}">
                  <gl-checkbox
                    v-model:checked="seasonOptionsConfig[item.legendName].checked"
                  ></gl-checkbox>
                </span>
                <gl-tooltip placement="top" :title="item.legendName" trigger="hover">
                  <span class="option-collapse-title ellipsis"> {{ item.legendName }}</span>
                </gl-tooltip>
              </template>
              <gl-form
                :colon="false"
                :model="seasonOptionsConfig[item.legendName]"
                :rules="rules"
                :label-col="{ span: 5 }"
                :wrapper-col="{ span: 18 }"
              >
                <gl-form-item name="name" label="名称">
                  <gl-input
                    v-model:value="seasonOptionsConfig[item.legendName].name"
                    :disabled="!seasonOptionsConfig[item.legendName].checked"
                    :maxlength="100"
                    class="wid-240"
                  />
                </gl-form-item>
                <gl-form-item label="颜色">
                  <color-input
                    v-model:value="seasonOptionsConfig[item.legendName].itemColor"
                    :disabled="!seasonOptionsConfig[item.legendName].checked"
                    class="wid-240"
                  />
                </gl-form-item>

                <gl-form-item label="线型">
                  <gl-select
                    v-model:value="seasonOptionsConfig[item.legendName].lineStyleType"
                    :disabled="!seasonOptionsConfig[item.legendName].checked"
                    class="wid-240"
                    placeholder="请选择线型"
                  >
                    <gl-select-option
                      v-for="styleItem in lineStyleTypeArr"
                      :key="styleItem.value"
                      :value="styleItem.value"
                      >{{ styleItem.label }}</gl-select-option
                    >
                  </gl-select>
                </gl-form-item>
                <gl-form-item label="线宽">
                  <gl-input-number
                    v-model:value="seasonOptionsConfig[item.legendName].lineStyleWidth"
                    :disabled="!seasonOptionsConfig[item.legendName].checked"
                    class="wid-240"
                    :min="1"
                    :max="50"
                    :step="1"
                    :precision="0"
                    placeholder="请输入数字"
                  />
                </gl-form-item>
              </gl-form>
            </gl-collapse-panel>
          </gl-collapse>
        </gl-collapse-panel>
      </gl-collapse>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { bus } from '@mysteel-standard/utils'
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { CHART_TYPE_ARR, BORDER_TYPE } from '../../../constants'
import { ColorInput } from '@mysteel-standard/components'
import { message } from 'gl-design-vue'
//props
interface Props {
  contentOption: any
  seasonChecked: boolean
  activeKey: string
  indexDataSeason: any
}
const props = withDefaults(defineProps<Props>(), {
  seasonChecked: false,
  activeKey: '0'
})
//emits
interface Emits {
  (e: 'change-season', val: Object): void
  (e: 'change-chart-type', val: Object): void
  (e: 'update:activeKey', val: Object): void
}
const emits = defineEmits<Emits>()
//选中指标
const collapseKey = computed({
  get() {
    return props.activeKey
  },
  set(val) {
    emits('update:activeKey', val)
  }
})
const yAxisIndexArr = computed(() =>
  props.contentOption.yAxis.map((item: { name: string }, i: number) => ({
    id: i,
    name: item.name || `轴${i + 1}`
  }))
)
//选择框 参数图例类型
const typeArr = CHART_TYPE_ARR
//选择框 参数线型
const lineStyleTypeArr = BORDER_TYPE
const disabledAll = ref(false)
const seasonCollapseKey = ref('seasonOptions')
const seasonListCollapseKey = ref('0')
//监听是否是季节性图例
watchEffect(() => {
  disabledAll.value = props.seasonChecked
})

//改变图例类型
const changeChartType = (
  type: string | Object,
  item: { labelPosition: string; isDisabledForPercentageStack: boolean }
) => {
  if (type === 'stacking' || type === 'percentageStacking') {
    item.labelPosition = 'inside'
  }
  if (type === 'bar') {
    if (item.labelPosition === 'bottom') {
      item.labelPosition = 'insideBottom'
    }
  } else {
    if (item.labelPosition === 'insideBottom') {
      item.labelPosition = 'bottom'
    }
  }
  item.isDisabledForPercentageStack = type === 'percentageStacking'
  emits('change-chart-type', type)
}

const indexList = computed({
  get() {
    const listCopy = props.contentOption.indexOptionsBarLine
    for (const i in listCopy) {
      listCopy[i].isDisabledForPercentageStack = listCopy[i].type === 'percentageStacking'
    }
    return props.contentOption.indexOptionsBarLine
  },
  set(val) {
    bus.emit('update-content-option', {
      indexOptionsBarLine: val
    })
  }
})

const changeSeason = (event: { target: { checked: boolean } }, item: any, index: number) => {
  if (['年度', '半年度'].includes(item?.frequency)) {
    message.warn('年度与半年度数据无法进行季节性分析！')
    item.isSeason = false
    return
  }
  if (event.target.checked) {
    disabledAll.value = true
    indexList.value.forEach((data: { checked: boolean }, i: number) => {
      data.checked = false
      if (i == index) {
        data.checked = true
      }
    })
  } else {
    disabledAll.value = false
    indexList.value.forEach((data: { checked: boolean }) => {
      data.checked = true
    })
  }
  emits('change-season', {
    checked: event.target.checked,
    item,
    index
  })
}

//标签位置
const changeLabel = (item: { isSeason: boolean }, index: number) => {
  if (item.isSeason) {
    emits('change-season', {
      checked: item.isSeason,
      item,
      index
    })
  }
}

// 季节性分析中-关闭
const closeSeason = () => {
  disabledAll.value = false
  indexList.value.forEach((data: { checked: boolean; isSeason: boolean }) => {
    data.checked = true
    data.isSeason = false
  })
  emits('change-season', {
    checked: false
  })
}

const indexDataSeasonReverse = computed(() => {
  const arr = JSON.parse(JSON.stringify(props.indexDataSeason))
  if (JSON.stringify(props.contentOption.seasonOptions) !== '{}') {
    return arr.reverse()
  } else {
    return []
  }
})

const seasonOptionsConfig = computed(() => props.contentOption.seasonOptions)

const checkName = async (value: any) => {
  const arr = Object.values(seasonOptionsConfig.value).filter((item: any) => item.name === value)
  if (arr?.length >= 2) {
    return Promise.reject(new Error('已有相同名称！'))
  }
  return Promise.resolve()
}

const rules: any = {
  name: [{ trigger: ['change', 'blur'], validator: checkName }]
}
</script>
<style lang="scss" scoped>
.index-options-chart {
  .option-collapse-title {
    display: inline-block;
    max-width: 300px;
    vertical-align: middle;
    margin-left: 8px;
  }
}
</style>
