<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-07-08 13:22:31
 * @Description: 指标chart配置
-->
<template>
  <div class="y-axis">
    <gl-collapse
      accordion
      expand-icon-position="left"
      :bordered="false"
      v-model:activeKey="collapseKey"
    >
      <template #expandIcon="{ isActive }">
        <caret-right-outlined :rotate="isActive ? 90 : 0" />
      </template>
      <gl-collapse-panel v-for="(item, index) in list" :key="index" :header="item.name">
        <template #extra>
          <span @click.stop="() => {}">
            <gl-switch v-model:checked="item.show" size="small"></gl-switch>
          </span>
        </template>
        <gl-form
          :model="item"
          :colon="false"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 18 }"
          label-align="left"
        >
          <gl-form-item label="名称">
            <gl-input v-model:value="item.name" :maxlength="50" placeholder="请输入名称" />
          </gl-form-item>
          <gl-form-item label="单位">
            <gl-input v-model:value="item.unit" :maxlength="50" placeholder="请输入单位" />
          </gl-form-item>
          <gl-form-item label="字体">
            <font-collection v-model:font="item.nameTextStyle" />
          </gl-form-item>
          <gl-form-item label="线型">
            <gl-select v-model:value="item.axisLine.lineStyle.type" placeholder="请选择线型">
              <gl-select-option v-for="i in lineStyleTypeArr" :key="i.value" :value="i.value">{{
                i.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="宽度">
            <gl-input-number
              v-model:value="item.axisLine.lineStyle.width"
              :min="0"
              placeholder="请输入宽度"
            />
          </gl-form-item>
          <gl-form-item label="颜色">
            <color-input v-model:value="item.axisLine.lineStyle.color" />
          </gl-form-item>
          <gl-form-item label="最小值">
            <gl-input-number
              v-model:value="item.min"
              placeholder="请输入最小值"
              style="width: 100%"
            />
          </gl-form-item>
          <gl-form-item label="最大值">
            <gl-input-number v-model:value="item.max" placeholder="请输入最大值" />
          </gl-form-item>
          <gl-form-item label="数据步长">
            <gl-input-number v-model:value="item.interval" placeholder="最小单位" />
          </gl-form-item>
          <gl-form-item label="偏移距">
            <gl-input-number
              v-model:value="item.offset"
              :min="0"
              placeholder="请输入Y轴之间偏移距"
            />
          </gl-form-item>
          <gl-form-item label="方向">
            <gl-radio-group v-model:value="item.inverse">
              <gl-radio-button v-for="(pos, i) in inverseArr" :key="i" :value="pos.value">
                {{ pos.label }}
              </gl-radio-button>
            </gl-radio-group>
          </gl-form-item>
          <gl-form-item label="位置">
            <gl-radio-group v-model:value="item.position">
              <gl-radio-button v-for="(pos, i) in posArr" :key="i" :value="pos.value">
                {{ pos.label }}
              </gl-radio-button>
            </gl-radio-group>
          </gl-form-item>
        </gl-form>
      </gl-collapse-panel>
    </gl-collapse>
    <div class="addY" @click="addYaxis">
      <icon name="add" />
      <span>新增轴线</span>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { bus } from '@mysteel-standard/utils'
import { cloneDeep } from 'lodash-es'
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { ColorInput } from '@mysteel-standard/components'
import FontCollection from '../font-collection.vue'
import { BORDER_TYPE, INIT_OBJ } from '../../../constants'
import { Icon } from '@mysteel-standard/components'
//props
interface Props {
  contentOption: any
  seasonChecked: boolean
  indexDataSeason: any
}
const props = withDefaults(defineProps<Props>(), {
  seasonChecked: false
})
//emits

const list: any = computed(() => props.contentOption.yAxis)
const lineStyleTypeArr = BORDER_TYPE
const posArr = [
  { value: 'left', label: '左轴' },
  { value: 'right', label: '右轴' }
]
const inverseArr = [
  { value: false, label: '正序' },
  { value: true, label: '逆序' }
]
const collapseKey = ref(0)
//添加轴
const addYaxis = () => {
  const y = cloneDeep(INIT_OBJ.yAxis)
  y.name = `轴${list.value.length + 1}`
  y.offset = 10 * list.value.length
  list.value.push(y)
}
</script>
<style lang="scss" scoped>
.y-axis {
  padding-left: 20px;
  .addY {
    width: 312px;
    height: 40px;
    background: rgba(0, 91, 172, 0.05);
    border-radius: 4px;
    border: 1px solid #005bac;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 14px;
    color: #005bac;
    cursor: pointer;
    margin: 0 auto 20px;
    span {
      margin-left: 6px;
    }
  }
}
</style>
