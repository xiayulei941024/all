<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-07-06 20:07:04
 * @Description: 表格布局 
-->
<template>
  <div class="table-options">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 18 }"
      label-align="left"
      class="table-layout-operation"
    >
      <gl-form-item label="标题" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.headerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="页脚" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.titleFont.footerTitle.show"
          class="f-r"
          size="small"
        ></gl-switch>
      </gl-form-item>
      <gl-form-item label="行列转置" label-align="right" :wrapper-col="{ span: 18 }">
        <gl-switch
          v-model:checked="form.showTranspose"
          class="f-r"
          size="small"
          @change="changeTrans"
        ></gl-switch>
      </gl-form-item>
      <gl-collapse
        accordion
        expand-icon-position="left"
        :bordered="false"
        v-model:activeKey="collapseKey"
      >
        <template #expandIcon="{ isActive }">
          <caret-right-outlined :rotate="isActive ? 90 : 0" />
        </template>
        <gl-collapse-panel key="text" header="文本">
          <gl-form-item label="字体">
            <font-collection v-model:font="form.textStyle" @change-style="changeStyle" />
          </gl-form-item>
          <gl-form-item label="位置">
            <text-align-radio
              v-model:value="form.textStyle.textAlign"
              @change-style="changeStyle"
            />
          </gl-form-item>
        </gl-collapse-panel>
        <gl-collapse-panel key="layout" header="格式">
          <gl-form-item label="行高" style="margin-bottom: 0">
            <gl-input-number
              v-model:value="form.textStyle.lineHeight"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入宽度"
              class="wid-240"
              @change="(value:number) => {changeStyle({ lineHeight: value })}"
            />
          </gl-form-item>
        </gl-collapse-panel>
        <gl-collapse-panel key="background" header="背景">
          <gl-form-item label="填充颜色">
            <color-input
              v-model:value="form.textStyle.backgroundColor"
              class="wid-240"
              @change-color="
                (val:string) => {
                  changeStyle({backgroundColor:val})
                }
              "
            />
          </gl-form-item>
        </gl-collapse-panel>
      </gl-collapse>
    </gl-form>
    <data-select :content-option="contentOption" />
  </div>
</template>

<script setup lang="ts">
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { ColorInput } from '@mysteel-standard/components'
import FontCollection from '../font-collection.vue'
import TextAlignRadio from './text-style/text-align-radio.vue'
import DataSelect from './filter-com/data-select.vue'
import { bus } from '@mysteel-standard/utils'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const collapseKey = ref('text')
const form = computed(() => props.contentOption.layoutTable)

//修改样式
const changeStyle = (style: any) => {
  bus.emit('change-table-style', style)
}

const updateFilters = (filters: any) => {
  bus.emit('update-content-option', {
    filters
  })
  bus.emit('change-table-filters', filters)
}
//行列转置
const changeTrans = (val: any) => {
  bus.emit('change-transpose', val)
}
</script>
<style scoped lang="scss">
.table-options {
  display: flex;
  flex-direction: column;
  height: 100%;

  .table-layout-operation {
    flex: 1;
    overflow-y: auto;
  }

  &-ul {
    padding: 10px 0;
    flex: 1;
    overflow-y: auto;

    &_item {
      padding: 0 10px;
      width: 100%;
      height: 40px;
      line-height: 40px;
      border-radius: 6px;
      font-size: 14px;
      overflow: hidden;
      text-overflow: ellipsis;
      cursor: pointer;

      &.active {
        background: #e5eff8;
        color: #005bac;
      }
    }
  }

  .data-select {
    height: 220px;

    .tab-title {
      width: 100%;
      height: 48px;
      line-height: 48px;
      font-size: 14px;
      text-align: center;
      font-weight: 500;
      color: #333333;
      background-color: #eeeeee;
      cursor: pointer;
    }
  }
}
</style>
