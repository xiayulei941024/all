<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-10 15:40:52
 * @Description: 数据筛选器
-->
<template>
  <div class="data-select">
    <header class="data-select-header tab-title">数据筛选器</header>
    <div class="info">
      <div v-if="filterList.length" class="drag-item">
        <div
          v-for="(item, index) in filterList"
          :key="index"
          class="title-item"
          :title="item.filterName"
        >
          <div class="text ellipsis" @click="handleEdit(item, index)">
            {{ item.filterName }}
          </div>
          <close-outlined @click="handleDelete(index)" />
        </div>
      </div>
    </div>
  </div>
  <filter-edit-dialog
    v-model:visible="filterVisible"
    title="编辑数据筛选器"
    :record="recordItem"
    @ok-cb="editFilter"
  />
</template>

<script setup lang="ts">
import { bus } from '@mysteel-standard/utils'
import { CloseOutlined } from '@ant-design/icons-vue'
import FilterEditDialog from './filter-edit-dialog.vue'
import { cloneDeep } from 'lodash-es'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const filterVisible = ref(false)
const active = ref(0)
const recordItem = ref({})
const filterList = computed({
  get() {
    return cloneDeep(props.contentOption.filters)
  },
  set() {}
})
//指标筛选器编辑
const handleEdit = (record: any, index: number) => {
  filterVisible.value = true
  active.value = index
  recordItem.value = cloneDeep(record)
}
const editFilter = (item: any) => {
  const list = cloneDeep(props.contentOption.filters)
  list[active.value] = item
  bus.emit('change-table-filters', list)
}
//指标筛选器删除
const handleDelete = (i: any) => {
  const list = cloneDeep(props.contentOption.filters)
  list.splice(i, 1)
  bus.emit('change-table-filters', list)
}
</script>

<style lang="scss" scoped>
.data-select {
  height: 220px;
  .tab-title {
    width: 100%;
    height: 48px;
    line-height: 48px;
    font-size: 14px;
    text-align: center;
    font-weight: 500;
    color: #333333;
    background-color: #eeeeee;
    cursor: pointer;
  }
  .info {
    padding: 20px;
    .drag-item {
      display: flex;
      .title-item {
        width: 100px;
        height: 28px;
        line-height: 28px;
        font-size: 14px;
        color: #005bac;
        border-radius: 14px;
        padding: 0 8px;
        background: #e5eff8;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-right: 12px;
        .text {
          cursor: pointer;
          width: 56px;
          margin-right: 8px;
        }
      }
    }
  }
}
</style>
