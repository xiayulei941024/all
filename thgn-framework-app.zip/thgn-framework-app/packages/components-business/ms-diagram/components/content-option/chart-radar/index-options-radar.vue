<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-17 14:00:34
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-03 16:15:39
 * @Description: 
-->
<template>
  <div class="index-options-radar">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 18 }"
      label-align="left"
    >
      <gl-collapse
        accordion
        expand-icon-position="left"
        :bordered="false"
        v-model:activeKey="collapseKey"
      >
        <template #expandIcon="{ isActive }">
          <caret-right-outlined :rotate="isActive ? 90 : 0" />
        </template>
        <gl-collapse-panel header="名称">
          <div
            v-for="(item, index) in form.list"
            :key="index"
            style="display: flex; align-items: center"
          >
            <gl-checkbox v-model:checked="item.checked" class="form-checkbox"></gl-checkbox>
            <gl-form-item label="名称">
              <gl-input
                v-model:value="item.indicatorName"
                class="wid-240"
                placeholder="请输入名称"
              />
            </gl-form-item>
          </div>
        </gl-collapse-panel>
        <gl-collapse-panel header="文本">
          <gl-form-item label="字体">
            <font-collection v-model:font="form.textStyle" />
          </gl-form-item>
        </gl-collapse-panel>
      </gl-collapse>
    </gl-form>
  </div>
</template>

<script lang="ts" setup>
import { CaretRightOutlined } from '@ant-design/icons-vue'
import FontCollection from '../font-collection.vue'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

//选中指标
const collapseKey = ref(0)

const form = computed(() => props.contentOption.indexOptionsRadar)
</script>
<style lang="scss" scoped>
.option-collapse-title {
  display: inline-block;
  max-width: 300px;
  vertical-align: middle;
  margin-left: 8px;
}
.form-checkbox {
  margin-bottom: 24px;
  margin-right: 10px;
}
</style>
