<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-26 14:47:09
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-09 17:05:53
 * @Description: 计算弹窗
-->
<template>
  <gl-modal
    v-model:visible="visible"
    title="参数设置"
    @ok="confirmBtn"
    @cancel="handleCancel"
    :confirm-loading="confirmLoading"
  >
    <gl-form :model="formInfo">
      <!-- 同环比 -->
      <template v-if="indicatorsType === 2">
        <gl-form-item label="变化类型">
          <gl-select v-model:value="formInfo.changeType">
            <gl-select-option v-for="(item, i) in changeTypeArr" :key="i" :value="item.val">
              {{ item.name }}
            </gl-select-option>
          </gl-select>
        </gl-form-item>
        <gl-form-item label="变化选项">
          <gl-radio-group v-model:value="formInfo.changeOption">
            <gl-radio v-for="(item, i) in changeOptionArr" :key="i" :value="item.val">{{
              item.name
            }}</gl-radio>
          </gl-radio-group>
        </gl-form-item>
        <gl-form-item label="环比期数">
          <gl-input-number
            v-model:value="formInfo.seqPeriod"
            :disabled="formInfo.changeOption === 'yoy'"
            :min="1"
          />
        </gl-form-item>
      </template>
      <!-- 累计求和 -->
      <template v-if="indicatorsType === 4">
        <gl-form-item>
          <gl-radio-group v-model:value="formInfo.type">
            <gl-radio v-for="(item, i) in typeArr" :key="i" :value="item.val">{{
              item.name
            }}</gl-radio>
          </gl-radio-group>
        </gl-form-item>
        <gl-form-item label="周期数">
          <gl-input-number
            v-model:value="formInfo.period"
            :disabled="formInfo.type === 2 || formInfo.type === 3"
          />
        </gl-form-item>
        <gl-form-item>
          <gl-checkbox v-model:checked="formInfo.checked" :disabled="formInfo.type === 1"
            >限于当年</gl-checkbox
          >
        </gl-form-item>
      </template>
    </gl-form>
  </gl-modal>
</template>

<script setup lang="ts">
import { bus } from '@mysteel-standard/utils'
import api from '../../api/index'
import { cloneDeep } from 'lodash-es'
import { changeTypeArr, changeOptionArr, typeArr } from '../../constants'
//props
interface Props {
  indicatorsType: number
  indicatorsVisible: boolean
  extractParam: any
  indexItem: any
  curEl: any
  formFrequency: any
  selectedCells: Array<string>
  matrixData: any
}
const props = withDefaults(defineProps<Props>(), {
  indicatorsType: 2,
  indicatorsVisible: false
})
//emits
interface Emits {
  (e: 'update:indicatorsVisible', val: boolean): void
}
const emits = defineEmits<Emits>()

const visible = computed(() => {
  return props.indicatorsVisible
})

const formInfo = computed(() => {
  return props.formFrequency
})

const confirmLoading: Ref = ref(false)

const confirmBtn = async () => {
  const [x, y] = props.selectedCells[0].split('_')
  const indexOptionsTable = cloneDeep(props.curEl.contentOption.indexOptionsTable)
  const dateIndexRequestList: any[] = []
  indexOptionsTable.forEach((item: any) => {
    dateIndexRequestList.push({
      indexCode: item.indexCode,
      frequencyName: item.frequency,
      isDerive: item.isDerive,
      indexName: item.indexName,
      decimalPlaces: item.decimalPlaces
    })
  })
  let params = {
    position: `${x},${y}`,
    rows: props.curEl.tableData.length,
    beginTime: props.extractParam?.beginTime,
    endTime: props.extractParam?.endTime,
    deriveOption: props.indicatorsType,
    indexRequestList: [
      {
        indexCode: props.indexItem.indexCode,
        frequencyName: props.indexItem.frequency,
        isDerive: props.indexItem.isDerive,
        indexName: props.indexItem.indexName,
        decimalPlaces: props.indexItem.decimalPlaces
      }
    ],
    dateIndexRequestList
  }
  if (props.indicatorsType === 2) {
    // 同环比计算
    params = Object.assign({}, params, {
      changeType: formInfo.value.changeType,
      changeOption: formInfo.value.changeOption,
      seqPeriod: formInfo.value.seqPeriod
    })
  }
  if (props.indicatorsType === 4) {
    /* 累计求和 */
    params = Object.assign({}, params, {
      accSumRequest: {
        type: formInfo.value.type,
        period: formInfo.value.type === 1 ? formInfo.value.period : formInfo.value.checked ? 1 : 0
      }
    })
  }
  confirmLoading.value = true
  const { err, res } = await api.getTableIndexData([params])
  confirmLoading.value = false
  if (!err && res) {
    const calData = res.data
    let deriveValue: any[] = []
    const currentData = calData.filter(
      (item: { indexCode: string; isDerive: number }) =>
        item.indexCode.includes(props.indexItem.indexCode) && item.isDerive
    )
    deriveValue =
      currentData[0]?.indexValues?.map((item: { dataValue: string }) => item.dataValue) || []
    const indexOptionsTable = cloneDeep(props.curEl.contentOption.indexOptionsTable)
    indexOptionsTable.forEach(
      (item: {
        checked: boolean
        calculation: { name: string; value: any[] }
        calculationParams: any
      }) => {
        if (item.checked) {
          let str = ''
          if (props.indicatorsType === 2) {
            str = changeOptionArr.filter((item) => item.val === formInfo.value.changeOption)[0].name
            str += changeTypeArr.filter((item) => item.val === formInfo.value.changeType)[0].name
          } else if (props.indicatorsType === 4) {
            str = typeArr.filter((item) => item.val === formInfo.value.type)[0].name
          }
          item.calculation = {
            name: `${str}`,
            value: deriveValue
          }
          item.calculationParams = cloneDeep(params)
          bus.emit('change-table-data', cloneDeep(item))
        }
      }
    )
    bus.emit('update-content-option', { indexOptionsTable })
    emits('update:indicatorsVisible', false)
  }
}

const handleCancel = () => {
  emits('update:indicatorsVisible', false)
}
</script>

<style lang="scss" scoped></style>
