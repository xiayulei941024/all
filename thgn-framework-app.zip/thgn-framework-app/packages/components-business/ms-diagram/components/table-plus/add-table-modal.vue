<template>
  <gl-modal
    v-model:visible="visible"
    title="设置表格结构"
    centered
    @ok="submit"
    @cancel="cancelBtn"
    :width="420"
  >
    <gl-form ref="ruleForm" :model="formInfo" autocomplete="off" class="add-form">
      <gl-form-item
        label="表格行数"
        name="row"
        :rules="[
          {
            required: true,
            message: '请输入表格行数',
            type: 'number',
            trigger: 'blur'
          }
        ]"
      >
        <gl-input-number
          v-model:value="formInfo.row"
          :min="1"
          style="width: 100%"
          placeholder="请输入表格行数"
        />
      </gl-form-item>
      <gl-form-item
        label="表格列数"
        name="col"
        :rules="[
          {
            required: true,
            message: '请输入表格列数',
            type: 'number',
            trigger: 'blur'
          }
        ]"
      >
        <gl-input-number
          v-model:value="formInfo.col"
          :min="1"
          style="width: 100%"
          placeholder="请输入表格列数"
        />
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>

<script setup lang="ts">
//props
interface Props {
  formState: {
    row: number | string
    col: number | string
  }
  addTableVisible: boolean
}
const props = withDefaults(defineProps<Props>(), {
  formState: () => ({
    row: '',
    col: ''
  }),
  addTableVisible: false
})
//emits
interface Emits {
  (e: 'submit', val: any): void
  (e: 'cancel'): void
  (e: 'update:addTableVisible', val: boolean): void
}
const emits = defineEmits<Emits>()

const visible = computed(() => {
  return props.addTableVisible
})

const formInfo: any = computed(() => {
  return props.formState
})

const ruleForm: Ref = ref(null)
//新增表格
const submit = () => {
  ruleForm.value.validate().then(async () => {
    emits('submit', formInfo.value)
    emits('update:addTableVisible', false)
  })
}
const cancelBtn = () => {
  if (ruleForm.value) {
    ruleForm.value.clearValidate()
    emits('update:addTableVisible', false)
  }
}
</script>

<style lang="scss" scoped>
.add-form {
  height: 100px;
  margin: 20px;
}
</style>
