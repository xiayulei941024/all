<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2024-07-19 14:13:00
 * @Description: 图表展示模块-图
-->
<template>
  <div class="chart-container">
    <div class="title">
      <div v-if="title.headerTitle.show" class="info header">
        <p :style="headerTitleStyle" v-html="title.headerTitle.name"></p>
        <icon
          v-if="!preview"
          name="icon-edit"
          @click="textEdit(title.headerTitle, 'headerTitle')"
        />
      </div>
    </div>
    <div class="content" v-if="showEditChart">
      <edit-chart
        ref="editChart"
        :curEl="curEl"
        :indexDataSeason="indexDataSeason"
        :seasonChecked="seasonChecked"
      />
    </div>
    <div class="title">
      <div v-if="title.footerTitle.show" class="info footer">
        <p :style="footerTitleStyle" v-html="title.footerTitle.name"></p>
        <icon
          v-if="!preview"
          name="icon-edit"
          @click="textEdit(title.footerTitle, 'footerTitle')"
        />
      </div>
    </div>
    <rich-editor v-model:visible="textVisible" v-model:font="font" :title="richEditorTitle" />
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { RichEditor } from '../../rich-editor'
import { CurEl } from '../types/interface'
import { LAYOUT_TYPE } from '../constants'
import EditChart from '../../edit-chart/index.vue'
import useTitleOptions from '../composables/content-options/use-title-options'
//props
interface Props {
  curEl: CurEl
  indexDataSeason: any[]
  seasonChecked: boolean
  preview?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  preview: false,
  seasonChecked: false
})

//标题
const title: any = computed({
  get() {
    const { contentOption } = props.curEl
    return contentOption[LAYOUT_TYPE[props.curEl.id]].titleFont
  },
  set() {}
})
const headerTitleStyle: any = computed(() => ({
  ...title.value.headerTitle,
  fontSize: `${title.value.headerTitle.fontSize}px`
}))
const footerTitleStyle: any = computed(() => ({
  ...title.value.footerTitle,
  fontSize: `${title.value.footerTitle.fontSize}px`
}))
const { textEdit, font, textVisible, richEditorTitle, titleType } = useTitleOptions()
watch(
  () => font.value,
  (newVal) => {
    const { contentOption } = props.curEl
    contentOption[LAYOUT_TYPE[props.curEl.id]].titleFont[titleType.value] = newVal
  }
)

const editChart = ref(null)

const showEditChart = ref(true)
onActivated(() => {
  showEditChart.value = true
})

onDeactivated(() => {
  showEditChart.value = false
})

defineExpose({
  editChart
})
</script>
<style lang="scss" scoped>
.chart-container {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  .title {
    height: 48px;
    padding: 0 28px 0 20px;
    .info {
      height: 100%;
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      &.header {
        border-bottom: 1px solid #e8e8e8;
      }
      &.footer {
        border-top: 1px solid #e8e8e8;
      }
      p {
        font-size: 14px;
        width: 100%;
        padding-right: 10px;
      }
    }

    .icon {
      &:hover {
        color: #005bac;
      }
    }
  }
  .content {
    width: 100%;
    height: calc(100% - 96px);
    .chart {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
