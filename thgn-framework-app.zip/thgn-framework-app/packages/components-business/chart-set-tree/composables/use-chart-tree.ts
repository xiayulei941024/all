/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-25 17:23:57
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-18 17:19:40
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
import { ref, Ref, reactive, onMounted } from 'vue'
export default (tabIndex: Ref, emits: any) => {
  const loading = ref(false)
  const companySelectedKeys = ref<any>([])
  const companyTreeData = reactive<any>([
    {
      id: 0,
      label: '公司图表库',
      type: 1,
      pid: -1,
      children: []
    }
  ])
  const myChartSelectedKeys = ref<any>([])
  const myChartTreeData = reactive<any>([
    {
      id: 0,
      moduleType: 5,
      label: '我的图表库',
      type: 1,
      pid: -1,
      children: []
    }
  ])
  const replaceFields = {
    children: 'children',
    title: 'label',
    key: 'id'
  }
  const getTree = async (tabIndex: number) => {
    const params = {
      type: tabIndex
    }
    loading.value = true
    const { res, err } = await api.queryChartsCatalogueList(params)
    loading.value = false
    if (!err && res) {
      const { data } = res
      if (tabIndex === 1) {
        companyTreeData[0].children.length = 0
        companySelectedKeys.value = [0]
        companyExpandedKeys.value = [0]
        companyTreeData[0].children = [...data]
      } else {
        myChartTreeData[0].children.length = 0
        myChartSelectedKeys.value = [0]
        myChartExpandedKeys.value = [0]
        myChartTreeData[0].children = [...data]
      }
    }
  }
  const nodeClick = async (
    selectedKeys: number[],
    {
      node
    }: {
      node: any
    }
  ) => {
    const { expanded, isLeaf, key } = node
    const data = {
      node,
      tabIndex: tabIndex.value
    }
    if (!isLeaf) {
      tabIndex.value === 1 ? companyNodeExpand(node) : myChartNodeExpand(node)
    }
    emits('get-chart-list', data)
  }
  const {
    expandedKeys: companyExpandedKeys,
    nodeExpand: companyNodeExpand,
    treeExpand: companyExpand
  } = useTreeExpand()
  const {
    expandedKeys: myChartExpandedKeys,
    nodeExpand: myChartNodeExpand,
    treeExpand: myChartExpand
  } = useTreeExpand()
  onMounted(() => {
    getTree(1)
  })
  return {
    loading,
    companySelectedKeys,
    companyExpandedKeys,
    companyTreeData,
    replaceFields,
    myChartSelectedKeys,
    myChartExpandedKeys,
    myChartTreeData,
    nodeClick,
    getTree,
    companyExpand,
    myChartExpand
  }
}
