/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-04 10:41:23
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-04 10:42:09
 * @Description:
 */
export { default as EditTable } from './index.vue'
