const express = require("express");
const axios = require("axios");
const cors = require("cors");
const app = express();
const https = require('https');
const fs = require('fs');
const dayjs = require('dayjs')
const mysql = require('mysql2');
const http = require('http');
const OSS = require('ali-oss');
const multer = require('multer');
const FormData = require('form-data');

const options = {
  key: fs.readFileSync('./ssl/server.key'),
  cert: fs.readFileSync('./ssl/star_trinasolar_com.crt'),
  ca: fs.readFileSync('./ssl/star_trinasolar_com.p7b'),
};

const hostname = process.env.NODE_ENV ? "" : "0.0.0.0"
const datebaseName = process.env.NODE_ENV ? 'matrix_sql': 'matrix_dev';

console.log('host',hostname);
// 创建数据库连接
const db = mysql.createConnection({
  host: '172.22.3.63',
  user: 'aibigdata',
  password: 'dbpswd#',
  database: datebaseName,
});
// 创建新数据库 'matrix_sql'
db.query('CREATE DATABASE IF NOT EXISTS matrix_dev', (err, result) => {
    if (err) throw err;
    console.log('Database "matrix_dev" created');
  });
// 连接到数据库
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database: ' + err.stack);
    return;
  }
  db.query(`CREATE TABLE IF NOT EXISTS user_info (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
      sub TEXT,
      uid TEXT,
      employee_number TEXT,
      mail TEXT,
      display_name TEXT,
      department_number TEXT,
      street TEXT,
      timestamp DATETIME,
      create_time TEXT
  )`, (err, result, fields) => {
    if (err) {
      return
    }
    console.log('success');
  })
    // 创建页面点击次数表
  db.query(`CREATE TABLE IF NOT EXISTS page_clicks (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    page_tag TEXT,
    timestamp DATETIME,
    create_time TEXT,
    user_info_uid TEXT,
    user_info_department_number TEXT
  )`);

    // 创建AI资讯用户信息表
    db.query(`CREATE TABLE IF NOT EXISTS ai_news_info (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      page_tag TEXT,
      timestamp TEXT,
      create_time TEXT,
      user_info_uid TEXT,
      user_info_department_number TEXT
    )`);

    // 创建智能翻译用户信息表
    db.query(`CREATE TABLE IF NOT EXISTS trans_info (
      id INTEGER PRIMARY KEY AUTO_INCREMENT,
      page_tag TEXT,
      timestamp TEXT,
      create_time TEXT,
      user_info_uid TEXT,
      user_info_department_number TEXT
    )`);

  // 创建翻译信息表
  db.query(`CREATE TABLE IF NOT EXISTS translate_info (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    filename TEXT,
    file_ext TEXT,
    file_size TEXT,
    timestamp TEXT,
    create_time TEXT,
    user_info_uid TEXT,
    user_info_sub TEXT,
    user_info_display_name TEXT,
    user_info_department_number TEXT
  )`);

  // 创建用户日志信息表
  db.query(`CREATE TABLE IF NOT EXISTS user_log (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    brand TEXT,
    model TEXT,
    netInfo TEXT,
    operatorType TEXT,
    success TEXT,
    timestamp TEXT,
    create_time TEXT,
    user_info_uid TEXT,
    user_info_sub TEXT,
    user_info_display_name TEXT,
    user_info_department_number TEXT
  )`);
  
  // 创建网站访问量表
  db.query(`CREATE TABLE IF NOT EXISTS website_visits (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    timestamp DATETIME,
    create_time TEXT,
    user_info_uid TEXT,
    user_info_department_number TEXT
  )`);
  console.log('Connected to MySQL database as ID ' + db.threadId);
});

const tagKeys = ['AI模型训练平台','联系我们', 'ChatBot', '数据探索性分析','ChatBI','图像生成','ASR','自动机器学习', 'AI NEWS', 'Face Swapping',
  'Vision', 'File Translation', '智能翻译','仓储库容优化', 'FastGPT', '工业视觉','智慧采购', '功率预测','AI算法','大模型','机器学习','工业质检','订单排产','天玑', 'WIKI']


const port = 3000;

setInterval(() => {
  db.query('SELECT 1', (err, rows) => {
    if (err) throw err;
  })
}, 1000 * 60 * 9)

app.use(express.json());
app.use(cors());

let codeObj = {};
app.get("/getcode", (req, res) => {
  codeObj = req.query;
  console.log('code', codeObj);
  codeObj.env = process.env.NODE_ENV
  codeObj.hostname = hostname
  res.send(codeObj);
});

app.get("/getNews", (req, res) => {
  axios.get("http://10.31.141.251:5000/news_list").then((res1) => {
    res.send(res1.data);
  }).catch(err => {
    res.send(err.message)
  })
})

// 支持文档格式
app.get("/support_file_type", (req, res) => {
  axios.get("http://172.22.3.1:8200/api/support_file_type").then((result) => {
    res.send(result.data)
  }).catch(err => {
    res.send(err.message)
  })
})

app.post("/getHistory", (req, res) => {
  axios.get(`http://172.22.3.1:8200/api/get_user_history?sub=${req.body.sub}`).then((result) => {
    res.send(result.data)
  }).catch(err => {
    res.send(err.message)
  })
})

// 配置OSS客户端
const client = new OSS({
  endpoint: "oss-cn-cz-thgndsj-d01-a.asoops.trinasolar.com/", // 替换为你的OSS区域
  accessKeyId: 'NM2SKmzlH27xBH9g', // 替换为你的AccessKeyId
  accessKeySecret: 'mQnvH3K0vrGkb8RFzdP3RAegaigZXF', // 替换为你的AccessKeySecret
  bucket: 'aibigdata', // 替换为你的Bucket名称
});

// 配置multer中间件
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

app.post('/upload2back', upload.single('file'), (req, res) => {
  const file = req.file;
  const buffer = file.buffer;
  client.put(req.body.ossPath, buffer)
  .then(() => {
    res.send('File uploaded to OSS successfully');
  })
  .catch(error => {
    console.log('errupload', error.message);
    res.status(500).send('File upload to OSS failed');
  });
});

app.post('/translate_file', (req, res) => {
  const {target_language, selected_model, uid, sub, oss_file_path, recognize_picture} = req.body;
  const formData = new FormData
  formData.append('target_language', target_language);
  formData.append('selected_model', selected_model);
  formData.append('uid', uid);
  formData.append('sub', sub);
  formData.append('oss_file_path', oss_file_path);
  formData.append('recognize_picture', recognize_picture + '');
  axios.post("http://172.22.3.1:8200/api/translate_oss_file", formData, {
    headers: {
      ...formData.getHeaders()
    }
  }).then((result) => {
    res.send(result.data)
  }).catch((e) => {
    res.send(e.message)
  })
});

//文本翻译
app.post("/translate_text", (req, res) => {
  axios.post("http://172.22.3.1:8200/api/translate_text", {...req.body}, {
    headers: {
      "Content-Type": "application/json",
      Accept: 'application/json',
    }
  }).then((result) => {
    res.send(result.data)
  }).catch((e) => {
    console.log('errtext',e.message);
    res.send(e.message)
  })
})

app.post("/fileInfoRecord", express.json(), (req, res) => {
  // 访问记录，包含用户信息和时间戳
  const { user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, filename, file_ext,file_size} = req.body;
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO translate_info ( user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, filename, file_ext, file_size, timestamp, create_time) VALUES (?, ?, ?, ?,?,?,?,?,?)",
  [user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, filename, file_ext, file_size, timestamp, create_time], (err, row) => {
    if (err) {
      console.log('fileinfo',err);
      return res.status(200).json({ error: "更新失败" });
    }
    res.status(200).json({ message: "ok" });
  })
})

app.post('/getUserLog', express.json(), (req, res) => {
  const { user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, brand, model,netInfo, operatorType, success} = req.body;
  console.log('ulog1',req.body);
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO translate_info ( user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, brand, model, netInfo, operatorType,timestamp, create_time, success) VALUES (?, ?, ?, ?,?,?,?,?,?,?,?)",
  [user_info_uid, user_info_sub, user_info_display_name, user_info_department_number, brand, model, netInfo, operatorType,timestamp, create_time, success], (err, row) => {
    if (err) {
      console.log('userLog',err);
      return res.status(200).json({ error: "更新失败" });
    }
    console.log('ulog',req.body);
    res.status(200).json({ message: "ok" });
  })
})

app.post("/clickRecord", express.json(), (req, res) => {
  // 点击记录，包含链接，用户信息和时间戳
  const { page_tag, user_info_uid, user_info_department_number } = req.body;
  if (!page_tag) {
    return res.status(200).json({ error: "page_tag and user_info_uid is required" });
  }
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO page_clicks (page_tag, user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?, ?)",
  [page_tag, user_info_uid, user_info_department_number, create_time, create_time], (err, row) => {
    if (err) {
      return res.status(200).json({ error: "更新失败" });
    }
    res.json(row);
  })
});

app.post('/aiNewsInfo', express.json(), (req, res) => {
  const { page_tag, user_info_uid, user_info_department_number } = req.body;
  if (!page_tag) {
    return res.status(200).json({ error: "page_tag and user_info_uid is required" });
  }
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO ai_news_info (page_tag, user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?, ?)",
  [page_tag, user_info_uid, user_info_department_number, create_time, create_time], (err, row) => {
    if (err) {
      return res.status(200).json({ error: "更新失败" });
    }
    res.json(row);
  })
})
app.post('/translationInfo', express.json(), (req, res) => {
  const { page_tag, user_info_uid, user_info_department_number } = req.body;
  if (!page_tag) {
    return res.status(200).json({ error: "page_tag and user_info_uid is required" });
  }
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO trans_info (page_tag, user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?, ?)",
  [page_tag, user_info_uid, user_info_department_number, create_time, create_time], (err, row) => {
    if (err) {
      return res.status(200).json({ error: "更新失败" });
    }
    res.json(row);
  })
})
app.post('/customer_bot_info', express.json(), (req, res) => {
  const {chat_content, conv_uid, user_info_uid, user_info_department_number} = req.body;
  if (!chat_content || conv_uid || !user_info_uid) {
    return res.status(200).json({ error: "chat_content or conv_uid or user_info_uid is required" });
  }
  const timestamp = dayjs().valueOf();
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss');
  db.query('INSERT INTO customer_bot_info (chat_content, conv_uid, user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?, ?, ?)',
  [chat_content, conv_uid, user_info_uid, user_info_department_number, timestamp, create_time], (err, row) => {
    if (err) {
      return res.status(200).json({error: "更新失败" });
    }
    res.json(row);
  })
})
app.post('/image_generation_info', express.json(), (req, res) => {
  const { prompt, selected_values, user_info_uid, user_info_department_number } = req.body;
  if (!prompt || !selected_values || !user_info_uid) {
    return res.status(200).json({ error: "prompt or selected_values or user_info_uid is required" });
  }
  const timestamp = dayjs().valueOf();
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss');
  db.query('INSERT INTO image_generation_info (prompt, selected_values, user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?, ?, ?)',
  [prompt, selected_values, user_info_uid, user_info_department_number, timestamp, create_time], (err, row) => {
    if (err) {
      console.log(err);
      return res.status(200).json({error: "更新失败"});
    }
    res.json(row);
  })
});

// 获取链接点击量记录，通过时间戳查询记录数量，将链接记录数量分类汇总给前端
app.post("/getRecord", async (req, res) => {
  const { start_time, end_time, last_start_time } = req.body;
  let tagRows = [];
  let lastTagRows = [];

  try {
      const tagRowsPromise = new Promise((resolve, reject) => {
          db.query(`SELECT * FROM page_clicks where create_time >= '${start_time}' and create_time <= '${end_time}'`,
              (err, rows) => {
                  if (err) {
                      reject(err);
                  }
                  tagRows = rows;
                  resolve();
              });
      });

      const lastTagRowsPromise = last_start_time ? new Promise((resolve, reject) => {
          db.query(`SELECT * FROM page_clicks where create_time >= '${last_start_time}' and create_time <= '${start_time}'`,
              (err, rows) => {
                  if (err) {
                      reject(err);
                  }
                  lastTagRows = rows;
                  resolve();
              });
      }) : [];
      await Promise.all([tagRowsPromise, lastTagRowsPromise]);
      const tagCounts = {};
      const lastTagCounts = {};

      tagRows.forEach((item) => {
          tagCounts[item.page_tag] = (tagCounts[item.page_tag] || 0) + 1;
      });

      last_start_time && lastTagRows.forEach((item) => {
          lastTagCounts[item.page_tag] = (lastTagCounts[item.page_tag] || 0) + 1;
      });
      const tagArr = []
      tagArr[0] = tagKeys.map(key => ({ tag: key, count: tagCounts[key] || 0}))
      tagArr[1] = last_start_time ? tagKeys.map(key => ({ tag: key, count: lastTagCounts[key] || 0})) : []
      res.json(tagArr);
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
});

app.get("/getTotalUserNum", express.json(), (req, res) => {
  let userNum = []
  db.query("SELECT COUNT(*) AS total_count FROM user_info", (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    userNum = row
    res.status(200).json(userNum[0]);
  })
})
app.get("/getUserWeek", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
    DATE_FORMAT(create_time, '%Y-%u') AS week_year,  -- 获取年和周数
    MIN(create_time) AS last_day_of_week,  -- 每周的最后一天
    COUNT(*) AS total_count  -- 每周的数据量
    FROM 
        user_info
    GROUP BY 
        week_year
    ORDER BY 
        week_year;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})

app.get("/getUser2Week", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
      DATE(create_time) AS date,
      COUNT(*) AS total_count
    FROM 
      user_info
    WHERE 
      create_time >= DATE_SUB(CURDATE(), INTERVAL 2 WEEK)
      AND create_time < CURDATE()
    GROUP BY 
      date
    ORDER BY 
      date DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})


app.get("/getTotalClickNum", express.json(), (req, res) => {
  let clickNum = []
  db.query("SELECT COUNT(*) AS total_count FROM page_clicks", (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    clickNum = row
    res.status(200).json(clickNum[0]);
  })
})

app.get("/getClickWeek", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
    DATE_FORMAT(create_time, '%Y-%u') AS week_year,
    MIN(create_time) AS last_day_of_week,
    COUNT(*) AS total_count
    FROM 
        page_clicks
    GROUP BY 
        week_year
    ORDER BY 
        week_year;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})

app.get("/getClick2Week", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
      DATE(create_time) AS date,
      COUNT(*) AS total_count
    FROM 
      page_clicks
    WHERE 
      create_time >= DATE_SUB(CURDATE(), INTERVAL 2 WEEK)
      AND create_time < CURDATE()
    GROUP BY 
      date
    ORDER BY 
      date DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})

app.get("/getTotalVisitNum", express.json(), (req, res) => {
  let visitNum = []
  db.query("SELECT COUNT(*) AS total_count FROM website_visits", (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    visitNum = row
    res.status(200).json(visitNum[0]);
  })
})

app.get("/getVisitWeek", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
    DATE_FORMAT(create_time, '%Y-%u') AS week_year,
    MIN(create_time) AS last_day_of_week,
    COUNT(*) AS total_count
    FROM 
        website_visits
    GROUP BY 
        week_year
    ORDER BY 
        week_year;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})

app.get("/getVisit2Week", express.json(), (req, res) => {
  let weekNum = []
  const sqlString = `SELECT 
      DATE(create_time) AS date,
      COUNT(*) AS total_count
    FROM 
      website_visits
    WHERE 
      create_time >= DATE_SUB(CURDATE(), INTERVAL 2 WEEK)
      AND create_time < CURDATE()
    GROUP BY 
      date
    ORDER BY 
      date DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    weekNum = row
    console.log(row);
    
    res.status(200).json(weekNum);
  })
})

// 获取top模块访问量
app.get("/getTopTag", express.json(), (req, res) => {
  let topTag = []
  const sqlString = `SELECT 
    page_tag AS tag_name,
    COUNT(*) AS total_count,
    CONCAT(ROUND((COUNT(*) / (SELECT COUNT(*) FROM page_clicks) * 100), 2), '%') AS percentage
    FROM 
        page_clicks
    GROUP BY 
        page_tag
    ORDER BY 
        total_count DESC
    LIMIT 10;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    topTag = row
    console.log(row);   
    res.status(200).json(topTag);
  })
})

// 获取top用户访问量
app.get("/getTopUser", express.json(), (req, res) => {
  let topUser = []
  const sqlString = `SELECT 
    user_info_uid, 
    COUNT(*) AS user_count
    FROM 
        website_visits
    GROUP BY 
        user_info_uid
    ORDER BY 
        user_count DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    topUser = row
    console.log(row);   
    res.status(200).json(topUser);
  })
})

app.get("/getNewsTopUser", express.json(), (req, res) => {
  let topUser = []
  const sqlString = `SELECT 
    user_info_uid,
    COUNT(*) AS click_count
    FROM 
        (
            SELECT user_info_uid FROM ai_news_info WHERE page_tag IN ('AI NEWS')
            UNION ALL
            SELECT user_info_uid FROM page_clicks WHERE page_tag IN ('AI NEWS')
        ) AS combined
    GROUP BY 
        user_info_uid
    ORDER BY 
        click_count DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    topUser = row
    console.log(row);
    
    res.status(200).json(topUser);
  })
})

app.get("/getTranslationTopUser", express.json(), (req, res) => {
  let topUser = []
  const sqlString = `SELECT 
    user_info_uid,
    COUNT(*) AS click_count
    FROM 
        page_clicks
    WHERE 
        page_tag IN ('File Translation', '智能翻译')
    GROUP BY 
        user_info_uid
    ORDER BY 
        click_count DESC;`
  db.query(sqlString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    topUser = row
    console.log(row);
    
    res.status(200).json(topUser);
  })
})

const selectString = `SELECT page_tag, COUNT(page_tag) AS limit_count
  FROM page_clicks
  GROUP BY page_tag
  ORDER BY limit_count DESC
  LIMIT 10;`
app.get("/getLimit5click", express.json(), (req, res) => {
  let limit5 = []
  db.query(selectString, (err, row) => {
    if (err) {
      return res.status(200).json({ error: "获取失败" });
    }
    console.log('ff', row);
    limit5 = row
    res.status(200).json(limit5);
  })
})


app.post("/webVisits", express.json(), (req, res) => {
  // 访问记录，包含用户信息和时间戳
  const { user_info_uid, user_info_department_number } = req.body;
  const timestamp = dayjs().valueOf()
  const create_time = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')
  db.query("INSERT INTO website_visits ( user_info_uid, user_info_department_number, timestamp, create_time) VALUES (?, ?, ?, ?)",
  [user_info_uid, user_info_department_number, create_time, create_time], (err, row) => {
    if (err) {
      console.log(err);
      return res.status(200).json({ error: "更新失败" });
    }
    res.status(200).json({ message: "ok" });
  })
})

app.post("/getVisits", express.json(), async (req, res) => {
  // 获取访问量，通过时间戳获取记录的数量
  const { start_time, end_time, last_start_time } = req.body;
  let visitRows = [];
  let lastVisitRows = [];
  try {
    const visitRowsPromise = new Promise((resolve, reject) => {
      db.query(
        `SELECT * FROM website_visits WHERE create_time >= '${start_time}' and create_time <= '${end_time}'`,
        (err, rows) => {
          if (err) {
            reject(err);
          }
          visitRows = rows;
          resolve();
        }
      );
    });

    const lastVisitRowsPromise = new Promise((resolve, reject) => {
      db.query(
        `SELECT * FROM website_visits where create_time >= '${last_start_time}' and create_time <= '${start_time}'`,
        (err, rows) => {
          if (err) {
            reject(err);
          }
          lastVisitRows = rows;
          resolve();
        }
      );
    });
    await Promise.all([visitRowsPromise, lastVisitRowsPromise]);
    res.json({
      current: visitRows.length || 0,
      last: lastVisitRows.length || 0,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/getToken", (req, res) => {
  let reUri = process.env.NODE_ENV ? "http://localhost:5600/" : "https://matrix.trinasolar.com/"
  const data = {
    client_secret: "MbTQ3RrMb3CFRNvTaXUC",
    client_id: "matrix_cli",
    grant_type: "authorization_code",
    redirect_uri: reUri,
    code: req.body.code,
  };

  console.log('zzz',data);
  axios
    .post("https://iam.trinasolar.com/mga/sps/oauth/oauth20/token", data, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })
    .then((response) => {
      // console.log('ddd', response.data);
      res.send(response.data);
    })
    .catch((error) => {
      console.log('sss',error?.response?.data, error.message);
      res.send({
        msg: error.message,
      });
    });
});

app.get("/userinfo", (req, res) => {
  axios
    .post(
      "https://iam.trinasolar.com/mga/sps/oauth/oauth20/userinfo",
      {},
      {
        headers: {
          Authorization: `Bearer ${req.query.accessToken}`,
        },
      }
    )
    .then((res1) => {
      const { sub, uid, employeenumber, mail, displayname, departmentnumber,street } = res1.data;
      const timestamp = dayjs().valueOf()
      const createtime = dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss')

    db.query("INSERT INTO user_info (sub, uid, employee_number, mail, display_name, department_number,street, timestamp, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", 
    [sub, uid, employeenumber, mail, displayname, departmentnumber, street,createtime, createtime], (err) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.send(res1.data);
    });
    })
    .catch((err) => {
      res.send({
        msg: err.message
      });
    });
});
app.post("/getUserCount", express.json(), async (req, res) => {
  // 获取用户量，通过时间戳查询表中记录数量，在根据用户名去重，得到用户的数量
  const { start_time, end_time, last_start_time } = req.body;
  let userRows = [];
  let lastUserRows = [];
  try {
    const userRowsPromise = new Promise((resolve, reject) => {
      db.query(
        `SELECT COUNT(DISTINCT uid) AS uid_count FROM user_info WHERE create_time >= '${start_time}' and create_time <= '${end_time}'`,
        (err, rows) => {
          if (err) {
            reject(err);
          }
          userRows = rows;
          resolve();
        }
      );
    });

    const lastUserRowsPromise = new Promise((resolve, reject) => {
      db.query(
        `SELECT COUNT(DISTINCT uid) AS uid_count FROM user_info where create_time >= '${last_start_time}' and create_time <= '${start_time}'`,
        (err, rows) => {
          if (err) {
            reject(err);
          }
          lastUserRows = rows;
          resolve();
        }
      );
    });
    await Promise.all([userRowsPromise, lastUserRowsPromise]);
    res.json({
      current: userRows[0].uid_count || 0,
      last: lastUserRows[0].uid_count || 0,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
})

app.get("/event-stream", (req, res) => {

  // 设置响应头，告知客户端这是 SSE
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // 定义一个函数用于发送消息
  const sendEvent = (data) => {
    res.write(`data: ${JSON.stringify({vis: data})}\n\n`);
  };

  // 初始消息
  let eventData = "# 123123 \n### 321";
  
  const markdown = `
  ### 1. 登录

  登录页面，输入用户名密码，点击登录，即可进入系统。

  ### 2. 首页

  首页，显示当前用户信息，以及当前用户拥有的权限。

  ### 3. 菜单管理

  菜单管理，可以添加、删除、修改菜单。

  ### 4. 用户管理

  用户管理，可以添加、删除、修改用户。
  \`\`\`
  <div>123</div>
  \`\`\`
  <p>321</p>


  # GFM Example
  - [x] Task 1
  - [ ] Task 2

  | Header | Header |
  |--------|--------|
  | Cell   | Cell   |
  `;
  function printText(text) {
    let index = 0;  // 追踪当前字符的索引
    
    const intervalId = setInterval(() => {
      if (index < text.length) {
        // console.log(text[index]);  // 打印当前字符
        sendEvent(eventData += text[index]);
        index++;  // 增加索引
      } else {
        clearInterval(intervalId);  // 如果文本打印完毕，清除定时器
        sendEvent("[DONE]");
      }
    }, 1);  // 每 20ms 执行一次
  }
  
  // sendEvent(eventData++, "Welcome to the EventStream!");

  // 定时推送数据
  const interval = setInterval(() => {
    // 0-9的随机数字
    const num = Math.floor(Math.random() * 10);
    sendEvent(eventData += num);
  }, 20); // 每3秒发送一条消息

  setTimeout(() => {
    printText(markdown);
    clearInterval(interval);
  }, 500);

  // 监听客户端断开连接
  req.on('close', () => {
    console.log('Client disconnected');
    clearInterval(interval);
    res.end();
  });
})

https.createServer(options, app).listen(port, () => {   //https.createServer(options, app).
  console.log(`Server is running on https://matrixbackend.trinasolar.com:${port}`);
});
 