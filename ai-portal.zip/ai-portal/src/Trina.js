// export const platformName = "TrinaX.ai";
// export const platformName = "TrinaXAI";
export const platformName = "Matrix";
export const headerPlat = "AI 模型训练平台";
export const headerCreate = "加入共创";

// export const platformName = "TrinaOne";
