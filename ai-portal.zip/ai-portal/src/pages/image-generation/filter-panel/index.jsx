import React, { useState } from 'react';
import { CloseOutlined } from '@ant-design/icons';
import { Button, Radio } from 'antd';
import classNames from 'classnames';
import Transition from '../../../utils/Transition';
import FilterRadio from './filter-radio';


const optionsList = [
  {
    title: "图片尺寸",
    key: "size",
    options: [
      {
        label: '竖图(1024x1792)',
        value: '竖图',
      },
      {
        label: '宽图(1792x1024)',
        value: '宽图',
      },
      {
        label: '方图(1024x1024)',
        value: '方图',
      },
    ]
  },
  {
    title: "图片风格",
    key: "style",
    options: [
      {
        label: '鲜艳',
        value: '鲜艳'
      },
      {
        label: '自然',
        value: '自然'
      }
    ]
  },
  {
    title: "词汇过滤",
    key: "agent",
    options: [
      {
        label: '有agent',
        value: "有agent"
      },
      {
        label: '无agent',
        value: "无agent"
      }
    ]
  }
];

const FilterPanel = React.memo(({...props}) => {
  // console.log('FilterPanel render');
  const { setSelectedValues } = props;

  // 更新指定子组件的 selected 值
  function handleSelectedChange(key, value) {
    setSelectedValues((prev) => {
      const newValues = {...prev};
      newValues[key] = value;
      return newValues;
    });
  };

  return (
    <div className='mb-4 flex relative'>
      {
        optionsList.map(options => (
          <FilterRadio
            className="mr-4"
            key={options.key}
            title={options.title}
            options={options.options}
            onSelectedChange={(value) => handleSelectedChange(options.key, value)}
          />
        ))
      }
    </div>
  )
})

export default FilterPanel;