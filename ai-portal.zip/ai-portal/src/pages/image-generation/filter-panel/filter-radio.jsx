import { useState, useEffect } from 'react';
import { CloseOutlined } from '@ant-design/icons';
import { Button, Radio } from 'antd';
import classNames from 'classnames';
import Transition from '../../../utils/Transition';
import { set } from 'lodash';

function FilterRadio({...props}) {
  // console.log('FilterRadio render');
  
  const { options, onSelectedChange, title, className } = props;
  // 显示选择项
  const [visible, setVisible] = useState(false);
  // 选中状态
  const [selected, setSelected] = useState(options[0].value);

  useEffect(() => {
    onSelectedChange && onSelectedChange(selected);
  }, []);

  // getOptionsByValue
  const currentOption = options.find(item => item.value === selected);

  function handleChange(e) {
    const value = e.target.value;
    setVisible(false);
    setSelected(value);
    onSelectedChange && onSelectedChange(value);
  }

  return (
    <div className={className}>
      <div>
        <Button onClick={ () => setVisible(true) }>{title}: {currentOption.value}</Button>
        <Transition
          show={visible}
          tag="div"
          className="w-full origin-bottom-left absolute bottom-0 left-0 bg-white p-2 rounded shadow-lg z-10"
          enter="transition ease-out duration-10000"
          enterStart="opacity-0 scale-95"
          enterEnd="opacity-100 scale-100"
          leave="transition ease-out duration-200"
          leaveStart="opacity-100 scale-100"
          leaveEnd="opacity-0 scale-95"
        >
          <div className={classNames("transition-all bg-white overflow-hidden")}>
            <div className='mb-2 text-lg font-medium'>{title}</div>
            <Radio.Group
              block
              options={options}
              value={selected}
              optionType="button"
              onChange={handleChange}
            />
            <CloseOutlined className='absolute top-3 right-3 w-4 h-4 cursor-pointer z-10' onClick={ () => setVisible(false)  }/>
          </div>
        </Transition>
      </div>
    </div>
  )
}

export default FilterRadio;