// react-markdown
import "./index.css"
import { Input, Button } from 'antd';
import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { SendOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import PromptList from './PromptList';
import useChat from "../../hooks/use-chat";
import CompletionContainer from "../../components/chat-component/completion-container";
import ChatContainer from '../../components/chat-component/chat-container';
import LogoMat from '../../images/logo-mat.png'
import FilterPanel from "./filter-panel";
import { service } from "../../axios";
import { useUserContext } from "../../context/UserContext";
import useHistory from "../../hooks/use-history";

export default function CustomerBot({ ...props }) {
  // console.log('CustomerBot render');
  const { userInfo } = useUserContext();

  // 设置document.title
  useEffect(() => {
    document.title = '图像生成';
  }, []);

  const conv_uid = useRef(new Date().getTime())

  // 历史记录
  const { history, setHistory } = useHistory('image-generation');
  const [hasBody, setHasBody] = useState(() => history.length > 0);
  const [userInput, setUserInput] = useState('');
  const [selectedValues, setSelectedValues] = useState({});
  const [loading, setLoading] = useState(false);

  const handlePicChat = useCallback(
    (userInput, selectedValues) => {
      setLoading(true);
      if (!hasBody) setHasBody(true);
      logSubmit(userInput, selectedValues);

      return new Promise(async (resolve) => {
        const tempHistory = [
          ...history,
          { role: 'human', context: userInput, order: 0, time_stamp: 0 },
          { role: 'view', context: '', order: 0, time_stamp: 0 },
        ]
        const index = tempHistory.length - 1;
        // 添加 loading
        tempHistory[index].context = `<img-loading />`;
        setHistory([...tempHistory]);
        const imageUrl = await getData({
          prompt: userInput,
          ...selectedValues
        });
        if (!imageUrl) {
          tempHistory[index].context = `<img-error />`;
        } else {
          tempHistory[index].context = `<img src="${imageUrl}" />`;
        }
        setHistory([...tempHistory]);
        setLoading(false);
        resolve();
      })
    },
    [history]
  )

  // 埋点 记录submit 按钮
  async function logSubmit(userInput, selectedValues) {
    const data = {
      prompt: userInput,
      selected_values: JSON.stringify(selectedValues),
      user_info_uid: userInfo.uid,
      user_info_department_number: userInfo.departmentnumber
    }
    const res = await service.post("/image_generation_info", data);
    console.log(res);
  }

  // useEffect(() => {
  //   getData();
  // }, []);]

  async function getData(data) {
    const res = await service.post("/openapi/generate_images", data, {
      timeout: null
    }).catch(err => {
      // console.error(err);
      return "";
    });
    const imageUrl = res.data?.image_url;
    return imageUrl;
  }
  // // 是否有history
  // const hasBody = useMemo(() => {
  //   return history.length > 0;
  // }, [history]);

  return (
    <div className='w-full h-screen bg-slate-100 relative flex flex-col'>
      <header className='shrink-0 w-full bg-white relative shadow-md shadow-slate-200 z-10' style={{ height: '60px', padding: '0 40px' }}>
        <div className='flex items-center h-full'>
          <img src={LogoMat} style={{ width: '30px', height: '30px' }}></img>
          <span className='font-bold tracking-wider' style={{ marginLeft: '10px' }}>图像生成</span>
        </div>
      </header>
      <div className={classNames("flex flex-col flex-1 bg-slate-100 overflow-hidden", {
        "justify-center": !hasBody,
        "items-center": !hasBody
      })}>
        <ChatContainer hasBody={hasBody} history={history} title="图像生成！" description="基于Dall-E-3模型，包含图像生成和图像风格迁移" />
        <div className={classNames("shrink-0 p-4 rounded-t-xl", {
          "w-3/6": !hasBody,
          "bg-white": hasBody,
          "shadow-sm": hasBody
        })}>
          <div className={classNames("mb-4", {
            // "w-3/6": !hasBody
          })}>
            <PromptList />
          </div>
          {/* 筛选项 */}
          {/* <div className='flex justify-between items-center'>
          </div> */}
          <CompletionContainer
            maxLength={100}
            hasBody={hasBody}
            setUserInput={setUserInput}
            onSubmit={handlePicChat.bind(undefined, userInput, selectedValues)}
            loading={loading}
          >
            <FilterPanel setSelectedValues={setSelectedValues} />
          </CompletionContainer>
        </div>
      </div>
    </div>
  );
}