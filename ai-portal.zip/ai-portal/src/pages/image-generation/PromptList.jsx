import { RedoOutlined } from '@ant-design/icons';
import { useEffect, useState, useRef } from 'react';
import useIntervalCarousel from '../../hooks/use-interval-carousel';

const promptList = [
  {
    title: "提示输入",
    pormpts: ["光伏", "光伏板", "太阳能", "新能源"]
  },
  {
    title: "风景类",
    pormpts: ["湖边日落", "雪山全景", "沙漠绿洲", "海滩日出"]
  },
  {
    title: "人物类",
    pormpts: ["快乐厨师", "街头艺人", "深思学者", "运动员胜利"]
  },
  {
    title: "企业类",
    pormpts: ["现代办公室", "会议室讨论", "工厂车间", "商业街景观"]
  },
  {
    title: "科幻未来类",
    pormpts: ["星际飞船巡航", "未来城市夜景", "量子电脑实验室", "外星生态圆顶"]
  },
  {
    title: "神秘幻想类",
    pormpts: ["龙的洞穴宝藏", "魔法森林仙境", "水晶宫殿", "幻影城堡"]
  },
  {
    title: "超级英雄类",
    pormpts: ["高空中的超人", "夜行侠在城市", "闪电英雄赛跑", "时间旅行者"]
  },
  {
    title: "梦幻天空类",
    pormpts: ["北极光之舞", "星河涌动", "彩色星云", "末日彗星"]
  },
  {
    title: "深海奇观类",
    pormpts: ["水下城市", "珊瑚礁王国", "海底火山", "藏宝海盗船"]
  }
]

function PromptList() {
  
  const { currentIndex, start, stop, manualChange } = useIntervalCarousel(promptList.length, 3000);
  // 根据current 计算currentPrompt
  const currentPrompt = promptList[currentIndex];

  return (
    <div className='flex items-start'>
      <div className="flex flex-1 mr-2 text-base text-gray-400 flex overflow-x-hidden" onMouseEnter={stop} onMouseLeave={start}>
        <div className="mr-2 shrink-0">{currentPrompt.title}: </div>
        <div className='truncate'>{ currentPrompt.pormpts.join('、') }</div>
      </div>
      <div className="text-gray-300 flex cursor-pointer" onClick={manualChange}>
        <RedoOutlined className='mr-1'/>
        <div>换一批</div>
      </div>
    </div>

  )
}

export default PromptList;