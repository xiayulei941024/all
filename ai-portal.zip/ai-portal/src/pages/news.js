export const news = [
  {
    week: "1125-1201",
    week_title: "2024年11月第4期",
    anchor: "20241125",
    week_abs_long: {
      创投: "小马智行上市成Robotaxi第一股，月之暗面推出Kimi数学版。",
      新闻: "月之暗面Kimi与清华等开源大模型架构Mooncake，天工大模型4.0首发，Cursor 0.43引入Agent功能。",
      行业: "阿塞拜疆成功拍卖100 MW太阳能项目，秘鲁亚马逊地区建成两座离网太阳能+储能公园，科研人员设计出效率达30.22%的钙钛矿硅叠层太阳能电池。",
      论文: "通过LLM路由优化 SQL 生成。",
    },
  },
  {
    week: "1125-1201",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "小马智行纳斯达克挂牌上市，摘得Robotaxi第一股",
    abstract:
      "小马智行（Pony.ai）于11月27日在纳斯达克上市，股票代码“PONY”，成为全球Robotaxi第一股。公司计划以每股13美元发行2300万股ADS，融资额可达2.99亿美元，若超额配售权行使，IPO总募资额约4.52亿美元。小马智行自2018年推出Robotaxi服务，技术核心为“虚拟司机”，已与多家车企和出行平台合作，致力于推动自动驾驶技术商业化落地。",
    link: "https://mp.weixin.qq.com/s/T6iRLPjdEs9MmgCrUn5SfA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/LiveKit.png",
    source_name: "Pony.ai小马智行",
    publish_time: "2024-11-29 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "月之暗面Kimi 联合清华大学等机构，开源共建大模型推理架构 Mooncake",
    abstract:
      "月之暗面Kimi联合清华大学等机构推出了大模型推理架构 Mooncake，项目以KVCache为中心，通过以存换算理念减少算力开销，提升推理吞吐量。Mooncake可以提高大模型在处理任务时的效率和性能，提升推理速度、降低成本、满足处理长文本和高并发需求。就像是为AI模型提供了一个更高效、更省钱的“加速器”，让它们能更好地服务于各种应用，比如智能助手、数据分析等。",
    link: "https://mp.weixin.qq.com/s/NsKDtC7qp2JxA_EunwSqvg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/月之暗面.png",
    source_name: "月之暗面",
    publish_time: "2024-11-28 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "国产大模型首发中文逻辑推理，「天工大模型4.0」o1版来了",
    abstract:
      "昆仑万维推出了国内首款具备中文逻辑推理能力的大模型“天工大模型4.0”o1版（Skywork o1），包含三款模型，其中开源版本Skywork o1 Open参数为8B，显著提升数学和代码指标，并解锁了数学推理任务。Skywork o1 Lite和Preview版本展现了更快的推理速度和深度思考能力。",
    link: "https://mp.weixin.qq.com/s/iJo7Pc648nvY21dW2-uEuQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-27 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "科研人员利用异质结底部技术设计效率达30.22%的钙钛矿硅叠层太阳能电池",
    abstract:
      "一个国际研究小组开发了一种基于甲基取代咔唑和亚微米级纹理硅底部异质结电池并采用空穴传输层的钙钛矿硅叠层太阳能电池。他们提议的电池配置使用市售的Czochralski硅片，预计效率将超过30%。",
    link: "https://www.pv-magazine-china.com/2024/11/26/%e7%a7%91%e7%a0%94%e4%ba%ba%e5%91%98%e5%88%a9%e7%94%a8%e5%bc%82%e8%b4%a8%e7%bb%93%e5%ba%95%e9%83%a8%e6%8a%80%e6%9c%af%e8%ae%be%e8%ae%a1%e6%95%88%e7%8e%87%e8%be%be30-22%e7%9a%84%e9%92%99%e9%92%9b/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-26 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "月之暗面 Kimi 全量上线 k0-math 数学模型，正式推出“Kimi数学版”",
    abstract:
      "据科技自媒体沃垠AI报道，Kimi 全量上线 k0-math 数学模型，正式推出“Kimi数学版”，采用Self-play RL强化学习和Cot思维链技术，擅长解决数学和推理问题，智力程度可比博士。Kimi数学版能理解模糊表达，进行推理或运算，实测9个问题表现出色，包括自媒体粉丝增长计算、双色球中奖概率等。Kimi数学版在MATH测试中得分93.8，超过o1-mini、o1-preview。",
    link: "https://mp.weixin.qq.com/s/yuRCeyhIO8lHgVHkvWYdKw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/LiveKit.png",
    source_name: "沃垠AI",
    publish_time: "2024-11-26 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "阿塞拜疆以每千瓦时0.0354美元的最低价格成功拍卖100 MW太阳能项目",
    abstract:
      "寰泰能源股份有限公司在阿塞拜疆首次可再生能源拍卖中以每千瓦时0.0354美元的最低报价，获得了在阿塞拜疆东部建设100 MW太阳能项目的合同。",
    link: "https://www.pv-magazine-china.com/2024/11/25/%e9%98%bf%e5%a1%9e%e6%8b%9c%e7%96%86%e4%bb%a5%e6%af%8f%e5%8d%83%e7%93%a6%e6%97%b60-0354%e7%be%8e%e5%85%83%e7%9a%84%e6%9c%80%e4%bd%8e%e4%bb%b7%e6%a0%bc%e6%88%90%e5%8a%9f%e6%8b%8d%e5%8d%96100-mw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-25 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "秘鲁亚马逊地区两座离网太阳能+储能公园落成",
    abstract:
      "这些位于洛雷托大区的站点隶属于Electro Oriente公司，总发电容量为9.6 MWp，储能容量为13.5 MWp，由Amazonas Energía Solar公司承建。",
    link: "https://www.pv-magazine-china.com/2024/11/25/%e7%a7%98%e9%b2%81%e4%ba%9a%e9%a9%ac%e9%80%8a%e5%9c%b0%e5%8c%ba%e4%b8%a4%e5%ba%a7%e7%a6%bb%e7%bd%91%e5%a4%aa%e9%98%b3%e8%83%bd%e5%82%a8%e8%83%bd%e5%85%ac%e5%9b%ad%e8%90%bd%e6%88%90/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-25 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Cursor 0.43版本引入 Agent 功能：全面理解并编辑项目，自动完成任务",
    abstract:
      "AI编程工具 Cursor 发布了0.43版本，引入了Composer Agent功能，具备项目理解与编辑能力，自动执行代码任务。同时推出Bug Finder功能，帮助提前修复代码问题。版本还包括语义搜索、文件推荐等改进，提升开发效率和体验。",
    link: "https://www.jiqizhixin.com/articles/2024-11-25-6",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-25 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过LLM路由优化 SQL 生成",
    abstract:
      "文本到 SQL 使用户能够通过自然语言与数据库交互，从而简化对结构化数据的访问。尽管功能强大的大型语言模型 ( LLMs ) 对复杂查询具有很高的准确性，但对于较简单的查询，它们会带来不必要的延迟和金钱成本。在本文中，我们介绍了第一个用于文本到 SQL 的LLM路由方法，该方法动态选择能够为每个查询生成准确 SQL 的最具成本效益的LLM。",
    link: "http://arxiv.org/abs/2411.04319",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-11-06 00:00:00",
  },
  {
    week: "1125-1201",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "Crystal：阐明LLM在语言和代码方面的能力",
    abstract:
      "专门从事代码生成的大型语言模型 ( LLMs )（通常也称为代码LLMs ），例如 StarCoder 和 Code Llama，在各种软件开发场景中发挥着越来越重要的作用。对于代码LLMs来说，对于许多特定应用程序（例如使用自然语言或代码解释进行代码片段检索）同时具备代码生成和自然语言能力也至关重要。获取语​​言和编码技能之间错综复杂的相互作用使强大的代码LLMs的开发变得复杂。",
    link: "http://arxiv.org/abs/2411.04156",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-11-06 00:00:00",
  },
  {
    week: "1118-1124",
    week_title: "2024年11月第3期",
    anchor: "20241118",
    week_abs_long: {
      新闻: "谷歌、腾讯和阿里在AI领域取得重大突破，分别在模型性能和平台技术上领先。",
      创投: "马斯克xAI融资355亿买英伟达GPU，闪极科技获数千万元A轮融资，12月发布AI拍摄眼镜。",
      行业: "巴西提高太阳能组件进口关税至25%，Thornova Solar在印尼启动生产，法国要求停车场安装太阳能。",
      论文: "穿针引线： LLMs能否在近百万规模的大海捞针中追踪线索？",
    },
  },
  {
    week: "1118-1124",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "谷歌 Gemini 突发试验版模型：重回竞技榜第一，新版 GPT-4o 只领先了 1 天",
    abstract:
      "谷歌与OpenAI的竞争升级，谷歌发布Gemini-Exp-1121模型，超越OpenAI的GPT-4o重回竞技榜第一。Gemini-Exp-1121在代码、推理和视觉理解能力上均有显著提升，性能全面领先。同时，OpenAI在ChatGPT测试版中被发现有“实时摄像”视频功能代码，预示着未来交流方式可能转向语音和视觉识别。",
    link: "https://mp.weixin.qq.com/s/j3WLx1tt3ahD53bRlHsZjg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-11-22 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "估值超3500亿！马斯克xAI又融资355亿，用于买英伟达GPU",
    abstract:
      "特斯拉CEO埃隆·马斯克的xAI公司在最新一轮融资中筹集了50亿美元，估值达到500亿美元。新资金将用于购买10万块英伟达芯片，扩大其AI数据中心。xAI的核心产品 Grok 聊天机器人年化收入已达1亿美元，计划12月推出更强大的Grok-3版本。",
    link: "https://zhidx.com/p/455971.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-11-21 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "闪极科技获数千万元A轮融资，新品AI拍摄眼镜将于12月19日发布",
    abstract:
      "「闪极科技」完成数千万元人民币A轮融资，光远投资领投，未来光锥前沿科技基金和云天励飞跟投。资金将用于新品“闪极AI拍摄眼镜”的市场拓展、技术研发及人才建设。该产品将于12月19日发布，主打持久续航、高清拍摄、影音质感及AI能力。",
    link: "https://mp.weixin.qq.com/s/XprfhqFPyv7w0GA0xgHIVA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/LiveKit.png",
    source_name: "智能涌现",
    publish_time: "2024-11-20 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "腾讯Angel机器学习平台获世界互联网大会领先科技奖",
    abstract:
      "2024年世界互联网大会领先科技奖在乌镇发布，腾讯Angel机器学习平台获得本年度领先科技奖。腾讯Angel机器学习平台突破了万亿级模型分布式训练和推理以及大规模应用部署等难题，率先实现大模型技术从底层硬件到关键软件技术的自主研发，在业务场景广泛应用，显著推动实体产业和数字经济发展，提升社会效率。",
    link: "https://zhidx.com/news/42358.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-11-20 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "法国发布新规强制要求停车场安装太阳能",
    abstract:
      "法国已颁布新规定，要求在停车场安装太阳能装置，并详细说明了计算方法、豁免情况和违规罚款。",
    link: "https://www.pv-magazine-china.com/2024/11/20/%e6%b3%95%e5%9b%bd%e5%8f%91%e5%b8%83%e6%96%b0%e8%a7%84%e5%bc%ba%e5%88%b6%e8%a6%81%e6%b1%82%e5%81%9c%e8%bd%a6%e5%9c%ba%e5%ae%89%e8%a3%85%e5%a4%aa%e9%98%b3%e8%83%bd/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-20 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "Thornova Solar在印度尼西亚启动太阳能电池和组件生产",
    abstract:
      "Thornova Solar已开始在印度尼西亚生产太阳能电池和组件。首席执行官William Sheng表示，此举符合不断变化的美国市场法规。该公司计划在2025年中期之前从印度尼西亚、老挝或美国向客户供应电池和组件。",
    link: "https://www.pv-magazine-china.com/2024/11/20/thornova-solar%e5%9c%a8%e5%8d%b0%e5%ba%a6%e5%b0%bc%e8%a5%bf%e4%ba%9a%e5%90%af%e5%8a%a8%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e5%92%8c%e7%bb%84%e4%bb%b6%e7%94%9f%e4%ba%a7/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-20 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "阿里发布 Qwen2.5-Turbo：支持百万超长上下文，性能提升显著",
    abstract:
      "阿里通义Qwen2.5系列更新，新增 Qwen2.5-Turbo 支持百万超长上下文，性能提升显著。上下文长度扩展至1M tokens，推理速度提升4.3倍，成本仅为0.3元/1M tokens。在长文本任务中，Qwen2.5-Turbo超越GPT-4o-mini，且短文本性能不减。模型已在HuggingFace和魔搭社区提供Demo，API服务上线阿里云平台。",
    link: "https://www.qbitai.com/2024/11/220926.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-11-19 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "行业",
    effect: "负面",
    color: "#108ee9",
    title: "巴西将太阳能组件的进口关税从9.6%提高至25%",
    abstract:
      "巴西光伏协会ABSolar表示，巴西政府决定将太阳能组件的进口关税从9.6%提高至25%，这可能会减缓该国的能源转型，并对正在进行的项目产生负面影响。",
    link: "https://www.pv-magazine-china.com/2024/11/18/%e5%b7%b4%e8%a5%bf%e5%b0%86%e5%a4%aa%e9%98%b3%e8%83%bd%e7%bb%84%e4%bb%b6%e7%9a%84%e8%bf%9b%e5%8f%a3%e5%85%b3%e7%a8%8e%e4%bb%8e9-6%e6%8f%90%e9%ab%98%e8%87%b325/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-18 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "穿针引线： LLMs能否在近百万规模的大海捞针中追踪线索？",
    abstract:
      "随着大型语言模型 ( LLMs ) 的上下文限制的增加，可能的应用程序和下游功能的范围也在扩大。在许多现实世界的任务中，决策取决于分散在通常包含不相关信息的不同文档集合中的细节。长上下文LLMs似乎非常适合这种形式的复杂信息检索和推理，而传统上这被证明是昂贵且耗时的。然而，尽管近年来较长上下文模型的发展取得了快速进展，但我们对LLMs如何有效利用其上下文的理解却没有跟上。为了解决这个问题，我们进行了一组检索实验。",
    link: "http://arxiv.org/abs/2411.05000",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-11-07 00:00:00",
  },
  {
    week: "1118-1124",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLM2CLIP：强大的语言模型解锁更丰富的视觉表示",
    abstract:
      "CLIP 是当今最重要的多模式基础模型之一。 CLIP 的功能有哪些？人类知识的载体自然语言提供的丰富监督信号塑造了强大的跨模态表示空间。然而，随着 GPT-4 和 LLaMA 等大型语言模型LLMs快速进步，语言理解和生成的界限不断被突破。这就提出了一个有趣的问题：能否利用LLMs的能力来进一步改进多模式表示学习？将LLMs纳入 CLIP 的潜在好处是显而易见的。 LLMs强大的文本理解能力可以从根本上提高 CLIP 处理图像标题的能力，极大地增强其处理长而复杂文本的能力，这是普通 CLIP 众所周知的限制。",
    link: "http://arxiv.org/abs/2411.04997",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-11-07 00:00:00",
  },
  {
    week: "1111-1117",
    week_title: "2024年11月第2期",
    anchor: "20241111",
    week_abs_long: {
      创投: "讯飞星火多模态交互大模型上线，OpenAI大改下代模型方向引发AI社区热议。",
      新闻: "灵宝CASBOT发布全尺寸双足人形机器人“星期三”，彩云科技推出AI小说生成模型，Meissonic发布新图像生成模型。",
      行业: "土耳其启动800 MW光伏项目招标，巴西预计到2040年增加18.2 GW储能容量。",
      论文: "LLMs在接受快速思维与慢速思维训练时会发生什么：梯度视角。",
    },
  },
  {
    week: "1111-1117",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "讯飞星火多模态交互大模型上线，数字人/语音/视觉支持一键全调用",
    abstract:
      "讯飞星火多模态交互大模型正式上线，实现语音、视觉、数字人交互三合一，支持一键调用。模型首发超拟人数字人技术，能精准匹配语音内容生成表情动作，实现跨模态语义一致性，AI情感表达真实连贯。同时支持多模态视觉交互，能全面感知背景场景、物流状态等信息。",
    link: "https://mp.weixin.qq.com/s/3byEiMJFmXOpcXAXFciUBA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/科大讯飞.png",
    source_name: "讯飞开放平台",
    publish_time: "2024-11-15 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "灵宝CASBOT发布首款全尺寸双足人形机器人“CASBOT 01”，昵称“星期三”",
    abstract:
      "灵宝CASBOT发布首款全尺寸双足人形机器人“CASBOT 01”，昵称“星期三”。这款通用类脑智能机器人身高179cm，体重60kg，拥有52个自由度，算力达550T，续航超4小时，能执行多种精细操作。标志着人形机器人赛道迎来新入局者，预计到2030年市场规模将达千亿元。",
    link: "https://www.jiqizhixin.com/articles/2024-11-14",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-14 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "0提示词就能续写小说！彩云科技首创DCFormer架构大模型，AI秒变网文产粮神器",
    abstract:
      "今日，在“From Paper to App”媒体沟通会上，AI技术公司彩云科技正式推出首款基于DCFormer架构开发的通用大模型“云锦天章”，旗下AI RPG平台“彩云小梦”也成为首款基于DCFormer架构开发的AI产品。",
    link: "https://zhidx.com/p/454971.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-11-14 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "到2040年，巴西将增加18.2 GW储能容量",
    abstract:
      "这个数字需要激励、监管和雄心。拉丁美洲清洁能源咨询公司（CELA）的一项研究估计，到2040年，巴西储能市场将以每年至少12.8%的速度增长，累计达到7.2 GW，不包括用户侧“电表后端”安装。",
    link: "https://www.pv-magazine-china.com/2024/11/13/%e5%88%b02040%e5%b9%b4%ef%bc%8c%e5%b7%b4%e8%a5%bf%e5%b0%86%e5%a2%9e%e5%8a%a018-2-gw%e5%82%a8%e8%83%bd%e5%ae%b9%e9%87%8f/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-13 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "端侧非自回归图像生成基础模型Meissonic登场，超越SDXL",
    abstract:
      "Meissonic，一种新型端侧非自回归图像生成模型，其高效、高分辨率的图像生成能力超越了SDXL。该模型通过增强型Transformer架构、先进的位置编码和特征压缩层等技术改进，在图像质量和细节上与领先扩散模型相媲美。Meissonic在8GB显存下即可运行，为中低端显卡用户提供了便利，同时展现了强大的zero-shot图像编辑能力。",
    link: "https://mp.weixin.qq.com/s/pYZxK3OFV8CH4VQET4_rLg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/新智元.png",
    source_name: "新智元",
    publish_time: "2024-11-12 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "土耳其启动800 MW光伏项目招标",
    abstract:
      "土耳其能源和自然资源部已针对六个拟议项目启动一项800 MW的太阳能招标活动。投标申请截止日期为2025年1月27日。",
    link: "https://www.pv-magazine-china.com/2024/11/12/%e5%9c%9f%e8%80%b3%e5%85%b6%e5%90%af%e5%8a%a8800-mw%e5%85%89%e4%bc%8f%e9%a1%b9%e7%9b%ae%e6%8b%9b%e6%a0%87/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-12 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "OpenAI大改下代大模型方向，scaling law撞墙？AI社区炸锅了",
    abstract:
      "OpenAI可能正在调整其大模型发展策略，因为最新旗舰模型Orion性能提升不如预期，且面临数据储量耗尽问题。AI行业正转向训练后模型改进，探索新的scaling laws。OpenAI内部对此有争议，一些研究者认为AI发展不会放缓，而其他人则看到了性能提升的递减趋势。",
    link: "https://mp.weixin.qq.com/s/0SXPOvFPFo4f7rphxbUuwA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-12 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLM目标劫持的伪会话注入",
    abstract:
      "目标劫持是对大型语言模型 ( LLMs ) 的一种对抗性攻击，其目标是操纵模型产生特定的预定输出，而不管用户的原始输入如何。在目标劫持中，攻击者通常会在用户的提示中附加精心设计的恶意后缀，这会强制模型忽略用户的原始输入并生成目标响应。在本文中，我们介绍了一种称为伪对话注入的新型目标劫持攻击方法，该方法利用了LLMs在对话上下文中角色识别方面的弱点。",
    link: "http://arxiv.org/abs/2410.23678",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1111-1117",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLMs在接受快速思维与慢速思维训练时会发生什么：梯度视角",
    abstract:
      "LLMs的后训练有何不同？当使用不同的响应和初始模型进行训练时，我们通过梯度的视角研究了大型语言模型（ LLMs ）中不同层的训练模式。鉴于最近在思维链 (CoT) 和过程奖励等推理路径上训练LLMs的流行，我们特别感兴趣的是快思维与慢思维对分层梯度的影响。在我们的研究中，没有CoT的快速思维比慢速思维（Detailed CoT）导致更大的梯度和更大的跨层梯度差异，表明后者带来的学习稳定性。",
    link: "http://arxiv.org/abs/2410.23743",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1104-1110",
    week_title: "2024年11月第1期",
    anchor: "20241104",
    week_abs_long: {
      新闻: "小鹏AI机器人投入使用，王慧文回归美团探索AI，Perplexity CEO表示AI产品多元变现，API成本下降。",
      行业: "达摩院发布高精度气象模型，阿根廷启动200 MW太阳能项目，英国电网目标2030年实现47 GW太阳能装机容量。",
      创投: "昆仑万维发布天工AI高级搜索功能，15岁山东初中生任CTO，其开源项目被数百万元收购。",
      论文: "GigaCheck：检测LLM生成的内容。",
    },
  },
  {
    week: "1104-1110",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "小鹏AI机器人来了！身高1米8，用上大模型，已进厂拧螺丝",
    abstract:
      "小鹏汽车在AI科技日上发布了AI机器人Iron，这款1.8米高的机器人拥有62个自由度，手部灵活且具备触觉反馈。采用了小鹏自研的图灵AI芯片和天玑AIOS，已在小鹏广州工厂投入生产小鹏P7+。Iron的设计考虑了人类生理特征，提高用户和社会的接受度。",
    link: "https://mp.weixin.qq.com/s/gw2B8mGDtOrGUzke0h-81A",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/LiveKit.png",
    source_name: "机器人前瞻",
    publish_time: "2024-11-07 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "达摩院发布八观气象大模型：精度达1小时1公里，率先落地新能源场景",
    abstract:
      "阿里巴巴达摩院发布八观气象大模型，时空精度达1小时1公里，提升新能源电力系统预测性能。模型融合多源数据，提高辐照度、风速等气象指标预测精度，助力国网山东电力调控中心应对极端天气，提升新能源发电功率和电力负荷预测准确率至96%和98%以上。",
    link: "https://www.jiqizhixin.com/articles/2024-11-06-9",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-06 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "英国电网运营商呼吁到2030年实现47 GW太阳能装机容量，年均部署4.6 GW",
    abstract:
      "英国国家能源系统运营商（NESO）发布了向英国政府提出的《2030年清洁电力建议》，陈述英国电力系统到2030年实现脱碳的多个途径。该建议呼吁将部署速度提高三倍，以实现清洁能源目标。",
    link: "https://www.pv-magazine-china.com/2024/11/06/%e8%8b%b1%e5%9b%bd%e7%94%b5%e7%bd%91%e8%bf%90%e8%90%a5%e5%95%86%e5%91%bc%e5%90%81%e5%88%b02030%e5%b9%b4%e5%ae%9e%e7%8e%b047-gw%e5%a4%aa%e9%98%b3%e8%83%bd%e8%a3%85%e6%9c%ba%e5%ae%b9%e9%87%8f%ef%bc%8c/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-06 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "消息称王慧文回归美团，带队独立探索 AI 应用",
    abstract:
      "《智能涌现》今日援引多个独立信源报道，原美团联合创始人、光年之外创始人王慧文如今已经回归，在美团带队探索 AI 应用。王慧文所在的美团 AI 团队被称为 GN06。该团队目前的主要业务方向包括情感陪伴、聊天机器人等。GN06的主要产品之一，是在2023年11月上线的AI情感陪伴产品Wow。",
    link: "https://mp.weixin.qq.com/s/gWfH-oj_Z-aiISSybzxSjg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/LiveKit.png",
    source_name: "智能涌现",
    publish_time: "2024-11-06 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "昆仑万维重磅发布天工AI高级搜索功能，做最懂金融投资、科研学术的AI搜索",
    abstract:
      "昆仑万维集团发布天工AI高级搜索功能，提供金融投资和科研学术领域的专业搜索体验。通过升级推理能力、金融投资和科研学术专业搜索，以及文档AI阅读分析的优化，实现精准、高效的问题解答。",
    link: "https://mp.weixin.qq.com/s/Dwa1eFfISYW9tZbY0A1wHw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/昆仑万维集团.png",
    source_name: "昆仑万维",
    publish_time: "2024-11-05 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "Perplexity CEO 最新洞察：AI 产品除订阅还有许多变现路径，API 成本每半年减少 50%，未来将专注增长",
    abstract:
      "Perplexity CEO 在TechCrunch Disrupt上讨论了AI搜索的未来和产品策略。他强调 Perplexity 将根据用户需求开发功能，替代传统搜索引擎。商业化方面，他提到AI行业运营成本高昂，但API成本正下降，Perplexity将探索灵活的广告变现模式，并推出Perplexity Publisher Program，通过广告收入分享和定制AI助手，帮助媒体和内容创作者参与AI搜索生态。",
    link: "https://mp.weixin.qq.com/s/TvITwN9rS69SoQlzFPX6Xg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-11-05 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "阿根廷200 MW太阳能项目开工建设",
    abstract:
      "总部位于智利的可再生能源开发商Verano Energy已开始在阿根廷西部建设一个200 MW的太阳能项目。安装和连接工作预计将于2025年底前完成。",
    link: "https://www.pv-magazine-china.com/2024/11/04/%e9%98%bf%e6%a0%b9%e5%bb%b7200-mw%e5%a4%aa%e9%98%b3%e8%83%bd%e9%a1%b9%e7%9b%ae%e5%bc%80%e5%b7%a5%e5%bb%ba%e8%ae%be/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-11-04 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "15岁山东初中生做CTO，开源项目刚刚被数百万元收购了",
    abstract:
      "15岁山东初中生zmh成为CTO，其开源项目ChatNio被数百万元收购。项目集成了多个AI模型，提供全面服务，包括chatbot、图像生成等，并以高性价比获得超过10万月活用户，实现每月约5万净利润。zmh虽年轻，但已拥有7年项目开发经验，技能涵盖全栈开发、网络安全等领域。",
    link: "https://mp.weixin.qq.com/s/qdXnBoMV4u2r-abUSnFReA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-11-04 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "GigaCheck：检测LLM生成的内容",
    abstract:
      "随着LLM助理的质量不断提高和传播，人工生成的内容数量正在迅速增长。在许多情况和任务中，此类文本已经与人类编写的文本没有区别，并且生成的质量往往只会提高。与此同时，检测方法的发展速度越来越慢，这使得防止这些技术的滥用变得具有挑战性。在这项工作中，我们通过提出 GigaCheck 来研究生成文本检测的任务。我们的研究探索了两种方法：（i）区分人类编写的文本和LLM生成的文本，以及（ii）检测人机协作文本中LLM生成的间隔。",
    link: "http://arxiv.org/abs/2410.23728",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1104-1110",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "社会科学遇见LLMs ：社会模拟中的大型语言模型有多可靠？",
    abstract:
      "大型语言模型 ( LLMs ) 越来越多地用于模拟，从而能够在角色扮演代理和计算社会科学 (CSS) 中应用。然而，这些模拟的可靠性尚未得到充分探索，这引起了人们对这些应用中LLMs的可信度的担忧。在本文中，我们的目标是回答“基于LLM的模拟有多可靠？”为了解决这个问题，我们引入了TrustSim，一个涵盖10个CSS相关主题的评估数据集，以系统地研究LLM模拟的可靠性。",
    link: "http://arxiv.org/abs/2410.23426",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-30 00:00:00",
  },
  {
    week: "1028-1103",
    week_title: "2024年10月第4期",
    anchor: "20241028",
    week_abs_long: {
      创投: "智谱AI拟投资15亿元效仿OpenAI；BP完成收购Lightsource业务。",
      新闻: "知乎、OpenAI、百川智能分别推出新功能和解决方案，提升知识获取与商业化效率。",
      行业: "苹果推出搭载M4 Max芯片的AI PC，续航达24小时；新型清洁工具提升钙钛矿和有机光伏设备生产；数字化解决太阳能电池板供应问题。",
      论文: "隐藏的说服者： LLMs的政治倾向及其对选民的影响。",
    },
  },
  {
    week: "1028-1103",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "首关15亿元，中国大模型独角兽智谱AI要学美国OpenAI当基金LP",
    abstract:
      "智谱边找钱、边撒钱，当起“攒局者”。截至目前，智谱Z计划已累计链接1200+大模型初创项目，其中投资超过20家、孵化超过30家企业。11月1日消息，国内大模型独角兽公司智谱AI宣布，领衔并联合石景山现代创新产业发展基金、奥飞数据、燕北资本、复琢投资等设立的风险投资基金“Z基金”（智谱生态基金）于近期完成首关，管理规模15亿元人民币，投资方向主要覆盖大模型赛道，侧重早期。",
    link: "https://mp.weixin.qq.com/s/I1JXXvXi8wgAh_ha9Zi4PQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/钛媒体.png",
    source_name: "钛媒体",
    publish_time: "2024-11-01 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "知乎直答新功能上线，「专业搜索」带来更高效的知识获取方式",
    abstract:
      "知乎AI搜索产品知乎直答正式上线“专业搜索”功能，引入维普、知乎精选等专业内容源，涵盖超过5000万篇中英文文献数据，极大满足广大用户对于高质量信息的需求。同时，知乎直答“专业搜索”支持文件上传和超长文件解析，并针对提供单篇精读、指定来源问答等功能，更加契合专业人士的生产力场景。",
    link: "https://mp.weixin.qq.com/s/NE5qLyp-0NI6NuQDKDcebw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/知乎日报.png",
    source_name: "知乎日报",
    publish_time: "2024-11-01 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "正式挑战谷歌！OpenAI上线ChatGPT搜索功能",
    abstract:
      "搜索功能先上线付费版ChatGPT Plus和Team，未来几个月内面向所有免费用户；搜索模型为GPT-4o微调版本，后训练得到o1-preview输出支持；ChatGPT可根据用户询问搜索网络，用户也可点击搜索图标手动搜索；提供天气、体育比赛、股票、地图等搜索信息，聊天时得到的搜索信息提供来源侧边栏。",
    link: "https://wallstreetcn.com/articles/3732593",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-11-01 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "隐藏的说服者： LLMs的政治倾向及其对选民的影响",
    abstract:
      "LLMs如何影响我们的民主？我们通过在美国总统选举背景下进行多项实验来调查LLMs的政治倾向以及LLMs对选民的潜在影响。通过投票模拟，我们首先展示了 18 名开放权重和封闭权LLMs对民主党提名人而非共和党提名人的政治偏好。通过分析他们对候选人政策相关问题的回答，我们展示了与基本版本相比，在指令调整模型中这种对民主党候选人的倾向如何变得更加明显。我们通过对 935 名美国登记选民进行实验，进一步探讨LLMs对选民选择的潜在影响。",
    link: "http://arxiv.org/abs/2410.24190",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "苹果最强AI PC登场！首搭M4 Max芯片，续航飙到24小时",
    abstract:
      "苹果M4系列MacBook Pro终于来了！与上一代相比，新款MacBook Pro的外观几乎没有变化，价格仍为12999元起。其中的重点更新就是全系搭载M4系列芯片、支持苹果AI，并首搭雷雳5接口、纳米纹理显示屏以及支持视频人物居中的1200万像素前置摄像头，续航最长达到24小时，30分钟就能充一半电。",
    link: "https://zhidx.com/p/452870.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "百川智能推出一站式大模型商业化解决方案",
    abstract:
      "百川智能推出一站式大模型商业化解决方案，即1+3产品矩阵（全链路优质通用训练数据，Baichuan4-Turbo、Baichuan4-Air两款模型和全链路领域增强工具链），该方案支持企业将专有数据与百川智能自用的全链路训练数据混合，对Baichuan4-Turbo、Baichuan4-Air两款模型进行调优和增强，实现了96%多场景可用率。",
    link: "https://zhidx.com/news/42331.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLMs在医学教育中的潜力：为资格考试生成问题和答案",
    abstract:
      "最近对大语言模型（ LLMs ）的研究主要集中在它们在专业领域的适应和应用。 LLMs在医疗领域的应用主要集中在医疗报告生成、总结、诊断推理以及医患互动问答等自动化任务上。成为一名好老师的挑战比成为一名好学生的挑战更加艰巨，这项研究开创了LLMs在医学教育领域的应用。在这项工作中，我们调查了LLMs可以根据几次提示生成医学资格考试问题和相应答案的程度。",
    link: "http://arxiv.org/abs/2410.23769",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-31 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "用于钙钛矿、有机光伏卷对卷生产设备的新型清洁工具",
    abstract:
      "一个德国研究小组开发了一种高精度的清洁工艺，用于去除钙钛矿和有机太阳能光伏卷对卷生产线电极上的毛刺。该清洁系统可集成在德国Acp系统公司的商用设备上。",
    link: "https://www.pv-magazine-china.com/2024/10/29/%e7%94%a8%e4%ba%8e%e9%92%99%e9%92%9b%e7%9f%bf%e3%80%81%e6%9c%89%e6%9c%ba%e5%85%89%e4%bc%8f%e5%8d%b7%e5%af%b9%e5%8d%b7%e7%94%9f%e4%ba%a7%e8%ae%be%e5%a4%87%e7%9a%84%e6%96%b0%e5%9e%8b%e6%b8%85%e6%b4%81/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-29 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "行业",
    effect: "负面",
    color: "#108ee9",
    title: "以数字化应对太阳能电池板供应挑战",
    abstract:
      "自2023年10月以来，高利率、库存过剩和组件价格下跌为太阳能分销商们创造了一场完美的风暴。BayWa re太阳能贸易公司首席执行官Frank Jessel解释了光伏行业应如何接受真正的数字化，以更好地应对这种波动。",
    link: "https://www.pv-magazine-china.com/2024/10/29/%e4%bb%a5%e6%95%b0%e5%ad%97%e5%8c%96%e5%ba%94%e5%af%b9%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e6%9d%bf%e4%be%9b%e5%ba%94%e6%8c%91%e6%88%98/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-29 00:00:00",
  },
  {
    week: "1028-1103",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "BP公司完成对Lightsource业务的收购",
    abstract:
      "油气巨头BP公司收购了Lightsource BP 50.03%的股权，该交易使BP公司实现了对该可再生能源开发商的完全控股。Lightsource BP预计将继续以独立运营模式进行交易，并保留其独立品牌。",
    link: "https://www.pv-magazine-china.com/2024/10/29/bp%e5%85%ac%e5%8f%b8%e5%ae%8c%e6%88%90%e5%af%b9lightsource%e4%b8%9a%e5%8a%a1%e7%9a%84%e6%94%b6%e8%b4%ad/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-29 00:00:00",
  },
  {
    week: "1021-1027",
    week_title: "2024年10月第3期",
    anchor: "20241021",
    week_abs_long: {
      新闻: "MiniMax发布对标GPT-4o的语音API，智谱与中国三星合作AI手机，北京新增12款生成式AI服务。",
      创投: "Anthropic发布Claude 3.5 Sonnet模型，Perplexity计划融资5亿美元。",
      行业: "晶科能源、天合光能称TOPCon组件优于p型背接触式电池板; 加州农民计划20 GW太阳能+储能; 土耳其目标2025年底太阳能装机22.6 GW。",
      论文: "LLMs比报告的更好吗？检测标签错误并减轻其对模型性能的影响。",
    },
  },
  {
    week: "1021-1027",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "MiniMax将于11月发布首款对标GPT-4o的端到端实时语音对话API产品",
    abstract:
      "AI 大模型领域的独角兽MiniMax将于今年11月发布对标GPT-4o的Realtime API服务，将提升端到端实时多模态处理能力，并带来更低延时、更自然、更沉浸的实时语音对话，为企业协作、社交、直播、游戏等多种场景提供服务。内部正在打磨这款产品，并非常希望11月发布时产品效果直接对标OpenAI GPT-4o。",
    link: "https://mp.weixin.qq.com/s/-Kzn8S6ZgU_4ptXBrtCthw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/钛媒体.png",
    source_name: "钛媒体",
    publish_time: "2024-10-25 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "智谱与中国三星官宣战略合作：AI 手机与 GLM 大模型相结合",
    abstract:
      "中国三星与智谱华章（简称“智谱”）昨日宣布战略合作，双方称将在 AI 手机领域展开深度共创，共同打造卓越体验的 AI 产品。近期高通宣布与智谱合作，为骁龙 8 至尊版适配优化 GLM-4V 端侧视觉大模型，支持丰富的多模态交互方式。",
    link: "https://mp.weixin.qq.com/s/U6HgOO11_NlIacqGNc2PoA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/chatglm.png",
    source_name: "智谱AI",
    publish_time: "2024-10-24 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "从LLMs到MLLM提取视觉图表推理能力",
    abstract:
      "解决复杂的图表问答任务需要多模态大型语言模型（MLLM）中的高级视觉推理能力。最近的研究表明，这些能力主要由两部分组成：从视觉输入中识别关键信息和进行推理。因此，一种有前途的方法来提高MLLM是构建相关的训练数据集中在这两个方面。然而，收集和注释复杂的图表和问题是昂贵和耗时的，确保注释答案的质量仍然是一个挑战。在本文中，我们提出了代码作为中介翻译（CIT），一个具有成本效益的，高效的，易于扩展的数据合成方法提取视觉推理能力从LLMs到MLLM。",
    link: "http://arxiv.org/abs/2410.18798",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-24 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLMs比报告的更好吗？检测标签错误并减轻其对模型性能的影响",
    abstract:
      "NLP基准依赖于标准化的数据集来训练和评估模型，对于推进该领域的发展至关重要。传统上，专家注释确保高质量的标签;然而，专家注释的成本并不能很好地与现代模型所需的更大数据集的需求增长相匹配。虽然众包提供了一个更具可扩展性的解决方案，但它往往以牺牲注释的精度和一致性为代价。大型语言模型（LLMs）的最新进展为增强注释过程提供了新的机会，特别是用于检测现有数据集中的标签错误。在这项工作中，我们考虑了最近的LLM作为一个法官的方法，利用LLMs合奏标记潜在的错误标记的例子。",
    link: "http://arxiv.org/abs/2410.18889",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-24 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "土耳其设定目标：到2025年底太阳能装机容量达到22.6 GW",
    abstract:
      "土耳其能源和自然资源部2025年预算提案设定了到明年年底安装22.6 GW太阳能的目标，高于今年的约18.8 GW。该部还计划增加国内资源在电力生产中的份额，同时减少天然气份额。",
    link: "https://www.pv-magazine-china.com/2024/10/23/%e5%9c%9f%e8%80%b3%e5%85%b6%e8%ae%be%e5%ae%9a%e7%9b%ae%e6%a0%87%ef%bc%9a%e5%88%b02025%e5%b9%b4%e5%ba%95%e5%a4%aa%e9%98%b3%e8%83%bd%e8%a3%85%e6%9c%ba%e5%ae%b9%e9%87%8f%e8%be%be%e5%88%b022-6-gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-23 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Anthropic 推出升级版 Claude 3.5 Sonnet 模型，可操控用户电脑",
    abstract:
      "Claude 发布新版本的 3.5 Sonnet 和新发布的 3.5 Haiku，能力都有大进步。这次 Claude 发布了一个重磅新功能——一个新的「计算机使用」API，该模型可以模拟按键、按钮点击和鼠标动作，实质上模拟了一个人坐在电脑前的操作。开发者现在可以通过 API 指导 Claude 像人类一样操作计算机, 包括观察屏幕、移动鼠标、点击按钮和输入文字。",
    link: "https://mp.weixin.qq.com/s/HBB3L5WswYQ-DPA0GN-mOQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/极客公园.png",
    source_name: "极客公园",
    publish_time: "2024-10-23 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "加州农民实施20 GW太阳能+储能计划",
    abstract:
      "金州最近签署了AB 2661号法案，授权韦斯特兰水区当局开发输电线路，此举有望使13万英亩排水受损的农田建设太阳能和储能项目成为可能。",
    link: "https://www.pv-magazine-china.com/2024/10/22/%e5%8a%a0%e5%b7%9e%e5%86%9c%e6%b0%91%e5%ae%9e%e6%96%bd20-gw%e5%a4%aa%e9%98%b3%e8%83%bd%e5%82%a8%e8%83%bd%e8%ae%a1%e5%88%92/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-22 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "晶科能源、天合光能称TOPCon组件性能优于p型背接触式太阳能电池板",
    abstract:
      "晶科能源和天合光能分别发布报告称，他们通过现场测试证明隧穿氧化物钝化接触（TOPCon）太阳能组件在每月发电量方面优于p型背接触式光伏组件。",
    link: "https://www.pv-magazine-china.com/2024/10/21/%e6%99%b6%e7%a7%91%e8%83%bd%e6%ba%90%e3%80%81%e5%a4%a9%e5%90%88%e5%85%89%e8%83%bd%e7%a7%b0topcon%e7%bb%84%e4%bb%b6%e6%80%a7%e8%83%bd%e4%bc%98%e4%ba%8ep%e5%9e%8b%e8%83%8c%e6%8e%a5%e8%a7%a6%e5%bc%8f/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-21 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "北京新增12款已完成备案的生成式人工智能服务",
    abstract:
      "根据《生成式人工智能服务管理暂行办法》，截至10月21日，北京市新增12款已完成备案的生成式人工智能服务，累计已完成94款生成式人工智能服务备案。已上线的生成式人工智能应用或功能，应在显著位置或产品详情页面，公示所使用已备案的生成式人工智能服务情况，注明模型名称、备案编号。",
    link: "https://www.jiemian.com/article/11855482.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/界面新闻.png",
    source_name: "界面新闻",
    publish_time: "2024-10-21 00:00:00",
  },
  {
    week: "1021-1027",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "一年估值增14倍！AI搜索初创公司Perplexity拟融资5亿美元",
    abstract:
      "据知情人士透露，借助OpenAI最新巨额融资的势头，利用市场对人工智能初创公司高涨的热情，人工智能搜索初创公司Perplexity已经开始了新一轮的融资谈判，目标是将其估值提高一倍以上，达到80亿美元甚至更多。",
    link: "https://new.qq.com/rain/a/20241021A012KL00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-10-21 00:00:00",
  },
  {
    week: "1014-1020",
    week_title: "2024年10月第2期",
    anchor: "20241014",
    week_abs_long: {
      新闻: "Windows版ChatGPT发布，Adobe推出文生视频AI，优必选发布新工业机器人Walker S1。",
      创投: "智谱AI开源CogView3-Plus-3B，马斯克进军Robotaxi，小马智行获广汽2700万美元投资。",
      行业: "大规模光伏发电有助于荒漠环境改善，预计到2030年新增太阳能装机容量将超过4000 GW。",
      论文: "利用网页用户界面实现文本丰富的可视化理解。",
    },
  },
  {
    week: "1014-1020",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "利用网页用户界面实现文本丰富的可视化理解",
    abstract:
      "丰富文本的视觉理解（处理密集文本内容与视觉效果集成的环境的能力）对于多模式大语言模型 (MLLM) 与结构化环境有效交互至关重要。为了增强这种能力，我们建议使用基于文本的大语言模型（LLM）从网页 UI 合成通用多模式指令。尽管缺乏直接的视觉输入，基于文本的LLM能够处理来自网页可访问性树的结构化文本表示。然后将这些指令与 UI 屏幕截图配对来训练多模式模型。我们引入了 MultiUI，这是一个包含来自 100 万个网站的 730 万个样本的数据集，涵盖了不同的多模式任务和 UI 布局。",
    link: "https://arxiv.org/abs/2410.13824",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-18 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Windows版ChatGPT正式发布！直接用上最强o1，快捷键即可召唤",
    abstract:
      "OpenAI 宣布推出 Windows 桌面应用，向 ChatGPT Plus、Enterprise、Team 和 Edu 用户开放 。不过，官方表示，目前开放的只是早期版本，将在今年晚些时候向所有 ChatGPT 用户推出「完整的体验」。用户可以在微软应用商店搜索 ChatGPT，接着下载安装即可，安装包大约 110MB 。",
    link: "https://mp.weixin.qq.com/s/C_TIZtmGxhUrwaZWF1xMVw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/爱范儿.png",
    source_name: "爱范儿",
    publish_time: "2024-10-18 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "DAWN：具有非自回归扩散框架的动态框架头像，用于生成头部视频",
    abstract:
      "头像生成旨在从单个肖像和语音音频剪辑中生成生动逼真的头像视频。尽管基于扩散的头部特写生成已经取得了重大进展，但几乎所有方法都依赖于自回归策略，这些策略受到超出当前生成步骤的上下文利用率有限、错误累积和生成速度较慢的影响。为了应对这些挑战，我们提出了 DAWN（具有非自回归扩散的动态帧头像），这是一个能够一次性生成动态长度视频序列的框架。",
    link: "https://arxiv.org/abs/2410.13726",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-10-18 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "国际能源署预测到2030年新增太阳能装机容量或超4000 GW",
    abstract:
      "国际能源署表示，到2030年可再生能源预计将满足全球近一半的电力需求，其中太阳能占到新增装机量的80%。其中，公用事业规模的太阳能将占到新增太阳能装机容量的大部分；而分布式太阳能的占比预计接近40%，包括住宅、工商业和离网项目。",
    link: "https://www.pv-magazine-china.com/2024/10/15/%e5%9b%bd%e9%99%85%e8%83%bd%e6%ba%90%e7%bd%b2%e9%a2%84%e6%b5%8b%e5%88%b02030%e5%b9%b4%e6%96%b0%e5%a2%9e%e5%a4%aa%e9%98%b3%e8%83%bd%e8%a3%85%e6%9c%ba%e5%ae%b9%e9%87%8f%e6%88%96%e8%b6%854000-gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-15 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Adobe推出文生视频AI模型，向OpenAI和Meta发起挑战",
    abstract:
      "在Adobe MAX年度大会上，这家美国电脑软件公司宣布，它已经开始对一种文生视频人工智能(AI)模型进行公开测试。这项技术被称为Firefly视频模型，Adobe称其技术取得了新的突破，将与OpenAI于今年早些时候推出的文生视频大模型Sora展开竞争。",
    link: "https://www.cls.cn/detail/1825286",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-10-15 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "马斯克刚进军Robotaxi，小马智行获广汽投资2700万美元",
    abstract:
      "马斯克发布特斯拉Robotaxi的同一天，中国知名Robotaxi独角兽获得了新认可。广汽宣布，要给小马智行投资2700万美元，相当于人民币1.9亿元。从2016年成立到今天，小马智行已经收获了十多轮融资，累计资金超过11亿美元（约78亿元），完成D轮融资后，估值达到85亿美元（约600亿元）。",
    link: "https://www.qbitai.com/2024/10/206844.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-10-14 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "智谱AI宣布开源文生图模型 CogView3-Plus-3B，采用Apache 2.0协议",
    abstract:
      "智谱AI宣布开源其先进的文本到图像生成模型 CogView3-Plus-3B。基于最新的DiT框架，通过Zero-SNR扩散噪声调度和文本-图像联合注意力机制，提升了图像生成的质量和灵活性。CogView3-Plus-3B支持从512到2048像素的多种分辨率生成，其性能与业界领先模型相媲美。",
    link: "https://mp.weixin.qq.com/s/Tk3nAtjewT9H2pJYZ9F3Tg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/chatglm.png",
    source_name: "智谱AI",
    publish_time: "2024-10-14 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "大规模光伏发电对荒漠地区具有积极的环境效应",
    abstract:
      "来自中国的研究人员发现，大型太阳能发电厂对沙漠地区的生态环境有积极的影响。他们在中国东北部青海省的一个1 GW的太阳能园区进行了测试。",
    link: "https://www.pv-magazine-china.com/2024/10/14/%e5%a4%a7%e8%a7%84%e6%a8%a1%e5%85%89%e4%bc%8f%e5%8f%91%e7%94%b5%e5%af%b9%e8%8d%92%e6%bc%a0%e5%9c%b0%e5%8c%ba%e5%85%b7%e6%9c%89%e7%a7%af%e6%9e%81%e7%9a%84%e7%8e%af%e5%a2%83%e6%95%88%e5%ba%94/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-14 00:00:00",
  },
  {
    week: "1014-1020",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "优必选发布全新一代工业人形机器人 Walker S1",
    abstract:
      "据优必选官方消息，优必选发布了全新一代工业人形机器人 Walker S1，并已进入汽车工厂实训。Walker S1与L4级无人物流车、无人叉车、工业移动机器人和智能制造管理系统协同作业，这也是全球范围内首个人形机器人与无人物流车等协同作业的工业场景解决方案。",
    link: "https://mp.weixin.qq.com/s/Gx3yMdLU1GrNGZHBQyHkBg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/优必选.png",
    source_name: "优必选",
    publish_time: "2024-10-14 00:00:00",
  },
  {
    week: "1001-1013",
    week_title: "2024年10月第1期",
    anchor: "20241001",
    week_abs_long: {
      创投: "海螺AI推出图像生成视频功能，智谱AI宣布10月API最低1折且每用户免费领1亿tokens。",
      新闻: "科大讯飞发布新技术，智谱清言鸿蒙版上线，诺贝尔物理学奖授予AI先驱。",
      行业: "立陶宛建最大光伏车棚，容纳44个充电桩；科学家研究硅藻土用于太阳能电池。",
      论文: "ChainBuddy：用于生成LLM管道的人工智能代理系统。",
    },
  },
  {
    week: "1001-1013",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "海螺AI推出“图生视频”功能，可实现高度一致的图像生成视频",
    abstract:
      "MiniMax视频模型在海螺AI平台上线五周后，访问量增速超800%，全球180个地区用户参与创作。模型在VBench评测中排名第一，新增”图生视频”功能，可实现高度一致的图像生成视频，支持连贯深度创作。海螺AI提供无需特效模板的电影级视频创作，激发了全球创作者的热情。",
    link: "https://mp.weixin.qq.com/s/PzJlmg8IHICpnP3yFEuihA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/海螺AI.png",
    source_name: "海螺AI",
    publish_time: "2024-10-10 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "2024 科大讯飞全球 1024 开发者节官宣：首发多模态视觉交互、超拟人虚拟人交互能力",
    abstract:
      "第七届世界声博会暨 2024 科大讯飞全球 1024 开发者节将于今年 10 月 24 日在合肥奥体中心正式开启。届时将发布讯飞星火大模型升级版，其底座能力将再次升级，包含数学、代码和长文本能力显著提升、中英文综合能力持续领先，训练推理效率大幅提升等特性。科大讯飞还将首次发布多模态视觉交互及超拟人虚拟人交互能力。",
    link: "https://mp.weixin.qq.com/s/RV5I2EE84_fSP_r6XV3dAg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/科大讯飞.png",
    source_name: "科大讯飞",
    publish_time: "2024-10-10 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "立陶宛最大的光伏车棚最多可容纳44个电动汽车充电桩",
    abstract:
      "总部位于立陶宛的Soliport公司建造了一个据称是波罗的海国家最大的太阳能车棚。这个250 kW的光伏发电系统与44个电动汽车充电桩相连，只将其产生的一小部分电力注入电网。",
    link: "https://www.pv-magazine-china.com/2024/10/09/%e7%ab%8b%e9%99%b6%e5%ae%9b%e6%9c%80%e5%a4%a7%e7%9a%84%e5%85%89%e4%bc%8f%e8%bd%a6%e6%a3%9a%e6%9c%80%e5%a4%9a%e5%8f%af%e5%ae%b9%e7%ba%b344%e4%b8%aa%e7%94%b5%e5%8a%a8%e6%b1%bd%e8%bd%a6%e5%85%85%e7%94%b5/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-09 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "科学家研究将硅藻土作为太阳能电池原料的潜力",
    abstract:
      "一个德国-阿尔及利亚研究团队一直在研究利用硅藻土生产硅的方法。硅藻土是一种含有无定形二氧化硅的化石材料。研究人员表示，对于潜在的太阳能电池应用，提取低杂质水平的硅将至关重要。",
    link: "https://www.pv-magazine-china.com/2024/10/09/%e7%a7%91%e5%ad%a6%e5%ae%b6%e7%a0%94%e7%a9%b6%e5%b0%86%e7%a1%85%e8%97%bb%e5%9c%9f%e4%bd%9c%e4%b8%ba%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e5%8e%9f%e6%96%99%e7%9a%84%e6%bd%9c%e5%8a%9b/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-10-09 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "智谱清言鸿蒙版 App 上线：支持多轮对话、写作辅助、代码生成等功能",
    abstract:
      "智谱清言今日官宣，第一时间完成所有基础功能与纯血鸿蒙适配，现在所有升级至 HarmonyOS NEXT 的用户均可体验智谱清言大模型。据介绍，智谱清言鸿蒙版 App 已支持多轮对话、写作辅助、代码生成、AI 搜索、AI 画图等功能，同时还支持 50 万个智能体被创建等功能。",
    link: "https://mp.weixin.qq.com/s/nMycl5PEXqjOLp6ZmudQTA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/chatglm.png",
    source_name: "智谱清言",
    publish_time: "2024-10-09 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "2024诺贝尔物理学奖，授予AI先驱 Geoffrey Hinton 和 John Hopfield",
    abstract:
      "2024年诺贝尔物理学奖授予了John J. Hopfield和Geoffrey E. Hinton，表彰他们在利用人工神经网络实现机器学习方面的奠基性发现和发明。两位科学家将平分1100万瑞典克朗（约合745万元人民币）的奖金。他们不仅推动了计算神经科学的发展，还为深度学习技术的广泛应用奠定了基础，包括在语音识别和图像识别等领域的突破。",
    link: "https://mp.weixin.qq.com/s/Bc5JVjFh7jZKnS7DV3Y_aw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-10-09 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "智谱 AI 宣布 10 月最低 1 折开放全部官方模型 API，每位用户免费领 1 亿 tokens",
    abstract:
      "智谱 AI 推出 10 月最新促销活动，最低 1 折调用开放平台 bigmodel.cn 所有官方模型 API，期间每位用户均可获赠 1 亿 tokens 额度。此外，在 10 月内，根据用户前一天的 token 用量，次日可享阶梯折扣。",
    link: "https://mp.weixin.qq.com/s/7QZRoxQC94qxcjHH5Xn98w",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/chatglm.png",
    source_name: "智谱AI",
    publish_time: "2024-10-08 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "用于工厂范围动态调度的可扩展多智能体强化学习",
    abstract:
      "实时动态调度是现代制造过程中一项重要而又极具挑战性的任务，其决策复杂度很高。最近，强化学习（RL）作为应对这一挑战的有效技术受到了关注。然而，经典的强化学习方法通常依赖于人为的调度规则，不适合大规模工厂范围的调度。为了弥合这一差距，本文采用了领导者-追随者多智能体强化学习（MARL）的概念，以获得所需的协调后，调度问题分解成一组由每个单独的代理处理的可扩展性的子问题。我们提出了一个基于规则的转换算法，以防止灾难性的损失，由于代理的错误，生产能力进一步加强的过程。",
    link: "https://arxiv.org/abs/2409.13571v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-20 00:00:00",
  },
  {
    week: "1001-1013",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "ChainBuddy：用于生成LLM管道的人工智能代理系统",
    abstract:
      "随着大型语言模型（LLM）的发展，它们的潜在应用显着增长。然而，在用户特定的任务上评估LLM行为并制作有效的管道仍然很困难。许多用户都在纠结从哪里开始，这通常被称为“空白页”问题。ChainBuddy是一个AI助手，用于生成内置于ChainForge平台的评估LLM管道，旨在解决这个问题。ChainBuddy提供了一种简单易用的方式来计划和评估LLM行为，使该过程不那么令人生畏，并且在各种可能的任务和用例中更容易访问。",
    link: "https://arxiv.org/abs/2409.13588v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-20 00:00:00",
  },
  {
    week: "0923-0929",
    week_title: "2024年9月第4期",
    anchor: "20240923",
    week_abs_long: {
      创投: "Canva利用AI挑战Adobe，极佳视界获三轮融资提升视频生成至4D模型。",
      新闻: "蔚蓝科技发布多模态AI机器狗，ChatGPT语音助手上线，腾讯发布能照顾老人的轮足式机器人。",
      行业: "英国智库预测2024年全球新增光伏装机容量593 GW，国际能源署呼吁加强并网，欧盟批准波兰12亿欧元可再生能源补助。",
      论文: "大型语言模型检索增强生成中的上下文压缩。",
    },
  },
  {
    week: "0923-0929",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "1.9 亿月活、260 亿估值的Canva，想借助 AI，挑战 2300 亿的 Adobe",
    abstract:
      "Canva，一个拥有1.9亿月活用户和260亿美元估值的在线设计平台，正借助人工智能技术，挑战市值2300亿美元的Adobe。Canva通过收购AI初创公司Leonardo.Ai和Photoshop竞争对手Affinity，进军办公领域，与Adobe争夺企业市场。Canva CEO Melanie Perkins认为AI工具旨在提高效率，与Canva的使命一致，公司目标是在未来几年内达到10亿月活跃用户。",
    link: "https://mp.weixin.qq.com/s/D_XhroXcb0Xd4d1SMHYljA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/极客公园.png",
    source_name: "极客公园",
    publish_time: "2024-09-27 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "空间智能公司「极佳视界」连获三轮融资，要将视频生成提升至4D世界模型",
    abstract:
      "空间智能公司「极佳视界」近日宣布完成近5000万元天使及天使+连续两轮融资，此两轮融资由北汽产投、奇绩创坛、华民投、龙鼎投资、清智资本、PKSHA Algorithm Fund等知名财务和产业投资机构投资。此前极佳视界已完成数千万元的种子轮融资，由辰韬资本投资。",
    link: "https://zhidx.com/p/447217.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-09-26 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "国产具身智能新突破：蔚蓝科技发布多模态AI机器狗BabyAlpha A2",
    abstract:
      "国产具身智能公司蔚蓝科技发布新品：四足机器狗BabyAlpha A2、开发者版本机器人及人形机器人。BabyAlpha A2具备定制化领养、多模态AI交互、AI绘本和共享相册功能，预计10月中旬上市。公司采用线上线下全渠道销售，产品已遍布全国并拓展海外市场。",
    link: "https://mp.weixin.qq.com/s/YFwhP6aeW35l69lAYvrOkQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-09-26 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "腾讯发布轮足式机器人！能照顾老人，还会自我收纳",
    abstract:
      "腾讯发布了Robotics X实验室的最近研发进展，推出了机器人“小五”。小五集合了此前多代机器人研发的核心能力，可以在真实人居环境中完成行走、搬运物体等动作，处理复杂任务，与人进行交互。在腾讯Robotics X实验室展示的小五进入养老院服务老人的场景中，它可以轻轻把老人从床上抱到轮椅上，还可以推着轮椅送老人去参加活动，途中还会注意躲避障碍。",
    link: "https://zhidx.com/p/446323.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-09-25 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "ChatGPT高级语音助手正式上线！OpenAI：50多种语言、9种声线可选",
    abstract:
      "OpenAI周二（24日）宣布，所有付费订阅ChatGPT Plus和Team计划的用户，都将可以使用新的AVM功能（高级语音模式），不过该模式将在未来几天逐步推出。它将首先在美国市场上线。下周，该功能将向OpenAI Edu 和Enterprise 计划的订阅者开放。据悉，AVM提高了部分外语的对话速度、流畅度并改进口音。",
    link: "https://www.cls.cn/detail/1808349",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-09-25 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "欧盟批准波兰12亿欧元可再生能源补助计划",
    abstract:
      "欧盟委员会批准了波兰一项价值12亿欧元（13亿美元）的国家援助计划，该计划将向生产太阳能电池板、电池、热泵和其他可再生能源设备零部件的公司提供直接资助。",
    link: "https://www.pv-magazine-china.com/2024/09/24/%e6%ac%a7%e7%9b%9f%e6%89%b9%e5%87%86%e6%b3%a2%e5%85%b012%e4%ba%bf%e6%ac%a7%e5%85%83%e5%8f%af%e5%86%8d%e7%94%9f%e8%83%bd%e6%ba%90%e8%a1%a5%e5%8a%a9%e8%ae%a1%e5%88%92/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-24 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "行业",
    effect: "负面",
    color: "#108ee9",
    title: "国际能源署呼吁加强太阳能和风能的并网措施",
    abstract:
      "国际能源署（IEA）的最新报告警告称，到2030年，如果不能在部署时支持并网，可能会危及高达15%的太阳能和风能项目。这一缺口将使它们在全球电力结构中的总份额减少5%。",
    link: "https://www.pv-magazine-china.com/2024/09/24/%e5%9b%bd%e9%99%85%e8%83%bd%e6%ba%90%e7%bd%b2%e5%91%bc%e5%90%81%e5%8a%a0%e5%bc%ba%e5%a4%aa%e9%98%b3%e8%83%bd%e5%92%8c%e9%a3%8e%e8%83%bd%e7%9a%84%e5%b9%b6%e7%bd%91%e6%8e%aa%e6%96%bd/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-24 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "英国智库预测2024年全球新增光伏装机容量为593 GW",
    abstract:
      "总部位于英国的能源智库Ember表示，预计今年全球太阳能新增装机容量将达到593 GW，较2023年增长29%。并指出到7月底已安装292 GW。",
    link: "https://www.pv-magazine-china.com/2024/09/23/%e8%8b%b1%e5%9b%bd%e6%99%ba%e5%ba%93%e9%a2%84%e6%b5%8b2024%e5%b9%b4%e5%85%a8%e7%90%83%e6%96%b0%e5%a2%9e%e5%85%89%e4%bc%8f%e8%a3%85%e6%9c%ba%e5%ae%b9%e9%87%8f%e4%b8%ba593-gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-23 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过深度学习对消费品中出现的微塑料和纳米塑料进行形态检测和分类",
    abstract:
      "塑料污染是一个不断升级的全球性问题，影响着健康和环境系统，从饮用水到空气的各种介质中都存在微塑料和纳米塑料。研究这些污染物的传统方法是劳动密集型和耗时的，需要转向更有效的技术。作为回应，本文介绍了微米和纳米塑料（MiNa），这是一种新型的开源数据集，用于使用物体检测算法自动检测和分类微米和纳米塑料。该数据集包括在现实水生条件下模拟的扫描电子显微镜图像，按聚合物类型对塑料进行分类，涵盖广泛的尺寸范围。我们展示了最先进的检测算法在MiNa上的应用，评估了它们的有效性",
    link: "https://arxiv.org/abs/2409.13688v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-20 00:00:00",
  },
  {
    week: "0923-0929",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大型语言模型检索增强生成中的上下文压缩",
    abstract:
      "利用外部数据库来提高大模型所生成内容的一致性和连贯性，对于复杂的，知识丰富的任务特别有价值，并通过利用特定领域的见解来促进持续改进。通过将LLM的固有知识与外部数据库的庞大、动态存储库相结合，RAG实现了协同效应。然而，RAG并非没有其局限性，包括有限的上下文窗口，不相关的信息，以及大量上下文数据的高处理开销。在这项全面的工作中，我们探讨了上下文压缩范式的演变，提供了一个深入的研究领域。",
    link: "https://arxiv.org/abs/2409.13385",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-20 00:00:00",
  },
  {
    week: "0914-0922",
    week_title: "2024年9月第3期",
    anchor: "20240914",
    week_abs_long: {
      新闻: "文生视频模型Runway和Luma开放API，Suno发布一键翻唱功能“Covers”。",
      创投: "李飞飞的公司 World Labs 获2.3亿融资；欧洲投资银行投资南非太阳能、风能项目。",
      行业: "意大利首次农业光伏招标规模达到1.7 GW; 里加港将建100 MW太阳能发电站。",
      论文: "用自然语言进行规划改进LLM检索代码生成。",
    },
  },
  {
    week: "0914-0922",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "文生视频模型Runway、Luma同时开放API",
    abstract:
      "著名文生视频模型 Runway 宣布开放最新文生视频模型Gen-3AlphaTurbo的API，帮助开发者将该功能集成在应用中。几乎在同一时间，Runway的主要竞争对手Luma也宣布开放了生成视频API，同样可以将文生视频功能集成在应用中。Luma的API提供的是最新模型 Dream Machine v1.6，在生成效率和质量方面同样非常出色。",
    link: "https://mp.weixin.qq.com/s/3khdaUEY3TZi9BlEd3uMDw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-19 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "里加港将建100 MW太阳能发电站",
    abstract:
      "立陶宛公司SNG Solar将在拉脱维亚里加港建造一座100 MW太阳能发电站。建成后，该设施将成为波罗的海地区最大的太阳能项目之一。",
    link: "https://www.pv-magazine-china.com/2024/09/18/%e9%87%8c%e5%8a%a0%e6%b8%af%e5%b0%86%e5%bb%ba100-mw%e5%a4%aa%e9%98%b3%e8%83%bd%e5%8f%91%e7%94%b5%e7%ab%99/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-18 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "「AI教母」李飞飞创业公司 World Labs 正式官宣！又拿到2.3亿美元融资",
    abstract:
      "AI 教母李飞飞的创业公司 World Labs，正式官宣启动！3 个月前，这家新晋 AI 独角兽，在完成约 1 亿美元融资后，估值 10 亿美金。近日，World Labs 又获 2.3 亿美金新一轮融资。这一次，新一轮融资由 a16z、NEA 和 Radical Ventures 领投，还有英伟达的风投部门参与。",
    link: "https://mp.weixin.qq.com/s/yKMiP3nstC_S1kAIKSJp-Q",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-18 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Suno 发布了重磅功能“Covers”，可以帮用户一键翻唱歌曲",
    abstract:
      "全球著名文生音乐模型Suno发布了重磅功能“Covers”，可以帮助用户一键翻唱任意风格的歌曲，可以是简单的录音或完整的歌曲。例如，上传一首流行歌曲《Original》，通过Covers就能识别歌曲里的乐谱、乐器、节奏以及旋律等，然后按照用户选择的新风格翻唱歌曲。虽然整体节奏、旋律可能有一些变化，但会保留原歌曲的核心灵魂部分同时呈现出全新的风格。",
    link: "https://new.qq.com/rain/a/20240916A00XY700",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-18 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "欧洲投资银行投资南非太阳能、风能项目",
    abstract:
      "欧洲投资银行（EIB）和南部非洲开发银行（DBSA）各投资1亿欧元（1.108亿美元）用于在南非建设中小型太阳能和陆上风能项目。目前，两家银行已承诺，将共同向南非嵌入式发电投资计划（EGIP）提供6亿欧元资金。",
    link: "https://www.pv-magazine-china.com/2024/09/17/%e6%ac%a7%e6%b4%b2%e6%8a%95%e8%b5%84%e9%93%b6%e8%a1%8c%e6%8a%95%e8%b5%84%e5%8d%97%e9%9d%9e%e5%a4%aa%e9%98%b3%e8%83%bd%e3%80%81%e9%a3%8e%e8%83%bd%e9%a1%b9%e7%9b%ae/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-17 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "意大利首次农业光伏招标规模达到1.7 GW",
    abstract:
      "意大利环境与能源安全部（MASE）表示，该国首次农业光伏招标活动已收到643份投标书，总发电容量达到1.7 GW。其中约56%的提案来自阳光明媚的意大利南部地区。",
    link: "https://www.pv-magazine-china.com/2024/09/16/%e6%84%8f%e5%a4%a7%e5%88%a9%e9%a6%96%e6%ac%a1%e5%86%9c%e4%b8%9a%e5%85%89%e4%bc%8f%e6%8b%9b%e6%a0%87%e8%a7%84%e6%a8%a1%e8%be%be%e5%88%b01-7-gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-16 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "用于实体匹配的微调大型语言模型",
    abstract:
      "生成式大语言模型（LLM）是一种有前途的替代预训练语言模型的实体匹配，由于其高zero-shot性能和泛化到不可见实体的能力。使用LLM进行实体匹配的现有研究集中在提示工程和上下文学习上。本文探讨了微调LLM实体匹配的潜力。我们沿着两个维度分析微调：1）训练示例的表示，我们尝试将不同类型的LLM生成的解释添加到训练集中，以及2）使用LLM选择和生成训练示例。除了在源数据集上的匹配性能之外，我们还研究了微调如何影响模型推广到其他域内数据集以及跨主题域的能力。",
    link: "https://arxiv.org/abs/2409.08185",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-12 00:00:00",
  },
  {
    week: "0914-0922",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "用自然语言进行规划改进LLM检索代码生成",
    abstract:
      "尽管扩展训练计算已使大型语言模型（LLMs）取得了显著的进步，但扩展推理计算却尚未产生类似的收益。我们假设，缺少的一个核心要素是 LLM 输出缺乏多样性，导致模型重复采样高度相似但不正确的世代，从而导致搜索效率低下。我们通过实证证明，通过搜索候选计划来解决自然语言中的问题，可以缓解这种缺乏多样性的问题。",
    link: "https://arxiv.org/abs/2409.03733",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-05 00:00:00",
  },
  {
    week: "0909-0913",
    week_title: "2024年9月第2期",
    anchor: "20240909",
    week_abs_long: {
      创投: "OpenAI洽谈新融资，估值1500亿美元；风平智能获近亿元A轮融资，推百元AI数字人。",
      新闻: "OpenAI即将发布神秘大模型“草莓”，面壁智能与梧桐科技合作推进智能座舱，快手启动中国首个AIGC导演共创计划。",
      行业: "波兰重启住宅太阳能退税计划，Kiwa发布光伏组件质量最佳实践白皮书。",
      论文: "LLM蜜罐：利用大型语言模型作为高级交互式蜜罐系统。",
    },
  },
  {
    week: "0909-0913",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "估值1500亿美元！OpenAI据称正洽谈新一轮融资",
    abstract:
      "据知情人士透露，全球人工智能（AI）领军企业OpenAI正在商谈以1,500亿美元的公司估值向投资者筹集65亿美元。据悉，新的估值（不包括筹集的资金）明显高于该公司今年早些时候要约收购中的860亿美元估值，巩固了其作为全球最有价值初创公司之一的地位。OpenAI还在商谈以循环贷款形式从银行筹集50亿美元。",
    link: "https://www.cls.cn/detail/1796741",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-09-12 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLM蜜罐：利用大型语言模型作为高级交互式蜜罐系统",
    abstract:
      "网络威胁的快速发展需要创新的解决方案来检测和分析恶意活动。蜜罐是一种诱饵系统，旨在引诱攻击者并与之互动，已成为网络安全的关键组成部分。在本文中，我们提出了一种新的方法来创建现实的和交互式的蜜罐系统使用大型语言模型（LLM）。通过在攻击者生成的命令和响应的不同数据集上微调预训练的开源语言模型，我们开发了一个能够与攻击者进行复杂互动的蜜罐。",
    link: "https://www.arxiv.org/abs/2409.08234",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-12 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLM-POTUS评分：用大型语言模型分析总统辩论的框架",
    abstract:
      "大型语言模型在自然语言处理方面表现出了卓越的能力，但它们在政治语篇分析中的应用仍有待探索。本文介绍了一种新的方法来评估总统辩论的表现，使用LLM，解决客观评估辩论结果的长期挑战。我们提出了一个框架，分析候选人的“政策，人格和观点”（3 P），以及他们如何与四个关键受众群体的“利益，意识形态和身份”（3 I）产生共鸣：选民，企业，捐助者和政治家。我们的方法采用大型语言模型来生成LLM-POTUS分数，这是一种基于3 P和3 I之间的对齐来衡量辩论表现的定量指标。",
    link: "https://arxiv.org/abs/2409.08147",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-09-12 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "面壁智能联合梧桐科技，端侧大模型支撑智能座舱",
    abstract:
      "面壁智能宣布，成为梧桐科技芯算一体 AI 座舱方案中端侧大模型重要合作伙伴，以 MiniCPM 车载多模态大模型实现舱驾协控相关的功能控制。这也是面壁 MiniCPM 端侧多模态模型首次支撑汽车智能座舱的系统底座。梧桐科技已与 10 余家主机厂伙伴，合作超过 100 余款各类车型，覆盖自主品牌、合资品牌、豪华品牌，产品装机量已超过三百万辆。",
    link: "https://mp.weixin.qq.com/s/rS00-oi5pTCIMfWCC-MHZg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/面壁智能.png",
    source_name: "面壁智能",
    publish_time: "2024-09-11 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "让不足百元的AI数字人替人打工，风平智能获近亿元A轮系列融资",
    abstract:
      "AI数字人公司风平智能（Fullpeace）已完成累计近亿元A轮系列融资，由璀璨者资本及华为系企业家华鲲资本基金共同投资，包括汇财资本、北京大学人工智能创新中心主任雷鸣、清华大学杰出校友系的基金在内的老股东全部跟投。其中，“1号AI”平台是这轮融资的核心，投产比非常高。1号AI结合数字人、AI和RPA技术，帮助用户打造具备媲美真人形象、声音，甚至拥有AI大脑的专属AI数字人。",
    link: "https://mp.weixin.qq.com/s/idW8Q9Vpdhejvqm2dStNdw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-11 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "曝 OpenAI 神秘大模型 “草莓” 两周内发布！",
    abstract:
      "据外媒The Information昨晚报道，OpenAI的新模型“草莓”（Strawberry），将在未来两周内作为 ChatGPT 服务的一部分发布。“草莓”项目是OpenAI盛传已久的神秘Q*模型，据传是此前OpenAI政变大戏的关键原因之一。它展现出了解答数学问题、复杂编程的强大能力，让AI安全的研究人员都为之震惊。",
    link: "https://zhidx.com/p/443627.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-09-11 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "Kiwa PVEL和Kiwa PI Berlin发布白皮书概述光伏组件质量的最佳实践",
    abstract:
      "Kiwa PVEL和Kiwa PI Berlin发布了一份白皮书，该白皮书采用最新的模块测试和工厂数据来指导测试和检查指标的最佳实践，旨在确保太阳能组件达到可接受的质量标准。",
    link: "https://www.pv-magazine-china.com/2024/09/10/kiwa-pvel%e5%92%8ckiwa-pi-berlin%e5%8f%91%e5%b8%83%e7%99%bd%e7%9a%ae%e4%b9%a6%e6%a6%82%e8%bf%b0%e5%85%89%e4%bc%8f%e7%bb%84%e4%bb%b6%e8%b4%a8%e9%87%8f%e7%9a%84%e6%9c%80%e4%bd%b3%e5%ae%9e%e8%b7%b5/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-10 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "波兰重启住宅太阳能、储能退税计划",
    abstract:
      "波兰政府现已启动第六版住宅太阳能和储能退税计划，总预算为4亿兹罗提（合1.032亿美元）。申请受理日期截至12月20日或直至资金用尽。",
    link: "https://www.pv-magazine-china.com/2024/09/09/%e6%b3%a2%e5%85%b0%e9%87%8d%e5%90%af%e4%bd%8f%e5%ae%85%e5%a4%aa%e9%98%b3%e8%83%bd%e3%80%81%e5%82%a8%e8%83%bd%e9%80%80%e7%a8%8e%e8%ae%a1%e5%88%92/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-09 00:00:00",
  },
  {
    week: "0909-0913",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "快手可灵AI启动中国首个AIGC导演共创计划",
    abstract:
      "快手宣布正式启动“可灵AI”电影共创计划，联合李少红、贾樟柯、叶锦添、薛晓路、俞白眉、董润年、张吃鱼、王子川、王卯卯等9位导演共同推出9部AIGC电影短片。据介绍，9部短片将全部由可灵AI进行视频生成，电影导演完全依托视频生成大模型，群体深度参与电影级内容创作，这在中国尚属首次。",
    link: "https://www.36kr.com/newsflashes/2942431979674499",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-09-09 00:00:00",
  },
  {
    week: "0902-0908",
    week_title: "2024年9月第1期",
    anchor: "20240902",
    week_abs_long: {
      新闻: "智谱荣耀合作AI实验室; 8岁儿童2小时用AI做游戏吸引50万人观看; MiniMax推出视频和音乐生成模型。",
      创投: "AI视频工具OpusClip获3000万美元投资，「无问芯穹」完成5亿元A轮融资，成立16个月吸纳近10亿。",
      行业: "2024年全球太阳能装机量将达592 GW，GameChange Solar向印度750 MWp电厂提供跟踪器。",
      论文: "金融交易中的大型语言模型代理综述。",
    },
  },
  {
    week: "0902-0908",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "智谱和荣耀正式签署 AI 大模型技术联合实验室战略合作协议",
    abstract:
      "据智谱官方消息，智谱和荣耀于 9 月 2 日，在北京正式签署 AI 大模型技术联合实验室战略合作协议。智谱表示，双方深化战略合作，将进一步探索基于用户场景的端侧 AI 智能体验，共同推动智能终端领域大模型技术和应用创新，并通过荣耀折叠屏手机等全场景产品为用户带来更加智慧便捷的 AI 服务。",
    link: "https://mp.weixin.qq.com/s/-DFm0tvgQNpjBCyqQKz_Ug",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-04 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "GameChange Solar将为印度750 MWp太阳能发电厂提供跟踪器",
    abstract:
      "GameChange Solar公司表示，已同意为Sterling and Wilson可再生能源公司在印度古吉拉特邦的一个750 MWp的太阳能项目提供其Genius Tracker解决方案。",
    link: "https://www.pv-magazine-china.com/2024/09/03/gamechange-solar%e5%b0%86%e4%b8%ba%e5%8d%b0%e5%ba%a6750-mwp%e5%a4%aa%e9%98%b3%e8%83%bd%e5%8f%91%e7%94%b5%e5%8e%82%e6%8f%90%e4%be%9b%e8%b7%9f%e8%b8%aa%e5%99%a8/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-03 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI视频工具OpusClip获北美风投3000万美元投资，用AI革新视频编辑",
    abstract:
      "OpusClip，一家由人工智能驱动的视频再利用初创公司，在由Millennium New Horizons主导的 A 轮融资中筹集了 3000 万美元，参与者包括Samsung Next、GTMfund 和 DCM Ventures，并正在通过新的 ClipAnything 功能增强其平台。这家初创公司致力于将长视频转变为可分享的、在社交媒体平台上病毒式传播的短片。",
    link: "https://mp.weixin.qq.com/s/qkFM75rFexCoJKtsmJusrA",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-03 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "8岁小孩哥上手用AI制作游戏，全程2小时，引来50多万人围观",
    abstract:
      "一个八岁的孩子，在没有任何编程经验的情况下，居然手动建起了一个网站。是不是炒作不知道，但真的感知到了 AI 正在让编程变的越来越简单。在没有任何编码经验的情况下建立了一个 Three.js 网站，利用 Claude AI 工具，并让 Cursor 为他完成所有代码工作。",
    link: "https://www.jiqizhixin.com/articles/2024-09-03-6",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-09-03 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "「无问芯穹」完成近5亿元A轮融资，成立仅16个月已吸纳近10亿",
    abstract:
      "「无问芯穹」宣布完成近5亿元A轮融资。这也是目前为止，国内AI Infra（大模型基础设施）层创业公司最大的单笔融资记录。「无问芯穹」联合创始人、CEO夏立雪表示，本轮投资将用于加强技术人才吸纳与技术研发，深入推动产品商业化发展并强化生态合作。值得注意的是，成立仅仅16个月，「无问芯穹」的累计融资额已近10亿元。这家公司过往投资方还包括红杉中国、百度、智谱、同歌创投等。",
    link: "https://36kr.com/p/2926572043361155",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-09-02 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "MiniMax宣布推出视频生成和音乐生成模型，旗下海螺AI已开放体验",
    abstract:
      "8月31日，一向低调的“AI六小龙” 之一——MiniMax第一次正式对外，在上海办了场“MiniMax Link伙伴日”活动。在会上，MiniMax创始人闫俊杰宣布推出视频生成模型和音乐模型。此外，他预告，新⼀版能从速度和效果都对标GPT-4o的大模型abab7，会在未来⼏周内发布。目前所有用户都可以登录海螺AI官网体验视频生成和音乐生成功能。",
    link: "https://new.qq.com/rain/a/20240901A063O100",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-09-02 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "2024年太阳能组件装机量将达到592 GW",
    abstract:
      "据彭博新能源财经（BloombergNEF）统计，2024年全球光伏行业将新装592 GW太阳能组件，与2023年相比增长33%。同时，由于各大制造商暂时缩减产量，该咨询机构还下调了2024年多晶硅产量预期。",
    link: "https://www.pv-magazine-china.com/2024/09/02/2024%e5%b9%b4%e5%a4%aa%e9%98%b3%e8%83%bd%e7%bb%84%e4%bb%b6%e8%a3%85%e6%9c%ba%e9%87%8f%e5%b0%86%e8%be%be%e5%88%b0592-gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-09-02 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "金融交易中的大型语言模型代理综述",
    abstract:
      "交易是一项竞争激烈的任务，需要策略、知识和心理坚韧的结合。随着大型语言模型（LLM）最近的成功，将LLM代理的新兴智能应用于这一竞争领域并了解他们是否能超越专业交易员是很有吸引力的。在这项调查中，我们提供了一个全面的审查，目前的研究使用LLMs作为代理人在金融交易。我们总结了在代理，数据输入，和LLM交易代理的性能在回测以及在这些研究中提出的挑战中使用的共同架构。这项调查旨在深入了解基于法学硕士的金融交易代理商的现状，并概述该领域未来的研究方向。",
    link: "https://arxiv.org/abs/2408.06361v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0902-0908",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过多轮对话中的迭代对象-实体对齐增强视觉对话状态跟踪",
    abstract:
      "视觉对话（VD）是一个任务，其中代理回答一系列图像相关的问题，基于多轮对话历史。然而，以前的VD方法通常将整个对话历史视为简单的文本输入，而忽略了回合级别的固有会话信息流。在本文中，我们介绍了多轮对话状态跟踪模型（MDST），一个框架，利用对话历史中学习到的对话状态来回答问题，从而解决了这一限制。MDST捕获每一轮对话历史，构建内部对话状态表示，定义为视觉语言表示的2元组。这些表示有效地为当前问题提供了基础，从而能够生成准确的答案。",
    link: "https://arxiv.org/abs/2408.06725",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0826-0901",
    week_title: "2024年8月第4期",
    anchor: "20240826",
    week_abs_long: {
      新闻: "智谱AI发布顶尖模型，Kimi推新API并扩展功能，OpenAI秋季发布新项目，字节成立研究院大举招聘AI人才。",
      创投: "Viggle 获a16z 1900万美元投资加速发展，以色列开发商获1.1亿欧元在罗马尼亚建太阳能发电厂。",
      行业: "印度上半年新增14.9 GW太阳能，ABB支持10 GW项目自动化，保加利亚批准太阳能工厂。",
      论文: "大型语言模型可以为选举虚假信息操作一致生成高质量的内容。",
    },
  },
  {
    week: "0826-0901",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "智谱AI发布了一系列新一代基座模型，性能指标均为国际第一梯队",
    abstract:
      "在KDD 2024大会上，智谱AI发布了新一代基座模型，包括语言模型 GLM-4-Plus 、文生图模型 CogView-3-Plus 、图像/视频理解模型 GLM-4V-Plus 、视频生成模型 CogVideoX 等，这些模型在相应领域均达到了国际第一梯队的水平。智谱AI还在「清言APP」上线了视频通话功能，并在MaaS平台上开放了 GLM-4-Flash API的免费使用。",
    link: "https://mp.weixin.qq.com/s/f0Wl2qJEqMOxZP3vxdQdJg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/AI工具集.png",
    source_name: "AI工具集",
    publish_time: "2024-08-30 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "保加利亚为太阳能电池和电池板工厂开绿灯",
    abstract:
      "保加利亚政府已批准与土耳其太阳能组件制造商Smart Solar Technologies AD达成谅解备忘录，该公司将在保加利亚南部建造太阳能电池和电池板工厂。",
    link: "https://www.pv-magazine-china.com/2024/08/28/%e4%bf%9d%e5%8a%a0%e5%88%a9%e4%ba%9a%e4%b8%ba%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e5%92%8c%e7%94%b5%e6%b1%a0%e6%9d%bf%e5%b7%a5%e5%8e%82%e5%bc%80%e7%bb%bf%e7%81%af/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-28 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI “草莓项目” 最快今年秋季发布，随后是 “猎户座”（Orion）",
    abstract:
      "AI工程师Tom Keldenich表示，OpenAI正在开发“草莓”和“猎户座”（Orion）两种模型。草莓主要用于解决复杂推理任务，尤其是在数学和编程领域，也会极大增强大模型的语言理解能力，例如，在《纽约时报》的测试中就表现非常好。猎户座则是超越GPT-4的继任模型，但其预训练数据由草莓模型生成。也就是这两个模型加起来，将会比现在任何模型的推理、生成能力都强。",
    link: "https://www.cls.cn/detail/1778853",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-08-28 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Kimi推出moonshot-v1-auto模型API，Kimi API将推出联网搜索功能",
    abstract:
      "Kimi开放平台推出了名为moonshot-v1-auto的新模型API，这一功能能够根据上下文所需的Tokens数量自动选择合适的模型，从而帮助用户节省费用。同时，官方预告了Kimi API新功能：将推出联网搜索功能。",
    link: "https://mp.weixin.qq.com/s/FYOXWEe_sGOHDlwAIDy58Q",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Kimi开放平台.png",
    source_name: "Kimi开放平台",
    publish_time: "2024-08-28 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "字节成立大模型研究院，疯狂氪金 AI 人才",
    abstract:
      "据 AI 科技评论报道，字节跳动正在秘密筹备成立大模型研究院，并积极招揽人才。知情人士称，已有外部 AI 大牛加入大模型研究院，直接向张一鸣汇报。2023 年 8 月，字节自研的底层大模型“云雀”上线，随即推出 AI 对话产品“豆包”。今年 5 月，字节发布“豆包大模型”家族，发起价格战，号称“比行业便宜 99.3%”。",
    link: "https://mp.weixin.qq.com/s/JDkpfi4axcnlpANnQjrPEg",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-08-27 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "创投",
    effect: "正面",
    color: "#d580ff",
    title: "以色列开发商获得1.1亿欧元用于在罗马尼亚建设太阳能发电厂",
    abstract:
      "Nofar Energy公司已从欧洲复兴开发银行（EBRD）和瑞福森国际银行获得1.1亿欧元（1.225亿美元）的融资，用于在罗马尼亚建设两个总容量为300 MW的太阳能项目。",
    link: "https://www.pv-magazine-china.com/2024/08/27/%e4%bb%a5%e8%89%b2%e5%88%97%e5%bc%80%e5%8f%91%e5%95%86%e8%8e%b7%e5%be%971-1%e4%ba%bf%e6%ac%a7%e5%85%83%e7%94%a8%e4%ba%8e%e5%9c%a8%e7%bd%97%e9%a9%ac%e5%b0%bc%e4%ba%9a%e5%bb%ba%e8%ae%be%e5%a4%aa/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-27 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "Viggle 宣布获a16z的1900万美元投资，帮助 Viggle 扩大规模、加速产品开发",
    abstract:
      "据TechCrunch报道，Viggle 宣布已完成由 Andreessen Horowitz 领投的 1900 万美元 A 轮融资，Two Small Fish 也参与其中。这家初创公司表示，此轮融资将帮助 Viggle 扩大规模、加速产品开发并扩大团队。Viggle 告诉 TechCrunch，它与 Google Cloud 等云提供商合作，以训练和运行其 AI 模型。",
    link: "https://mp.weixin.qq.com/s/kHNmPYHNhhw5WngvzRcpgg",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-08-27 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "ABB为印度10 GW可再生能源项目提供自动化解决方案",
    abstract:
      "ABB基于可编程逻辑控制器的自动化解决方案目前正在为印度超过10 GW的可再生能源工厂提供服务，包括太阳能、风能和电池储能系统等。",
    link: "https://www.pv-magazine-china.com/2024/08/27/abb%e4%b8%ba%e5%8d%b0%e5%ba%a610-gw%e5%8f%af%e5%86%8d%e7%94%9f%e8%83%bd%e6%ba%90%e9%a1%b9%e7%9b%ae%e6%8f%90%e4%be%9b%e8%87%aa%e5%8a%a8%e5%8c%96%e8%a7%a3%e5%86%b3%e6%96%b9%e6%a1%88/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-27 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "印度上半年新增14.9 GW太阳能",
    abstract:
      "在今年1月至6月期间，印度新增14.9 GW太阳能装机容量，突破了此前所有的半年度和年度光伏装机纪录。",
    link: "https://www.pv-magazine-china.com/2024/08/26/%e5%8d%b0%e5%ba%a6%e4%b8%8a%e5%8d%8a%e5%b9%b4%e6%96%b0%e5%a2%9e14-9-gw%e5%a4%aa%e9%98%b3%e8%83%bd/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-26 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "表格实体消歧的语言模型评估",
    abstract:
      "表格是信息的重要容器，但理解它们的含义可能具有挑战性。事实上，最近，已经关注语义表解释（STI），即，该任务涉及表格数据的语义注释，以消除其含义的歧义。多年来，人们对基于深度学习的数据驱动方法的兴趣激增，这些方法越来越多地与基于数学的方法相结合。在过去的一段时间里，大型语言模型（LLM）的出现导致了一种新的表格注释方法。在这一研究领域的兴趣，其特点是多重挑战，导致了采用不同技术的方法的扩散。然而，这些方法并没有在一个共同的基础上得到一致的评价，因此很难进行评价和比较。这项工作提出了一个广泛的评估四个国家的最先进的（SOTA）的方法-鳄鱼（以前的s-elBat），Dagobah，TURL和TableLlama;前两个属于家庭的基于算法，而其他分别是编码器和解码器的LLM。主要目标是衡量这些方法解决实体消歧任务的能力，最终目的是在该领域开辟新的研究路径。",
    link: "https://arxiv.org/abs/2408.06423",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0826-0901",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大型语言模型可以为选举虚假信息操作一致生成高质量的内容",
    abstract:
      "大型语言模型的进步引起了人们对它们在大规模产生令人信服的选举虚假信息方面的潜在用途的担忧。本研究提出了一个两部分的调查LLMs的能力，自动化阶段的选举虚假信息操作。首先，我们介绍DisElect，这是一种新型评估数据集，旨在衡量LLM对在英国本地化背景下为选举虚假信息操作生成内容的指令的合规性，包含2，200个恶意提示和50个良性提示。",
    link: "https://arxiv.org/abs/2408.06731",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0819-0825",
    week_title: "2024年8月第3期",
    anchor: "20240819",
    week_abs_long: {
      创投: "《黑神话：悟空》3D资产生成工具上线，AMD 收购 ZT Systems，AI 学术搜索引擎 Consensus 获 USV 投资。",
      新闻: "AI辅助搜索受欢迎，Perplexity四季度投放广告；字节豆包模型升级，能力提升20.3%；通义千问启用新域名，新增深度搜索。",
      行业: "菲律宾启动全球最大太阳能公园，印度储能容量增长，丹麦AI工具助太阳能复兴，以色列2050年净零目标。",
      论文: "基于大语言模型的因果代理。",
    },
  },
  {
    week: "0819-0825",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "一句话生成《黑神话：悟空》3D资产，胡渊鸣创业项目Meshy上新，免费试用",
    abstract:
      "截至目前，Meshy 已经更新到了第 4 代。从 2023 年 11 月登场，Meshy 就以快速、保真、操作简易走在行业前列。在 Meshy-4 中，胡渊鸣团队突破了 3D AI 生成的一些技术难题，无论你是使用文本到 3D 还是图像到 3D，现在都能体验到生成模型的几何质量大幅提升。",
    link: "https://www.jiqizhixin.com/articles/2024-08-23-5",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-08-26 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "AI辅助搜索越来越受欢迎 Perplexity计划在四季度开始投放广告",
    abstract:
      "人工智能(AI)搜索初创公司Perplexity AI周四宣布，该公司计划于第四季度在其搜索应用程序上投放广告。据知情人士声称，在广告方面，Perplexity将采用一种名为CPM(每千次展示成本)的模式，价格将超过50美元。它指的是广告主付给媒体的每千次广告展示费用，而不是每次点击费用。",
    link: "https://www.cls.cn/detail/1773403",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-08-23 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "字节豆包语音模型和视觉模型再升级 综合能力提升20.3%",
    abstract:
      "2024火山引擎 AI 创新巡展在上海举办，带来豆包大模型的一系列产品升级。豆包语音模型和视觉模型再升级，对话式 AI 实时交互解决方案进一步强化 AI 交互体验。最新版豆包大语言模型的综合能力相比三个月前首次发布时提升了20.3%，豆包·文生图模型、豆包·语音识别模型等模型也有大幅升级",
    link: "https://mp.weixin.qq.com/s/nzNkPQqSTSA07OVytSOs7w",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/火山引擎.png",
    source_name: "火山引擎",
    publish_time: "2024-08-22 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "通义千问宣布启用新域名“tongyi.ai”，网页版聊天新增深度搜索功能",
    abstract:
      "阿里大语言模型“通义千问”今日宣布启用新域名“tongyi.ai”，并带来多项新功能。网页版聊天新增深度搜索功能；App 图片微动效支持多尺寸图片；App 自定义唱演支持 3:4 画幅（原先 1:1）。",
    link: "https://mp.weixin.qq.com/s/Z1qeYdUgK030OY1oHFxIsA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/通义千问.png",
    source_name: "通义千问",
    publish_time: "2024-08-20 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "以色列提出2050年净零蓝图，展望太阳能份额达到77%",
    abstract:
      "以色列能源与基础设施部提出了2050年绿色目标的3个愿景，具体根据太阳能、氢气和核能生产发展的情况而变化。在最专注太阳能的愿景中，以色列将拥有108GW的光伏容量。",
    link: "https://www.pv-magazine-china.com/2024/08/20/%e4%bb%a5%e8%89%b2%e5%88%97%e6%8f%90%e5%87%ba2050%e5%b9%b4%e5%87%80%e9%9b%b6%e8%93%9d%e5%9b%be%ef%bc%8c%e5%b1%95%e6%9c%9b%e5%a4%aa%e9%98%b3%e8%83%bd%e4%bb%bd%e9%a2%9d%e8%be%be%e5%88%b077/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-20 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "丹麦公司推出AI工具为太阳能行业赢回老客户",
    abstract:
      "丹麦创业公司Shiney AI表示，公司希望通过针对性的短信和电邮营销为光伏安装公司吸引新老客户。",
    link: "https://www.pv-magazine-china.com/2024/08/20/%e4%b8%b9%e9%ba%a6%e5%85%ac%e5%8f%b8%e6%8e%a8%e5%87%baai%e5%b7%a5%e5%85%b7%e4%b8%ba%e5%a4%aa%e9%98%b3%e8%83%bd%e8%a1%8c%e4%b8%9a%e8%b5%a2%e5%9b%9e%e8%80%81%e5%ae%a2%e6%88%b7/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-20 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AMD 宣布 49 亿美元收购服务器制造商 ZT Systems 以挑战英伟达",
    abstract:
      "AMD 宣布同意以 75% 现金和 25% 股票交易方式收购服务器制造商 ZT Systems，交易价值为 49 亿美元，以增加数据中心技术。ZT Systems 将成为 AMD 数据中心解决方案业务集团的一部分。ZT Systems 在过去 12 个月的收入超过 100 亿美元。",
    link: "https://mp.weixin.qq.com/s/afC2u6VBjqQ4snQfHGPKgQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-08-20 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "2028财年印度可再生能源储能容量上升6GW",
    abstract:
      "评级机构Crisil预测，由于健康渠道的推动，到2028财年，印度可再生能源储能容量将激增6GW。",
    link: "https://www.pv-magazine-china.com/2024/08/20/2028%e8%b4%a2%e5%b9%b4%e5%8d%b0%e5%ba%a6%e5%8f%af%e5%86%8d%e7%94%9f%e8%83%bd%e6%ba%90%e5%82%a8%e8%83%bd%e5%ae%b9%e9%87%8f%e4%b8%8a%e5%8d%876gw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-20 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "菲律宾凭借绿色通道证书快速启动世界上最大的太阳能公园",
    abstract:
      "菲律宾投资委员会向一个太阳能项目颁发了绿色通道证书，该项目被吹捧为迄今为止世界上最大的太阳能项目。该资格认证将为项目方在申请许可证及获得审批时获得更多便利。",
    link: "https://www.pv-magazine-china.com/2024/08/19/%e8%8f%b2%e5%be%8b%e5%ae%be%e5%87%ad%e5%80%9f%e7%bb%bf%e8%89%b2%e9%80%9a%e9%81%93%e8%af%81%e4%b9%a6%e5%bf%ab%e9%80%9f%e5%90%af%e5%8a%a8%e4%b8%96%e7%95%8c%e4%b8%8a%e6%9c%80%e5%a4%a7%e7%9a%84%e5%a4%aa/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-19 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "斯坦福都在用的 AI 学术搜索引擎 Consensus 获 USV 1100 万美元领投",
    abstract:
      "近日，AI 学术搜索引擎 Consensus 宣布完成 1100 万美元融资，A 轮融资由 Union Square Ventures 领投，其他投资者还包括 Nat Friedman、Daniel Gross 以及 Draper Associates 等。据悉，Consensus 目前拥有 40 万月活跃用户，包括学生、医生和注重健康的消费者，这些用户通过搜索引擎来回答各种问题，包括肌酸补充剂、正念的好处以及现金转移是否可以减少贫困。",
    link: "https://mp.weixin.qq.com/s/b7jCDGTxVpTa9GgZBMJDWQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-08-19 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "验证冻结LLM在知识图完成中的力量",
    abstract:
      "经典的知识图补全（KGC）方法仅依赖于结构信息，难以解决知识图（KG）固有的稀疏性。大型语言模型（LLM）通过强大的上下文建模从大型语料库中学习广泛的知识，这是减轻以前方法局限性的理想选择。直接微调LLM提供了很大的能力，但以巨大的时间和内存消耗为代价，而利用冻结的LLM产生次优的结果。在这项工作中，我们的目标是有效和高效地利用LLM为KGC。我们捕捉上下文感知的知识三元组的隐藏状态，采用提示刺激LLM的中间层。然后，我们训练这些隐藏状态的数据有效的分类器，以利用KGC中冻结LLM的固有功能。我们还生成的KG上的子图采样的实体描述，减少三元组的歧义，丰富的知识表示。",
    link: "https://arxiv.org/abs/2408.06787",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0819-0825",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "基于大语言模型的因果代理",
    abstract:
      "因果数据集通常是表格式的，而LLM在处理自然语言数据方面表现出色，这导致了结构上的不匹配，阻碍了表格数据的有效推理。这种因果推理能力的缺乏限制了LLM的发展。为了应对这些挑战，我们在代理框架内为LLM配备了因果工具，称为因果代理，使其能够解决因果问题。",
    link: "https://arxiv.org/abs/2408.06849",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0812-0818",
    week_title: "2024年8月第2期",
    anchor: "20240812",
    week_abs_long: {
      新闻: "稚晖君发布5款机器人，蚂蚁成立“数字蚂力”进军AI企业服务，毒舌AI每小时赚4000美元。",
      创投: "CodeRabbit获1600万美元融资，NEA领投李飞飞新公司1亿美元融资，李沐感叹创业艰辛。",
      行业: "以色列推屋顶太阳能，美国支持Qcells，全球高速公路潜力大。",
      论文: "CROME：用于高效多模式LLM的跨模式适配器。",
    },
  },
  {
    week: "0812-0818",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "稚晖君一口气发布5款人形机器人，远征A2系列主打“面向量产改进”",
    abstract:
      "在这场发布会中，稚晖君一口气推出了三款远征系列机器人产品：交互服务机器人「远征 A2」、柔性智造机器人「远征 A2-W」、重载特种机器人「远征 A2-Max」。最后的 One more thing 环节，智元 X-Lab 孵化的模块化机器人系列产品「灵犀 X1」和「灵犀 X1-W」也作为「彩蛋」正式亮相。",
    link: "https://www.qbitai.com/2024/08/180603.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-08-19 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "李沐：创业一年，人间三年",
    abstract:
      "作者李沐：给小伙伴汇报一下 LLM 创业第一年的进展、纠结和反思。在 Amazon 呆到第五年的时候就想着创业了，但被疫情耽搁了。到第 7 年半的时候，觉得太痒了，就提了离职。现在想来，如果有什么事这一辈子总要试下的，就蹭早。因为真开始后会发现有太多新东西要学，总感叹为啥没能早点开始。",
    link: "https://mp.weixin.qq.com/s/kTsUiyZTU7YAAUyDMZ7pyw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-08-16 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "CodeRabbit获1600万美元融资，助力AI自动化代码审查",
    abstract:
      "据 Techcrunch 报道， CodeRabbit 宣布获得 1600 万美元的 A 轮融资，由 CRV 领投，Flex Capital 和 Engineering Capital 参投。CodeRabbit是一家 AI 初创公司，其目标是通过人工智能来自动化代码审查过程。CodeRabbit 的平台利用先进的人工智能推理来理解代码背后的意图，并为开发者提供可操作的、类似人类的反馈。",
    link: "https://new.qq.com/rain/a/20240815A084KT00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-08-16 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "蚂蚁进军AI企业服务市场！成立“数字蚂力”新公司，发力AI to B",
    abstract:
      "蚂蚁集团在北京成立新公司“数字蚂力”，发力AI to B市场，将以人工智能技术服务企业经营。数字蚂力总部位于海淀区的蚂蚁T空间。该空间也是蚂蚁北京创新科技总部，蚂蚁集团将依托首都科技和人才优势，加大科技创新投入力度，围绕人工智能和数据要素根技术开展前沿探索。",
    link: "https://www.qbitai.com/2024/08/179125.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-08-15 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "NEA 领投李飞飞 World Labs 新一轮 1 亿美元融资 估值已超 10 亿美元",
    abstract:
      "上个月，李飞飞创立的 World Labs 公司被曝在短短两个月内完成两轮融资，获得了包括 a16z 以及 AI 基金 Radical Ventures 在内的顶级科技投资者的投资，估值超过 10 亿美元。根据 TechCrunch 获悉，World Labs 最新一轮由 NEA 领投，估值超过 10 亿美元，最早《金融时报》在 7 月份报道了这笔超过 1 亿美元的投资。",
    link: "https://mp.weixin.qq.com/s/peHDCFwBKz6g5qWcNUhDPw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-08-15 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "研究人员表示全球高速公路可容纳523亿太阳能面板",
    abstract:
      "来自中国科学院、清华大学、中国地球科学院和哥伦比亚大学的研究人员得出结论，太阳能覆盖全球高速公路可满足全球每年能源需求的60%以上。",
    link: "https://www.pv-magazine-china.com/2024/08/14/%e7%a0%94%e7%a9%b6%e4%ba%ba%e5%91%98%e8%a1%a8%e7%a4%ba%e5%85%a8%e7%90%83%e9%ab%98%e9%80%9f%e5%85%ac%e8%b7%af%e5%8f%af%e5%ae%b9%e7%ba%b3523%e4%ba%bf%e5%a4%aa%e9%98%b3%e8%83%bd%e9%9d%a2%e6%9d%bf/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-14 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "美国政府向Qcells太阳能工厂放贷14.5亿美元",
    abstract:
      "美国能源部（DoE）宣布有条件承诺向Qcells提供14.5亿美元贷款，用于在佐治亚州建立生产太阳能硅锭、晶圆、太阳能电池和光伏组件的工厂。",
    link: "https://www.pv-magazine-china.com/2024/08/13/%e7%be%8e%e5%9b%bd%e6%94%bf%e5%ba%9c%e5%90%91qcells%e5%a4%aa%e9%98%b3%e8%83%bd%e5%b7%a5%e5%8e%82%e6%94%be%e8%b4%b714-5%e4%ba%bf%e7%be%8e%e5%85%83/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-13 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "Sinovoltaics更新欧洲太阳能组件生产基地地图",
    abstract:
      "关于欧洲光伏组件生产供应链的最新报告提供了121个太阳能生产基地的状况，包括关闭和搁置的产能。报告绘制了生产光伏组件、电池片、晶圆、硅锭、多晶硅和冶金级硅的工厂地图。",
    link: "https://www.pv-magazine-china.com/2024/08/13/sinovoltaics%e6%9b%b4%e6%96%b0%e6%ac%a7%e6%b4%b2%e5%a4%aa%e9%98%b3%e8%83%bd%e7%bb%84%e4%bb%b6%e7%94%9f%e4%ba%a7%e5%9f%ba%e5%9c%b0%e5%9c%b0%e5%9b%be/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-13 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "毒舌 AI Twitter Personality 每小时赚 4000 美元，每分钟 36 个新用户",
    abstract:
      "病毒式传播的“毒舌 AI”Twitter Personality 每小时赚4000美元！（约2.8万元），只需输入一个推特用户名，就能得到 AI 根据历史发言做的犀利点评。而且只要是公开账号就行，并不需要获取任何权限，除了查看 AI 对自己的看法，还可以用来恶搞朋友，甚至名人。“毒舌AI”Twitter Personality构建在低代码开发平台 Wordware 上。",
    link: "https://www.qbitai.com/2024/08/177145.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-08-12 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title:
      "以色列强制要求新建大型建筑物安装屋顶太阳能且计划到2040年达成3.5 GW的目标",
    abstract:
      "以色列当局已出台新的法规，要求新建大型建筑物安装屋顶光太阳能，且计划到2040年部署3.5 GW太阳能。新规要求光伏系统的最低产能为5 kW。",
    link: "https://www.pv-magazine-china.com/2024/08/12/%e4%bb%a5%e8%89%b2%e5%88%97%e5%bc%ba%e5%88%b6%e8%a6%81%e6%b1%82%e6%96%b0%e5%bb%ba%e5%a4%a7%e5%9e%8b%e5%bb%ba%e7%ad%91%e7%89%a9%e5%ae%89%e8%a3%85%e5%b1%8b%e9%a1%b6%e5%a4%aa%e9%98%b3%e8%83%bd%e4%b8%94/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-12 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LongWriter：从长上下文LLM释放10，000多个单词生成",
    abstract:
      "当前的长上下文大型语言模型（LLM）可以处理多达100，000个标记的输入，但难以生成超过2，000个单词的输出。通过控制实验，我们发现模型的有效生成长度本质上受监督微调（SFT）过程中所看到的样本的限制。换句话说，它们的输出限制是由于现有SFT数据集中缺乏长输出示例。为了解决这个问题，我们引入了AgentWrite，这是一种基于代理的管道，它将超长生成任务分解为子任务，使现成的LLM能够生成超过20，000个字的连贯输出。",
    link: "https://arxiv.org/abs/2408.07055",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0812-0818",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "CROME：用于高效多模式LLM的跨模式适配器",
    abstract:
      "多模态大型语言模型（MLLM）表现出卓越的图像语言能力，但其广泛使用面临着成本效益培训和适应的挑战。现有的方法通常需要昂贵的语言模型再训练和有限的适应性。此外，当前对zero-shot性能改进的关注不足以为特定于任务的调优提供指导。我们提出了CROME，一个有效的视觉语言指令调优框架。它具有一个新的门控跨模态适配器，有效地结合了视觉和文本表示之前，输入到一个冻结的LLM。这个轻量级的适配器，用最少的参数训练，实现了高效的跨模态理解。",
    link: "https://arxiv.org/abs/2408.06610",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0805-0811",
    week_title: "2024年8月第1期",
    anchor: "20240805",
    week_abs_long: {
      新闻: "阿里开源Qwen2-Math超越GPT-4o和Claude-3.5，Kimi上下文缓存存储费用降价50%。",
      创投: "OpenAI基金牵头投资Opal，「零一万物」融资数亿美元，有国际战投和东南亚财团加盟。",
      行业: "美国新法案削减对中国太阳能制造商的45 X税收抵免，澳大利亚太阳能电池板回收公司与加拿大硅阳极开发商合作。",
      论文: "调整大型语言模型以实现可控推荐。",
    },
  },
  {
    week: "0805-0811",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "阿里开源Qwen2-Math：数学推理全球第一，超越GPT-4o和Claude-3.5",
    abstract:
      "阿里开源了Qwen2-Math（1.5B/7B/72B）系列，Qwen2-Math是一系列基于Qwen2 LLM构建的专门用于数学解题的语言模型，数学推理能力全球第一。在Math上的评测结果表明，最大的数学专用模型Qwen2-Math-72B-Instruct超越了最先进的模型，包括GPT-4o、Claude-3.5-Sonnet、Gemini-1.5-Pro和Llama-3.1-405B。",
    link: "https://qwenlm.github.io/zh/blog/qwen2-math/",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Qwen.png",
    source_name: "Qwen",
    publish_time: "2024-08-09 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过上下文学习增强检索增强语言模型的鲁棒性",
    abstract:
      "检索增强语言模型（RALM）通过利用外部知识，大大提高了开放领域问题解答（QA）的性能。然而，RALMs 仍然难以应对无法回答的查询（检索到的上下文不包含正确答案）和冲突信息（由于检索不完善，不同来源提供的答案相互矛盾）。本研究引入了一种基于上下文学习的方法来增强 RALMs 的推理能力，使其在不完善的检索场景中更加稳健。我们的方法结合了机器阅读理解（MRC）演示（称为案例），以增强模型识别未回答问题和检索上下文冲突的能力。",
    link: "https://arxiv.org/abs/2408.04414",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "月之暗面 Kimi 上下文缓存 Cache 存储费用降价 50%",
    abstract:
      "月之暗面宣布，Kimi 开放平台的上下文缓存 Cache 存储费用降价 50%，Cache 存储费用由 10 元 / 1M tokens / min 降低至 5 元 / 1M tokens / min，即日起生效。7 月 1 日，Kimi 开放平台上下文缓存（Context Caching）功能开启公测。官方表示，该技术在 API 价格不变的前提下，可为开发者降低最高 90% 的长文本旗舰大模型使用成本，并提升模型响应速度。",
    link: "https://mp.weixin.qq.com/s/WnJxHXpKSsNq1Sl-LHj0Ug",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/月之暗面.png",
    source_name: "月之暗面",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "使用新型多尺度Transformer方法进行高效、准确的肺炎检测",
    abstract:
      "肺炎是一种严重的呼吸道疾病，给诊断带来了巨大挑战，尤其是在欠发达地区。传统的诊断方法，如胸部 X 光片，在放射科医生之间的解释存在差异，因此需要可靠的自动化工具。在本研究中，我们提出了一种结合深度学习和基于变压器的注意力机制的新方法，以提高胸部 X 光片的肺炎检测能力。",
    link: "https://arxiv.org/abs/2408.04290",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "OpenAI基金牵头6000万美元投资硬件初创企业Opal",
    abstract:
      "据The information报道，OpenAI基金正在牵头为Opal（之前称为Opal Camera）进行 6000 万美元的 B 轮融资。其他投资方包括 YouTuber Casey Neistat和TikTok兄弟Charli和Dixie D’Amelio，以及Founders Fund和Kindred Ventures在内的现有投资者参投。",
    link: "https://mp.weixin.qq.com/s/TgVwwcZ_HGDEGwo3Ga2a2A",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/钛媒体.png",
    source_name: "钛媒体",
    publish_time: "2024-08-08 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "「零一万物」完成数亿美元融资，某国际战投、东南亚财团加盟",
    abstract:
      "李开复创办的AI大模型独角兽公司零一万物已经完成新一轮融资，金额达数亿美元。知情人士表示，此轮融资参与方包括某国际战投、东南亚财团等多家机构。如今的“大模型六小虎”（智谱AI、零一万物、百川智能、MiniMax、月之暗面、阶跃星辰），正以惊人的速度，跨过200亿元的估值大关。",
    link: "https://mp.weixin.qq.com/s/JwEHBtHs4HQZMCh5pg25Ng",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-08-07 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "行业",
    effect: "负面",
    color: "#108ee9",
    title: "美国出台新法案削减对中国太阳能制造商的45 X税收抵免",
    abstract:
      "在丰厚的税收抵免吸引着世界各地的清洁能源制造商前往美国建厂的同时，其中许多新建制造工厂都属于中国公司的事实引发了争议。而全新出台的法案旨在解决这一争议。",
    link: "https://www.pv-magazine-china.com/2024/08/06/%e7%be%8e%e5%9b%bd%e5%87%ba%e5%8f%b0%e6%96%b0%e6%b3%95%e6%a1%88%e5%89%8a%e5%87%8f%e5%af%b9%e4%b8%ad%e5%9b%bd%e5%a4%aa%e9%98%b3%e8%83%bd%e5%88%b6%e9%80%a0%e5%95%86%e7%9a%8445-x%e7%a8%8e%e6%94%b6/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-06 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "行业",
    effect: "正面",
    color: "#108ee9",
    title: "澳大利亚太阳能电池板回收公司与加拿大硅阳极开发商携手合作",
    abstract:
      "澳大利亚太阳能电池板回收公司Lotus Energy已与加拿大硅阳极开发商Neo Battery Materials签署协议，将携手满足未来北美地区的电动汽车与储能需求。",
    link: "https://www.pv-magazine-china.com/2024/08/06/%e6%be%b3%e5%a4%a7%e5%88%a9%e4%ba%9a%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e6%9d%bf%e5%9b%9e%e6%94%b6%e5%85%ac%e5%8f%b8%e4%b8%8e%e5%8a%a0%e6%8b%bf%e5%a4%a7%e7%a1%85%e9%98%b3%e6%9e%81%e5%bc%80/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-08-06 00:00:00",
  },
  {
    week: "0805-0811",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "调整大型语言模型以实现可控推荐_x000D_\n",
    abstract:
      "受大型语言模型（LLM）卓越的通用智能的启发，研究人员已开始探索如何将其应用于下一代推荐系统--会话式、可解释和可控制的系统。然而，现有文献主要集中于将特定领域的知识整合到 LLM 中以提高准确性，而往往忽略了遵循指令的能力。为了弥补这一不足，我们首先引入了一系列监督学习任务，这些任务使用了从传统推荐模型中提取的标签，旨在明确提高 LLMs 遵循特定推荐指令的能力。随后，我们开发了一种基于强化学习的对齐程序，以进一步加强 LLM 在响应用户意图和减少格式错误方面的能力。",
    link: "https://arxiv.org/abs/2403.05063",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-08-04 00:00:00",
  },
  {
    week: "0727-0804",
    week_title: "2024年7月第4期",
    anchor: "20240727",
    week_abs_long: {
      创投: "AI销售助手Sybill融资1100万美元，每周节省5小时; 人形机器人「星尘智能」获数千万美元Pre-A轮融资，专注AI机器人商业化; AI图像生成平台LiblibAI完成数亿元融资，一年三轮。",
      新闻: "Midjourney V6.1新版上线，远景人脸优化，GPT-4o语音模式向用户开放，豆包大模型日均tokens使用量超5000亿。",
      行业: "欧洲可再生能源土地需求少，印度以相对低廉的价格分配可再生能源和储能，农业光伏发电在印度具备较低的成本和较短的投资回收期。",
      论文: "Control MLLM：多模式大型语言模型的免训练视觉提示学习。",
    },
  },
  {
    week: "0727-0804",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Midjourney V6.1新版本上线即爆火：优化远景人脸，细节更丰富",
    abstract:
      "时隔半年，Midjourney带来重磅更新，现在已开放体验。v6.1在8个方面进行升级。一句话总结，就是让生成图像看上去更好看。而且再下一个版本马上就会发布，官方表示v6.2可能在下月和大家见面，将会做更多升级，比如文字方面。",
    link: "https://www.qbitai.com/2024/07/173178.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-08-01 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI销售助手Sybill融资1100万美元，帮助销售每周节省5小时",
    abstract:
      "Sybill 是一家专为销售代表打造人工智能助理的初创公司，该公司周三表示，它已在由 Greycroft 领投的 A 轮融资中筹集到 1100 万美元。销售人工智能助理的市场已经变得相当拥挤，因为很多公司都利用生成式人工智能和大型语言模型来帮助销售人员自动完成繁琐的工作，如填写提案申请、更新内部数据库等。",
    link: "https://mp.weixin.qq.com/s/ExmABSxu-KR3bgwsrh8t6w",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-08-01 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过视觉问题回答，引入医学大型视觉语言模型来诊断病理",
    abstract:
      "大模型虽然在医学视觉问题诊断（VQA）任务上表现出令人满意的性能，但医学LVLM（MLVLM）仍然存在幻觉问题，这使得它们无法诊断复杂的病理。此外，由于不平衡的训练数据，它们很容易无法学习少数民族的病理学。我们提出了两个提示策略MLVLM，减少幻觉，提高VQA性能。",
    link: "https://arxiv.org/abs/2407.21368",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-31 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "人形机器人「星尘智能」获数千万美元Pre-A轮融资，专注AI机器人商业化",
    abstract:
      "AI机器人公司星尘智能（Astribot）宣布完成数千万美元Pre-A轮融资，由经纬创投领投，道彤投资及清辉投资等产业资本跟投，老股东云启资本跟投。华兴资本担任独家财务顾问。本轮融资将用于顶尖人才招募、研发投入、商业化部署等工作。",
    link: "https://mp.weixin.qq.com/s/KnKc0aK-G8ACMuxhSJ9Ypw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯新闻",
    publish_time: "2024-07-31 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI向部分用户开放GPT-4o语音模式 今秋将扩大至所有付费用户",
    abstract:
      "OpenAI周二宣布，即日起开始向部分ChatGPT Plus用户推出GPT-4o的语音模式；目前GPT-4o语音模式可使用四种预设声音，Juniper、Breeze、Cove和Ember，这些声音是与付费配音演员合作制作的。",
    link: "https://www.cls.cn/detail/1748979",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-31 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "Control MLLM：多模式大型语言模型的免训练视觉提示学习",
    abstract:
      "在这项工作中，我们提出了一种无需训练的方法，通过可学习的视觉标记优化将视觉引用注入多模态大型语言模型（MLLM）。我们观察文本提示标记和视觉标记之间的关系，在MLLM中，注意层模型之间的连接。我们的方法涉及到调整视觉标记从MLP输出在推理过程中，控制哪些文本提示令牌出席哪些视觉标记。我们基于能量函数优化了可学习的视觉标记，增强了注意力图中参考区域的强度。这使得能够进行详细的区域描述和推理，而不需要大量的训练成本或模型再训练。",
    link: "https://arxiv.org/abs/2407.21534",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-31 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "豆包大模型日均tokens使用量超5000亿，AI生图玩法猛猛上新",
    abstract:
      "近日，国产大模型「顶流」—— 字节跳动豆包大模型，迎来一场集中放送：在 2024 火山引擎 AI 创新巡展成都站活动上，豆包大模型团队公布了豆包大模型的最新进展，以及文生图模型、语音模型等垂直模型的新升级。与此同时，豆包大模型家族的最新成员 ——「豆包・图生图模型」正式面世，一口气上新了 50 多项玩法。",
    link: "https://www.jiqizhixin.com/articles/2024-07-29-5",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-07-30 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "科研人员发现印度农业光伏发电LCOE为$0.059 /kWh，投资回收期为7年",
    abstract:
      "印度科研人员对农业光伏系统与单面和双面屋顶光伏系统进行了性能比较，发现前者投资回收期更短，平准化能源成本（LCOE）更低。他们对性能的分析考虑了面板温度、功率输出、土地当量比和可靠性。",
    link: "https://www.pv-magazine-china.com/2024/07/30/%e7%a7%91%e7%a0%94%e4%ba%ba%e5%91%98%e5%8f%91%e7%8e%b0%e5%8d%b0%e5%ba%a6%e5%86%9c%e4%b8%9a%e5%85%89%e4%bc%8f%e5%8f%91%e7%94%b5lcoe%e4%b8%ba0-059-kwh%ef%bc%8c%e6%8a%95%e8%b5%84%e5%9b%9e%e6%94%b6/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-30 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "欧洲发展可再生能源所需土地“极少”",
    abstract:
      "欧洲环境署（EEB）表示，欧盟2.2%的土地可以容纳所需的太阳能和风能项目以逐步淘汰化石燃料和核能，并到2040年实现气候中和。",
    link: "https://www.pv-magazine-china.com/2024/07/30/%e6%ac%a7%e6%b4%b2%e5%8f%91%e5%b1%95%e5%8f%af%e5%86%8d%e7%94%9f%e8%83%bd%e6%ba%90%e6%89%80%e9%9c%80%e5%9c%9f%e5%9c%b0%e6%9e%81%e5%b0%91/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-30 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "印度以$0.059 /kWh均价分配630 MW可再生能源加储能",
    abstract:
      "中标开发商将建立可再生能源项目，并配备储能系统，以需求跟踪的方式提供累计630 MW的稳定可调度可再生能源电力。",
    link: "https://www.pv-magazine-china.com/2024/07/30/%e5%8d%b0%e5%ba%a6%e4%bb%a50-059-kwh%e5%9d%87%e4%bb%b7%e5%88%86%e9%85%8d630-mw%e5%8f%af%e5%86%8d%e7%94%9f%e8%83%bd%e6%ba%90%e5%8a%a0%e5%82%a8%e8%83%bd/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-30 00:00:00",
  },
  {
    week: "0727-0804",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "一年三轮，AI图像生成平台LiblibAI完成数亿元融资",
    abstract:
      "AI图像生成平台 “LiblibAI哩布哩布AI”在至今的一年内，已经完成了三轮融资，总金额达数亿元人民币：天使轮投资方为源码资本、高榕创投和金沙江创投；第二轮由战略投资方领投；第三轮由明势资本领投；老股东持续多轮加持。其中，远识资本为多轮融资的独家财务顾问。",
    link: "https://36kr.com/p/2880308225184642",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-07-29 00:00:00",
  },
  {
    week: "0720-0726",
    week_title: "2024年7月第3期",
    anchor: "20240720",
    week_abs_long: {
      新闻: "OpenAI发布AI搜索产品SearchGPT，IBM财报超预期，马斯克宣布年底开发全球最强AI。",
      创投: "沙特阿美投资韩国芯片制造商1500万美元，Cohere获得5亿美元融资，估值达55亿美元。",
      行业: "德国上半年阳台光伏装机量达到200 MW；超过一半的加利福尼亚州太阳能客户将加装电池储能系统。",
      论文: "Q-Sparse：所有大型语言模型都可以完全稀疏激活。",
    },
  },
  {
    week: "0720-0726",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI发布AI搜索产品SearchGPT，并开放内测候补",
    abstract:
      "OpenAI发布了名为SearchGPT的AI搜索产品，并开放候补名单，进行小范围测试。OpenAI创始人兼CEO Sam Altman，已经为新AI搜索产品吹了一波“彩虹屁”：“比起传统搜索产品，我对这（SearchGPT）的喜爱程度和适应速度令人惊喜。”",
    link: "https://36kr.com/p/2878012847477633",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-07-26 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "AI带动软件收入大涨 IBM财报超预期",
    abstract:
      "IBM公布了强于分析师预期的第二季度业绩报告。报告公布后，该公司股价在周三的盘后交易中一度上涨5%。截至发稿，盘后涨幅收窄回3%。得益于与人工智能相关的软件收入增加，这家科技界的蓝色巨人上调了软件业务的年度增长预期。而软件业务也成为该公司主要增长动力。",
    link: "https://www.cls.cn/detail/1743677",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-25 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "Q-Sparse：所有大型语言模型都可以完全稀疏激活",
    abstract:
      "微软亚洲研究院提出的Q-Sparse实现了大型语言模型激活的完全稀疏性，有效降低推理成本，展现出广泛的兼容性，包括与BitNet技术的正交互补性，为LLMs推理中的数据类型提供全面优化。",
    link: "https://arxiv.org/abs/2407.10969",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-24 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "马斯克宣布全球最大AI训练集群：年底开发出全球最强AI",
    abstract:
      "马斯克昨日在社交平台X上发文宣布xAI团队、X团队、英伟达及支持公司于当地时间凌晨4点20分开始在“世界上最强大的AI训练集群”——孟菲斯超级集群上进行训练。该集群在单个RDMA fabric上使用10万张液冷H100。马斯克在评论区透露其目标是“今年12月前训练出世界上最强大的人工智能”。",
    link: "https://zhidx.com/news/42257.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-07-23 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "超过一半的加利福尼亚州太阳能客户将加装电池储能系统",
    abstract:
      "电池成本下降、法规变化和对能源独立的兴趣正推动着加利福尼亚州住宅太阳能项目的电池加装率走高。",
    link: "https://www.pv-magazine-china.com/2024/07/23/%e8%b6%85%e8%bf%87%e4%b8%80%e5%8d%8a%e7%9a%84%e5%8a%a0%e5%88%a9%e7%a6%8f%e5%b0%bc%e4%ba%9a%e5%b7%9e%e5%a4%aa%e9%98%b3%e8%83%bd%e5%ae%a2%e6%88%b7%e5%b0%86%e5%8a%a0%e8%a3%85%e7%94%b5%e6%b1%a0%e5%82%a8/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-23 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "发力AI产业！沙特阿美向韩国芯片制造商投资1500万美元",
    abstract:
      "沙特阿美风险投资部门Wa’ed Ventures已向韩国芯片制造商Rebellions公司投资了1500万美元；沙特目前正加速发展人工智能产业，这笔投资将有助于沙特在全球技术和创新竞赛中的努力；据悉，Rebellions将利用这笔资金在沙特建立一家新的子公司。",
    link: "https://www.cls.cn/detail/1741351",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-23 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "加拿大AI独角兽Cohere获得5亿美元D轮融资，估值达55亿美元",
    abstract:
      "加拿大AI独角兽Cohere昨日宣布获得5亿美元D轮融资，估值达55亿美元。本轮融资由加拿大养老金投资管理公司PSP Investments领投，新投资者包括思科、日本富士通、AMD旗下AMD Ventures、加拿大出口信贷机构EDC等。",
    link: "https://zhidx.com/news/42256.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-07-23 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "德国上半年阳台光伏装机量达到200 MW",
    abstract:
      "德国联邦网络局（Bundesnetzagentur）称，今年上半年德国共安装22万套阳台光伏系统，达到200 MW。",
    link: "https://www.pv-magazine-china.com/2024/07/22/%e5%be%b7%e5%9b%bd%e4%b8%8a%e5%8d%8a%e5%b9%b4%e9%98%b3%e5%8f%b0%e5%85%89%e4%bc%8f%e8%a3%85%e6%9c%ba%e9%87%8f%e8%be%be%e5%88%b0200-mw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-22 00:00:00",
  },
  {
    week: "0720-0726",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "为图表理解定制的多模态语言模型的预训练",
    abstract:
      "本文通过探索提高多模态大型语言模型（MLLM）对图表理解所需的训练过程来解决图表理解问题，并提出了CHOPINLLM，这是一种专为深入理解图表而定制的MLLM。CHOPINLLM有效地解释了各种类型的图表，包括未标注的图表，同时保持了强大的推理能力。此外，我们建立了一个新的基准来评估MLLM在不同理解水平上对不同图表类型的理解。实验结果表明，CHOPINLLM在理解各种类型的带注释和无注释图表方面表现出很强的性能。",
    link: "https://arxiv.org/abs/2407.14506",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-19 00:00:00",
  },
  {
    week: "0713-0719",
    week_title: "2024年7月第2期",
    anchor: "20240713",
    week_abs_long: {
      行业: "OpenAI正研发AI芯片，储能碳纤维为无重力电池铺路，双面光伏单轴跟踪系统可降低电力成本。",
      新闻: "OpenAI推出价格低廉GPT-4o mini; 特朗普盟友启动AI“曼哈顿计划”; Anthropic发布支持实时翻译的Claude Android版; 美国提出《COPIED法案》，规范AI内容。",
      创投: "小雨智造获得小米投资，李飞飞的World Labs估值超过10亿美元，逐际动力完成亿级A轮融资。",
      论文: "BEAF：观察前后变化以评估视觉语言模型中的幻觉。",
    },
  },
  {
    week: "0713-0719",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI 推出性能强大但价格更便宜的 AI 模型 GPT-4o mini",
    abstract:
      "美国人工智能初创公司OpenAI宣布，正式上架价格显著下降的新一代入门级别人工智能“小模型”GPT-4o mini。最新上架的GPT-4o mini则是一个规格更小、更便宜的变体，通过兼具“能力和性价比”，拓展低价位市场的竞争。根据OpenAI披露，GPT-4o mini的API价格将会是15美分/100万Tokens输入，以及60美分/100万Tokens输出。上下文窗口依然是12.8万个Tokens，知识截止日期为2023年10月。",
    link: "https://www.cls.cn/detail/1738086",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-19 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "OpenAI 据称正与博通等公司接洽以研发 AI 芯片",
    abstract:
      "据媒体周四援引知情人士的话报道称，ChatGPT制造商OpenAI正在与包括博通（Broadcom）在内的芯片设计商接洽，共同探讨研发全新的人工智能（AI）芯片。此外，该公司还在招聘前谷歌员工，希望借助其开发Tensor处理器的经验和技术，开发出自家的AI服务器芯片。",
    link: "https://www.cls.cn/detail/1738322",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-19 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "基于语言模型的具有可控自发行为的自发风格文本到语音合成",
    abstract:
      "由于缺乏高质量的数据和模型能力的限制，旨在生成类人语音的自发式语音合成经常遇到挑战。最近的基于语言模型的TTS系统可以在大型，多样化和低质量的语音数据集上进行训练，从而产生高度自然的合成语音。然而，它们受到模拟各种自发行为和捕捉自发语音中的韵律变化的困难的限制。在本文中，我们提出了一种新的自发语音合成系统的语言模型的基础上。我们系统地对各种自发行为进行分类和统一建模。",
    link: "https://arxiv.org/abs/2407.13509",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-18 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "具身智能科技公司「小雨智造」获小米、智源等投资",
    abstract:
      "据36氪报道，小米集团和机器人泰斗王田苗，投了一家具身智能科技公司「小雨智造」。该公司2023年2月成立 ，成立之后陆续完成了亿元种子轮融资，由小米集团、机器人泰斗王田苗、北京智源研究院出资。据了解，「小雨智造」的核心创始团队也曾是小米曾经的高层：「小雨智造」创始人乔忠良是小米的初创成员之一，曾经是MIUI研发负责人，负责过MIUI 9到MIUI 12等产品，于2023年1月从小米离职；其联合创始人王文林，曾任职小米软件系统平台部总经理，主导了“小米大脑”和IoT系统的开发。团队其他成员来自于小米、华为、字节跳动、微软等公司。",
    link: "https://36kr.com/p/2866102868085639",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-07-18 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "BEAF：观察前后变化以评估视觉语言模型中的幻觉",
    abstract:
      "视觉语言模型（VLM）通过视觉编码器和大型语言模型（LLM）的组合来感知世界。在大规模视觉文本数据集上预先训练的视觉编码器提供了对视觉数据的zero-shot泛化，并且LLM赋予其对VLM的高推理能力。它使VLM无需微调即可在广泛的基准测试中实现高性能，表现出零或Few-Shot的能力。然而，最近的研究表明，VLM很容易产生幻觉。这种不受欢迎的行为降低了可靠性和可信度，从而使用户无法完全信任VLM的输出。本文提出了一种增强可信度并更好地解决VLM的幻觉问题的方案。",
    link: "https://arxiv.org/abs/2407.13442",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-18 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "特朗普盟友起草AI行政命令，启动“曼哈顿计划”",
    abstract:
      "据外媒报道，前美国总统唐纳德·特朗普的盟友正在起草一项全面的人工智能行政命令，该命令将启动一系列“曼哈顿项目”，以开发军事技术，并立即审查“不必要和繁琐的法规”。这表明特朗普第二届政府可能会推行有利于硅谷投资者和公司的人工智能（AI）政策。",
    link: "https://zhidx.com/p/434111.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-07-17 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "李飞飞旗下AI初创企业World Labs估值已超10亿美元",
    abstract:
      "据英国《金融时报》援引知情人士称，著名华裔计算机科学家李飞飞创办的“空间智能”创企World Labs估值已经赶超10亿美元。该创企主要利用类似人类的视觉数据处理技术，使AI具备高级推理能力。据两位知情人士透露，从今年4月成立至今，World Labs已经进行了两轮融资，投资方包括顶级科技投资者Andreessen Horowitz和AI基金Radical Ventures。据了解，其最新一轮的融资金额可能达到约1亿美元。",
    link: "https://zhidx.com/p/434184.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-07-17 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Anthropic 推出 Claude Android 版，支持实时翻译",
    abstract:
      "OpenAI竞争对手Anthropic于周二推出了AI聊天机器人Claude App的Android版应用程序，希望通过在更多平台上提供Claude来说服用户放弃ChatGPT。Claude Android应用程序将与5月发布的iOS版本运作模式相同，用户可免费访问Anthropic最佳的AI模型Claude 3.5 Sonnet，并通过Anthropic的Pro和Team订阅升级计划。用户将能够在设备间同步他们与Claude的对话，并可以将照片或文件上传到应用程序进行实时图像分析。",
    link: "https://wallstreetcn.com/articles/3719812?keyword=anthropic",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-07-17 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "储能碳纤维复合材料为无重力电池铺平了道路",
    abstract:
      "在瑞典查尔姆斯理工大学研究工作的基础上，Sinonus公司已开发出一种基于碳纤维的结构电池，这种电池不仅可以储存能量，而且还可以成为产品结构不可或缺的组成部分。据称，在当前技术水平下，这种电池的可能能量密度范围约为传统锂离子电池的25-50%。",
    link: "https://www.pv-magazine-china.com/2024/07/16/%e5%82%a8%e8%83%bd%e7%a2%b3%e7%ba%a4%e7%bb%b4%e5%a4%8d%e5%90%88%e6%9d%90%e6%96%99%e4%b8%ba%e6%97%a0%e9%87%8d%e5%8a%9b%e7%94%b5%e6%b1%a0%e9%93%ba%e5%b9%b3%e4%ba%86%e9%81%93%e8%b7%af/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-16 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "IEA-PVPS表示，双面光伏单轴跟踪系统可将电力成本降至最低",
    abstract:
      "国际能源署光伏发电系统计划（IEA-PVPS）最新情况说明涵盖了双面光伏模块和先进的跟踪系统。根据该情况说明，双面模块与单轴跟踪系统相结合，可以将能量产出提高35%。",
    link: "https://www.pv-magazine-china.com/2024/07/16/iea-pvps%e8%a1%a8%e7%a4%ba%ef%bc%8c%e5%8f%8c%e9%9d%a2%e5%85%89%e4%bc%8f%e5%8d%95%e8%bd%b4%e8%b7%9f%e8%b8%aa%e7%b3%bb%e7%bb%9f%e5%8f%af%e5%b0%86%e7%94%b5%e5%8a%9b%e6%88%90%e6%9c%ac%e9%99%8d%e8%87%b3/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-16 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "人形机器人公司「逐际动力」完成数亿元A轮融资，多巨头领投",
    abstract:
      "通用机器人公司「逐际动力」完成数亿元A轮战略融资，由阿里巴巴、招商局创投、上汽集团旗下尚颀资本领投，原始股东峰瑞资本、绿洲资本和明势资本跟投。「逐际动力」创立于2022年，主要产品包括全尺寸人形机器人、四轮足机器人、双足机器人等，落地应用于智能制造、工业巡检、物流配送、家庭服务等领域。",
    link: "https://36kr.com/p/2860538964462467",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-07-15 00:00:00",
  },
  {
    week: "0713-0719",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "美国提出《COPIED法案》，要求标记、验证和检测生成式 AI 内容",
    abstract:
      "7月12日晚，美国参议院官网公布了一个由，Cantwell、Blackburn和Heinrich三位两党国会议员提出新的法案——COPIED Act。该法案的主要目的是，制定完善的规则来标记、验证和检测ChatGPT、Uido、Suno、Midjourney等生成式AI产品，提升生成内容的透明度防止被非法乱用以及保护公众的个人数据和隐私。同时保护记者、歌唱家、演员和其他艺术、商业群体的利益，并保留对违规者非法使用其数据训练AI大模型的法律追究权益。",
    link: "https://mp.weixin.qq.com/s/SkiWUjVs06EGFmAjYErP4g",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/AIGC开放社区.png",
    source_name: "AIGC开放社区",
    publish_time: "2024-07-13 00:00:00",
  },
  {
    week: "0706-0712",
    week_title: "2024年7月第1期",
    anchor: "20240706",
    week_abs_long: {
      新闻: "三星将升级Bixby语音助手，OpenAI CEO与赫芬顿创建新AI健康公司，MOSS大模型即将进入“世界模型”阶段，Kimi智能助手推新浏览器插件。",
      创投: "AI初创公司Groq获得贝莱德3亿美元投资，估值22亿，Captions完成6000万美元C轮融资，EDF投资以色列机器人农业光伏初创公司。",
      行业: "马斯克的xAI与甲骨文合作破裂，计划购买自有芯片建数据中心；南非对太阳能板征10%关税；越南对双边PPA开放能源市场。",
      论文: "FunAudioLLM：人类与大模型之间自然交互的语音理解和生成基础模型。",
    },
  },
  {
    week: "0706-0712",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "消息称 AI 芯片初创公司 Groq 获贝莱德 3 亿美元投资，最新估值 22 亿美元",
    abstract:
      "根据 The Information 最新报道，英伟达竞敌 Groq 预计将在未来两周内完成由贝莱德领投的 3 亿美元融资，估值达到 22 亿美元。相较于 2021 年，由 Tiger Global Management 和 D1 Capital 领投的 11 亿美元估值翻了一倍。Groq 创始人是谷歌专用芯片 NPU 发明者之一 Jonathan Ross。今年 2 月，Groq 发布了演示视频，展示了其 AI 芯片如何在几分之一秒内运行 LLM。",
    link: "https://mp.weixin.qq.com/s/rItE2u3dXdAIqm4PXICvyw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-07-11 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "三星今年将推出升级版语音助手Bixby 配备自家大模型",
    abstract:
      "三星移动业务负责人在接受最新采访时表示，该公司将在今年推出基于自己人工智能（AI）模型的升级版语音助手Bixby。此前就有报道称，三星正在研发升级版Bixby，而此次是该公司首次确认发布时间。Bixby的升级反映了三星正在其设备套件上更加努力地推广人工智能功能。此外，除了自家的Bixby外，三星还将继续允许其他的语音助手在其设备上运用。例如，谷歌的人工智能助手也可以在三星的最新设备上使用。",
    link: "https://www.cls.cn/detail/1730618",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-11 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "FunAudioLLM：人类与大模型之间自然交互的语音理解和生成基础模型",
    abstract:
      "本报告介绍了 FunAudioLLM，这是一个旨在增强人类与大型语言模型 (LLM) 之间的自然语音交互的模型系列。其核心是两个创新模型：SenseVoice，处理多语言语音识别、情感识别和音频事件检测； CosyVoice，通过控制多种语言、音色、说话风格和说话者身份来促进自然语音生成。SenseVoice 和 CosyVoice 相关模型已在 Modelscope 和 Huggingface 上开源，相应的训练、推理和微调代码也在 GitHub 上发布。FunAudioLLM 支持语音到语音翻译、情感语音聊天、交互式播客和富有表现力的有声读物旁白等应用，从而突破了语音交互技术的界限。",
    link: "https://arxiv.org/abs/2407.04051",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-11 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "马斯克旗下xAI与甲骨文百亿美元合作谈判破裂，拟自购芯片建数据中心",
    abstract:
      "近期，马斯克麾下人工智能公司xAI与甲骨文之间的协议扩展谈判宣告破裂。原协议中，xAI计划从甲骨文租赁专用的英伟达人工智能芯片。但据知情人士透露，xAI现已决定自主采购芯片，以构建其数据中心基础设施。据悉，xAI原本与甲骨文正就一项多年期的合作协议进行深入探讨，该协议旨在让xAI从甲骨文处租用英伟达芯片，以支持其即将打造的超级计算机项目，预计交易规模可达100亿美元之巨。",
    link: "https://new.qq.com/rain/a/20240710A00P5X00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-07-10 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "LLaVA-NeXT-Interleave：处理大型多模态模型中的多图像、视频和 3D",
    abstract:
      "视觉指令调整在增强大型多模态模型(LMMs)的能力方面取得了显著进展。然而,现有的开放式LMMs主要集中在单图像任务上,它们在多图像、多帧(视频)、多视角(3D)和多块(单图像)等更复杂的场景中的应用尚未得到充分探索。为了解决这些问题,我们提出了LLaVA-NeXT-Interleave。该模型旨在同时处理LMMs中的多图像、多帧、多视角和多块情境。",
    link: "https://arxiv.org/abs/2407.07895v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-10 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "EDF投资以色列一家机器人农业光伏初创公司",
    abstract:
      "AgRE.tech已从EDF和Zemach Regional Industries融资200万美元，当前正在为现有光伏基础设施开发一个机器人操作系统。该公司表示，其将很快开拓商用领域。",
    link: "https://www.pv-magazine-china.com/2024/07/10/edf%e6%8a%95%e8%b5%84%e4%bb%a5%e8%89%b2%e5%88%97%e4%b8%80%e5%ae%b6%e6%9c%ba%e5%99%a8%e4%ba%ba%e5%86%9c%e4%b8%9a%e5%85%89%e4%bc%8f%e5%88%9d%e5%88%9b%e5%85%ac%e5%8f%b8/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-10 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI 视频初创公司 Captions 获 6000 万美元 C 轮融资",
    abstract:
      "生成式 AI 视频制作和编辑初创公司 Captions，目前已从众多明星投资者那里完成新一轮融资，估值跃升至 5 亿美元。周二，Captions 宣布完成由 Index Ventures 牵头的 6000 万美元融资，总筹集资金达到 1 亿美元。本轮融资其他投资者包括 Kleiner Perkins、a16z 和 Sequoia Capital，还有 Jared Leto 等新投资者，Leto 也是另一家 AI 视频公司 Pika 投资者之一。",
    link: "https://mp.weixin.qq.com/s/ZDKw5kYslCbgc0wtQuV_Tw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-07-10 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "多模态集成如何提高 LLM 的优化性能：容量车辆路径问题的案例研究",
    abstract:
      "大型语言模型在解决复杂优化问题方面展现出了强大的能力。然而，现有的基于 LLM 的优化方法普遍存在一个主要限制，即在仅依赖数值文本提示时，难以捕捉决策变量之间的关系，尤其在处理高维问题时更为明显。鉴于此，我们首先提出使用能够处理文本和视觉提示的多模态 LLM 来提升优化性能，以便对所处理的优化问题有更深层次的理解。这种整合使得对优化问题的理解更加全面，类似于人类的认知过程。我们开发了一个基于多模态 LLM 的优化框架，该框架模拟了人类的问题解决工作流程，从而提供了更细致和有效的分析。通过对著名的组合优化问题——容量约束车辆路径问题（CVRP）——进行广泛的实证研究，评估了该方法的有效性。",
    link: "https://arxiv.org/abs/2403.01757v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-09 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI CEO 奥特曼与赫芬顿成立一个新的AI健康公司",
    abstract:
      "OpenAI CEO Sam Altman 与AI医疗健康巨头Thrive Global的CEO阿里安娜·赫芬顿（Arianna Huffington）一起在《时代》杂志上发表了一篇文章，正式宣布了Thrive AI Health公司的成立。Thrive AI Health的目标是打造一个个性化“AI健康教练”，以手机App形式呈现。目前公司CEO是谷歌前健康和可穿戴设备负责人德卡洛斯·洛夫（DeCarlos Love），OpenAI创业基金和Thrive Global是主要投资方。",
    link: "https://zhidx.com/p/432849.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-07-09 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "越南向双边PPA开放能源市场",
    abstract:
      "据国有媒体报道，越南政府本周颁布新规，允许独立发电商（IPP）与电力消费者之间签订直接购电协议（DPPA）。IPP现在可通过国家电网或直连线路向最终客户出售电力。",
    link: "https://www.pv-magazine-china.com/2024/07/08/%e8%b6%8a%e5%8d%97%e5%90%91%e5%8f%8c%e8%be%b9ppa%e5%bc%80%e6%94%be%e8%83%bd%e6%ba%90%e5%b8%82%e5%9c%ba/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-08 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "月之暗面为 Kimi 智能助手推出官方浏览器插件",
    abstract:
      "据月之暗面官方微信公众号消息，月之暗面推出 Kimi浏览器插件，并为网页用户带来多项新功能。Kimi 插件，目前只有两个按钮：一个是点问笔，划选文字后就会出现；另一个是总结器，出现在网页右下角，帮你快速总结全文、答疑解惑。",
    link: "https://mp.weixin.qq.com/s/-srEcOwDiEoHp1tTdleTPA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/月之暗面.png",
    source_name: "月之暗面",
    publish_time: "2024-07-08 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "南非对太阳能电池板征收10%的进口关税",
    abstract:
      "南非国际贸易管理委员会（ITAC）对太阳能电池板征收10%的进口关税，以保护当地制造商、吸引投资和深化价值链建设。南非光伏行业协会质疑缺乏正式的行业参与，称时机“不理想”。",
    link: "https://www.pv-magazine-china.com/2024/07/08/%e5%8d%97%e9%9d%9e%e5%af%b9%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e6%9d%bf%e5%be%81%e6%94%b610%e7%9a%84%e8%bf%9b%e5%8f%a3%e5%85%b3%e7%a8%8e/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-08 00:00:00",
  },
  {
    week: "0706-0712",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "MOSS大模型项目负责人邱锡鹏：大模型的下个阶段是“世界模型”",
    abstract:
      "复旦大学教授、MOSS大模型项目负责人邱锡鹏认为，当前，大语言模型还存在很多不足。比如在落地阶段，大语言模型的会遇到难以解决的“幻觉问题”，即生成不真实、不可靠、不存在的信息。邱锡鹏将大模型的未来趋势和发展方向，总结为观察世界、产生动作，并走向“世界模型”。",
    link: "https://www.cls.cn/detail/1726287",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-07-08 00:00:00",
  },
  {
    week: "0629-0705",
    week_title: "2024年6月第5期",
    anchor: "20240629",
    week_abs_long: {
      新闻: "法国AI实验室Kyutai推出新模型，Suno发布iOS APP，Runway开放Gen-3 Alpha模型，扎克伯格讨论智能眼镜、神经腕带与AI未来。",
      创投: "Character AI计划向谷歌和Meta出售，LeyLine完成数百万融资，提供AI创新平台，SK海力士将投资103万亿韩元于AI和芯片领域。",
      行业: "Rain AI招募苹果芯片专家加速AI芯片研发，已发现钙钛矿太阳能电池自我修复方法，且乌迪内斯足球队在体育场建造1.1 MW光伏系统。",
      论文: "RegMix：作为语言模型预训练回归的数据混合方法",
    },
  },
  {
    week: "0629-0705",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "法国开源AI研究实验室Kyutai发布对标GPT-4O的实时语音多模态模型Moshi",
    abstract:
      "7月4日凌晨，法国知名开源AI研究实验室Kyutai在官网发布了，具备看、听、说多模态大模型——Moshi。Moshi功能与OpenAI在5月14日展示的最新模型GPT-4o差不多，可以听取人的语音提问后进行实时推理回答内容。但GPT-4o的语音模式要在秋天才能全面开放使用，而Moshi已经提供使用了。",
    link: "https://wallstreetcn.com/articles/3718786",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-07-04 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "乌迪内斯足球队在意大利体育场建造1.1 MW光伏系统",
    abstract:
      "Bluenergy正在意大利乌迪内斯俱乐部的足球场开发1.1 MW的光伏系统。该公司表示该项目可能包括300 kW的电池。",
    link: "https://www.pv-magazine-china.com/2024/07/04/%e4%b9%8c%e8%bf%aa%e5%86%85%e6%96%af%e8%b6%b3%e7%90%83%e9%98%9f%e5%9c%a8%e6%84%8f%e5%a4%a7%e5%88%a9%e4%bd%93%e8%82%b2%e5%9c%ba%e5%bb%ba%e9%80%a01-1-mw%e5%85%89%e4%bc%8f%e7%b3%bb%e7%bb%9f/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-04 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过语言模型的自我修正，用发散的思维链改进微调过程",
    abstract:
      '事实证明，要求大语言模型生成中间推理步骤是提高性能的有效方法。在这项工作中，我们提出了一种进一步提高性能的新方法，即要求模型在单个推理步骤中生成解决方案之前对多个推理链进行比较。我们称这种方法为 "发散推理"（Divergent CoT，DCoT）。我们发现，在 DCoT 数据集上进行指令调整，甚至可以提高更小、更容易获得的小模型性能。通过一系列严格的实验，我们发现在 DCoT 上进行微调后，不同模型系列和规模（1.3B 到 70B）的性能都比 CoT 基准线有了持续提高。通过经验评估和人工评估的结合，我们还表明，这些性能提升源于模型在单个推理步骤中生成了多个不同的推理链，这表明语言模型中的自我修正功能是可行的。',
    link: "https://arxiv.org/abs/2407.03181",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-03 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "使用基于 AST 的排名和模式修剪改进检索增强的Text-to-SQL",
    abstract:
      "我们从大型语言模型的角度关注文本到 SQL 的语义解析。在商业数据库模式的规模和BI解决方案的可部署性等相关挑战的推动下，我们提出了一种动态检索输入数据库信息并使用抽象语法树为上下文学习选择少量示例的方法。此外，我们还研究了并行语义解析器在多大程度上可用于生成预期 SQL 查询的近似版本，以支持我们的检索。我们将这种方法发挥到了极致，我们调整了一个参数少于 500M 的模型，使其成为一个极其高效的近似器，并增强了它以并行方式处理模式的能力。我们将这种方法应用于单语和跨语言的语义解析基准，结果表明它比最先进的基准有所改进。",
    link: "https://export.arxiv.org/abs/2407.03227",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-03 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "AI 音乐和歌曲生成平台 Suno 推出 iOS 移动端 APP",
    abstract:
      "Suno是一款广受欢迎的人工智能音乐和歌曲生成器服务，在网络上已有超过1200万人使用，该公司推出了首款iOS设备移动应用程序。Suno iOS 版允许用户只需提供文字描述或用手机录制音频，就能轻松创建自己的音乐。用户可以生成 4 分钟长的歌曲和 2 分钟长的歌曲扩展。",
    link: "https://www.toutiao.com/article/7387209561117131273/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/cnBeta.png",
    source_name: "cnBeta",
    publish_time: "2024-07-03 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "研究人员发现帮助钙钛矿太阳能电池自我修复的方法",
    abstract:
      "由澳大利亚墨尔本蒙纳士大学（Monash University）领导的一个全球研究小组称，已取得一项突破，能使钙钛矿太阳能电池更可靠高效。",
    link: "https://www.pv-magazine-china.com/2024/07/02/%e7%a0%94%e7%a9%b6%e4%ba%ba%e5%91%98%e5%8f%91%e7%8e%b0%e5%b8%ae%e5%8a%a9%e9%92%99%e9%92%9b%e7%9f%bf%e5%a4%aa%e9%98%b3%e8%83%bd%e7%94%b5%e6%b1%a0%e8%87%aa%e6%88%91%e4%bf%ae%e5%a4%8d%e7%9a%84%e6%96%b9/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-07-02 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Runway 的文生视频模型 Gen-3 Alpha 向所有人开放",
    abstract:
      "Runway宣布，文生视频模型Gen-3 Alpha向所有用户开放使用，每个月最少12美元才能使用。Gen-3一次性只能生成11秒的720P视频，也不会带任何背景音乐，有用户表示Gen-3的功能比Sora更好，并将再次改变文生视频赛道。",
    link: "https://wallstreetcn.com/articles/3718567",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-07-02 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "LeyLine 完成首轮数百万美元融资，为创意行业提供一站式AI工作流平台",
    abstract:
      "位于西雅图初创企业「LeyLine」，已于近日完成首轮数百万美元融资，公司致力于推出全球首个针对游戏，短剧，动画，CG等内容制作行业的AI赋能人机混合智能生态系统。本轮融资的领投方为春华创投（春华资本旗下VC），跟投方包括总部位于波士顿的深科技基金Taihill Venture和多位著名天使投资人。",
    link: "https://36kr.com/p/2837756606548609",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-07-02 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Character AI融资困难，计划出售给谷歌和Meta",
    abstract:
      "由谷歌前员工创立的AI独角兽公司Character AI，曾因角色扮演聊天产品而备受瞩目。尽管A16Z曾以10亿美元估值投资1.5亿美元，但随着市场新鲜感消退和竞争加剧，公司面临融资困难，正考虑出售给谷歌或Meta。Character AI与这些科技巨头探讨了潜在合作，包括计算资源和知识产权共享。同时，公司也在寻求新的收入来源，如广告和API访问，以维持增长。",
    link: "https://mp.weixin.qq.com/s/QFRYRzkMZbKMZmyJeTEYow",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Z Finance.png",
    source_name: "Z Finance",
    publish_time: "2024-07-02 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "RegMix：作为语言模型预训练回归的数据混合方法",
    abstract:
      "大型语言模型预训练的数据混合会显着影响性能，但如何确定有效的混合仍不清楚。我们通过将其制定为回归任务来自动识别高性能数据混合方案。 RegMix 使用不同的数据混合训练一组小模型，并拟合回归模型以预测它们各自混合的性能。通过拟合的回归模型，我们模拟了排名最高的混合方案，并用它来训练具有需要更大计算量的大模型。为了凭经验验证 RegMix，我们针对不同混合比例的 1B 个 token 训练了 512 个具有 1M 个参数的模型，以拟合回归模型并找到最佳混合比例。使用这种最佳比例，再训练 25B 令牌（即大 1000 倍、长 25 倍）的 1B 参数模型，我们发现该模型在 64 个候选 1B 参数模型与其他混合中表现最佳。",
    link: "https://arxiv.org/abs/2407.01492",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-07-01 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "扎克伯格最新深度访谈讨论智能眼镜、神经腕带与个性化AI的未来",
    abstract:
      "近日， Meta CEO Mark Zuckerberg 与科技创作者 Robin Kallaway 进行了一场深度对话，讨论了未来十年的技术发展，尤其是智能眼镜、神经腕带和 AI 技术在创作者和小企业中的应用。Zuckerberg 详细讨论了智能眼镜的未来发展方向，认为其将逐步取代手机成为主要的个人硬件设备。他提到，未来的智能眼镜将分为三种类型：无显示屏的基础型、带有抬头显示的中级型和全息显示的高级型。他还强调，未来的 AI 技术将不会是单一的，而是多样化的，允许创作者和小企业创建定制化的 AI。这种多样化的 AI 体验将提升用户互动的丰富性和个性化。",
    link: "https://mp.weixin.qq.com/s/X36tcY_pOVpE66xgHSvSqA",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-06-30 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "SK海力士计划到2028年投资103万亿韩元，用于AI和芯片领域",
    abstract:
      "韩国SK海力士母公司SK集团表示，到2028年，SK海力士将投资103万亿韩元（746亿美元），以加强其芯片业务，专注于人工智能。SK集团还表示，计划到2026年确保80万亿韩元的资金，用于投资人工智能和半导体领域，以及为股东回报提供资金，并对超过175家的子公司进行精简。",
    link: "https://www.cls.cn/detail/1718836",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-30 00:00:00",
  },
  {
    week: "0629-0705",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "Rain AI 招募苹果芯片专家，加速AI芯片研发",
    abstract:
      "美国芯片初创公司Rain AI周五发布公告称，公司挖来曾在苹果效力17年的芯片高管Jean Didier Allegrucci。他将担任公司的硬件工程主管，领导下一代突破性节能芯片的开发。三周前，Rain AI刚挖来Meta ASIC架构团队的首席架构师Amin Firoozshahian。",
    link: "https://www.cls.cn/detail/1718087",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-29 00:00:00",
  },
  {
    week: "0622-0628",
    week_title: "2024年6月第4期",
    anchor: "20240622",
    week_abs_long: {
      新闻: '"OpenAI超越微软销量，年收入达10亿美元，与《时代》合作训练ChatGPT，Anthropic推出Claude机器人协作功能。"',
      创投: '"Stability AI获得8000万美元投资，豁免4亿债务；AI独角兽阶跃星辰拟进行新融资，估值20亿；OpenAI收购远程协作公司Multi。"',
      行业: "报道称字节跳动与博通合作开发5nm AI芯片；巴西浮动式太阳能为水力发电厂创造机会",
      论文: "RoboUniView是机器人操作的视觉模型，MUMU用于多模式图像生成，UIO-LLM优化长上下文的无偏增量。",
    },
  },
  {
    week: "0622-0628",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI 与《时代》杂志达成合作协议，将用其内容训练 ChatGPT",
    abstract:
      "当地时间周四，《时代》杂志与OpenAI宣布，两家公司达成了一项多年内容授权协议和战略合作伙伴关系。该协议允许OpenAI将这家出版商的内容引入ChatGPT，并帮助训练其最先进的人工智能(AI)模型。据新闻稿介绍，OpenAI可以通过这笔交易访问《时代》过去100多年的档案和文章，以训练其AI模型，并在其面向消费者的产品(如ChatGPT)中用于回复用户的询问。",
    link: "https://www.cls.cn/detail/1717111",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-28 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI AI模型销量超越微软，年化收入达10亿美元",
    abstract:
      "在2019年与微软建立合作伙伴关系后，AI初创公司OpenAI显示出了惊人的销售能力，根据最新两家公司内部数据，截至3月，OpenAI通过出售对其AI模型的访问权限，产生了约10亿美元的年化收入。相比之下，微软的同类产品Azure OpenAI Service，直到最近才达到了10亿美元的年化收入（ARR）。",
    link: "https://wallstreetcn.com/articles/3718291",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-06-28 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "Stability AI 获前 Facebook 总裁主导的 8000 万美元投资，并豁免 4 亿美元的债务",
    abstract:
      "由前 Facebook 总裁 Sean Parker 领衔的投资者群体承诺向 Stability AI 投资 8000 万美元，以接管这家在商业与运营受阻的 AI 独角兽。据悉，新一轮投资的投资者包括 Greycroft、O’Shaughnessy Ventures 和生物技术投资者 Robert Nelsen，老股东Coatue、Lightspeed 以及 Ashton Kutcher 的Sound Ventures 也承诺投资。此外，包括前 Google CEO Eric Schmidt 以及伦敦 Stability AI 早期支持者在内的投资者群体已经与供应商达成协议，豁免 Stability AI 欠下的 1 亿美元债务，同时免除公司未来 3 亿美元的义务，这些债务主要用于云计算服务提供商。",
    link: "https://mp.weixin.qq.com/s/tRRWpdivtehDZYi-vkNBZw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-06-27 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "RoboUniView：具有统一视图表示的机器人操纵的视觉语言模型",
    abstract:
      "利用视觉语言模型（VLM）的机器人操作代表了一种新的范式，旨在提高模型的能力，推广到新的对象和指令。然而，由于相机规格和安装位置的变化，现有方法在不同的机器人平台上表现出显著的性能差异。为了应对这一挑战，我们在本文中提出了RoboUniView，这是一种创新的方法，可以从动作学习中提取视觉特征。我们首先通过对易于访问的数据进行预训练，从多视角视图中学习统一的视图表示，然后从这个统一的视图表示中导出动作来控制机器人操作。这种统一的视图表示更准确地反映了物理世界，并且不受机器人平台的相机参数的约束。得益于这种方法，我们在要求严格的CALVIN基准测试中实现了最先进的性能。",
    link: "https://arxiv.org/abs/2406.18977",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-27 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Anthropic 为 Claude 聊天机器人推出 Projects 团队知识库协作功能",
    abstract:
      "Anthropic 旗下的 AI 聊天机器人 Claude 现在允许用户将聊天组织成 Projects 项目，集中管理知识集合和聊天活动，可帮助团队成员共享最佳聊天记录，促进创意生成、战略决策和卓越成果。Porjects 功能使用户可以将Claude的输出与内部知识结合，例如风格指南、代码库、访谈记录或过去的工作，从而提供专业协助。用户可以为每个项目定义自定义指令，以进一步定制Claude的响应。",
    link: "https://www.anthropic.com/news/projects",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Anthropic.png",
    source_name: "Anthropic",
    publish_time: "2024-06-27 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "UIO-LLM：长上下文LLM的无偏增量优化",
    abstract:
      "由于上下文窗口大小有限，管理长文本对于大型语言模型（LLM）来说是一项挑战。本研究介绍了UIO-LLM，一个无偏的增量优化方法的内存增强Transformers器下的长上下文设置。我们最初将该过程概念化为一个简化的编码器-解码器框架，其中权重共享的编码器和解码器分别将上下文段封装到存储器中，并利用这些存储器来预测后续段的输出。随后，通过将我们的记忆增强型Transformers视为完全连接的递归神经网络（RNN），我们使用截断时间反向传播（TBPTT）算法改进了训练过程，该算法采用了创新的增量优化技术。这些技术不仅降低了时间复杂度，而且通过无偏优化过程解决了梯度计算中的偏差。",
    link: "https://arxiv.org/abs/2406.18173",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-26 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "MUMU：从文本到图像数据引导多模式图像生成",
    abstract:
      "本文训练一个模型，从交错文本和图像的多模式提示中生成图像，我们的模型MUMU由视觉语言模型编码器和扩散解码器组成，并在单个8xH100 GPU节点上进行训练。尽管MUMU只在来自同一图像的素材上进行训练，但它学会了将来自不同图像的输入组合成连贯的输出。我们的结果显示了使用多模态模型作为图像生成的通用控制器的前景。",
    link: "https://arxiv.org/abs/2406.18790v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-26 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "曝AI独角兽阶跃星辰正进行新一轮融资，估值20亿美元",
    abstract:
      "阶跃星辰，总部位于上海的AI大模型公司，微软前全球副总裁姜大昕创办，在自研大模型、应用产品先后亮相后，正在获得更大的认可，垒起更大的雪球。据量子位报道，阶跃星辰正在进行一轮估值20亿美元的新融资，阿里巴巴再次出现在布局传闻中。阶跃星辰至今公开的toC产品共两款，一款叫跃问，聊天类应用，定位个人效率助手。另一款叫冒泡鸭，是AI开放世界平台，提供海量智能体，主打一个休闲娱乐。",
    link: "https://www.qbitai.com/2024/06/158025.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-06-25 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "OpenAI 收购屏幕共享远程协作公司 Multi",
    abstract:
      "6 月 24 日，继收购 Rockset 后，OpenAI 又收购了一家远程协作公司 —— Multi，是近期 OpenAI 大举投资企业解决方案的战略之一。Multi 提供的功能包括满足最多 10 人通过屏幕共享进行协作、自定义快捷方式以及代码、设计以及文档的自动链接。此前，Multi 已经从 Greylock 以及 First Round Capital 等风投公司筹集近 1300 万美元。交易完成后，Multi 团队的 5 名成员将加入 OpenAI。",
    link: "https://mp.weixin.qq.com/s/JjMBJ6iUQdhaglqCkldTag",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-06-25 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "报道称字节跳动与博通合作开发5nm AI芯片",
    abstract:
      "据报道，字节跳动为削减采购成本并确保高端 AI芯片供应稳定，正与美国博通（Broadcom）合作开发先进 AI 处理器。消息指，该处理器为5nm ASIC（专用集成电路），预计会符合美国出口管制新规，制造工作将外包给台积电。消息人士称，虽然目前芯片设计工作正顺利进行中，但仍未进入“流片”（试生产）阶段，预计台积电今年不会生产这款芯片。目前，字节跳动和博通尚未回应置评请求。台积电拒绝置评。",
    link: "https://mp.weixin.qq.com/s/y7Qi5d78WhHVJ4LJlQ9bWQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/钛媒体.png",
    source_name: "钛媒体",
    publish_time: "2024-06-24 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "德国5月份光伏装机容量降至946MW",
    abstract:
      "德国光伏装机容量小幅增长主要来自大型商用系统和地面安装系统。德国联邦网络局还修正了4月份的新增数据，从1,040MW修正为1,177MW。",
    link: "https://www.pv-magazine-china.com/2024/06/24/%e5%be%b7%e5%9b%bd5%e6%9c%88%e4%bb%bd%e5%85%89%e4%bc%8f%e8%a3%85%e6%9c%ba%e5%ae%b9%e9%87%8f%e9%99%8d%e8%87%b3946mw/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-06-24 00:00:00",
  },
  {
    week: "0622-0628",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "巴西浮动式太阳能为水力发电厂创造机会",
    abstract:
      "能源咨询和分析公司PSR发布的一项估计显示，如果伊泰普水电站建设一座大型浮动式太阳能发电站，其发电能力几乎可以翻一番，而该太阳能发电站仅占其1,350平方公里水库面积的10%。安装浮动式光伏系统可能是发电厂更新改造的一个替代方案，尽管其面临监管和运营方面的限制。",
    link: "https://www.pv-magazine-china.com/2024/06/24/%e5%b7%b4%e8%a5%bf%e6%b5%ae%e5%8a%a8%e5%bc%8f%e5%a4%aa%e9%98%b3%e8%83%bd%e4%b8%ba%e6%b0%b4%e5%8a%9b%e5%8f%91%e7%94%b5%e5%8e%82%e5%88%9b%e9%80%a0%e6%9c%ba%e4%bc%9a/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/pv-magazine.png",
    source_name: "pv-magazine",
    publish_time: "2024-06-24 00:00:00",
  },
  {
    week: "0615-0621",
    week_title: "2024年6月第3期",
    anchor: "20240615",
    week_abs_long: {
      行业: "宋清辉预测，2030年储能行业规模将达3万亿元，同时天合光能的场景化解决方案在SNEC大放异彩。",
      创投: "AI蛋白质设计平台「百奥几何」完成Pre-A轮融资，同时AI教育初创「柯南AI」收获数百万元天使轮投资。",
      新闻: '"DeepSeek Coder V2超越GPT4-Turbo发布开源代码，英伟达开源大模型Nemotron-4 340B，且聆心智能推出新一代模型CharacterGLM Pro。"',
      论文: "AGLA缓解视觉语言模型中的对象幻觉，VoCo-LLaMA则运用大型语言模型实现视觉压缩。",
    },
  },
  {
    week: "0615-0621",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "VoCo-LLaMA：利用大型语言模型实现视觉压缩",
    abstract:
      "视觉语言模型（VLM）在各种多模态任务中取得了显着的成功，但它们经常受到有限的上下文窗口和处理高分辨率图像输入和视频的高计算成本的影响。视觉压缩可以通过减少视觉标记数来缓解这个问题，我们提出VoCo-LLaMA，第一种使用LLM压缩视觉令牌的方法。通过在视觉指令调整阶段引入视觉压缩令牌并利用注意力蒸馏，我们的方法将LLM如何理解视觉令牌提取到其VoCo令牌的处理中。VoCo-LLaMA有助于有效的视觉压缩，并提高了推理阶段的计算效率。",
    link: "https://arxiv.org/abs/2406.12275",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-21 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "AGLA：通过全球和局部注意力的聚集来缓解大型视觉语言模型中的对象幻觉",
    abstract:
      "大型视觉语言模型（LVLM）面临着对象幻觉的普遍问题，其中生成的文本响应与给定图像中的地面真实对象不一致。本文研究了各种LVLM，并指出注意力不足的歧视性的局部图像特征作为对象幻觉的根本原因之一。",
    link: "https://arxiv.org/abs/2406.12718",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-21 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "宋清辉：储能行业蓬勃增长 2030年储能行业规模或将达到3万亿元",
    abstract:
      "著名经济学家宋清辉接受《证券日报》记者采访时表示，随着全球市场对能源需求的水涨船高以及商业运营模式的日趋完善，未来储能行业有望迎来更加蓬勃增长的前景。据清晖智库统计，2025年储能行业规模有望突破1万亿元大关，到2030年规模或将达到3万亿元。",
    link: "https://new.qq.com/rain/a/20240619A01GE200",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-06-19 09:05:00",
  },
  {
    week: "0615-0621",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI蛋白质设计平台「百奥几何」完成Pre-A轮融资",
    abstract:
      "百奥几何已完成新一轮融资，本轮融资由将门创投领投，智谱AI、盛景嘉成跟投，老股东高榕创投持续追加投资。募集资金将主要用于加速生成式AI大模型在生物制造领域落地，以及推进自有产品的开发。百奥几何成立于2021年，专注开发生成式AI蛋白质设计平台，从而赋能生物制造领域",
    link: "https://www.36kr.com/p/2825527221274884",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-06-19 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "天合光能场景化解决方案闪耀SNEC",
    abstract:
      "SNEC 2024圆满收官，天合光能全场景化解决方案闪耀亮相，众多拳头产品赚足观众目光。天合光能自主研发的三款高效电池组件并列展示在“210+N创领展区”，全部搭载210产品技术平台，分别叠加采用i-TOPCon电池技术、TSHJ异质结电池技术、THBC背接触异质结电池技术，最高组件输出功率达760W。",
    link: "https://new.qq.com/rain/a/20240618A02J5000",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-06-18 10:35:00",
  },
  {
    week: "0615-0621",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "DeepSeek Coder V2开源发布，首超GPT4-Turbo的代码能力",
    abstract:
      "今天，全球首个在代码、数学能力上与GPT-4-Turbo争锋的模型，DeepSeek-Coder-V2，正式上线和开源。DeepSeek-Coder-V2 沿用 DeepSeek-V2 的模型结构，总参数 236B，激活 21B，在代码、数学的多个榜单上位居全球第二，介于最强闭源模型 GPT-4o 和 GPT-4-Turbo 之间。",
    link: "https://mp.weixin.qq.com/s/XvDMVZmynO5MxxdpEo9hFg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/DeepSeek.png",
    source_name: "DeepSeek",
    publish_time: "2024-06-18 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI教育科技初创公司「柯南AI」完成数百万元天使轮融资",
    abstract:
      "柯南（广东横琴）智能科技有限公司（以下简称「柯南AI」）近日完成数百万元天使轮融资，投资方为六丰集团和鉴面科技的创始人，华峰资本担任独家财务顾问。「柯南AI」成立于2024年，是一家专注研发AI+儿童教育产品的科技创新的企业。其近期推出基于自研 AI大模型的AI+儿童教育产品“神笔马良魔画AI平板”，是一款集成AI绘画、AI写作、AI动画制作和AI音乐制作等数十个AI工具的平板电脑。",
    link: "https://36kr.com/p/2823194481248519",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-06-17 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "英伟达开源通用大模型Nemotron-4 340B",
    abstract:
      "本周五，英伟达宣布推出 Nemotron-4 340B。它包含一系列开放模型，开发人员可以使用这些模型生成合成数据，用于训练大语言模型（LLM），可用于医疗健康、金融、制造、零售等所有行业的商业应用。通过独特的开放模型许可，Nemotron-4 340B 为开发人员提供了一种免费、可扩展的方式来生成合成数据，从而帮助人们构建强大的 LLM。",
    link: "https://mp.weixin.qq.com/s/ghN4Vyr7ipNkP2Od70oAEw",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-06-15 00:00:00",
  },
  {
    week: "0615-0621",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "聆心智能发布新一代超拟人大模型CharacterGLM Pro",
    abstract:
      "2023年8月，初代CharacterGLM发布，模型尺寸66B，在各项拟人化和角色扮演的性能指标上完全不输给当时OpenAI的GPT-4大模型。聆心智能经过大半年的持续努力，在落地服务客户，分析产品和用户反馈，重构和优化训练数据集，细化测评标准，以及大模型核心技术升级的基础上，于2024年2月份完成了CharacterGLM Pro版本的训练和初步测评。又经过了3个多月的持续打磨，CharacterGLM Pro的性能和稳定性得到了进一步提升。",
    link: "https://mp.weixin.qq.com/s/kYz4sdzYGOJKX8dUsTbNeg",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/聆心智能.png",
    source_name: "聆心智能",
    publish_time: "2024-06-15 00:00:00",
  },
  {
    week: "0608-0614",
    week_title: "2024年6月第2期",
    anchor: "20240608",
    week_abs_long: {
      新闻: "领英将推AI求职顾问，中国备案492算法，三星聘苹果资深人士领航AI，上海交大发布大参数模型框架，复旦推100门AI课程。",
      创投: "Hugging Face收购Argilla，三星领投Tenstorrent投前估值20亿美元。亚马逊投资2.3亿美元于AI初创企业；GPTZero、InScope、Pyte、BlinqIO获数百万轮融资; Mistral AI完成6亿欧元B轮融资。",
      行业: "OpenAI自研芯片进展顺利，挖走谷歌专家，同时华为Ascend 910B AI芯片成功超越A100，成为中国市场关键产品。",
      论文: "研究总结：测量文本生成图像的感知变异性，通过LLaMA-3回收大量网络图像， 使用VisionLLM v2端到端处理多模态视觉语言任务，扩大视频理解能力，丰富面部表情以拓展情感对话。",
    },
  },
  {
    week: "0608-0614",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "领英（LinkedIn）宣布将推出系列AI求职顾问新功能",
    abstract:
      "作为求职界的龙头公司之一，领英（LinkedIn）周四宣布将推出一系列由人工智能驱动的新服务，从申请工作到提供相关的准备材料，以及搜索整个领英以帮助用户更快地找到心仪职位。该功能仅面向领英的高级订阅者，个人求职者月费约30美元，企业订阅者月费约60美元。",
    link: "https://www.cls.cn/detail/1703930",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "更少的token和更少的视频：扩展大型视觉语言模型中的视频理解能力",
    abstract:
      "在基于图像的大型视觉语言模型（image-LVLM）的进步中，向基于视频的模型（video-LVLM）的过渡受到高质量视频数据的有限可用性的阻碍。本文通过利用图像和视频之间的视觉共性来有效地将图像LVLM演变为视频LVLM来解决这一挑战。我们提出了一个具有成本效益的视频LVLM增强模型架构。",
    link: "https://arxiv.org/html/2406.08024v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "情感对话：用表情、眼神和动作丰富面部表情",
    abstract:
      "生动的说话人脸生成在电影和游戏制作等多媒体领域有着巨大的应用潜力。虽然现有的方法准确地将嘴唇运动与输入音频同步，但它们通常忽略了情感和面部线索之间的关键对齐，包括表情，凝视和头部姿势。这些对齐对于合成逼真的视频是必不可少的。为了解决这些问题，我们提出了一个两阶段的音频驱动的说话人脸生成框架，采用3D面部地标作为中间变量。该框架通过自我监督学习实现了表情，凝视和姿势与情绪的协作对齐。具体来说，我们将此任务分解为两个关键步骤，即语音到地标合成和地标到人脸生成。",
    link: "https://export.arxiv.org/abs/2406.07895",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "如果我们用LLaMA-3回收数十亿张网络图像会怎样？",
    abstract:
      "网络抓取的图像-文本对本质上是嘈杂的。先前的研究表明，在语义上对齐和丰富这些对的文本描述可以显着增强各种视觉语言任务的模型训练，特别是文本到图像生成。然而，这一领域的大规模调查仍然主要是封闭来源的。我们的论文旨在弥合这一社区的努力，利用强大的 textit{开源} LLaMA-3，GPT-4级LLM。我们的重新捕获管道很简单：首先，我们对LLaMA-3-8B驱动的LLaVA-1.5进行微调，然后使用它从DataComp-1B数据集中重新捕获13亿张图像。我们的实证结果证实，这个增强的数据集，Recap-DataComp-1B，在训练高级视觉语言模型方面提供了实质性的好处。",
    link: "https://arxiv.org/abs/2406.08478",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "亚马逊承诺以AWS信用额度投资2.3亿美元，用于AI初创企业",
    abstract:
      "亚马逊承诺以亚马逊云服务(AWS)的信用额度投资2.3亿美元，为处于早期阶段的人工智能初创企业提供指导和培训，以促进对人工智能和机器学习技术的使用。新承诺的一部分资金将用于资助第二批AWS生成式人工智能加速器，这一计划将为前80家使用生成式人工智能解决复杂挑战的早期初创企业提供专业知识，及每家高达100万美元的额度。",
    link: "https://www.zhitongcaijing.com/content/detail/1135125.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智通财经.png",
    source_name: "智通财经",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "三星领投AI芯片公司Tenstorrent新一轮融资，投前估值为20亿美元",
    abstract:
      "据The Information报道，三星牵头对Tenstorrent进行了一轮至少3亿美元的投资。Tenstorrent是一家总部位于多伦多的人工智能芯片公司，其首席执行官吉姆·凯勒(Jim Keller)曾在苹果和特斯拉工作过。据参与这轮融资的两名人士透露，Tenstorrent的投前估值为20亿美元。",
    link: "https://www.cls.cn/detail/1703750",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "一字胜千图：测量和理解文本到图像生成中的感知变异性",
    abstract:
      "扩散模型是文本到图像生成中的最新技术，但其感知可变性仍然没有得到充分研究。在本文中，我们研究了提示如何影响基于黑盒扩散的模型中的图像变异性。我们提出了W1 KP，这是一组图像中人类校准的变异性度量，从现有的图像对感知距离中引导而来。当前的数据集不涵盖最近的扩散模型，因此我们还策划了三个测试集进行评估。",
    link: "https://arxiv.org/abs/2406.08482",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "VisionLLM v2：用于数百项视觉语言任务的端到端通用多模态大型语言模型",
    abstract:
      "VisionLLM v2是一个端到端的通才多模态大型模型（MLLM），它将视觉感知，理解和生成统一在一个框架内。与传统的仅限于文本输出的MLLM不同，VisionLLM v2大大拓宽了其应用范围。它不仅在传统的视觉问答（VQA）方面表现出色，而且在开放式的跨领域视觉任务中表现出色，例如对象定位，姿态估计以及图像生成和编辑。为此，我们提出了一种新的信息传输机制，称为“超级链接”，作为一种媒介，连接MLLM与特定任务的解码器。它不仅允许MLLM和多个下游解码器之间的任务信息和梯度反馈的灵活传输，而且还有效地解决了多任务场景中的训练冲突。",
    link: "https://arxiv.org/abs/2406.08394",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Hugging Face宣布以1000万美元收购数据集服务公司Argilla",
    abstract:
      "Hugging Face 周四宣布，已同意以 1000 万美元收购名为 Argilla 的公司，这是 Huggingface 迄今为止第四笔收购。CEO Clément Delangue 透露，每周都会听到大约 10 家 AI 初创公司表示有意被收购，尤其是今年，这个数字增长很多，也可能是市场进一步整合的迹象。Delangue 还表示，Hugging Face 开发 AI 软件并将其托管给其他公司，由于拥有大量资源，它可能会吸引渴望被收购的企业。",
    link: "https://mp.weixin.qq.com/s/LmhVxBQKSdtXDFkJCkTsew",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/有新Newin.png",
    source_name: "有新Newin",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI内容检测初创公司GPTZero获1000万美元A轮融资",
    abstract:
      "AI内容检测初创公司GPTZero宣布筹集了1000万美元的A轮融资，估值约5000万美元。本轮融资由Footwork的联合创始人Nikhil Basu Trivedi领投，其他投资者包括Reach Capital、Jack Altman的Alt Capital、Uncork Capital以及Neo（Ali Partovi的基金）。",
    link: "https://ai-bot.cn/gptzero-secures-10-million-series-a-funding/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/TechCrunch.png",
    source_name: "TechCrunch",
    publish_time: "2024-06-14 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "InScope完成430万美元种子轮融资，利用AI自动化企业财务报告和审计",
    abstract:
      "AI自动化财务报告的金融科技公司InScope宣布筹集了430万美元的种子轮融资。本轮融资由Lightspeed Venture Partners和Better Tomorrow Ventures领投。该公司计划将筹集的资金用于扩大其客户基础至50家公司，扩展产品规模，增长团队，以及增强其人工智能能力。",
    link: "https://ai-bot.cn/inscope-4-3-million-seed-funding/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/TechCrunch.png",
    source_name: "TechCrunch",
    publish_time: "2024-06-13 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI软件测试平台BlinqIO完成500万美元新一轮融资",
    abstract:
      "生成式人工智能软件测试平台的BlinqIO公司宣布筹集了500万美元的新一轮融资。本轮融资由Flint Capital领投，Inovia Capital Precede Fund I（由前谷歌首席财务官、前推特主席Patrick Pichette领导）、前Deliveroo首席财务官Raif Jacobs、TAL ventures和SeedIL也参与了投资。",
    link: "https://ai-bot.cn/blinqio-secures-5-million-new-funding/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/SiliconANGLE.png",
    source_name: "SiliconANGLE",
    publish_time: "2024-06-13 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI数据安全计算平台Pyte完成500万美元的新一轮融资",
    abstract:
      "AI数据安全计算平台Pyte宣布筹集了500万美元的新一轮融资，本轮融资由Myriad Venture Partners领投，Innovation Endeavors、Liberty Mutual Strategic Ventures和Pillar VC等参投。该公司计划将筹集的资金用于加速其安全计算平台的商业化。",
    link: "https://ai-bot.cn/pyte-ai-secures-5-million-new-funding/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/PR Newswire.png",
    source_name: "PR Newswire",
    publish_time: "2024-06-13 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "国家网信办发布第六批深度合成服务算法备案信息，腾讯混元等492个算法在列",
    abstract:
      "国家网信办今日发布公告，根据《互联网信息服务深度合成管理规定》，现公开发布第六批境内深度合成服务算法备案信息。AI工具集从《境内深度合成服务算法备案清单（2024 年 6 月）》文件获悉，本次共有 492 个算法通过备案，其中包括腾讯混元大模型多模态算法（应用产品为腾讯元宝）、零一万物大模型多模态生成算法、快手快意大模型生成合成算法、商汤V-ME视频合成算法、钉钉AI助理智能生成算法等、绘蛙电商模特试装图像合成算法等。",
    link: "https://ai-bot.cn/6th-deepfake-synthesis-algorithm-list/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/中国网信网.png",
    source_name: "中国网信网",
    publish_time: "2024-06-12 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "上海交大发布LLM手机推理框架PowerInfer-2，可流畅运行470亿参数模型",
    abstract:
      "上海交大IPADS实验室推出了面向手机的大模型推理引擎（目前论文已在arxiv公开）：PowerInfer-2.0。PowerInfer-2.0能够在内存有限的智能手机上实现快速推理，让Mixtral 47B模型在手机上达到11 tokens/s的速度。与热门开源推理框架llama.cpp相比，PowerInfer-2.0的推理加速比平均达到25倍，最高达29倍。",
    link: "https://www.qbitai.com/2024/06/153436.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/量子位.png",
    source_name: "量子位",
    publish_time: "2024-06-12 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "三星聘请苹果Siri战略资深人士领导北美人工智能中心",
    abstract:
      "据知情人士透露，三星正在创建一个名为北美人工智能中心（North America AI Center）的新机构，将多伦多和加利福尼亚山景城的团队合并在一起。公司聘请了前苹果公司高管Murat Akbacak来管理新部门。Akbacak此前在苹果负责制定和执行个人助理Siri的战略，专注于个性化、情境化以及对话和多模式人工智能。",
    link: "https://www.cls.cn/detail/1701604",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-06-12 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Mistral AI宣布完成6亿欧元的B轮融资，估值58亿欧元",
    abstract:
      "法国人工智能初创公司Mistral AI宣布筹集了6亿欧元的B轮融资（4.68 亿欧元股权和1.32亿欧元债务），估值近60亿欧元（58亿欧元），本轮融资由General Catalyst领投，Lightspeed Venture Partners、Andreessen Horowitz、Nvidia、Samsung Venture Investment Corporation、Salesforce Ventures、三星风险投资公司等参投。",
    link: "https://ai-bot.cn/mistral-ai-600-million-euro-series-b-funding/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Financial Times.jpeg",
    source_name: "Financial Times",
    publish_time: "2024-06-12 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "复旦大学：将在下一个学年推出至少100门AI领域课程",
    abstract:
      "6月11日，复旦大学召开2024年招生培养政策发布会，公布今年本科生招生培养政策亮点。从今年秋季学期开始，复旦大学将在2024-2025学年推出至少100门AI领域课程，打开AI+融合创新人才培养新局面。AI大课将以AI-BEST课程体系的形式，进入所有复旦学生的学业安排，分别为：本研一体化打造AI通识基础课程（AI-B）、AI专业核心课程（AI-E）、AI学科进阶课程（AI-S）和AI垂域应用课程（AI-T）。",
    link: "https://www.thepaper.cn/newsDetail_forward_27694297",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/澎湃新闻.png",
    source_name: "澎湃新闻",
    publish_time: "2024-06-11 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "华为宣称Ascend 910B AI芯片成功超越A100 成为中国市场的重要替代品",
    abstract:
      "据《南华早报》报道，华为高管表示，华为面向中国市场推出的尖端Ascend 910B AI芯片在性能上已超越英伟达A100 AI GPU。华为大幅提升Ascend平台性能，Ascend 910B以更高的性能和价值挑战英伟达A100，专为中国设计。",
    link: "https://cloud.tencent.com/developer/article/2429834",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯云.png",
    source_name: "腾讯云",
    publish_time: "2024-06-09 00:00:00",
  },
  {
    week: "0608-0614",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "OpenAI 自研芯片进展曝光，百万年薪挖角谷歌 TPU 人才",
    abstract:
      "OpenAI自研芯片的计划终于看到了实质性进展。据SemiAnalysis的最新报道，OpenAI最近开始大规模招募，计划将只有几个人的芯片团队扩展到几十个人。而且，他们延续了招聘人才的一贯策略——挖角谷歌。新近招募的几乎所有研究人员，都是现任或前任的谷歌TPU团队成员。OpenAI之所以瞄准谷歌的TPU团队，既是希望得到最先进的技术和人才，也同样有商业竞争上的考量。在硅谷的众多科技巨头中，只有谷歌研发的TPU能成功替代英伟达的芯片，并部署在公司内部的云服务中。",
    link: "https://mp.weixin.qq.com/s/Jt1kA9Pfu7x84C-CeiDPcQ",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/新智元.png",
    source_name: "新智元",
    publish_time: "2024-06-09 00:00:00",
  },
  {
    week: "0601-0607",
    week_title: "2024年6月第1期",
    anchor: "20240601",
    week_abs_long: {
      行业: "马斯克对特斯拉AI芯片采购计划的夸大被质疑，而黄仁勋认为物理AI、机器人时代已来。",
      新闻: "阿里云、博查AI、视野大模型、Asana协作平台、面壁智能和智谱AI发布了新的AI模型、搜索API、视频更新、协作功能和开源模型，助力智能化发展。",
      创投: "Humane谈判以10亿美元出售给惠普；生数科技完成数亿融资；Cohere以50亿美元估值融资4.5亿，启动沙特阿美旗下智谱AI 4亿美元投资。",
      论文: "本研究通过插件方法实现交互式文本到图像检索，利用多实例视觉提示生成器丰富大型语言模型的视觉表示，并细化视觉-文本对齐的相似性分数，构建统一的多模式布局生成器PosterLLaVaA。",
    },
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "面壁智能宣布小钢炮 MiniCPM 模型免费商用",
    abstract:
      "作为开源社区的贡献者和受益者，面壁智能、OpenBMB & 清华 NLP 实验室讨论决定将面壁「小钢炮」 MiniCPM 免费商用。即日起， MiniCPM 和 MiniCPM-V 权重将对学术研究完全开放，并且企业、个人在填写问卷登记后亦允许商业使用，社区使用 MiniCPM 系列模型需要遵循 Apache 2.0 和《MiniCPM 模型社区许可协议》。",
    link: "https://mp.weixin.qq.com/s/NvM3eTvVBX4A8IUWsh3Y9w",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "阿里云开源推出通义千问 Qwen2 大模型，上下文窗口最高达 128K",
    abstract:
      "阿里云通义千问宣布 Qwen 系列模型从 Qwen1.5 到 Qwen2 的重大升级。目前，已在Hugging Face和ModelScope上同步开源 Qwen2 大模型。更新包括：5个尺寸的预训练和指令微调模型, 包括Qwen2-0.5B、Qwen2-1.5B、Qwen2-7B、Qwen2-57B-A14B以及Qwen2-72B；在中文英语的基础上，训练数据中增加了27种语言相关的高质量数据；多个评测基准上的领先表现；代码和数学能力显著提升；增大了上下文长度支持，最高达到128K tokens（Qwen2-72B-Instruct）。",
    link: "https://qwenlm.github.io/zh/blog/qwen2/",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Qwen.png",
    source_name: "Qwen",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "视频大模型Vidu更新：时长延至32秒，首次支持音视频合成",
    abstract:
      "据钛媒体AGI报道，生数科技与清华大学联合发布的中国首个长时长、高一致性、高动态性视频大模型Vidu，近期完成三个最新、重大技术迭代，实现国内视频模型更大一步技术跨越。1、目前Vidu可以一键生成32s视频；2、支持音视频合成，即Vidu视频生成有声音了（Text-2-Audio）3、支持4D生成，可以从单一视频生成时空一致的4D内容。",
    link: "https://mp.weixin.qq.com/s/zOsgAm8v-C44qWhz-TSUsw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "视觉-文本交叉对齐：细化视觉-语言模型中的相似性分数",
    abstract:
      "最近已经发现，使用预先训练的视觉语言模型（VLM）如CLIP，将整个查询图像与由大型语言模型生成的几个更精细的文本描述对齐，可以显著提高zero-shot性能。然而，在本文中，我们根据经验发现，更精细的描述往往更有效地与查询图像的局部区域，而不是整个图像，然后我们从理论上验证了这一发现。因此，我们提出了一种方法称为加权视觉文本交叉对齐（WCA）。该方法从局部视觉提示技术开始，旨在识别查询图像中的局部视觉区域。然后，通过使用预先训练的VLM创建相似性矩阵，将局部视觉区域与更精细的描述交叉对齐。",
    link: "https://arxiv.org/html/2406.02915v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "生数科技完成数亿元 Pre-A 轮融资，加速布局多模态大模型",
    abstract:
      "近日，生数科技完成数亿元 Pre-A 轮融资，该轮融资由北京市人工智能产业投资基金、百度联合领投，中关村科学城公司等跟投，启明创投等数位老股东继续支持。此前，生数科技已经获得来自蚂蚁集团、BV百度风投、卓源亚洲、锦秋基金、达泰资本、智谱AI等机构的投资。本轮融资完成后，生数科技将坚持其原生通用多模态技术路线，持续迭代优化自研大模型，并加速产品开发与市场拓展。",
    link: "https://mp.weixin.qq.com/s/CoBJG-9lcnBrJ_lORBvMgw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "消息称沙特阿美旗下风投基金Prosperity7参与智谱AI 4亿美元的一轮投资",
    abstract:
      "据媒体周五报道，两位知情人士称，沙特阿美风险投资部门旗下基金Prosperity7参与了对中国人工智能初创企业智谱AI约4亿美元的新一轮投资。目前智谱AI估值约为30亿美元，本次投资也为智谱在中国以外地区开辟新市场提供了机会。",
    link: "https://wallstreetcn.com/articles/3716250",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "消息称 Humane 正谈判以 10 亿美元的价格出售给惠普",
    abstract:
      "此前有传言称 Humane 正在为其 AI Pin 业务寻找潜在买家，而一份新报告表明惠普可能是其中的竞争者。据《纽约时报》报道，在 Humane 的 699 美元可穿戴 AI Pin 受到广泛批评后一周左右，该公司开始与惠普洽谈以 10 亿美元以上的价格出售其业务。上个月，彭博社曾报道称 Humane “希望以 7.5 亿至 10 亿美元的价格被收购”。另外，惠普曾在 2010 年以 12 亿美元收购了 Palm 硬件及其 webOS 操作系统。",
    link: "https://www.theverge.com/2024/6/6/24172718/humane-ai-pin-selling-hp-rumor-1-billion",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/The Verge.png",
    source_name: "The Verge",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "智谱AI开源 GLM-4-9B 系列模型，通用能力超越 Llama 3",
    abstract:
      "智谱AI今日推出了第四代 GLM 系列开源模型：GLM-4-9B。相较于第三代模型，数据量是 ChatGLM3-6B 模型的 3 倍以上，训练效率提高了 3.5 倍。基于强大的预训练基座，GLM-4-9B 的模型中英文综合性能相比 ChatGLM3-6B 提升了 40%，尤其是在中文对齐能力 AlignBench，指令遵从 IFeval，工程代码 Natural Code Bench 方面都取得了非常显著的提升。对比训练量更多的 Llama 3 8B 模型也没有逊色，英文方面有小幅领先，中文学科方面更是有着高达 50% 的提升。",
    link: "https://mp.weixin.qq.com/s/osbpRJPRGET_0s3k0mfdxw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "报道称马斯克关于特斯拉的AI芯片采购计划夸大其词，马斯克回应",
    abstract:
      "英伟达内部邮件显示，马斯克让英伟达将原本预留给特斯拉的几万颗H100芯片，优先发货给他旗下的社交媒体公司X和AI初创公司xAI，而非特斯拉，这导致特斯拉推迟收到价值超过5亿美元的GPU。马斯克回击称，特斯拉没有合适的场所来激活那些英伟达芯片，所以它们只会闲置在仓库里。",
    link: "https://wallstreetcn.com/articles/3716533",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "博查AI搜索首发多模态搜索、智能体搜索、联网搜索API能力",
    abstract:
      "AI搜索引擎 博查AI搜索首发多模态搜索(Media Search)和智能体搜索(Agent Search)能力，引入抖音高质量内容和AI智能体，进一步增强AI搜索的通用性和结果丰富性，在搜网页、搜短剧、搜视频、搜图片、搜行业等场景下都有不错的表现提升。此外，博查还发布国内首个联网搜索API(Web Search API)，为AI产业提供内容合规、价格实惠、搜索结果更适合AI使用的搜索服务。",
    link: "https://mp.weixin.qq.com/s/ALc57b5g__7-lU4ko950HA",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "协作平台 Asana 推出“AI Teammates”功能，可帮助团队布置和计划任务",
    abstract:
      "办公协作平台 Asana 在一份新闻稿中表示，其人工智能模型可以利用存储的团队历史关系和过去项目信息，将工作分配给技能最匹配的人员，例如标记了解品牌风格的设计师来从事创意项目。名为“AI Teammates”的功能可以帮助团队布置任务并确定每个人承担了哪些责任，提出建议和计划。",
    link: "https://www.theverge.com/2024/6/5/24170480/asana-ai-teammate-workflow-assistant-chatbot",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/The Verge.png",
    source_name: "The Verge",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "使用大型语言模型的交互式文本到图像检索：即插即用方法",
    abstract:
      "本文中主要解决对话框形式的上下文查询内的交互式文本到图像检索任务。我们提出了新的框架——PlugIR，首先，通过重新制定的对话形式的背景下，消除了微调现有的视觉对话数据的检索模型的必要性，从而使任何任意的黑盒模型的使用。其次，本文构造的LLM问题产生的目标图像的属性的非冗余的问题，在当前上下文中的检索候选图像的信息的基础上。这种方法减轻了生成的问题中的噪声和冗余问题。",
    link: "https://arxiv.org/html/2406.03411v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "使用多实例视觉提示生成器增强多模式大型语言模型以丰富视觉表示",
    abstract:
      "多模态大语言模型（MLLM）通过融合视觉表示与利用一些视觉适配器的LLM，在各种视觉语言任务中实现了SOTA性能。在本文中，我们首先建立，适配器使用基于查询的Transformers，如Q-former是一个简化的多实例学习方法，不考虑实例的异构性相关性。然后，我们提出了一个通用的组件，称为多实例视觉提示生成器（MIVPG），将丰富的视觉表示到LLM利用图像或补丁之间的实例相关性为同一个样本。在三个不同场景的公共视觉语言（VL）数据集上的定量评估表明，所提出的MIVPG在主要的VL任务中改进了Q-former。",
    link: "https://arxiv.org/abs/2406.02987",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "PosterLLaVaA：用LLM构建统一的多模式布局生成器",
    abstract:
      "布局生成是实现自动化图形设计的关键，要求以视觉上令人愉悦和约束遵循的方式安排各种多模态设计元素的位置和大小。以前的方法对于大规模应用是低效的，或者对于不同的设计要求缺乏灵活性。我们的研究引入了一个统一的框架，自动图形布局生成，利用多模态大语言模型（MLLM），以适应不同的设计任务。相比之下，我们的数据驱动方法采用结构化文本（JSON格式）和视觉指令调整，以在特定的视觉和文本约束下生成布局，包括用户定义的自然语言规范。",
    link: "https://arxiv.org/abs/2406.02884",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI初创公司Cohere以50亿美元估值融资4.5亿美元，英伟达、思科等参投",
    abstract:
      "据路透社报道，消息人士透露，加拿大人工智能初创公司Cohere已从英伟达、Salesforce Venture、思科等投资者处筹集到4.5亿美元资金。这结束了Cohere长达数月的融资努力，而该公司仍在商谈以50亿美元的估值在同一轮融资中筹集更多资金。",
    link: "https://www.jiemian.com/article/11252642.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/界面新闻.png",
    source_name: "界面新闻",
    publish_time: "2024-06-07 00:00:00",
  },
  {
    week: "0601-0607",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "黄仁勋：下一波AI的浪潮是物理AI，机器人时代已经到来",
    abstract:
      "6月2日晚间，台北国际电脑展（COMPUTEX）开幕前夕，英伟达CEO黄仁勋在台湾大学综合体育馆发表主题为“开启产业革命的全新时代”的现场演讲。在长达两个小时的发言中，黄仁勋透露了一些对于AI发展的见解、关于英伟达未来芯片的信息，并将机器人放在最后一个部分“压轴登场”。",
    link: "https://www.thepaper.cn/newsDetail_forward_27617619",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/澎湃新闻.png",
    source_name: "澎湃新闻",
    publish_time: "2024-06-04 15:17:00",
  },
  {
    week: "0525-0531",
    week_title: "2024年5月第2期",
    anchor: "20240525",
    week_abs_long: {
      行业: "美国限制AMD、英伟达AI芯片中东销售，清华团队推出类脑视觉芯片。Gartner预测2024年AI芯片市场增长33%，马斯克计划2025年打造xAI超算工厂。",
      创投: "谷歌在马来投资20亿建数据中心和AI开发，Perplexity求2.5亿融资，字节跳动、AIGC科技、马斯克的AI企业都在筹集资金，软银寻求每年90亿美元AI投资。",
      新闻: '"Tool Use功能上线，科技巨头联手制定AI标准，苹果计划改造Siri，微软与OpenAI合作，OpenAI重启机器人团队并推出教育版ChatGPT。"',
      论文: "Xwin-LM是一个强大可扩展的对齐实践，能进行大型语言模型的幻觉分析注释、自动化评估和图神经网络检索推理。",
    },
  },
  {
    week: "0525-0531",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "马斯克计划打造10万颗芯片的xAI超算工厂，最快2025年运行",
    abstract:
      "据The Information报道，马斯克日前向投资者确认，xAI计划将多达 10 万个专用训练芯片串联成一台大型计算机——或者他所说的“超级计算工厂”，预计2025年秋季之前投入运行。马斯克强调，此次交付完成后，连接在一起的芯片组（英伟达的旗舰 H100 GPU）将至少是当今最大的 GPU 集群的四倍，例如 Meta Platforms 为训练其 AI 模型而构建的 GPU 集群。",
    link: "https://mp.weixin.qq.com/s/63gBiAmRFEHEhgdGux5kRw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "马斯克xAI官宣B轮融资60亿美元，估值约180亿美元",
    abstract:
      "马斯克旗下的大模型创企xAI官宣拿到60亿美元（折合约435亿人民币）B轮融资，估值达到约180亿美元（折合约1304亿人民币），一举跃升独角兽。本轮融资的主要投资者包括特斯拉和SpaceX的首批投资者安东尼奥·格拉西亚斯（Antonio Gracias）领导的Valor Equity Partners、迪拜投资公司Vy Capital、美国私人风投Andreessen Horowitz、Sequoia Capital、风投公司Fidelity Management&Research Company、沙特王国控股公司Kingdom Holding等。",
    link: "https://zhidx.com/p/424459.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "软银寻求每年90亿美元的AI投资，同时寻求更大的交易",
    abstract:
      "软银正在为实现可能是其迄今最激进的转型而保留更大交易的实力，但仍准备每年投入近90亿美元用于人工智能投资。软银首席财务官表示，希望加大对人工智能公司的投资，但他拒绝就有关Arm和软银正在考虑生产人工智能芯片的媒体报道发表评论。",
    link: "https://www.jiemian.com/article/11215654.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/界面新闻.png",
    source_name: "界面新闻",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "谷歌承诺在马来西亚投资20亿美元，将建数据中心、进一步开发AI",
    abstract:
      "谷歌在马来西亚的投资承诺达到了20亿美元，标志着其在该地区首个数据中心和谷歌云计划的启动。Alphabet的首席财务官露丝·波拉特(Ruth Porat)宣称，这是谷歌在东南亚国家中最大规模的投资计划。谷歌还表示，除了开发云计算服务外，还将支持针对学生和教育工作者的人工智能素养计划。",
    link: "https://www.zhitongcaijing.com/content/detail/1128178.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智通财经.png",
    source_name: "智通财经",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "英特尔、谷歌、微软、Meta等科技巨头成立联盟制定 AI 加速器连接标准",
    abstract:
      "英特尔、谷歌、微软、Meta以及其他科技巨头周四宣布成立一个新的行业组织——“Ultra Accelerator Link (UALink) 推广组”，意在制定行业标准，领导数据中心中AI加速器芯片之间连接组件的发展，挑战英伟达在AI加速器一家独大的地位。分析认为，英伟达目前已提供互联技术，加上霸主地位稳固，目前英伟达没有动机也没有必要参与该联盟。",
    link: "https://wallstreetcn.com/articles/3716178",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "美国政府限制 AMD 和英伟达 AI 芯片向中东销售",
    abstract:
      "据报道，美国官员已经放慢了向英伟达和AMD等芯片制造商发放向中东地区大批量出口AI加速计算芯片的许可证。与此同时，报道称，官员们正在对该地区的人工智能开发进行国家安全评估。知情人士称，目前尚不清楚评估需要多长时间，怎样才算大批量出口也没有具体定义。",
    link: "https://mp.weixin.qq.com/s/4kkkHu0lBm7X0PQ0DBrVRg",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "纳德拉：微软与OpenAI的合作关系和微软与英特尔的处于同一级别",
    abstract:
      "据外媒报道，微软CEO萨提亚·纳德拉近日在接受美国科技网站采访时谈到了微软与OpenAI的合作关系，微软如何在整个公司内转向AI，以及微软与谷歌的竞争关系，微软的资本支出水平问题等等。纳德拉提到，微软与OpenAI的合作伙伴关系，和微软与英特尔的合作伙伴关系是处在同一级别的。“在2019年，我们想，也许微软应该大手笔投入到计算中，由于OpenAI比任何人都更坚信这一点，甚至超过微软内部一些人，于是我们就压下了赌注。",
    link: "https://new.qq.com/rain/a/20240531A000RA00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "清华团队发布世界首款类脑互补视觉芯片「天眸芯」",
    abstract:
      "清华团队发布世界首款类脑互补视觉芯片——「天眸芯」。这是一种基于视觉原语的互补双通路类脑视觉感知新范式，标志着我国在类脑计算和类脑感知两个重要方向，取得的重大突破！研究《面向开放世界感知具有互补通路的视觉芯片》（A Vision Chip with Complementary Pathways for Open-world Sensing）一经发布，即登上Nature封面。",
    link: "https://mp.weixin.qq.com/s/8b1lYJzfjmWwmPgaOS_90A",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "消息称苹果将用 AI 彻底改造 Siri，让其控制所有功能",
    abstract:
      "5月31日，彭博记者、知名苹果爆料人Mark Gurman援引知情人士报道称，苹果公司计划使用更先进的人工智能对其 Siri 虚拟助手进行全面改造，这一举措将允许用户通过语音控制单独应用内的所有功能。据报道，新版本的Siri将能够更精准地操作和导航iPhone或iPad，实现打开特定文件、移动笔记、发送或删除邮件、打开Apple News中的特定出版物、发送网络链接或请求文章摘要等操作。",
    link: "https://wallstreetcn.com/articles/3716195",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "字节再试AI硬件：用收购补充团队、两条产品线共发力",
    abstract:
      "字节跳动正在AI领域倾注极大力量，除了在大模型应用等软件侧发力，其对AI+硬件的探索也未曾停止。据36氪报道，字节AI硬件方向的探索，在内部分为两条产品线：一条产品线代号为“D线”，负责人为李浩乾，其为OWS（Open Wearable Stereo，开放式可穿戴立体声耳机）耳机品牌Oladance创始人。不久前，字节收购了这一品牌。另一条产品线为O线，负责人也是字节曾收购公司的创始人，其向字节跳动技术副总裁洪定坤汇报。",
    link: "https://36kr.com/p/2785354366305413",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大型语言模型的自动化评估",
    abstract:
      "论文提出了一种自动化评估大型语言模型（LLMs）的方法，通过代理之间的对战和委员会讨论来评估模型性能。这种方法可以减少人工评估的需要，提高评估的效率和准确性。",
    link: "https://arxiv.org/html/2405.20267v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大型语言模型推理的图神经网络检索",
    abstract:
      "这篇论文介绍了一种结合图神经网络（GNN）和检索机制的方法，用于增强大型语言模型（LLMs）的推理能力。通过构建图结构来表示和检索知识，GNN-RAG提高了模型在复杂推理任务上的性能。",
    link: "https://arxiv.org/html/2405.20139v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大型语言模型中的幻觉分析注释",
    abstract:
      "这篇论文探讨了大型语言模型（LLMs）中出现的幻觉现象，并提出了一种分析和注释这些幻觉的方法。研究者们通过详细的案例研究，分析了幻觉的类型和原因，以帮助改进模型的准确性和可靠性。",
    link: "https://arxiv.org/html/2405.20315v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "Xwin-LM: 强大且可扩展的对齐实践",
    abstract:
      "这篇论文《Xwin-LM: Strong and Scalable Alignment Practice for LLMs》提出了一种新的大规模语言模型（LLMs）对齐实践方法。它通过引入Xwin-LM框架，旨在解决现有LLMs在对齐和扩展性方面的挑战。Xwin-LM通过模块化设计和优化的参数分配，提高了模型的可扩展性和效率。此外，该框架还强调了在训练过程中对齐的重要性，以确保模型在不同任务和数据集上都能保持一致性和稳定性。这项工作为构建更加强大和可扩展的语言模型提供了新的思路和方法。",
    link: "https://arxiv.org/html/2405.20335v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI 重启之前一度被放弃的机器人团队",
    abstract:
      "据国外媒体报道，据三位消息人士透露，随着对人工智能机器人的投资升温，OpenAI正式重启了此前被放弃的机器人团队。知情人士表示，OpenAI目前正在招募研究工程师以重建机器人团队，该团队已于2020年解散。尽管OpenAI尚未公开披露其自主研发机器人技术的具体细节，但在最近公布的招聘公告中，他们明确表示新加入的员工将成为“这个全新团队的首批成员之一”。",
    link: "https://new.qq.com/rain/a/20240531A00SI900",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI 推出 ChatGPT Edu 教育版本，支持 GPT-4o、自定义 GPT 等",
    abstract:
      "OpenAI在官网宣布，推出ChatGPT Edu版本。据悉，这是一个专门为大学校园提供的ChatGPT，支持GPT-4o、网络搜索、自定义GPT、数据分析、代码生成等功能，可以极大提升学生、老师的学习质量和教学效率。目前，牛津、剑桥、伯明翰等24所“罗素大学集团”的全球顶尖大学，已经在教育中使用ChatGPT等生成式AI产品。而沃顿商学院、亚利桑那州立大学在今天也官宣与OpenAI进行合作，在教育领域深度应用ChatGPT。",
    link: "https://mp.weixin.qq.com/s/_zljXwvak2EYt4P6rq5P8Q",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "Gartner：2024 年全球人工智能芯片销售收入将增长 33% 到 710 亿美元",
    abstract:
      "根据研究分析公司 Gartner 的最新预测，2024 年全球人工智能半导体收入预计将达到 710 亿美元，较 2023 年增长 33%。Gartner 副总裁分析师 Alan Priestley 表示：“如今，生成式人工智能 (GenAI) 正在推动数据中心对高性能人工智能芯片的需求。到 2024 年，用于服务器的人工智能加速器的价值将达到 210 亿美元，到 2028 年将增至 330 亿美元。” Gartner 预测，2024 年人工智能 PC 出货量将占到 PC 总出货量的 22%，到 2026 年底，企业购买的 100% 的 PC 将是人工智能 PC。",
    link: "https://www.gartner.com/en/newsroom/press-releases/2024-05-29-gartner-forecasts-worldwide-artificial-intelligence-chips-revenue-to-grow-33-percent-in-2024",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Gartner.png",
    source_name: "Gartner",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Claude 上线 Tool Use 功能，可与外部数据和工具交互",
    abstract:
      "人工智能公司 Anthropic 宣布 AI 助手 Claude 的 Tool Use 功能已全面上线。该功能使 Claude 能够自主与外部数据源、API 和工具进行交互，以改变企业利用人工智能实现任务自动化、个性化推荐和简化数据分析的方式。对于使用 Anthropic Messages API、Amazon Bedrock 和 Google Vertex AI 的开发人员来说，Tool Use 现已在整个 Claude 3 模型系列中可用。",
    link: "https://www.anthropic.com/news/tool-use-ga",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Anthropic.png",
    source_name: "Anthropic",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI搜索创企Perplexity正进行2.5亿美元融资，估值超210亿",
    abstract:
      "据The Information报道，AI 搜索引擎初创企业Perplexity正进行2.5亿美元的第四轮融资，公司最新估值高达30亿美元（约合人民币217.51亿元），比今年早些时候的估值提升三倍。报道称，Perplexity AI此轮领投方为美国投资机构 Bessemer Venture Partners，老股东包括Databricks、NEA、AIX Ventures、Elad Gil 和 Nat Friedman。",
    link: "https://mp.weixin.qq.com/s/x__fyCv2pjX70hnmfdTffQ",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0525-0531",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AIGC科技企业「爱设计&AiPPT.cn」宣布完成数千万元B1轮融资",
    abstract:
      "AIGC科技企业「爱设计」宣布完成B1轮融资。本轮融资由A股上市公司视觉中国领投，星连资本和36氪跟投，这是「爱设计」在短短 4 年内获得的第四轮融资，此前，「爱设计」曾先后获得来自心元资本，微梦传媒，视觉中国，信天创投，策源创投，亚杰基金及知名战投方投资。本轮融资将用于人工智能技术，内容版权创作者体系和国内外用户增长等方面。「爱设计」成立于2018年，从在线设计工具的角度切入，延伸至企业AIGC 内容营销中台，去年 8 月份又孵化上线了AI 办公单品AiPPT.cn/AiPPT.com。",
    link: "https://36kr.com/p/2794101990048901",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-31 00:00:00",
  },
  {
    week: "0511-0524",
    week_title: "2024年5月第1期",
    anchor: "20240511",
    week_abs_long: {
      行业: "扎克伯格提醒：GPU补货已恢复，但其高耗电问题仍是主要难题。",
      新闻: "Meta将推出AI聊天机器人并投入400亿美元研发，全球16家公司承诺AI安全，谷歌和Meta竞购好莱坞合作，杨红霞离职创业，黄仁勋讨论AI在英伟达的重要性，微软发布大量产品更新。",
      创投: "智驾、trawa、深智透医分别获数千万融资，Alpha Intelligence筹集2.5亿美元AI投资基金，软银集团将投资10万亿日元于AI革命。",
      论文: "原文涉及图像分割的透明度失真稳健性，视觉与文本合作的少样本学习，以及大模型文生图的实证研究分析。",
    },
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "黄仁勋最新访谈：英伟达已离不开AI，AGI或五年内出现",
    abstract:
      "在近期举办的Stripe Sessions用户大会上，移动支付巨头Stripe的联合创始人兼CEO帕特里克·克里森（Patrick Collison），与英伟达CEO黄仁勋进行了一场炉边对话。对于人工智能的未来，黄仁勋表示出了极大的信心。他预测人工智能将在未来高速发展，并强调英伟达在未来五年将大力运用人工智能来推动GPU的生产与创新。此外，黄仁勋还提到了英伟达的核心价值观之一——“爱与关怀”。他认为这与Stripe所倡导的“美与技艺”价值观有着异曲同工之妙，都体现了对于卓越品质的不懈追求和对于用户的深切关怀。",
    link: "https://new.qq.com/rain/a/20240522A09FGH00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过视觉和文本知识联合进行少样本学习",
    abstract:
      "少样本学习的目的是将识别器从已知的类别推广到一个全新的场景。在只有少量支持样本的情况下，几种高级方法最初引入类名称作为识别新类的先验知识。然而，对于如何利用视觉和文本知识的相互优势的全面理解仍然存在障碍。在本文中，我们提出了一种称为 BiKop 的连贯的双向知识渗透策略，该策略基于人类直觉：类名描述提供一般表示，而图像捕获个体的特异性。 BiKop主要通过双向知识渗透建立层次化的联合一般-具体表示。",
    link: "https://arxiv.org/abs/2405.12543",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "软银集团将向“AI革命”投资10万亿日元",
    abstract:
      "日本软银集团（SBG）会长兼社长孙正义提出的“AI革命”开始启动。软银集团计划以AI半导体为突破口，把业务扩大到数据中心、机器人、发电等行业。预计投资额最高可达到10万亿日元规模（约合人民币4640.9亿元）。",
    link: "https://www.36kr.com/p/2773800463022848",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "谷歌和Meta据称出价数千万美元与好莱坞合作",
    abstract:
      "据知情人士透露，谷歌母公司Alphabet Inc.和Meta Platforms Inc.已与好莱坞主要电影公司进行了讨论，希望电影公司能授权IP内容用于这两家科技巨头的人工智能视频生成软件。据悉，两家公司都在开发能够根据文本提示创建逼真场景的技术，并提供了数千万美元的资金与电影公司合作。此外，微软支持的竞争对手OpenAI也在进行类似的对话。",
    link: "https://www.cls.cn/detail/1685127",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "智驾公司鉴智机器人获 3000 万美元新融资，亦庄国投领投、地平线跟投",
    abstract:
      "智能驾驶公司鉴智机器人近日完成了 3000 万美元的 Pre-B 轮融资，由北京经开区产业升级基金及北京智能网联汽车产业基金联合领投，二者都是亦庄国投管理的投资基金；此轮跟投的鉴智老股东中，则有智能驾驶计算平台公司地平线。鉴智是目前中国市场仅有的两家可基于双目摄像头做纯视觉方案的智驾供应商，另一家是大疆。",
    link: "https://mp.weixin.qq.com/s/klEqhyp2t8hcn28itwxmAA",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "扎克伯格警告：GPU不再缺货，功耗成为大问题",
    abstract:
      "Facebook 联合创始人兼首席执行官马克·扎克伯格 (Mark Zuckerberg) 认为，能源限制将成为 IT 行业的下一个瓶颈。他在最近的一次采访中表示，他认为长期的GPU荒已经基本结束，人工智能的增长和发展短期内不会受到资本限制的限制。相反，能源问题将成为下一个主要的关键点。",
    link: "https://mp.weixin.qq.com/s/FsZ2M-A3rxB_197CRsDl6g",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "微软Build开发者大会发布50+产品更新，Altman压轴预告新模型",
    abstract:
      "5月22日凌晨，微软 Build 2024 开发者大会今晨在美国西雅图召开，微软一口气发布了 50 多项更新，带来从 AI 基础设施的搭建，到模型产品的落地方向的工具和生产力工具。作为接棒 OpenAI 和Google发布会，微软不仅要和苹果等厂商争夺 AI PC 的定义权，誓要“颠覆”10亿打工人的Copilot，全新加持Agent。OpenAI CEO奥特曼（Sam Altman）压轴登场，谈及新模型时，奥特曼表示，新的模态和整体智能将是OpenAI下一个模型的关键。他预计模型将会变得更智能、更强大，更安全，而且GPT-4o将会速度更快，成本更低。",
    link: "https://zhidx.com/p/426282.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智东西.png",
    source_name: "智东西",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "大模型文生图的实证研究和分析",
    abstract:
      "文本到图像生成的一个关键先决条件是对文本输入的准确理解。现有的方法利用CLIP模型的文本编码器来表示输入提示。然而，预先训练的CLIP模型只能以77的最大标记长度对英语进行编码。此外，与大型语言模型（LLM）相比，CLIP的文本编码器的模型容量相对有限，后者提供多语言输入，适应更长的上下文，并实现卓越的文本表示。在本文中，我们研究了LLM作为文本编码器，以提高文本到图像生成中的语言理解。我们引入了一个三阶段的训练管道，该管道将现有的文本到图像模型与LLM有效地集成在一起。",
    link: "https://arxiv.org/abs/2405.12914",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "图像分割任务的透明度失真稳健性",
    abstract:
      "语义图像分割促进了多种现实世界的应用，从工业过程监控的自动驾驶到人类的视觉辅助。这些模型通常使用示例输入以监督方式进行训练。这些示例和操作中的输入之间的分布变化可能会导致错误的分割。语义分割模型针对不同相机或照明设置、镜头畸变、对抗性输入和图像损坏引起的分布变化的鲁棒性一直是最近研究的主题。然而，研究界尚未解决由不均匀玻璃结构（例如窗户）或热空气中的混沌折射引起的空间变化径向畸变效应的鲁棒性问题。我们提出了一种方法来综合增强具有空间变化失真的现有数据集。我们的实验表明，这些失真效应会降低最先进的分割模型的性能。事实证明，预训练和扩大模型容量是在一定程度上缓解性能下降的合适策略，而对扭曲图像的微调只能带来边际性能提升。",
    link: "https://arxiv.org/abs/2405.12864",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title:
      "OpenAI投资者Alpha Intelligence Capital筹集2.5亿美元新基金，聚焦AI投资",
    abstract:
      "OpenAI等人工智能公司的投资者Alpha Intelligence Capital(AIC)正在筹集一只规模达2.5亿美元的基金，并吸引到了法国和新加坡的政府实体作为投资者。AIC合伙人Arnaud Barthelemy和Terry Chou表示，已为该基金筹集到1.6亿美元资金，并有望在9月前完成最终募资。他们补充称，法国兴业银行和新加坡一家国有基金将参与其中。一位知情人士透露称，新加坡主权财富基金淡马锡是这只新基金的投资者之一。",
    link: "https://www.zhitongcaijing.com/content/detail/1123754.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智通财经.png",
    source_name: "智通财经",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "OpenAI、微软、智谱AI等全球16家公司共同签署前沿人工智能安全承诺",
    abstract:
      "5 月 21 日，图灵奖得主 Yoshua Bengio、Geoffrey Hinton 和姚期智联合国内外数十位业内专家和学者，在权威科学期刊 Science 上刊文，呼吁世界各国领导人针对 AI 风险采取更有力的行动，并警告说，“近六个月所取得的进展还不够”。他们认为，AI 的无节制发展很有可能最终导致生命和生物圈的大规模损失，以及人类的边缘化或灭绝。",
    link: "https://mp.weixin.qq.com/s/CsMa-FSp2Kf19ci0_ZoAsw",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "Meta 将推出付费版聊天机器人Meta AI，今年或投入400亿美元用于AI技术研发",
    abstract:
      "据媒体报道称，Facebook和Instagram的母公司Meta Platforms正在考虑向用户收取更高级版本的人工智能助手费用，该助手被称为Meta AI。谷歌、微软、OpenAI和Anthropic通过其聊天机器人收取每月20美元的订阅费。订阅后，人们可以在微软 Word 等工作场所应用中使用这些公司的聊天机器人，并在使用率高时获得优先访问权等。目前尚无法得知 Meta 高级版可能提供的功能，以及 Meta 可能收取的费用。",
    link: "https://mp.weixin.qq.com/s/XoynQI-uKnrAK1jo2qsdXQ",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "AI大牛杨红霞离职创业，曾为字节和阿里大模型研发主力",
    abstract:
      "据36氪从多个独立信源处获悉，字节跳动大语言模型研发技术专家杨红霞，已于近日从字节跳动离职，并开始筹备AI创业项目。杨红霞曾担任阿里达摩院超大规模多模态预训练模型M6的技术负责人，后加入字节AML（Applied Machine Learning，机器学习系统）团队。",
    link: "https://36kr.com/p/2788351176311687",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI医学影像初创公司「深智透医」获近千万美元B+轮融资",
    abstract:
      "AI医学影像企业「深智透医」（简称“深透”，Subtle Medical Inc.）近日完成B+轮近千万美元融资，由老股东Fusion Fund，新股东嘉加资本（ENVISIONX Capital）、蓝驰创投硅谷总部基金Bluerun Ventures、上海文周投资及其它亚太区域战略合作方共同投资。本轮融资将用于加速AI产品的全球商业落地及研发创新。",
    link: "https://36kr.com/p/2771350743743239",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0511-0524",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI 驱动的能源采购和管理平台 trawa 获 1000 万欧元种子轮融资",
    abstract:
      "总部位于德国柏林的可再生能源供应商trawa通过其人工智能解决方案简化了中小企业 的能源采购和管理，获得了由 Balderton Capital 领投的 1000 万欧元种子轮融资。德国气候技术投资者AENU以及之前的投资者Speedinvest、Magnetic和TinyVC也参与了本轮融资。",
    link: "https://www.eu-startups.com/2024/05/berlin-based-cleantech-trawa-raises-e10-million-to-cut-sme-energy-costs-and-emissions",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/EU-Startups.png",
    source_name: "EU-Startups",
    publish_time: "2024-05-24 00:00:00",
  },
  {
    week: "0430-0510",
    week_title: "2024年4月第2期",
    anchor: "20240430",
    week_abs_long: {
      新闻: "OpenAI不会发布GPT-5及AI搜索引擎；苹果开发数据中心AI芯片；微软在马来西亚投资22亿美元扩展云及AI服务；DeepSeek开源MoE模型竞争GPT-4-Turbo。",
      行业: "国资委要求加速新技术如人工智能与制造流程和所有元素的深度融合。",
      创投: '"软银转向AI和芯片投资，马斯克xAI公司、DEEPX、Sift Healthcare等几家AI公司获取新融资，李飞飞启动空间智能创业项目。"',
      论文: "定量评估LVLMs的幻觉输出，优化抗干扰水印模型PWFN，并进行跨模态文本-图像检索。",
    },
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "马斯克旗下xAI公司有望本周完成新融资，成立10个月估值就达180亿",
    abstract:
      "据媒体报道，知情人士透露，埃隆·马斯克旗下的人工智能初创公司X.AI Corp.（简称“xAI”）有望最快在本周完成一轮融资。半个月前曾有报道提到，xAI将在融资中筹集60亿美元，投资者中将包含红杉资本（Sequoia Capital），最终将使这家成立不到10个月的人工智能初创公司的估值达到约180亿美元。",
    link: "https://www.cls.cn/detail/1671738",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "韩国 AI 芯片开发公司 DEEPX 获 8000 万美元 C 轮融资",
    abstract:
      "韩国AI芯片设计公司DeepX表示，该公司在新一轮融资中募资1100亿韩元（约合8000万美元），这轮融资使得该公司估值超过7000亿韩元，增长八倍。总部位于首尔的SkyLake Equity Partners成为其第二大股东。",
    link: "https://www.36kr.com/newsflashes/2769382059604736",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/36氪.png",
    source_name: "36氪",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "软银愿景基金持股组合缩水数百亿美元，孙正义转向AI和芯片",
    abstract:
      "软银集团旗下的旗舰基金愿景基金（Vision Fund）近年来已悄悄抛售或减记了价值数百亿美元的上市公司股份。公司创始人孙正义正从曾经热衷的风险投资交易转向半导体和人工智能领域的战略投资。监管文件显示，自2021年底以来，愿景基金的美国上市公司投资组合缩水了近290亿美元。该基金减持了Coupang Inc.、DoorDash Inc.和Grab Holdings Ltd.等公司的股份；除了在美国上市的公司外，愿景基金还在逐步减持印度初创企业Paytm和中国商汤科技集团的股份，目前软银在这两家公司的持股比例都不到5%。",
    link: "https://www.cls.cn/detail/1672636",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "跨模态文本-图像检索",
    abstract:
      "作为一种基于匹配的任务，跨模态文本图像检索常常面临文本和图像之间信息不对称的问题。为了应对这一挑战，我们提出了一种用于遥感图像的知识感知文本图像检索（KTIR）方法。通过从外部知识图谱中挖掘相关信息，KTIR 丰富了搜索查询中可用的文本范围，并缩小了文本和图像之间的信息差距，以实现更好的匹配。此外，通过集成特定领域的知识，KTIR 还增强了预训练视觉语言模型对遥感应用的适应能力。",
    link: "https://arxiv.org/abs/2405.03373v1",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "苹果正在开发用于数据中心的AI芯片，寻求在竞争中占据优势",
    abstract:
      "腾讯科技讯 5月7日消息，据国外媒体报道，苹果公司一直在研发自家芯片，旨在用于数据中心服务器，以运行尖端的人工智能软件。这一战略性举措可能使苹果在愈演愈烈的人工智能竞赛中占据优势地位。过去十年间，苹果已经成为为iPhone、iPad、Apple Watch和Mac电脑设计芯片的领军企业。据内部人士透露，这个服务器项目的内部代号为ACDC项目（Apple Chips in Data center，苹果数据中心芯片)，苹果可能将芯片用于自家服务器上。",
    link: "https://new.qq.com/rain/a/20240507A00PZT00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯科技",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "李飞飞成立“空间智能”方向的初创公司，已完成种子轮融资",
    abstract:
      "公司方向定为“空间智能”——旨在让AI能像人类一样对视觉信息进行高级推理。消息人士表示，这将是该技术的一次飞跃。投资方包括硅谷风投a16z和Radical Ventures。作为AI领域影响力最大的女性和华人，李飞飞长期对学术界和工业界贡献斐然。她在斯坦福拿下终身教职，曾担任谷歌云AI首席科学家、推动Google AI中国中心成立、并长期统筹谷歌云AI、谷歌大脑以及中国本土团队工作。",
    link: "https://mp.weixin.qq.com/s/RPhN_TR3lW990epLE7izmA",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "意外！OpenAI：下周一不会发布GPT-5，也不发布AI搜索引擎",
    abstract:
      "Sam Altman的这一宣布令市场再次意外。昨天报道称，OpenAI计划下周一5月13日宣布其基于AI的搜索产品。最早的爆料是OpenAI于本周四宣布，几天前报道称该时间被推迟，如今来看，这是又一次的推迟。5月14日谷歌将举行一年一度的“Google I/O”大会，OpenAI最终还是没有“抢跑”谷歌。",
    link: "https://wallstreetcn.com/articles/3714579",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/华尔街见闻.png",
    source_name: "华尔街见闻",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "微软宣布在马来西亚投资22亿美元发展云计算和人工智能服务",
    abstract:
      "微软5月2日宣布，将于未来4年内投资22亿美元以支援马来西亚的数码化转型，这是微软进军马来西亚以来的最大单笔投资。该投资包括：建设云端和AI基础建设；为另外的20万马来西亚人提供AI技能培训机会；加强与马来西亚政府的合作，建立全国AI卓越中心；支援马来西亚程式开发员社群的发展。",
    link: "https://www.jiemian.com/article/11132911.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/界面新闻.png",
    source_name: "界面新闻",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "定量评估大型视觉语言模型(LVLMs)自由形式输出中幻觉",
    abstract:
      "减轻大型视觉语言模型（LVLM）中的幻觉仍然是一个悬而未决的问题。最近的基准没有解决开放式自由形式反应中的幻觉，我们将其称为“I 型幻觉”。相反，他们专注于对非常具体的问题格式做出反应的幻觉——通常是关于特定对象或属性的多项选择反应——我们称之为“II 型幻觉”。此外，此类基准测试通常需要对可能发生变化的模型进行外部 API 调用。在实践中，我们观察到 II 型幻觉的减少并不会导致 I 型幻觉的减少，而是两种形式的幻觉通常是反相关的。为了解决这个问题，我们提出了 THRONE，一种新颖的基于对象的自动框架，用于定量评估 LVLM 自由形式输出中的 I 型幻觉。",
    link: "https://arxiv.org/abs/2405.05256",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "国资委：加快人工智能等新技术与制造全过程、全要素深度融合",
    abstract:
      "4月28日，国务院国资委召开中央企业大规模设备更新工作推进会，深入学习贯彻习近平总书记重要讲话精神和党中央决策部署，落实国务院推动大规模设备更新和消费品以旧换新工作会议精神，对中央企业推进大规模设备更新工作作出部署。",
    link: "https://www.cls.cn/detail/1665289",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "从噪音中提取水印(PWFN):一种改进的抗强干扰水印模型",
    abstract:
      "数字水印是通过以人眼无法察觉的方式改变图像来嵌入秘密信息的过程。为了提高模型的鲁棒性，许多基于深度学习的水印方法通过向噪声层添加不同的噪声来使用编码器-噪声-解码器架构。然后解码器从失真图像中提取水印信息。但该方法只能抵抗弱噪声攻击。为了提高解码器对较强噪声的鲁棒性，本文提出在噪声层和解码器之间引入去噪模块。该模块旨在降低噪声并恢复部分因失真而丢失的信息。",
    link: "https://arxiv.org/abs/2405.05170",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Triomics获1500万美元A轮融资，利用AI进行癌症临床试验匹配",
    abstract:
      "Triomics是一家利用生成人工智能彻底改变癌症治疗的公司，今天宣布获得1500万美元的资金，由著名的硅谷公司领导，如Lightspeed、Nexus Venture Partners、General Catalyst和Y Combinator。Triomics与领先的学术癌症中心和研究人员合作，开发生成性人工智能性能和安全基准以及最佳实践。Triomics合作伙伴包括以肿瘤学为重点的LLM培训合作组织（COLT），由十几个NCI指定的癌症中心的领导者组成的联盟，以及癌症中心癌症信息学协会（CI4CC）。",
    link: "https://www.vbdata.cn/intelDetail/163956",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/动脉网.png",
    source_name: "动脉网",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "Sift Healthcare获2000万美元B轮融资，提供AI驱动的医疗支付解决方案",
    abstract:
      "在B Capital的领导下，在现有投资者（包括Allos Ventures、First Trust Capital Partners和Rock River Capital）的持续支持下，随着公司发展其行业第一支付智能平台，Sift将利用这笔资金优先考虑团队扩展和人工智能技术投资。Sift Healthcare成立于2017年，是一家总部位于密尔沃基的医疗支付分析和数据科学公司。",
    link: "https://www.vbdata.cn/intelDetail/163620",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/动脉网.png",
    source_name: "动脉网",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "DeepSeek开源MoE模型，性能直逼GPT-4-Turbo",
    abstract:
      "开源大模型领域，又迎来一位强有力的竞争者。近日，探索通用人工智能（AGI）本质的 DeepSeek AI 公司开源了一款强大的混合专家 (MoE) 语言模型 DeepSeek-V2，主打训练成本更低、推理更加高效。",
    link: "https://www.jiqizhixin.com/articles/2024-05-07-3",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/机器之心.png",
    source_name: "机器之心",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI 法律科技初创公司 Definely 获 700 万美元 A 轮融资",
    abstract:
      "该公司总部位于伦敦，在全球拥有60多名员工，目前正专注于增加来自英国、美国、加拿大和澳大利亚最大公司和律师事务所的40000名活跃用户。随着该公司在整合人工智能方面的进展，它还将积极寻求扩大其经验丰富的技术团队。",
    link: "https://tech.eu/2024/05/08/legaltech-definely-secures-7m-for-ai-driven-contract-management/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/Tech.eu.png",
    source_name: "Tech.eu",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0430-0510",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "AI 云计算平台 RunPod 获 2000 万美元种子轮融资",
    abstract:
      "投资者越来越多地押注创新型生成式 AI 初创公司。最新的一家初创公司是 RunPod，它提供了一个启动板来帮助开发人员部署定制的全栈 AI 应用程序。今天，RunPod 宣布已筹集 2000 万美元种子资金，由英特尔投资和戴尔科技资本共同领投，Julien Chaummond、Nat Friedman 和 Adam Lewis 参投。除这笔资金外，RunPod 还宣布英特尔投资副总裁兼高级董事总经理 Mark Rostick 将加入其董事会。",
    link: "https://accesspath.com/tech/5927798/",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/前途科技.png",
    source_name: "前途科技",
    publish_time: "2024-05-10 00:00:00",
  },
  {
    week: "0413-0429",
    week_title: "2024年4月第1期",
    anchor: "20240413",
    week_abs_long: {
      新闻: "清华大学在芯片领域有重要突破，百度AI开发者大会安排，国内首个汽车大模型标准发布，中国首个长时长视频大模型Vidu亮相。",
      行业: '"欧普泰2023年度报告显示营收同比提高35.42%，其背后是AI技术推动的光伏检测创新。"',
      创投: "初创公司Perplexity AI获6300万美元融资，估值超10亿；张月光创立沐言智能目前融资近3亿；福布斯预测2024年AI初创企业50强。",
      论文: "OneChart优化图表提取，语言模型开发视觉分类器，双向布局优化房间模糊布局，OpenBias检测文本到图像偏差，Mini-Gemini发掘视觉语言模型潜力。",
    },
  },
  {
    week: "0413-0429",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "通过双向布局估算改进全景房间布局模糊问题",
    abstract:
      "布局注释中固有的模糊性给开发准确的 360° 房间布局估计模型带来了重大挑战。为了解决这个问题，我们提出了一种新颖的 Bi-Layout 模型，能够预测两种不同的布局类型。一种止于模糊区域，而另一种延伸到涵盖所有可见区域。我们的模型采用两个全局上下文嵌入，其中每个嵌入都旨在捕获每种布局类型的特定上下文信息。通过我们新颖的特征引导模块，图像特征从这些嵌入中检索相关上下文，生成布局感知特征以进行精确的双布局预测。",
    link: "https://arxiv.org/abs/2404.09993",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "福布斯：2024年人工智能初创企业50强",
    abstract:
      "随着人工智能热潮的持续，一种新的技术经济正在帮助企业开发和部署人工智能驱动的应用程序。在《福布斯》第六届年度“人工智能50强”榜单上，这类新锐企业正大行其道。该榜单遴选了AI领域最有前途的初创公司，由《福布斯》在领先行业专家的帮助下，与数据合作伙伴红杉资本和Meritech Capital共同编制而成。",
    link: "https://www.forbeschina.com/innovation/innovation/67577",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/福布斯中国.png",
    source_name: "福布斯中国",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title:
      "清华大学：芯片领域重要突破，大规模干涉-衍射异构集成芯片太极（Taichi）",
    abstract:
      "记者11日从清华大学获悉，针对大规模光电智能计算难题，清华大学电子工程系副教授方璐课题组、自动化系戴琼海院士课题组，摒弃传统电子深度计算范式，另辟蹊径，首创分布式广度光计算架构，研制大规模干涉-衍射异构集成芯片太极（Taichi），实现160 TOPS/W的通用智能计算。",
    link: "https://www.cls.cn/detail/1644516",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "搜索初创公司Perplexity AI获新一轮6300万美元融资 估值升至逾10亿美元",
    abstract:
      "智通财经APP获悉，谷歌(GOOGL.US)竞争对手、美国人工智能搜索公司Perplexity AI在新一轮融资中筹集了约6300万美元，估值超过10亿美元。这笔融资将于周二宣布，使Perplexity的估值较三个月前翻了一番。投资者Daniel Gross领投，亿万富翁Stanley Druckenmiller、Y Combinator首席执行官Garry Tan和Figma Inc.首席执行官Dylan Field参与了这轮融资。另外，包括亚马逊(AMZN.US)创始人杰夫·贝佐斯和英伟达(NVDA.US)在内的几位Perplexity早期投资者也加入了这轮融资。",
    link: "https://www.zhitongcaijing.com/content/detail/1108072.html",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/智通财经.png",
    source_name: "智通财经",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "创投",
    effect: "",
    color: "#d580ff",
    title: "前妙鸭张月光创立「沐言智能」，目前已进行四轮融资近 3 亿人民币",
    abstract:
      "近日，AI 科技评论独家获悉：去年爆款产品「妙鸭」产品负责人张月光离职创业后，已经进行四轮融资，融资金额接近 3 亿人民币。阿里团队开发的「妙鸭」写真风格 AIGC 产品以渲染效果好、易用性高的优势爆火出圈，「妙鸭」相机产品负责人张月光也被称为“第一批 AIGC 产品经理”。",
    link: "https://mp.weixin.qq.com/s/Zk3RXDpBh7cWBsMBX4T01w",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "全面走向“人工智能＋” 国内首个汽车大模型标准发布",
    abstract:
      "中国信息通信研究院今天（28日）发布了国内首个汽车大模型标准。标准主要涵盖三个能力域，其中场景丰富度侧重评估汽车大模型对智能座舱和自动驾驶等细分场景的支持情况，能力支持度重点关注汽车大模型在感知、理解、推理、生成等人工智能技术能力上的表现，应用成熟度主要评估汽车大模型在系统生态、部署定制、场景适配等方面的应用情况。",
    link: "https://www.cls.cn/detail/1661952",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/财联社.png",
    source_name: "财联社",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "使用大型语言模型不断发展可解释的视觉分类器",
    abstract:
      "多模态预训练模型（例如 CLIP）由于其开放词汇灵活性和高性能，在零样本分类中很受欢迎。然而，计算图像和类别标签之间相似度分数的视觉语言模型很大程度上是黑盒，可解释性有限，存在偏见风险，并且无法发现未记录下来的新视觉概念。此外，在实际设置中，类名的词汇和专业概念的属性将是未知的，这使得这些方法无法在大规模视觉语言数据集中不常见的图像上表现良好。为了解决这些局限性，我们提出了一种新方法，可以发现视觉识别的可解释但有区别的属性集。我们引入了一种进化搜索算法，该算法使用大型语言模型及其上下文学习能力来迭代地改变分类属性的概念瓶颈。",
    link: "https://arxiv.org/abs/2404.09941",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "中国首个长时长、高一致性、高动态性视频大模型，Vidu 登场！",
    abstract:
      "今日，在中关村论坛未来人工智能先锋论坛上，生数科技联合清华大学正式发布中国首个长时长、高一致性、高动态性视频大模型——「Vidu」。该模型采用团队原创的Diffusion与Transformer融合的架构U-ViT，支持一键生成长达16秒、分辨率高达1080P的高清视频内容。",
    link: "https://mp.weixin.qq.com/s/Lba_WJTQWjQ3lOaLNJA4qA",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/微信.png",
    source_name: "微信",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "行业",
    effect: "",
    color: "#108ee9",
    title: "「年报」欧普泰2023年营收同比上升35.42% AI技术助力光伏检测创新",
    abstract:
      "4月22日，欧普泰（836414）发布了2023年年报。报告显示，2023年，公司实现营业收入1.80亿元，同比上升35.42%；实现归属于上市公司股东的净利润0.34亿元，同比上升17.92%。欧普泰表示，报告期内，公司的主营业务和主要产品未发生变化。营业收入增长的主要原因，一是公司研发的新产品投入市场，取得较好的业绩，二是得益于新客户的开发。",
    link: "https://baijiahao.baidu.com/s?id=1797084281152233601&wfr=spider&for=pc",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/百度.png",
    source_name: "百家号",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "OpenBias：文本到图像生成模型中的开放集偏差检测",
    abstract:
      "文本到图像的生成模型正变得越来越流行并且可供公众使用。随着这些模型的大规模部署，有必要深入研究其安全性和公平性，以免传播和延续任何类型的偏见。然而，现有的工作侧重于检测先验定义的封闭偏差集，将研究限制在众所周知的概念上。在本文中，我们解决了文本到图像生成模型中开放集偏差检测的挑战，提出了 OpenBias，这是一种新的管道，可以不可知地识别和量化偏差的严重性，而无需访问任何预编译集。",
    link: "https://arxiv.org/abs/2404.07990",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "OneChart：通过一个辅助token净化图表结构提取",
    abstract:
      "由于风格、价值观、文本等的多样性，图表解析带来了巨大的挑战。即使是具有数十亿参数的高级大型视觉语言模型（LVLM）也难以令人满意地处理此类任务。为了解决这一问题，我们提出了OneChart：一种专门为图表信息的结构提取而设计的可靠代理。与流行的LVLM类似，OneChart包含了一个自回归主体。为了提高输出数字部分的可靠性，我们在总令牌的开头引入了一个辅助令牌以及一个额外的解码器。数值优化（辅助）令牌允许用于图表解析的后续令牌通过因果注意来捕获增强的数值特征。",
    link: "https://arxiv.org/abs/2404.09987",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "论文",
    effect: "",
    color: "#87d068",
    title: "Mini-Gemini：挖掘多模态视觉语言模型的潜力",
    abstract:
      "在这项工作中，我们介绍了 Mini-Gemini，这是一个增强多模态视觉语言模型（VLM）的简单而有效的框架。尽管 VLM 取得了进步，促进了基本的视觉对话和推理，但与 GPT-4 和 Gemini 等高级模型相比，性能差距仍然存在。我们试图从高分辨率视觉标记、高质量数据和 VLM 引导生成三个方面挖掘 VLM 的潜力，以实现更好的性能和任意工作流程，从而缩小差距。",
    link: "https://arxiv.org/abs/2403.18814",
    source_logo:
      "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/arXiv.png",
    source_name: "arXiv",
    publish_time: "2024-04-29 00:00:00",
  },
  {
    week: "0413-0429",
    topic: "新闻",
    effect: "",
    color: "#eb2f96",
    title: "Create 2024百度AI开发者大会",
    abstract:
      "4月16日，Create2024百度AI开发者大会在深圳举办。百度创始人、董事长兼首席执行官李彦宏发表了题为《人人都是开发者》的主旨演讲。他认为，大模型和生成式AI将彻底改变开发者这个群体。",
    link: "https://new.qq.com/rain/a/20240416A08H8H00",
    source_logo: "https://gitee.com/kakuibeyond/pic-bed/raw/master/ts/腾讯.png",
    source_name: "腾讯网",
    publish_time: "2024-04-29 00:00:00",
  },
];
