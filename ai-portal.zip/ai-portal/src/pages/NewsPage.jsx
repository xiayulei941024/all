import React , { useEffect, useState }from 'react';
import {
  StyleProvider,
  legacyLogicalPropertiesTransformer,
} from "@ant-design/cssinjs";
import {
  ConfigProvider,
  Timeline,
  Tag,
  FloatButton,
  Tabs,
  Image,
  Divider,
} from "antd";
import { SunOutlined, MoonOutlined, ArrowUpOutlined } from "@ant-design/icons";
import { useLocation } from "react-router-dom";
import AiImg from '../images/ai-title.png'
import { color } from 'echarts';

const NewsPage = React.memo(() => {
  const location = useLocation();
  const [isMobile, setIsMobile] = useState(false);
  const [blackTheme, setBlackTheme] = useState(false);

//   const data = location.state

  const titleStyle = {
    fontSize: "18px",
    lineHeight: 1.4,
    color: blackTheme ? "#c6c9cf" : "#282a2d",
    marginBottom: "1rem",
  };

  const layoutStyle = {
    width: "100%",
    minHeight: "100vh",
    paddingTop: isMobile ? "24px" : "24px",
    backgroundColor: blackTheme ? "#1b1d1f" : "#f9f9f9",
  };

  const contentStyle = {
    width: isMobile ? "95%" : "35%",
    backgroundColor: blackTheme ? "#2c2e2f" : "white",
    margin: "0 auto",
    // textAlign: 'center',
    padding: isMobile ? "0.75rem" : "1.25rem",
    minHeight: "100vh",
    border: "1px solid rgba(0,0,0,.125)",
    borderWidth: 0,
    boxShadow: "0px 0px 20px -5px rgba(158,158,158,.2)",
  };
  const changeTheme = () => {
    setBlackTheme(!blackTheme);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1025) {
        setIsMobile(true);
      } else {
        setIsMobile(false);
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [isMobile]);

  console.log("props", location);
  return (
    <StyleProvider
      hashPriority="high"
      transformers={[legacyLogicalPropertiesTransformer]}
    >
      <div style={layoutStyle}>
        <div style={contentStyle}>
          <p
            style={{
              lineHeight: 1.5,
              fontSize: "1.75rem",
            //   fontWeight: '700',
              color: blackTheme ? "#c6c9cf" : "#282a2d",
              marginBottom: '16px',
            }}
          >
            <img
              src={AiImg}
              style={{ marginBottom: "1.25rem", width: "100%" }}
            ></img>
            新闻标题休息休息嘻嘻嘻嘻要使p标签中的文字居中显示
          </p>
          <span style={{fontSize: '.875rem', color: '#6c757d', marginRight: '1rem'}}>2024.06.19 06:08 </span>
          <span style={{fontSize: '.875rem', color: '#6c757d', marginRight: '1rem'}}>来源：IT之家 </span>
          <Divider style={{backgroundColor: 'rgb(129 129 129 / 25%)'}}></Divider>
          <img src='' style={{margin: '5px 0 20px', width: '100%', border:'2px solid #eee', borderRadius: '6px'}}></img>
          <p style={{fontSize: '1rem', lineHeight: 2, marginBottom: '1.25rem', color: blackTheme ? '#bbb' : '#1d232b'}}>GPTZero是由24岁的Alex Cui和26岁的Tian创办的AI内容检测初创公司，两人自高中以来就是朋友。该公司成立于2022年12月，提供一种AI检测工具，用以识别内容是否由人工智能生成。GPTZero在2023年1月正式推出，并迅速获得了市场的关注和认可。GPTZero的检测技术在准确性上具有优势，基于大量人类与AI生成文本的数据，并且结合了先进的开源工具和深度学习模型。公司的客户基础不仅包括教师，还扩展到了政府采购机构、撰写资助申请的组织、招聘经理以及AI训练数据标注者等。GPTZero的长期愿景是创建一个互联网的新层面，以确保人类和AI内容的适当责任和区分。</p>
          <p style={{fontSize: '1rem', lineHeight: 2, marginBottom: '1.25rem', color: blackTheme ? '#bbb' : '#1d232b'}}>GPTZero是由24岁的Alex Cui和26岁的Tian创办的AI内容检测初创公司，两人自高中以来就是朋友。该公司成立于2022年12月，提供一种AI检测工具，用以识别内容是否由人工智能生成。GPTZero在2023年1月正式推出，并迅速获得了市场的关注和认可。GPTZero的检测技术在准确性上具有优势，基于大量人类与AI生成文本的数据，并且结合了先进的开源工具和深度学习模型。公司的客户基础不仅包括教师，还扩展到了政府采购机构、撰写资助申请的组织、招聘经理以及AI训练数据标注者等。GPTZero的长期愿景是创建一个互联网的新层面，以确保人类和AI内容的适当责任和区分。</p>
          <p style={{fontSize: '1rem', lineHeight: 2, marginBottom: '1.25rem', color: blackTheme ? '#bbb' : '#1d232b'}}>GPTZero是由24岁的Alex Cui和26岁的Tian创办的AI内容检测初创公司，两人自高中以来就是朋友。该公司成立于2022年12月，提供一种AI检测工具，用以识别内容是否由人工智能生成。GPTZero在2023年1月正式推出，并迅速获得了市场的关注和认可。GPTZero的检测技术在准确性上具有优势，基于大量人类与AI生成文本的数据，并且结合了先进的开源工具和深度学习模型。公司的客户基础不仅包括教师，还扩展到了政府采购机构、撰写资助申请的组织、招聘经理以及AI训练数据标注者等。GPTZero的长期愿景是创建一个互联网的新层面，以确保人类和AI内容的适当责任和区分。</p>
          <p style={{fontSize: '.875rem', lineHeight: 2, marginBottom: '1.25rem', color: blackTheme ? '#bbb' : '#1d232b'}}>（消息来源：<a href="https://techcrunch.com/2024/06/13/gptzero-profitable-ai-detection-startup-10m-series-a/" target="_blank" rel="noopener nofollow" style={{color: '#5961f9', paddingRight: '5px'}}>TechCrunch</a>）</p>
        </div>
        <FloatButton.Group shape="circle" style={{ right: 24 }}>
          <FloatButton
            icon={blackTheme ? <SunOutlined /> : <MoonOutlined />}
            onClick={changeTheme}
          />
          <FloatButton.BackTop
            visibilityHeight={0}
            icon={<ArrowUpOutlined />}
          />
        </FloatButton.Group>
      </div>
    </StyleProvider>
  );
});

export default NewsPage;
