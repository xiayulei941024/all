// react-markdown
import "./index.css"
import { Input, Button } from 'antd';
import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { SendOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import PromptList from './PromptList';
import useChat from "../../hooks/use-chat";
import CompletionContainer from "../../components/chat-component/completion-container";
import ChatContainer from '../../components/chat-component/chat-container';
import LogoMat from '../../images/logo-mat.png'
import { service } from "../../axios";
import { useUserContext } from "../../context/UserContext";
import useHistory from '../../hooks/use-history';

export default function CustomerBot({ ...props }) {
  // console.log('CustomerBot render');
  const chat = useChat({ queryAgentURL: '/api/v1/chat/completions' });
  const { userInfo } = useUserContext();

  // 设置document.title
  useEffect(() => {
    document.title = '智能客服';
  }, []);


  const conv_uid = useRef(new Date().getTime())

  // 历史记录
  const { history, setHistory } = useHistory('customer-bot');
  const [hasBody, setHasBody] = useState(() => history.length > 0);

  const [userInput, setUserInput] = useState('');
  const [loading, setLoading] = useState(false);
  // 聊天操作
  const handleChat = useCallback(
    (content, data = {
      incremental: false,
    }) => {
      setLoading(true);
      if (!hasBody) setHasBody(true);
      logSubmit(content, conv_uid.current);

      return new Promise((resolve) => {
        const tempHistory = [
          ...history,
          { role: 'human', context: content, order: 0, time_stamp: 0 },
          { role: 'view', context: '', order: 0, time_stamp: 0 },
        ];
        const index = tempHistory.length - 1;
        // 添加 loading
        tempHistory[index].context = `<chat-loading />`;
        setHistory([...tempHistory]);
        chat({
          data: { user_input: content, user_name: userInfo.employeenumber },
          chatId: conv_uid.current.toString(),
          onOpen: () => {
            // 开启会话 后，清空上下文
            tempHistory[index].context = "";
          },
          onMessage: (message) => {
            if (data?.incremental) {
              tempHistory[index].context += message;
            } else {
              tempHistory[index].context = message;
            }
            setHistory([...tempHistory]);
          },
          onDone: () => {
            // getChartsData(tempHistory);
            setLoading(false);
            console.log('done');
            resolve();
          },
          onClose: () => {
            // getChartsData(tempHistory);
            setLoading(false);
            console.log('close')
            resolve();
          },
          onError: (message) => {
            tempHistory[index].context = message;
            setHistory([...tempHistory]);
            setLoading(false);
            console.log('error')
            resolve();
          },
        });
      });
    },
    [history, chat],
  );

  // 埋点 记录submit 按钮
  async function logSubmit(userInput, conv_uid) {
    const data = {
      chat_content: userInput,
      conv_uid: conv_uid,
      user_info_uid: userInfo.uid,
      user_info_department_number: userInfo.departmentnumber,

    }
    const res = await service.post("/image_generation_info", data);
    console.log(res);
  }

  return (
    <div className='w-full h-screen bg-slate-100 relative flex flex-col'>
      <header className='shrink-0 w-full bg-white relative shadow-md shadow-slate-200 z-10' style={{ height: '60px', padding: '0 40px' }}>
        <div className='flex items-center h-full'>
          <img src={LogoMat} style={{ width: '30px', height: '30px' }}></img>
          <span className='font-bold tracking-wider' style={{ marginLeft: '10px' }}>智能客服</span>
        </div>
      </header>
      <div className={classNames("flex flex-col flex-1 bg-slate-100 overflow-hidden", {
        "justify-center": !hasBody,
        "items-center": !hasBody
      })}>
        <ChatContainer hasBody={hasBody} history={history} title="💬 智能客服" description="🚀 想了解什么信息，快来问我吧" />
        <div className={classNames("shrink-0 p-4 rounded-t-xl", {
          "w-3/6": !hasBody,
          "bg-white": hasBody,
          "shadow-sm": hasBody
        })}>
          <div className={classNames("mb-4", {
            // "w-3/6": !hasBody
          })}>
            <PromptList />
          </div>
          {/* 筛选项 */}
          {/* <div className='flex justify-between items-center'>
          </div> */}
          <CompletionContainer maxLength={100} hasBody={hasBody} setUserInput={setUserInput} onSubmit={handleChat.bind(undefined, userInput)} loading={loading} />
        </div>
      </div>
    </div>
  );
}