import { RedoOutlined } from '@ant-design/icons';
import { useEffect, useState, useRef } from 'react';
import useIntervalCarousel from '../../hooks/use-interval-carousel';

const promptList = [
  "打招呼/闲聊/知识库问答: 你好/你能做什么/介绍一下天合光能/...",
  "产品序列号真伪查询:如 0110630400065/0110630400066/...",
  "产品信息查询:如 DE21.70/NEG9R.B8/...",
  "询问价格相关:会提示让客户提供姓名和联系电话，我们销售人员会第一时间联系您。 同时可以提供 400 客服电话： 分销 4006890000#1，直销 4006890000#2",
  "建工单:当用户输入姓名,电话和问题描述时,会自动为用户创建工单",
]

function PromptList() {
  
  const { currentIndex, start, stop, manualChange } = useIntervalCarousel(promptList.length, 3000);
  // 根据current 计算currentPrompt
  const currentPrompt = promptList[currentIndex];

  return (
    <div className='flex items-start'>
      <div className="flex flex-1 mr-2 text-base text-gray-400 flex overflow-x-hidden" onMouseEnter={stop} onMouseLeave={start}>
        <div className="mr-2 shrink-0">示例问题: </div>
        <div className='truncate'>{ currentPrompt }</div>
      </div>
      <div className="text-gray-300 flex cursor-pointer" onClick={manualChange}>
        <RedoOutlined className='mr-1'/>
        <div>换一批</div>
      </div>
    </div>

  )
}

export default PromptList;