import axios from'axios';

// const baseURL = import.meta.env.MODE  === 'development' ? '/api' : 'https://matrixbackend.trinasolar.com:3000';
const baseURL = '/api';
console.log('baseURL', import.meta.env.MODE, baseURL);
const service = axios.create({
    baseURL: baseURL, // api的base_url
    timeout: 10000, // 请求超时时间
    // headers: { 'content-type': 'application/json;charset=utf-8' }
  })
const axiosUpload = axios.create({
  // baseURL: baseURL,
  // timeout: 5000,
})

const axiosTranslate = axios.create({
  baseURL: baseURL,
  // timeout: 30000,
})
export  {service, axiosUpload, axiosTranslate}