import { EventStreamContentType, fetchEventSource } from '@microsoft/fetch-event-source';
import { message } from 'antd';
import { useCallback, useEffect, useMemo } from 'react';
import { service } from '../axios';

// type Props = {
//   queryAgentURL?: string;
// };

// type ChatParams = {
//   chatId: string;
//   data?: Record<string, any>;
//   query?: Record<string, string>;
//   onMessage: (message: string) => void;
//   onClose?: () => void;
//   onDone?: () => void;
//   onError?: (content: string, error?: Error) => void;
// };

const useChat = ({ queryAgentURL = '/api/chat' }) => {
  const ctrl = useMemo(() => new AbortController(), []);

  const chat = useCallback(
    async ({ data, chatId, onOpen, onMessage, onClose, onDone, onError }) => {
      if (!data?.user_input) {
        message.warning("请输入你的问题");
        return;
      }

      const parmas = {
        ...data,
        conv_uid: chatId,
      };

      if (!parmas.conv_uid) {
        message.error('conv_uid 不存在，请刷新后重试');
        return;
      }

      try {
        const res = await service.post("/gen_chat_params", {
          ...parmas
        })
        await fetchEventSource(`${queryAgentURL}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(res.data.data),
          signal: ctrl.signal,
          openWhenHidden: false,
          async onopen(response) {
            if (response.ok && response.headers.get('content-type') === EventStreamContentType) {
              onOpen?.();
              return;
            }
          },
          onclose() {
            ctrl.abort();
            onClose?.();
          },
          onerror(err) {
            throw new Error(err);
          },
          onmessage: (event) => {
            let message = event.data;
            message = message.replaceAll('\\n', '\n');
            message = message.replaceAll('\n\n', '\n');
            if (message === '[DONE]') {
              // 暂时没有 [DONE]
              onDone?.();
            } else if (message?.startsWith('[ERROR]')) {
              // 暂时没有 [ERROR]
              onError?.(message?.replace('[ERROR]', ''));
            } else {
              onMessage?.(message);
            }
          },
        });
      } catch (err) {
        ctrl.abort();
        onError?.('我们碰到了一些问题,请重试...', err);
      }
    },
    [queryAgentURL],
  );

  useEffect(() => {
    return () => {
      ctrl.abort();
    };
  }, []);

  return chat;
};

export default useChat;
