import { useState, useEffect } from 'react';

function useHistory(key) {
  // 组合key
  key = 'history_' + key;

  const [history, setHistory] = useState(() => {
    console.log('getHistory');
    const storedHistory = localStorage.getItem(key);
    return storedHistory ? JSON.parse(storedHistory) : [];
  });

  // 设置history到localStorage
  useEffect(() => {
    console.log('setHistory', history)
    localStorage.setItem(key, JSON.stringify(history));
  }, [history]);

  return {
    history,
    setHistory
  }
}

export default useHistory;