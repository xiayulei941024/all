import {service} from './axios/index'

export const clickRecord = (e, tag = '') => {
    if (tag) {
      //发送请求到后端，统计点击量
      service.post('/clickRecord', {
        page_tag: tag,
        user_info_uid: JSON.parse(localStorage.getItem('userInfo')).uid,
        user_info_department_number: JSON.parse(localStorage.getItem('userInfo')).departmentnumber
      })
      .then(response =>{
        console.log(response.data);
      })
      .catch(error =>{
        console.log(error);
      });

    }
}

export default clickRecord