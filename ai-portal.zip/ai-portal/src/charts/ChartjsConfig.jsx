// Import Chart.js
import { Chart, Tooltip } from 'chart.js';
// Import Tailwind config
import { hexToRGB } from '../utils/Utils';

Chart.register(Tooltip);

// Define Chart.js default settings
Chart.defaults.font.family = '"Inter", sans-serif';
Chart.defaults.font.weight = 500;
Chart.defaults.plugins.tooltip.borderWidth = 1;
Chart.defaults.plugins.tooltip.displayColors = false;
Chart.defaults.plugins.tooltip.mode = 'nearest';
Chart.defaults.plugins.tooltip.intersect = false;
Chart.defaults.plugins.tooltip.position = 'nearest';
Chart.defaults.plugins.tooltip.caretSize = 0;
Chart.defaults.plugins.tooltip.caretPadding = 20;
Chart.defaults.plugins.tooltip.cornerRadius = 8;
Chart.defaults.plugins.tooltip.padding = 8;

// Function that generates a gradient for line charts
export const chartAreaGradient = (ctx, chartArea, colorStops) => {
  if (!ctx || !chartArea || !colorStops || colorStops.length === 0) {
    return 'transparent';
  }
  const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
  colorStops.forEach(({ stop, color }) => {
    gradient.addColorStop(stop, color);
  });
  
  return gradient;
};

export const chartColors = {
  textColor: {
    light: '#9CA3AF',
    dark: '#6B7280',
  },
  gridColor: {
    light: '#F3F4F6',
    dark: `rgba(${hexToRGB('#374151')}, 0.6)`,
  },
  backdropColor: {
    light: "#fff",
    dark: "#1F2937",
  },
  tooltipTitleColor: {
    light: "#1F2937",
    dark: "#F3F4F6",
  },
  tooltipBodyColor : {
    light: "#6B7280",
    dark: "#9CA3AF"
  },
  tooltipBgColor: {
    light: "#fff",
    dark: "#374151",
  },
  tooltipBorderColor: {
    light: "#E5E7EB",
    dark: "#4B5563",
  },
};
