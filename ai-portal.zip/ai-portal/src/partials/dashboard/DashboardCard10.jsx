import React ,{useEffect, useState} from 'react';

// import Image01 from '../../images/user-36-05.jpg';
// import Image02 from '../../images/user-36-06.jpg';
// import Image03 from '../../images/user-36-07.jpg';
// import Image04 from '../../images/user-36-08.jpg';
// import Image05 from '../../images/user-36-09.jpg';

import { service } from '../../axios';

function DashboardCard10() {

  const [customers, setCustomers] = useState([])
  const getTotalUser = async () => {
    const res = await service.get('/getTopUser')
    const user = res.data.slice(12, 22).map((e, i) => {  // 剔除最高的12个用户，基本都是本组用户
      return {
        id: i,
        name: e.user_info_uid,
        email: e.user_info_uid + '@trinasolar.com',
        spent: e.user_count,
      }
    })
    setCustomers(user)
  }
  
  useEffect(() => {
    getTotalUser()
  }, [])


  // const customers = [
  //   {
  //     id: '0',
  //     // image: Image01,
  //     name: 'Tao_Gao(高涛)',
  //     email: 'tao.gao03@trinasolar.com',
  //     location: '0000004332',
  //     spent: '310',
  //   },
  //   {
  //     id: '1',
  //     // image: Image02,
  //     name: 'Lin_Gong(龚林)',
  //     email: 'lin.gong@trinasolar.com',
  //     location: '0000004332',
  //     spent: '280',
  //   },
  //   {
  //     id: '2',
  //     // image: Image03,
  //     name: 'PeiWen_Xu(徐沛文)',
  //     email: 'peiwen.xu@trinasolar.com',
  //     location: '0000012839',
  //     spent: '267',
  //   },
  // ];

  return (
    <div className="col-span-full  bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <header className="px-5 py-4 border-b border-gray-100 dark:border-gray-700/60">
        <h2 className="font-semibold text-gray-800 dark:text-gray-100">TOP 用户访问量</h2>
      </header>      
      <div className="p-3">

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            {/* Table header */}
            <thead className="text-xs font-semibold uppercase text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50">
              <tr>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">姓名</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">邮箱</div>
                </th>
                <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-left">访问次数</div>
                </th>
                {/* <th className="p-2 whitespace-nowrap">
                  <div className="font-semibold text-center">部门号</div>
                </th> */}
              </tr>
            </thead>
            {/* Table body */}
            <tbody className="text-sm divide-y divide-gray-100 dark:divide-gray-700/60">
              {
                customers.length > 0 && customers.map(customer => {
                  return (
                    <tr key={customer.id}>
                      <td className="p-2 whitespace-nowrap">
                        <div className="flex items-center">
                          {/* <div className="w-10 h-10 shrink-0 mr-2 sm:mr-3">
                            <img className="rounded-full" src={customer.image} width="40" height="40" alt={customer.name} />
                          </div> */}
                          <div className="font-medium text-gray-800 dark:text-gray-100">{customer.name}</div>
                        </div>
                      </td>
                      <td className="p-2 whitespace-nowrap">
                        <div className="text-left">{customer.email}</div>
                      </td>
                      <td className="p-2 whitespace-nowrap">
                        <div className="text-left font-medium text-green-500">{customer.spent}</div>
                      </td>
                    </tr>
                  )
                })
              }
            </tbody>
          </table>

        </div>

      </div>
    </div>
  );
}

export default DashboardCard10;
