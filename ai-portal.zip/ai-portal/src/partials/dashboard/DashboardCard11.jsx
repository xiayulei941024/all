import React ,{useEffect, useState} from 'react';
import BarChart from '../../charts/BarChart03';
import { service } from '../../axios';
// Import utilities

function DashboardCard11() {

  const [chartData, setChartData]  = useState(null)
  
  const getData = async () => {
    const res = await service.get('/getTopTag')
    const total = await service.get('/getTotalClickNum')
    const data = {
      labels: ['Reasons'],
      datasets: [
        {
          label: res.data[0].tag_name,
          data: [res.data[0].total_count],
          backgroundColor: '#8470FF',
          hoverBackgroundColor: '#755FF8',
          barPercentage: 1,
          categoryPercentage: 1,
        },
        {
          label: res.data[1].tag_name,
          data: [res.data[1].total_count],
          backgroundColor: '#5D47DE',
          hoverBackgroundColor: '#4634B1',
          barPercentage: 1,
          categoryPercentage: 1,
        },
        {
          label: res.data[2].tag_name,
          data: [res.data[2].total_count],
          backgroundColor: '#67BFFF',
          hoverBackgroundColor: '#56B1F3',
          barPercentage: 1,
          categoryPercentage: 1,
        },
        {
          label: res.data[3].tag_name,
          data: [res.data[3].total_count],
          backgroundColor: '#3EC972',  //#F0BB33  #DFAD2B
          hoverBackgroundColor: '#34BD68',
          barPercentage: 1,
          categoryPercentage: 1,
        },
        {
          label: res.data[4].tag_name,
          data: [res.data[4].total_count],
          backgroundColor: '#F0BB33',
          hoverBackgroundColor: '#DFAD2B',
          barPercentage: 1,
          categoryPercentage: 1,
        },
        {
          label: 'Other',
          data: [total.data.total_count - res.data[0].total_count - res.data[1].total_count - res.data[2].total_count - res.data[3].total_count - res.data[4].total_count],
          backgroundColor: '#E5E7EB',
          hoverBackgroundColor: '#BFC4CD',
          barPercentage: 1,
          categoryPercentage: 1,
        },
      ],
    };
    setChartData(data)   
  }
  
  useEffect(() => {
    getData()
  }, [])

  if (!chartData ) {
    return <div>Loading...</div>
  }

  // const chartData = {
  //   labels: ['Reasons'],
  //   datasets: [
  //     {
  //       label: 'ChatBot',
  //       data: [231],
  //       backgroundColor: '#8470FF',
  //       hoverBackgroundColor: '#755FF8',
  //       barPercentage: 1,
  //       categoryPercentage: 1,
  //     },
  //     {
  //       label: 'AI翻译',
  //       data: [100],
  //       backgroundColor: '#5D47DE',
  //       hoverBackgroundColor: '#4634B1',
  //       barPercentage: 1,
  //       categoryPercentage: 1,
  //     },
  //     {
  //       label: 'AI资讯',
  //       data: [81],
  //       backgroundColor: '#67BFFF',
  //       hoverBackgroundColor: '#56B1F3',
  //       barPercentage: 1,
  //       categoryPercentage: 1,
  //     },
  //     {
  //       label: 'ChatPix',
  //       data: [65],
  //       backgroundColor: '#3EC972',  //#F0BB33  #DFAD2B
  //       hoverBackgroundColor: '#34BD68',
  //       barPercentage: 1,
  //       categoryPercentage: 1,
  //     },
  //     {
  //       label: 'Other',
  //       data: [72],
  //       backgroundColor: '#E5E7EB',
  //       hoverBackgroundColor: '#BFC4CD',
  //       barPercentage: 1,
  //       categoryPercentage: 1,
  //     },
  //   ],
  // };

  return (
    <div className="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <header className="px-5 py-4 border-b border-gray-100 dark:border-gray-700/60 flex items-center">
        <h2 className="font-semibold text-gray-800 dark:text-gray-100">模块访问量</h2>
      </header>
      <div className="px-5 py-3">
        <div className="flex items-start">
          {/* <div className="text-3xl font-bold text-gray-800 dark:text-gray-100 mr-2">449</div> */}
          {/* <div className="text-sm font-medium text-red-700 px-1.5 bg-red-500/20 rounded-full">-22%</div> */}
        </div>
      </div>      
      {/* Chart built with Chart.js 3 */}
      <div className="grow">
        {/* Change the height attribute to adjust the chart height */}
        <BarChart data={chartData} width={595} height={48} />
      </div>
    </div>
  );
}

export default DashboardCard11;
