import React from 'react';
import DoughnutChart from '../../charts/DoughnutChart';

// Import utilities

function DashboardCard06() {

  const chartData = {
    labels: ['国内', '海外'],
    datasets: [
      {
        label: '地区占比',
        data: [
          '91', '9',
        ],
        backgroundColor: [
          '#8470FF',
          '#67BFFF',
          '#4634B1',
        ],
        hoverBackgroundColor: [
          '#755FF8',
          '#56B1F3',
          '#0B324F',
        ],
        borderWidth: 0,
      },
    ],
  };

  return (
    <div className="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <header className="px-5 py-4 border-b border-gray-100 dark:border-gray-700/60">
        <h2 className="font-semibold text-gray-800 dark:text-gray-100">访问来源</h2>
      </header>
      {/* Chart built with Chart.js 3 */}
      {/* Change the height attribute to adjust the chart height */}
      <DoughnutChart data={chartData} width={389} height={260} />
    </div>
  );
}

export default DashboardCard06;
