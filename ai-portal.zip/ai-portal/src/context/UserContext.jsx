import React, { useCallback } from 'react'
const UserContext = React.createContext(null);

const UserContextProvider = ({ children }) => {
  // const useUserInfo = () => {
    const getUserInfo = useCallback(() => {
      try {
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (userInfo) {
          return userInfo;
        }
      } catch (error) {
        console.error("Failed to parse userInfo from localStorage:", error);
      }
      return null;
    }, []);

  //   return getUserInfo;
  // };

  // const getUserInfo = useUserInfo();
  const userInfo = getUserInfo();

  return <UserContext.Provider value={{userInfo}}>{children}</UserContext.Provider>;
};

export default UserContextProvider;
export const useUserContext = () => React.useContext(UserContext);
