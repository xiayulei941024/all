import { RobotOutlined, UserOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import markdownComponents from './config';

function ChatContent(props) {
  const { content } = props;
  const { role, context } = content;
  const isRobot = role === 'view';


  return (
    <div
      className={classNames('relative flex flex-wrap w-full p-2 md:p-4 rounded-xl break-words', {
        'bg-white dark:bg-[#232734]': isRobot,
      })}
    >
      <div className="mr-2 flex flex-shrink-0 items-center justify-center h-7 w-7 rounded-full text-lg sm:mr-4">
        {isRobot ? <RobotOutlined /> : <UserOutlined />}
      </div>
      <div className="flex-1 overflow-hidden items-center text-md leading-8">
        {/* 我发送的以文本渲染 */}
        {!isRobot && typeof context === 'string' && context}

        {/* 机器人发送的内容以markdown渲染 */}
        {isRobot && typeof context === 'string' && (
          <ReactMarkdown
            components={markdownComponents}
            remarkPlugins={[remarkGfm]}
            rehypePlugins={[rehypeRaw]}
          >
            {context}
          </ReactMarkdown>
        )}
      </div>
    </div>
  )
}

export default ChatContent;