import { 
  LinkOutlined,
  LoadingOutlined,
  ReadOutlined,
  SyncOutlined, 
  DownloadOutlined,
  LeftOutlined,
  RightOutlined,
  RotateLeftOutlined,
  RotateRightOutlined,
  SwapOutlined,
  UndoOutlined,
  ZoomInOutlined,
  ZoomOutOutlined,
 } from '@ant-design/icons';
import ReactMarkdown from 'react-markdown';
import { Table, Image, Tag, Tabs, Popover, Space } from 'antd';
import { CodePreview } from './code-preview';
import rehypeRaw from 'rehype-raw';
import fallback from "../../../images/fallback.png";

const customeTags = ['custom-view', 'chart-view', 'references', 'summary'];

function matchCustomeTagValues(context) {
  const matchValues = customeTags.reduce((acc, tagName) => {
    const tagReg = new RegExp(`<${tagName}[^>]*\/?>`, 'gi');
    context = context.replace(tagReg, (matchVal) => {
      acc.push(matchVal);
      return '';
    });
    return acc;
  }, []);
  return { context, matchValues };
}

const basicComponents = {
  "chat-loading"(props) {
    return (
      <div className='flex items-center gap-2'>
        <LoadingOutlined />
        {/* Matrix 正在生成您的创意图片，AI模型需要较长时间，请耐心等待30s... */}
        {/* ChatPix模块正在生成图像... */}
        正在思考中...
      </div>
    )
  },
  "img-loading"(props) {
    return (
      <div className='flex items-center gap-2'>
        <LoadingOutlined />
        Matrix 正在生成您的创意图片，AI模型需要较长时间，请耐心等待30s...
        {/* ChatPix模块正在生成图像... */}
      </div>
    )
  },
  "img-error"(props) {
    return (
      <div className=''>
        <img src={fallback} alt="" />
        图片生成失败,请重试...
      </div>
    )
  },
  code({ inline, node, className, children, style, ...props }) {
    const content = String(children);
    /**
     * @description
     * In some cases, tags are nested within code syntax,
     * so it is necessary to extract the tags present in the code block and render them separately.
     */
    const { context, matchValues } = matchCustomeTagValues(content);
    const lang = className?.replace('language-', '') || 'javascript';

    return (
      <>
        {!inline ? (
          <CodePreview code={context} language={lang} />
        ) : (
          <code {...props} style={style} className="p-1 mx-1 rounded bg-theme-light dark:bg-theme-dark text-sm">
            {children}
          </code>
        )}
        <ReactMarkdown components={markdownComponents} rehypePlugins={[rehypeRaw]}>
          {matchValues.join('\n')}
        </ReactMarkdown>
      </>
    );
  },
  ul({ children }) {
    return <ul className="py-1">{children}</ul>;
  },
  ol({ children }) {
    return <ol className="py-1">{children}</ol>;
  },
  li({ children, ordered }) {
    return <li className={`text-sm leading-7 ml-5 pl-2 text-gray-600 dark:text-gray-300 ${ordered ? 'list-decimal' : 'list-disc'}`}>{children}</li>;
  },
  table({ children }) {
    return (
      <table className="my-2 rounded-tl-md rounded-tr-md max-w-full bg-white dark:bg-gray-800 text-sm rounded-lg overflow-hidden">{children}</table>
    );
  },
  thead({ children }) {
    return <thead className="bg-[#fafafa] dark:bg-black font-semibold">{children}</thead>;
  },
  th({ children }) {
    return <th className="!text-left p-4">{children}</th>;
  },
  td({ children }) {
    return <td className="p-4 border-t border-[#f0f0f0] dark:border-gray-700">{children}</td>;
  },
  h1({ children }) {
    return <h3 className="text-2xl font-bold my-4 border-b border-slate-300 pb-4">{children}</h3>;
  },
  h2({ children }) {
    return <h3 className="text-xl font-bold my-3">{children}</h3>;
  },
  h3({ children }) {
    return <h3 className="text-lg font-semibold my-2">{children}</h3>;
  },
  h4({ children }) {
    return <h3 className="text-base font-semibold my-1">{children}</h3>;
  },
  a({ children, href }) {
    return (
      <div className="inline-block text-blue-600 dark:text-blue-400">
        <LinkOutlined className="mr-1" />
        <a href={href} target="_blank">
          {children}
        </a>
      </div>
    );
  },
  img({ src, alt }) {
    const handleDownload = () => {
      const imageUrl = src; // 图片的 URL
      const suffix = imageUrl.slice(imageUrl.lastIndexOf('.'));
      const imageName = `Matrix_${new Date().getTime()}${suffix}`; // 下载的文件名
  
      // 创建一个 <a> 元素
      const a = document.createElement('a');
      a.href = imageUrl + "?response-content-type=application/octet-stream";  // 设置图片链接
      a.download = imageName;  // 设置下载的文件名
  
      // 触发点击事件
      a.click();
      // 销毁a
      URL.revokeObjectURL(imageUrl);
      a.remove();
    };

    
    return (
      <div>
        <Image
          width={src ? '20%' : 'auto'}
          preview={!!src ?
            {
              toolbarRender: (
                _,
                {
                  transform: { scale },
                  actions: {
                    onActive,
                    onFlipY,
                    onFlipX,
                    onRotateLeft,
                    onRotateRight,
                    onZoomOut,
                    onZoomIn,
                    onReset,
                  },
                },
              ) => (
                <Space size={12} className="toolbar-wrapper">
                  <LeftOutlined onClick={() => onActive?.(-1)} />
                  <RightOutlined onClick={() => onActive?.(1)} />
                  <DownloadOutlined onClick={handleDownload} />
                  <SwapOutlined rotate={90} onClick={onFlipY} />
                  <SwapOutlined onClick={onFlipX} />
                  <RotateLeftOutlined onClick={onRotateLeft} />
                  <RotateRightOutlined onClick={onRotateRight} />
                  <ZoomOutOutlined disabled={scale === 1} onClick={onZoomOut} />
                  <ZoomInOutlined disabled={scale === 50} onClick={onZoomIn} />
                  <UndoOutlined onClick={onReset} />
                </Space>
              )
            }
          : false
          }
          className="min-h-[1rem] max-h-full border rounded"
          src={src}
          alt={alt}
          placeholder={
            <Tag icon={<SyncOutlined spin />} color="processing">
              Image Loading...
            </Tag>
          }
          fallback={fallback}
        />
      </div>
    );
  },
  blockquote({ children }) {
    return (
      <blockquote className="py-4 px-6 border-l-4 border-blue-600 rounded bg-white my-2 text-gray-500 dark:bg-slate-800 dark:text-gray-200 dark:border-white shadow-sm">
        {children}
      </blockquote>
    );
  },
};


const markdownComponents = {
  ...basicComponents,
};

export default markdownComponents;
