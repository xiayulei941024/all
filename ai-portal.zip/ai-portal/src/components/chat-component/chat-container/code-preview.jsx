import { Button, message } from 'antd';
import { CopyOutlined } from '@ant-design/icons';
import { oneDark, coldarkDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import copy from 'copy-to-clipboard';
import { CSSProperties, useContext } from 'react';

export function CodePreview({ code, light, dark, language, customStyle }) {

  return (
    <div className="relative">
      <Button
        className="absolute right-3 top-2 text-gray-300 hover:!text-gray-700 bg-gray-100"
        type="text"
        icon={<CopyOutlined />}
        onClick={() => {
          const success = copy(code);
          message[success ? 'success' : 'error'](success ? '复制成功' : '复制失败');
        }}
      />
      <SyntaxHighlighter customStyle={customStyle} language={language} style={oneLight}>
        {code}
      </SyntaxHighlighter>
    </div>
  );
}
