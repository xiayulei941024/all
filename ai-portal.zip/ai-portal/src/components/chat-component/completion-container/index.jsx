import { SendOutlined } from '@ant-design/icons';
import React, { useState, useCallback } from 'react';
import classNames from 'classnames';
import { Input, Button } from 'antd';
import { omit } from 'lodash';
// import FilterPanel from '../filter-panel';
import CompletionInput from './CompletionInput.jsx';

const CompletionContainer = React.memo(({children, ...props}) => {
  // console.log('CompletionContainer render');
  const { maxLength, hasBody, onSubmit, setUserInput, loading } = props;

  // 输入内容
  // const [userInput, setUserInput] = useState('');

  // 提交
  // function handleSubmit() {
  //   // console.log('userInput', userInput);
  //   // console.log('selectedValues', selectedValues)
  //   onSubmit(userInput, selectedValues)
  // }

  
  // 管理子组件的 selected 值
  // const [selectedValues, setSelectedValues] = useState({});
  
  return (
    <>
      {/* <FilterPanel setSelectedValues={setSelectedValues} /> */}
      { children }
      <CompletionInput maxLength={maxLength} hasBody={hasBody} setUserInput={setUserInput} onSubmit={onSubmit} loading={loading} />
    </>
  );
})

export default CompletionContainer;