import { Input, Button } from 'antd';
import { SendOutlined } from '@ant-design/icons';
import { omit } from 'lodash';
import { useState } from 'react';
import classNames from 'classnames';

function CompletionInput({ ...props }) {
  // console.log('CompletionInput render')
  const { maxLength = 100, hasBody, onSubmit, setUserInput, loading } = props;

  const [value, setValue] = useState('');

  function setInputValue(val) {
    setUserInput(val);
    setValue(val);
  }

  function handleKeyDown(e) {
    if (!value.trim()) return;
    if (e.keyCode === 13) {
      if (e.shiftKey) {
        // loading的时候 需要手动加换行
        if (loading) {
          setInputValue((state) => state + '\n');
        }
        return;
      }
      handleSubmit();
    }
  }

  // 提交并清空输入
  function handleSubmit() {
    if (loading) return;
    onSubmit();
    setTimeout(() => {
      setInputValue('');
    }, 0);
  }



  function handleChange(e) {
    const _value = e.target.value;
    // 输入并且正在加载中，去掉最后一个回车符
    if (_value.length > value.length) {
      if (loading && _value.endsWith('\n')) {
        // newText = newText.slice(0, -1);
        setInputValue(_value.slice(0, -1));
        return;
      }
    }
    if (typeof props.maxLength === 'number') {
      setInputValue(_value.substring(0, maxLength));
    }
  }


  return (
    <div className={
      classNames("shrink-0 customer-textarea-container bg-white", {
        // "w-3/6": !hasBody,
        flex: hasBody
      })}
    >
      <Input.TextArea
        className="w-full h-full"
        placeholder="请输入内容"
        size="large"
        style={{ border: "none", "outline": "none", boxShadow: "none" }}
        value={value}
        autoSize={{
          minRows: hasBody ? 1 : 3,
          maxRows: 4
        }}
        maxLength={maxLength}
        // {...omit(props, ['hasBody'])}
        onPressEnter={handleKeyDown}
        onChange={handleChange}
      />
      <div className={
        classNames("flex", {
          "justify-end": !hasBody,
          "items-end": hasBody
        })
      }>
        <Button
          className="ml-2 flex items-center justify-center"
          size="large"
          type="text"
          loading={loading}
          icon={<SendOutlined />}
          onClick={handleSubmit}
        />
      </div>
    </div>
  )
}

export default CompletionInput;