import ProCard from './ProCard'
import type { ProCardProps } from './ProCard'

import type { ProCardTabsProps } from './types'

export type { ProCardTabsProps, ProCardProps }

export default ProCard
