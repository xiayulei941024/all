import { ref, computed } from 'vue'
import type { Ref, ComputedRef } from 'vue'
import { defineStore } from 'pinia'
import { message } from 'ant-design-vue'
import { getNewsListByids, getUserSessionApi, pubedDetailApi } from '@/api/news'
import type { IHistory, INewsDetail, INote, ISession, ISessionItem } from '@/views/news-lm/types'
import { useUserStore } from '@/stores/user-store'

export enum Actions {
  ADD_ALL,
  REMOVE_ALL,
  ADD,
  REMOVE,
}
export enum Modes {
  DEFAULT,
  CHAT,
  NEWS,
  SOURCES,
}

interface INewsLmStore {
  colMode: Ref<Modes> // 3栏目展示模式
  colWidth: ComputedRef<[number, number, number]>
  setColMode: (mode: Modes) => void
  // // fileList,
  // // setFileList,
  newsShow: Ref<boolean> // true - 详情 false - 列表
  closeNewsShow: () => void
  newsSources: Ref<number[]> // 要闻中所有新闻id集合
  newsSourcesList: ComputedRef<INewsDetail[]> // 要闻中所有新闻集合
  setNewsSources: (type: Actions, newsDetail: INewsDetail) => void
  selectedNewsSources: Ref<number[]> // 要闻列表中被选中的新闻
  setSelectedNewsSources: (type: Actions, newsId: number) => void

  newsNoteWeakMap: WeakMap<INote, INewsDetail> // 根据md中圆圈的note信息 获取新闻详情
  setNewsNoteWeakMap: (note: INote) => void

  currentNews: Ref<INewsDetail> // 当前需要被展示的新闻
  currentNote: Ref<INote> // 当前note项
  setCurrentNews: (newsDetail: INewsDetail) => void // 调用即可查看新闻
  setCurrentNote: (note: INote) => boolean // 调用即可查看圆圈的note信息 false - newsNoteWeakMap中未查询到信息

  activeKey: Ref<string> // tabs - 要闻 - "1" 历史记录 - "2"
  setActiveKey: (key: string) => void // 切换 tabs

  historySessions: Ref<ISession[]> // 历史会话  //* 接口来的数据(sessionRecordList)会被转化为histories,以便于前端使用
  addHistorySessions: (session: ISession) => void // 添加历史会话
  removeHistorySession: (id: string) => void // 移除历史会话
  currentHistoryId: Ref<string> // 当前的历史会话
  setCurrentHistoryId: (id: string) => void // 设置当前历史会话
  currentHistory: ComputedRef<ISession> // 当前历史会话
}

export const useNewsLmStore = defineStore(
  'newsLm',
  (): INewsLmStore => {
    const isInit = ref(true) // 初始化中
    onMounted(async () => {
      // 获取所有的新闻源
      await initNewsMap()
      await initSession()
      isInit.value = false
    })

    async function initSession() {
      const userStore = useUserStore()
      const userId = userStore.userInfo?.userId
      if (!userId) return
      const res = await getUserSessionApi(userId)
      historySessions.value =
        res.data
          ?.map((item: ISession) => {
            return {
              ...item,
              histories: sessionToHistories(item.sessionRecordList),
            }
          })
          .sort((a, b) => {
            // 排序一下
            const timeA = new Date(a.recentTime).getTime()
            const timeB = new Date(b.recentTime).getTime()
            return timeB - timeA
          }) || []

      if (historySessions.value && historySessions.value.length > 0) {
        setCurrentHistoryId(historySessions.value[0].sessionId)
        const newsIdList = currentHistory.value.newsIdList
        await initNewsMap(newsIdList)
        newsSources.value = [...new Set([...newsSources.value, ...newsIdList])]
        selectedNewsSources.value = [...newsIdList]
      }
    }

    // 接口的session转换为我需要的history
    function sessionToHistories(sessionRecordList: ISessionItem[]) {
      const histories: IHistory[] = []
      sessionRecordList.forEach((item: ISessionItem) => {
        const _histories = [
          { role: 'user', content: item.questionContent },
          {
            role: 'assistant',
            content: item.fullContent,
          },
        ]
        histories.push(..._histories)
      })
      return histories
    }
    // // 存储文件对象
    // const fileList = ref<any[]>([])
    // // 废弃
    // function setFileList(list) {
    //   fileList.value = list
    // }
    const colMode = ref(Modes.DEFAULT)
    const colWidth: ComputedRef<[number, number, number]> = computed(() => {
      const presuppose: Record<Modes, [number, number, number]> = {
        [Modes.DEFAULT]: [40, 40, 20],
        [Modes.CHAT]: [30, 60, 10],
        [Modes.NEWS]: [60, 30, 10],
        [Modes.SOURCES]: [35, 35, 30],
      }
      return presuppose[colMode.value]
    })
    function setColMode(mode: Modes) {
      colMode.value = mode || Modes.DEFAULT
    }

    const newsShow = ref(false) // true - 详情 false - 列表
    function closeNewsShow() {
      newsShow.value = false
    }
    // 当前需要被展示的新闻
    const currentNews = ref<INewsDetail | null>(null)
    // 当前的note项
    const currentNote = ref<INote | null>(null)
    // 查看新闻
    function setCurrentNews(newsDetail) {
      setColMode(Modes.NEWS)
      newsShow.value = true
      currentNote.value = null
      currentNews.value = newsDetail
    }
    // 查看重点note
    function setCurrentNote(note): boolean {
      if (!newsNoteWeakMap.has(note) || !newsNoteWeakMap.get(note)) {
        return false
      }
      newsShow.value = true
      currentNote.value = note
      currentNews.value = newsNoteWeakMap.get(note)
      return true
    }
    // 维护新闻池
    const newsMap = new Map<number, INewsDetail>()
    // 建立脚标与新闻池的弱引用
    const newsNoteWeakMap = new WeakMap<INote, INewsDetail>()
    async function setNewsNoteWeakMap(note: INote) {
      let newsDetail = newsMap.get(note.newsId)

      // 获取并缓存新闻
      if (!newsDetail) {
        newsDetail = await getNewsDetail(note.newsId)
      }
      // 有可能还是不存在
      if (!newsDetail) return
      newsNoteWeakMap.set(note, newsDetail)
    }
    // 获取新闻详情
    async function getNewsDetail(newsId) {
      const res = await getNewsListByids({
        newsIdList: [newsId],
      })
      if (res.data && res.data.length > 0) {
        newsMap.set(newsId, res.data[0])
      }
      return res.data[0]
    }

    // 触发更新
    const trigger = ref(false)
    function triggerUpdate() {
      trigger.value = !trigger.value
    }
    // 初始化新闻池
    async function initNewsMap(newsIdList?: number[]) {
      if (!newsSources.value || newsSources.value.length === 0) return
      const data = {
        newsIdList: newsIdList || newsSources.value,
      }
      const res = await getNewsListByids(data)
      res.data?.forEach(item => {
        newsMap.set(item.id, item)
      })
      // 手动触发
      triggerUpdate()
    }

    // 加入sources的新闻
    const newsSources = ref<number[]>([])
    // 计算出来 可以用来渲染的新闻源
    const newsSourcesList = computed(() => {
      trigger.value
      return newsSources.value.map(item => ({ ...newsMap.get(item), checked: false }))
    })
    // newsSources操作
    function setNewsSources(type, newsDetail) {
      if (type === Actions.ADD) {
        newsSources.value.push(newsDetail.id)
        newsMap.set(newsDetail.id, newsDetail)
        setSelectedNewsSources(Actions.ADD, newsDetail.id)
      } else {
        newsSources.value = newsSources.value.filter(item => item !== newsDetail.id)
        newsMap.delete(newsDetail.id)
        setSelectedNewsSources(Actions.REMOVE, newsDetail.id)
      }
    }

    // 加入sources并被选中的新闻
    const selectedNewsSources = ref<number[]>([])
    // selectedNewsSources操作
    function setSelectedNewsSources(type, newsId: number) {
      switch (type) {
        case Actions.ADD_ALL:
          selectedNewsSources.value = [...newsSources.value]
          break
        case Actions.REMOVE_ALL:
          selectedNewsSources.value = []
          break
        case Actions.ADD:
          selectedNewsSources.value.push(newsId)
          break
        case Actions.REMOVE:
          selectedNewsSources.value = selectedNewsSources.value.filter(item => item !== newsId)
          break
        default:
          break
      }
    }

    // tabs - 要闻/历史记录
    const activeKey = ref('1')
    function setActiveKey(key) {
      activeKey.value = key
    }

    // 当前会话
    const currentHistoryId = ref<string>()
    function setCurrentHistoryId(id) {
      currentHistoryId.value = id
    }

    const currentHistory: ComputedRef<ISession> = computed(
      () => historySessions.value.find(item => item.sessionId === currentHistoryId.value) || ({} as ISession)
    )
    // 历史会话
    const historySessions = ref<ISession[]>([])
    function removeHistorySession(id) {
      historySessions.value = historySessions.value.filter(item => item.sessionId !== id)
    }
    function addHistorySessions(session: ISession) {
      historySessions.value.push(session)
    }

    return {
      colMode,
      colWidth,
      setColMode,
      // fileList,
      // setFileList,
      newsShow,
      closeNewsShow,
      newsSources, // 选中的新闻id集合
      newsSourcesList, // 选中的新闻集合
      setNewsSources,
      selectedNewsSources,
      setSelectedNewsSources,

      newsNoteWeakMap,
      setNewsNoteWeakMap,

      currentNews,
      currentNote,
      setCurrentNews,
      setCurrentNote,

      activeKey,
      setActiveKey,

      historySessions,
      addHistorySessions,
      removeHistorySession,
      currentHistoryId,
      setCurrentHistoryId,
      currentHistory,
    }
  },
  {
    persist: {
      pick: ['newsSources', 'selectedNewsSources'], // 只持久化
    },
  }
)
