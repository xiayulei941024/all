import MultiLineEllipsis from './index.vue'
import MultiLineSpread from './spread.vue'
export { MultiLineSpread }
export default MultiLineEllipsis
