export { default as DictSelect } from './group/DictSelect.vue'
export { default as DictCheckboxGroup } from './group/DictCheckboxGroup.vue'
export { default as DictRadioGroup } from './group/DictRadioGroup.vue'

export { default as DictBadge } from './display/DictBadge.vue'
export { default as DictTag } from './display/DictTag.vue'
export { default as DictText } from './display/DictText.vue'

export { default as DictTagGroup } from './display/DictTagGroup.vue'
