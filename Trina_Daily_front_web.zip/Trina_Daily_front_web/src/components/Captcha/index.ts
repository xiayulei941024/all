export { default as SliderCaptcha } from '@/components/Captcha/SliderCaptcha.vue'
export { default as RotateCaptcha } from '@/components/Captcha/RotateCaptcha.vue'
export { default as ConcatCaptcha } from '@/components/Captcha/ConcatCaptcha.vue'
export { default as WordClickCaptcha } from '@/components/Captcha/WordClickCaptcha.vue'
