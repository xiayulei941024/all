import TableOperateButton from './index.vue'
export default TableOperateButton
