<template>
  <div class="news-lm">
    <!-- <a-card
      :bordered="false"
      class="page-content"
      :style="{
        width: colWidth[0] + '%',
      }"
    >
      <div class="header-title">新闻</div>
      <NewsList :is-lm="true" @show-news-detail="data => console.log(data)" />
    </a-card> -->
    <NewsList
      :style="{
        width: colWidth[0] + '%',
      }"
    ></NewsList>
    <NewsLmChat
      :style="{
        width: colWidth[1] + '%',
      }"
    />
    <NewsLmSources
      :style="{
        width: colWidth[2] + '%',
      }"
    />
    <!-- <NewsLmUpload /> -->
  </div>
</template>

<script lang="ts" setup>
// import NewsLmUpload from './includes/upload'
import NewsList from './includes/news/index.vue'
import NewsLmChat from './includes/chat/index.vue'
import NewsLmSources from './includes/sources/index.vue'
import { useNewsLmStore } from '@/stores/news-lm'

defineOptions({ name: 'NewsLm' })

const newsLmStore = useNewsLmStore()
const { colWidth } = storeToRefs(newsLmStore)
</script>

<style lang="less" scoped>
.news-lm {
  display: flex;
  height: calc(100vh - 128px);
  display: flex;
  gap: 16px;
  > div {
    transition: all 0.3s;
  }
}
</style>
