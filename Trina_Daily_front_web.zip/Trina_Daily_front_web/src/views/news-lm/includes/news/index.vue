<template>
  <div class="news-container">
    <a-card
      :bordered="false"
      class="page-content"
      :body-style="{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }"
    >
      <div class="header-title">
        新闻
        <template v-if="!newsLmStore.newsShow">
          <menu-fold-outlined v-if="colMode === Modes.NEWS" @click="setColMode(Modes.DEFAULT)" />
          <menu-unfold-outlined v-else @click="() => setColMode(Modes.NEWS)" />
        </template>
        <a-button type="text" @click="closeNewsShow(), setColMode(Modes.DEFAULT)" v-if="newsLmStore.newsShow">
          <template #icon>
            <ShrinkOutlined />
          </template>
        </a-button>
      </div>
      <div class="news-main">
        <NewsPool
          v-show="!newsLmStore.newsShow"
          :is-lm="true"
          @show-news-detail="data => setCurrentNews(data)"
          style="height: 100%"
        />
        <NewsDetail v-if="newsLmStore.newsShow" />
      </div>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import NewsPool from '@/views/news-pool/index.vue'
import NewsDetail from './NewsDetail.vue'
import { useNewsLmStore, Modes } from '@/stores/news-lm'

const newsLmStore = useNewsLmStore()
const { setCurrentNews, closeNewsShow, setColMode } = newsLmStore
const { colMode } = storeToRefs(newsLmStore)
defineOptions({ name: 'NewsLmNews' })
</script>

<style lang="less" scoped>
@import url(../../index.less);
.news-container {
  height: 100%;
  .page-content {
    height: 100%;
    .header-title {
      #header-title;
    }
    .news-main {
      // flex: 1;
      // display: flex;
      // flex-direction: column;
      overflow: hidden;
      // gap: 8px;
    }
  }
}
</style>
