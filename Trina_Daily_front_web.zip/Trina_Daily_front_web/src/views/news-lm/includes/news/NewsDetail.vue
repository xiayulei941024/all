<template>
  <div class="news-detail">
    <a-card :bordered="false">
      <div class="detail-wrapper">
        <div class="title" v-html="detail.title"></div>
        <div class="tips">
          <img
            v-if="detail.addMode === 0 && detail.siteName"
            class="source-logo"
            :src="getLogoUrlByName(detail.siteName)"
            :alt="detail.siteName"
          />
          <span class="comming-source">{{ detail.siteName }}</span>
          <span class="create-date">{{ detail.createTime }}</span>
          <span class="link-source">
            <a
              :herf="detail.sourceUrl"
              v-if="detail.newUrl || detail.sourceUrl"
              target="_blank"
              @click="() => openNewWindow(detail.newUrl || detail.sourceUrl)"
            >
              原文链接
            </a>
          </span>
        </div>
        <div style="font-size: 16px; font-weight: bold; margin-bottom: 4px">AI解读:</div>
        <div class="overview">
          <MultiLineSpread :line="2">
            <span v-html="detail.explainContent || 'AI解读未生成'"></span>
          </MultiLineSpread>
        </div>
        <div style="font-size: 16px; font-weight: bold; margin-bottom: 4px">摘要:</div>
        <div class="overview">
          <MultiLineSpread :line="2">
            <span v-html="detail.abstractReal || '摘要未生成'"></span>
          </MultiLineSpread>
        </div>
        <MarkedToHtml v-if="detail.addMode === 0" :text="markContent" />
        <div v-else>{{ markContent }}</div>
      </div>
    </a-card>
  </div>
</template>

<script setup lang="ts">
import { useNewsLmStore } from '@/stores/news-lm'
import { getLogoUrlByName } from '@/utils/logo-util'
import { MultiLineSpread } from '@/components/MultiLineEllipsis'

const newsLmStore = useNewsLmStore()
const detail = computed(() => newsLmStore.currentNews)

const markContent = computed(() => {
  const markContent = detail.value.markContent
  // return markContent
  if (newsLmStore.currentNote) {
    const { start, end } = newsLmStore.currentNote
    // markContent.slice(0, 100).replace('"12 days of OpenAI"活动进入倒数第 2 天', '短') + markContent.slice(100)
    const startText = markContent.slice(0, start)
    const middleText = markContent.slice(start, end)
    const endText = markContent.slice(end)
    // console.log(startText, 1)
    // console.log(middleText, 2)
    // console.log(endText, 3)
    return `${startText}<div style="background: #eadef9">${middleText}</div>${endText}`
  } else {
    return markContent
  }
})
const openNewWindow = url => window.open(url, '_blank')
</script>

<style lang="less" scoped>
.news-detail {
  height: 100%;
  overflow-y: auto;
  &::-webkit-scrollbar {
    width: 5px;
    height: 6px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(31, 31, 31, 0.2);
    border-radius: 3px;
    box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.05);
  }
}
.detail-wrapper {
  line-height: 22px;
  color: rgba(0, 0, 0, 0.65);
  font-size: 14px;
}
.title {
  font-size: 20px;
  font-weight: 600;
  line-height: 28px;
}
.tips {
  margin: 16px 0;
}
.source-logo {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 0.5px solid rgba(0, 0, 0, 0.06);
  overflow: hidden;
  margin-right: 8px;
  object-fit: contain;
  vertical-align: bottom;
}
.create-date {
  color: rgba(0, 0, 0, 0.45);
  margin: 0 16px;
}
.overview {
  padding: 16px;
  background: #f5f6f6;
  line-height: 26px;
  color: rgba(0, 0, 0, 0.45);
  margin-bottom: 24px;
}
</style>
