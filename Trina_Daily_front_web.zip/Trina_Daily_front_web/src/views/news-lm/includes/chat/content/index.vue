<template>
  <div class="content-container" ref="chatContainerRef">
    <!-- <div class="upload-main" v-if="pageStatus !== 'noSources'">
      <NesLmUpload style="width: auto">
        <template #default="{ showModal }">
          <a-button @click="showModal">
            <template #icon>
              <cloud-upload-outlined />
            </template>
            上传资源</a-button
          >
        </template>
      </NesLmUpload>
      添加一个资源开启对话
    </div> -->
    <div class="chat-empty">
      <div class="chat-empty-main">
        <div class="chat-empty-main-icon">🤔</div>
        <div class="chat-empty-main-title">简单的问候</div>
        <div class="chat-empty-main-selection">
          选中了{{ selectedNewsSources.length }}/{{ newsSources.length }}个要闻
        </div>
        <div class="chat-empty-main-description">根据您选中的要闻，开启您新全新的会话吧</div>
        <div class="chat-emput-main-btn">
          <a-button> <PlusOutlined />添加笔记</a-button>
        </div>
      </div>
    </div>
    <div v-if="history && history.length > 0 && !isInit" class="chat-main" @click="handleClick">
      <ContentChat v-for="(item, index) in history" :key="index" :row="item" :is-loading="isLoading"></ContentChat>
    </div>
    <!-- <div v-html="result" class="chat-main" @click="handleClick"></div> -->
  </div>
</template>

<script lang="ts" setup>
import NesLmUpload from '../../upload/index.vue'
import { useNewsLmStore } from '@/stores/news-lm'
import getMarkdown from './getMarkdown'
import ContentChat from './includes/ContentChat.vue'
import throttle from 'lodash.throttle'

const newsLmStore = useNewsLmStore()
const { newsSources, selectedNewsSources, isInit } = storeToRefs(newsLmStore)

const props = withDefaults(defineProps<{ history: any[]; isLoading: boolean }>(), {
  history: () => [],
  isLoading: false,
})
defineOptions({ name: 'NewsLmChatContent' })

const hasContent = ref(false)
// noSources | empty |  hasBody
const pageStatus = computed(() => {
  if (hasContent.value) return 'hasBody'
  if (newsSources.value.length === 0) return 'noSources'
  return 'empty'
})

const chatContainerRef = ref(null)
const throttleFunction = throttle(() => {
  nextTick(() => {
    chatContainerRef.value.scrollTo(0, chatContainerRef.value.scrollHeight)
  })
}, 200)
watch(
  () => props.history,
  val => {
    throttleFunction()
  },
  {
    immediate: true,
  }
)
</script>

<style lang="less" scoped>
.content-container {
  position: relative;
  flex: 1;
  overflow-y: auto;
  &::-webkit-scrollbar {
    width: 5px;
    height: 6px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(31, 31, 31, 0.2);
    border-radius: 3px;
    box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.05);
  }
  .upload-main {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 8px;
  }
  .chat-empty {
    // position: absolute;
    // left: 5%;
    // top: 20%;
    // height: 100%;
    // display: flex;
    // flex-direction: column;
    // align-items: center;
    // justify-content: center;
    padding-top: 10%;
    padding-left: 5%;
    padding-bottom: 10%;
    .chat-empty-main {
      &-icon {
        font-size: 40px;
      }
      &-title {
        font-size: 32px;
      }
      &-selection {
        font-size: 20px;
      }
      &-description {
        font-size: 16px;
        color: rgba(0, 0, 0, 0.5);
        margin-bottom: 6px;
      }
    }
  }
  .chat-main {
    position: relative;
    padding: 2px;
  }
  // 穿透
  ::v-deep .markdown-custom-note {
    display: inline-flex;
    background: rgba(0, 0, 0, 0.1);
    border-radius: 50%;
    padding: 0 5px;
    justify-content: center;
    align-items: center;
    @height: 14px * 1.5715;
    min-height: @height;
    min-width: @height;
    cursor: pointer;
  }
}
</style>
