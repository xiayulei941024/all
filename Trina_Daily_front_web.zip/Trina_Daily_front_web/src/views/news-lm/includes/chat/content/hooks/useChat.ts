import { EventStreamContentType, fetchEventSource } from '@microsoft/fetch-event-source'
import { message } from 'ant-design-vue'

// type Props = {
//   queryAgentURL?: string;
// };

// type ChatParams = {
//   chatId: string;
//   data?: Record<string, any>;
//   query?: Record<string, string>;
//   onMessage: (message: string) => void;
//   onClose?: () => void;
//   onDone?: () => void;
//   onError?: (content: string, error?: Error) => void;
// };

const useChat = ({ queryAgentURL = '/api/chat-stream' }) => {
  const ctrl = new AbortController()

  onUnmounted(() => {
    ctrl.abort()
  })

  const chat = async ({ data, onOpen, onMessage, onClose, onDone, onError }) => {
    if (!data?.query) {
      message.warning('请输入你的问题')
      return
    }

    const params = {
      ...data,
    }

    try {
      await fetchEventSource(`${queryAgentURL}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
        signal: ctrl.signal,
        openWhenHidden: false,
        async onopen(response) {
          if (response.ok && response.headers.get('content-type')?.startsWith(EventStreamContentType)) {
            onOpen?.()
            return
          }
        },
        onclose() {
          ctrl.abort()
          onClose?.()
        },
        onerror(err) {
          throw new Error(err)
        },
        onmessage: event => {
          // console.log(event)
          let message = event.data
          message = message.replaceAll('\\n', '\n')
          // message = message.replaceAll('\n\n', '\n')

          console.log(message)
          if (message === '[DONE]') {
            // 暂时没有 [DONE]
            onDone?.()
          } else if (message?.startsWith('[ERROR]')) {
            // 暂时没有 [ERROR]
            onError?.(message?.replace('[ERROR]', ''))
          } else {
            onMessage?.(message)
          }
        },
      })
    } catch (err) {
      ctrl.abort()
      onError?.('我们碰到了一些问题,请重试...', err)
    }
  }

  return chat
}

export default useChat
