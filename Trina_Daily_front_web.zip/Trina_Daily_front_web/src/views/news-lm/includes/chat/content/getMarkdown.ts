import { Marked } from 'marked'

import { markedHighlight } from 'marked-highlight'

import hljs from 'highlight.js'
import 'highlight.js/styles/github-dark.css'

import markedFootnote from 'marked-footnote'
import type { INote } from '@/views/news-lm/types'

function useMarkdown(props, setNewsNoteWeakMap) {
  const markdownLoading = ref(false)
  onMounted(() => {
    markdownLoading.value = true
  })
  const result = ref('')
  const noteData = new Map<number, INote>()
  // console.log(markdownStr)
  const md = new Marked()

  // 原有规则 :::id=1&documentId=2&start=33&end=41
  const rule1 = {
    name: 'oldRule',
    level: 'inline', // Is this a block-level or inline-level tokenizer?
    start(src) {
      // console.log('start', src)
      return src.match(/:::/)?.index
    }, // Hint to Marked.js to stop and check for a match
    tokenizer(src, tokens) {
      // const rule = /^:([^:\n]+):([^:\n]*)(?:\n|$)/ // Regex for the complete token, anchor to string start
      const rule = /^:::id=(\d+)&documentId=(\d+)&start=(\d+)&end=(\d+)/ // Regex for the complete token, anchor to string start
      const match = rule.exec(src) // 匹配<NewsMd /> // const rule2 = /<NewsMd/ // const match2 = rule2.exec(src) // console.log(tokens) // if (match2) { //   console.log('match2', match2) //   return { //     // Token to generate //     type: 'description', // Should match "name" above //     raw: 'news', // Text to consume from the source //     // id: 1, //     // dt: this.lexer.inlineTokens('123'), // Additional custom properties, including //     // dd: this.lexer.inlineTokens('123'), //   any further-nested inline tokens //   } // }

      if (match) {
        console.log('match', match)
        return {
          // Token to generate
          type: 'oldRule', // Should match "name" above
          raw: match[0], // Text to consume from the source
          id: this.lexer.inlineTokens(match[1]), // Additional custom properties, including
          documentId: this.lexer.inlineTokens(match[2]), //   any further-nested inline tokens
          start: this.lexer.inlineTokens(match[3]), //   any further-nested inline tokens
          end: this.lexer.inlineTokens(match[4]), //   any further-nested inline tokens
        }
      }
    },
    renderer(token) {
      const { id, documentId, start, end } = token
      console.log(token)
      return `
        <div
          class="markdown-custom-note"
          id="${this.parser.parseInline(id)}"
          document-id="${this.parser.parseInline(documentId)}"
          start="${this.parser.parseInline(start)}"
          end="${this.parser.parseInline(end)}"
        >
          ${this.parser.parseInline(id)}
        </div>
      ` // return `\n<dt>${this.parser.parseInline(token.dt)}</dt><dd>${this.parser.parseInline(token.dd)}</dd>`
    },
    childTokens: ['id', 'documentId', 'start', 'end'], // Any child tokens to be visited by walkTokens
  }

  // 首标记匹配
  const rule2 = {
    name: 'first_footer_note',
    level: 'inline', // Is this a block-level or inline-level tokenizer?
    start(src) {
      // console.log('start', src)
      return src.match(/^\[\^\d+\]/)?.index
    }, // Hint to Marked.js to stop and check for a match
    tokenizer(src, tokens) {
      const startRule = /^\[\^([^\]]+)\](?!:)/

      const startMatch = startRule.exec(src)
      if (startMatch) {
        console.log('匹配到首标记了', startMatch)
        return {
          // Token to generate
          type: 'first_footer_note', // Should match "name" above
          raw: startMatch[0], // Text to consume from the source
          id: this.lexer.inlineTokens(startMatch[1]),
        }
      }
    },
    renderer(token) {
      const { id } = token // console.log(token)
      // return `你好`
      const _id = this.parser.parseInline(id) * 1
      console.log(_id, noteData, 123131)
      if (!noteData.has(_id)) {
        return ``
      }
      return `
        <span
          class="markdown-custom-note"
          id="${_id}"
        >
          ${_id}
        </span>
      ` // return `\n<dt>${this.parser.parseInline(token.dt)}</dt><dd>${this.parser.parseInline(token.dd)}</dd>`
    },
    childTokens: ['id'], // Any child tokens to be visited by walkTokens
  }
  // 尾标记匹配 - 暂时用不上
  const rule3 = {
    name: 'footer_note_inline',
    level: 'inline', // Is this a block-level or inline-level tokenizer?
    start(src) {
      // console.log('start', src)
      return src.match(/^\[\^\d+\]/)?.index
    }, // Hint to Marked.js to stop and check for a match
    tokenizer(src, tokens) {
      const endRule = /^\[\^([^\]]+)\]:\s{1}(.*)/

      const endMatch = endRule.exec(src)
      if (endMatch) {
        // console.log('匹配到详情了', endMatch)
        return {
          // Token to generate
          type: 'footer_note_inline', // Should match "name" above
          raw: endMatch[0], // Text to consume from the source
        }
      }
    },
    renderer(token) {
      return ``
    },
  }
  // 未完成标记匹配
  const rule4 = {
    name: 'no_footer_note',
    level: 'inline', // Is this a block-level or inline-level tokenizer?
    start(src) {
      // console.log('start', src)
      return src.match(/^\[/)?.index
    }, // Hint to Marked.js to stop and check for a match
    tokenizer(src, tokens) {
      const rule = /^\[\^{0,1}\d*$/

      const match = rule.exec(src)
      if (match) {
        console.log('匹配到未完成标记了', match)
        return {
          // Token to generate
          type: 'no_footer_note', // Should match "name" above
          raw: match[0], // Text to consume from the source
        }
      }
    },
    renderer(token) {
      // const { isEnd } = token
      // console.log(token)
      // if (isEnd) return token.raw
      // return `匹配到`
      return `` // return `\n<dt>${this.parser.parseInline(token.dt)}</dt><dd>${this.parser.parseInline(token.dd)}</dd>`
    }, // childTokens: ['id', 'documentId'], // Any child tokens to be visited by walkTokens
  }
  // 尾标记匹配
  const rule5 = {
    name: 'last_footer_note',
    level: 'block', // Is this a block-level or inline-level tokenizer?
    start(src) {
      // console.log('start', src)
      return src.match(/^参/)?.index
    }, // Hint to Marked.js to stop and check for a match
    tokenizer(src, tokens) {
      const rule = /^(参考来源：[\s\S]*|参考来源：|参考来源|参考来|参考|参)$/

      // console.log(src)
      const match = rule.exec(src)
      if (match) {
        console.log('匹配到尾标记了', match)

        return {
          // Token to generate
          type: 'last_footer_note', // Should match "name" above
          raw: match[0], // Text to consume from the source
        }
      }
    },
    renderer(token) {
      return ``
    },
  }

  const renderer = new md.Renderer() // renderer.html = function (html) { //   console.log('html', html) //   if (html.raw.startsWith('<NewsMd')) { //     // 这里可以自定义渲染逻辑 //     return `<div class="news-md-container">123</div>` //   } //   // 对其他 HTML 元素使用默认渲染 //   return html.raw //   // return `<div class="news-md-container">${html}</div>` // } // 重写 `link` 方法来处理脚注 // renderer.paragraph = text => { //   console.log(text) //   return 123 //   // 正则表达式匹配脚注 //   const footnotePattern = /\[\^([^\]]+)\](?=\s*$)/g //   text = text.replace(footnotePattern, (match, id) => { //     return `<sup id="fnref:${id}"><a href="#fn:${id}" class="footnote-ref">${id}</a></sup>` //   }) //   return 12312321 // }
  function walkTokens(token) {
    // Post-processing on the completed token tree
    // console.log(token)
    // 数据传输完毕 - 准备最后一次解析前
    if (!props.isLoading) {
      // 创建一个promise的任务集
      const promiseList = []
      if (token.type == 'last_footer_note') {
        console.log(token, 'token1')
        const reg = /\[\^(\d+)\]:\s\[\[(\d+),(\d+),(\d+)\]\]+/g

        const matchs: RegExpStringIterator<RegExpMatchArray> = token.raw.matchAll(reg)

        matchs.forEach((item: RegExpMatchArray) => {
          const [_, id, newsId, start, end] = item
          // console.log('item', id, newsId, start, end)
          const note = {
            newsId: Number(newsId),
            start: Number(start),
            end: Number(end),
          }
          noteData.set(Number(id), note)
          promiseList.push(setNewsNoteWeakMap.bind(undefined, note))
          // setNewsNoteWeakMap(note)
        })
      }
      if (token.type == 'first_footer_note') {
        console.log(token, 'token2')
      }
      if (token.type == 'no_footer_note') {
        // token.text = '2'
        console.log(token, 'token3')
        token.isEnd = true
      } // if (token.type === 'strong') { //   token.text += ' walked'; //   token.tokens = this.Lexer.lexInline(token.text) // }

      // 完成所有promise任务
      Promise.all(promiseList.map(item => item())).then(() => {
        markdownLoading.value = false
      })
    }
  }
  md.setOptions({
    renderer: renderer,
    gfm: true,
    tables: true,
    breaks: true, // 启用换行符处理
    pedantic: false,
    sanitize: false,
    smartLists: true,
    smartypants: true,
  })
    .use(
      markedHighlight({
        emptyLangClass: 'hljs',
        langPrefix: 'hljs language-',
        highlight(code, lang, info) {
          const language = hljs.getLanguage(lang) ? lang : 'plaintext'
          return hljs.highlight(code, { language }).value
        },
      })
    )
    .use({
      extensions: [
        // rule3,
        rule4,
        rule2,
        rule5,
      ],
      walkTokens,
    }) //
  // .use(markedFootnote())

  // md配置完成之后执行watch
  watchEffect(() => {
    result.value = md.parse(props.row.content)
  })
  return {
    result,
    noteData,
    markdownLoading,
  }
}

export default useMarkdown
