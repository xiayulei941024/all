<template>
  <div class="news-md">
    <div class="left">
      <user-outlined v-if="row.role == 'user'" />
      <UsbOutlined v-else />
    </div>
    <div class="middle">：</div>
    <div v-if="row.role == 'user'" class="right" v-text="row.content"></div>
    <!-- eslint-disable-next-line -->
    <div v-else class="right" v-html="result" @click="handleClick"></div>
  </div>

  <a-popover v-model:visible="visible" trigger="click">
    <template v-if="visible" #title>
      <div v-if="!markdownLoading" style="font-size: 16px">{{ detail?.title }}</div>
    </template>
    <template v-if="visible" #content>
      <div v-if="markdownLoading">加载中</div>
      <!-- <div v-else>新闻内容</div> -->
      <MarkedToHtml v-else :text="markContent" style="max-width: 30vw" />
    </template>
    <div v-if="visible" :style="btnStyle"></div>
  </a-popover>
</template>

<script setup lang="ts">
import getMarkdown from '../getMarkdown'
import { useNewsLmStore } from '@/stores/news-lm'
import { message } from 'ant-design-vue'

const newsLmStore = useNewsLmStore()
const { setCurrentNote, setNewsNoteWeakMap, closeNewsShow } = newsLmStore

const detail = computed(() => newsLmStore.currentNews)

const markContent = computed(() => {
  const markContent = detail?.value?.markContent || ''
  if (newsLmStore.currentNote) {
    const { start, end } = newsLmStore.currentNote

    const middleText = markContent.slice(start, end)

    // console.log(middleText)

    return `<div style="background: #eadef9">${middleText}</div>`
  } else {
    return '暂无内容'
  }
})
defineOptions({ name: 'ContentChat' })

const props = withDefaults(defineProps<{ row: any; isLoading: boolean }>(), {
  row: () => ({}),
  isLoading: false,
})

const visible = ref(false)
const btnStyle = ref({})

// const result = computed(() => {
//   // console.log(props.row, props.row.content)
//   // console.log(props.row.content)
//   const { result: _result } = getMarkdown(props.row.content)
//   return _result
// })
const { result, noteData, markdownLoading } = getMarkdown(props, setNewsNoteWeakMap)

// console.log(markdown, markdown.result.value)

watch(visible, val => {
  if (!val) {
    btnStyle.value = {
      position: 'absolute',
      cursor: 'pointer',
      width: 0,
      height: 0,
      left: '-1000px',
      top: '-1000px',
    }
    setCurrentNote(null)
    // closeNewsShow()
  }
})
function handleClick(e) {
  if (markdownLoading.value) return
  const target = e.target
  if (!target.classList.contains('markdown-custom-note')) return
  btnStyle.value = Object.assign(btnStyle.value, {
    position: 'absolute',
    cursor: 'pointer',
    width: target.clientWidth + 'px',
    height: target.clientHeight + 'px',
    left: target.offsetLeft + 'px',
    top: target.offsetTop + 'px',
    // background: 'red',
  })

  const id = target.getAttribute('id')

  const currentData = noteData.get(Number(id))
  // 决定展示与隐藏
  let bol = false
  if (currentData) {
    // 查找当前新闻
    bol = setCurrentNote(currentData)
  }
  console.log(bol)
  if (bol) {
    visible.value = bol
  } else {
    message.error('新闻池中不存在该新闻')
  }
}
</script>

<style lang="less" scoped>
.news-md {
  padding: 20px;
  background: #fff;
  border-radius: 4px;
  box-shadow: 0 2px 4px 2px rgba(0, 0, 0, 0.08);
  margin-bottom: 16px;
  display: flex;
  .right :deep {
    p {
      margin-bottom: 0;
    }
    img {
      max-width: 100%;
    }
  }
}
</style>
