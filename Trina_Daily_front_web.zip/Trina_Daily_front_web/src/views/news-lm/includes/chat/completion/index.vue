<template>
  <div class="completion-container">
    <div class="body">
      <a-textarea
        :value="props.inputValue"
        class="textarea"
        placeholder="请输入内容"
        size="large"
        :auto-size="{
          minRows: 3,
          maxRows: 4,
        }"
        @press-enter="handleKeyDown"
        @change="handleChange"
      >
      </a-textarea>
    </div>
    <div class="footer">
      <div class="footer-btn" @click="handleSubmit">
        <LoadingOutlined v-if="isLoading" />
        <send-outlined v-else />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useNewsLmStore } from '@/stores/news-lm'

defineOptions({ name: 'NewsLmChatCompletion' })

const newsLmStore = useNewsLmStore()
const { selectedNewsSources } = storeToRefs(newsLmStore)

const props = defineProps<{
  inputValue: string
  isLoading: boolean
}>()
const emits = defineEmits<{
  (e: 'submit'): void
  (e: 'update:inputValue'): void
  // (e: 'update:isLoading', bol: boolean): void
}>()

function setInputValue(value: string) {
  emits('update:inputValue', value)
}
function handleChange(e: InputEvent) {
  const _value = e.target.value
  // 输入并且正在加载中，去掉最后一个回车符
  if (_value.length > props.inputValue.length) {
    if (_value.endsWith('\n')) {
      // newText = newText.slice(0, -1);
      setInputValue(_value.slice(0, -1))
      return
    }
  }
  setInputValue(_value)
  // if (typeof props.maxLength === 'number') {
  //   setInputValue(_value.substring(0, maxLength))
  // }
}
function handleKeyDown(e) {
  if (!props.inputValue.trim()) return
  if (e.keyCode === 13) {
    if (e.shiftKey) {
      // loading的时候 需要手动加换行
      if (props.isLoading) {
        setInputValue(props.inputValue + '\n')
      }
      return
    }
    handleSubmit()
  }
}

function handleSubmit() {
  // if (!selectedNewsSources || selectedNewsSources.length === 0) return;
  if (props.isLoading) return
  emits('submit')
  setInputValue('')
}
</script>

<style lang="less" scoped>
.completion-container {
  flex: 0 0 auto;
  border: 0.5px solid rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  transition: all 0.3s, height 0s;
  &:focus-within {
    border-color: @primary-color;
  }
  .textarea {
    border: none;
    outline: none;
    box-shadow: none;
    border-radius: 8px;
  }
  .footer {
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    .footer-btn {
      width: 40px;
      height: 40px;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      &:hover {
        color: @primary-color;
      }
    }
  }
}
</style>
