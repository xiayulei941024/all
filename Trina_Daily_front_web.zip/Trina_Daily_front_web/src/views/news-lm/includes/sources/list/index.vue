<template>
  <div class="sources-list">
    <div class="header" v-if="hasNewsSource">
      <div class="header-title">选择全部要闻</div>
      <a-checkbox :checked="checkAll" :indeterminate="indeterminate" @update:checked="handleCheckAll"></a-checkbox>
    </div>
    <div class="tips" v-else>请从左侧选择一些新闻</div>
    <div class="list">
      <div class="item" v-for="item in newsSourcesList" :key="item.id" @click="setCurrentNews(item)">
        <a-popover trigger="hover">
          <template #content>
            <!-- <a-popconfirm title="确定移除此要闻吗？" @confirm="setNewsSources(Actions.REMOVE, item)"> -->
            <a-button type="text" @click="setNewsSources(Actions.REMOVE, item)">
              <template #icon>
                <DeleteOutlined />
              </template>
              删除要闻
            </a-button>
            <!-- </a-popconfirm> -->
          </template>
          <a-button type="text" class="item-icon" shape="circle" @click.stop>
            <template #icon>
              <MoreOutlined style="font-size: 24px" />
            </template>
          </a-button>
        </a-popover>
        <a-tooltip>
          <template #title>{{ item.title }}</template>
          <div class="item-title">{{ item.title }}</div>
        </a-tooltip>
        <a-checkbox
          @click.stop=""
          :checked="selectedNewsSources.includes(item.id)"
          @update:checked="bol => setSelectedNewsSources(bol ? Actions.ADD : Actions.REMOVE, item.id)"
        ></a-checkbox>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { storeToRefs } from 'pinia'
import { Actions, useNewsLmStore } from '@/stores/news-lm'

defineOptions({ name: 'NewsLmSourcesList' })

const newsLmStore = useNewsLmStore()
const { setSelectedNewsSources, setCurrentNews, setNewsSources } = newsLmStore
const { newsSourcesList, selectedNewsSources } = storeToRefs(newsLmStore)

// const checkAll = ref(false)

// watch(checkAll, val => {
//   console.log(123)
//   // newsSourcesList.value.forEach(item => {
//   //   item.checked = val
//   // })
// })
// 是否选择了要闻
const hasNewsSource = computed(() => {
  return newsSourcesList.value.length > 0
})

const checkAll = computed(() => {
  return selectedNewsSources.value.length === newsSourcesList.value.length
})

const indeterminate = computed(() => {
  return selectedNewsSources.value.length > 0 && selectedNewsSources.value.length < newsSourcesList.value.length
})

function handleCheckAll(bol) {
  setSelectedNewsSources(bol ? Actions.ADD_ALL : Actions.REMOVE_ALL)
}

function handleClick() {
  newsSourcesList.value.forEach(item => {
    console.log(item.checked)
  })
}
</script>

<style lang="less" scoped>
.sources-list {
  display: flex;
  flex-direction: column;
  height: 100%;
  .header {
    display: flex;
    justify-content: space-between;
    border-bottom: 0.5px solid rgba(0, 0, 0, 0.06);
    margin-left: 24px;
    padding-right: 10px;
    .header-title {
      font-size: 18px;
      font-weight: bold;
    }
  }
  .tips {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    padding-bottom: 50%;
  }
  .list {
    flex: 1;
    overflow: scroll;
    padding-left: 24px;
    &::-webkit-scrollbar {
      width: 5px;
      height: 6px;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(31, 31, 31, 0.2);
      border-radius: 3px;
      box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.05);
    }
    .item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      padding: 8px 5px 8px 0;
      font-size: 18px;
      position: relative;
      cursor: pointer;
      &:hover {
        padding-left: 20px;
        background: rgba(0, 0, 0, 0.018);
        transition: all 0.3s;
        .item-icon {
          left: -16px;
        }
      }
      .item-icon {
        position: absolute;
        left: -56px;
        top: 50%;
        transform: translateY(-50%);
        width: 50px;
        height: 50px;
      }
      .item-title {
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-right: 4px;
      }
    }
  }
}
</style>
