<template>
  <div class="sources-history">
    <div class="tips" v-if="showMap.length === 0">暂无历史会话</div>
    <div v-else class="list">
      <div
        class="item"
        :class="{
          active: currentHistoryId == key,
        }"
        v-for="(item, index) in showMap"
        :key="item.sessionId"
        @click="setCurrentHistoryId(item.sessionId)"
      >
        <!-- <a-popover trigger="hover">
          <template #content>
            <a-popconfirm title="确定移除此会话吗？" @confirm="handleRemove(key)">
              <a-button type="text">
                <template #icon>
                  <DeleteOutlined />
                </template>
                删除会话
              </a-button>
            </a-popconfirm>
          </template>
          <a-button type="text" class="item-icon" shape="circle">
            <template #icon>
              <MoreOutlined style="font-size: 24px" />
            </template>
          </a-button>
        </a-popover> -->
        <!-- <MarkedToHtml class="item-title" :text="value[1].content" /> -->
        <!-- <div
          class="item-title"
          v-text="
            DOMPurify.sanitize(
              marked
                .parse(
                  value[0].content
                    .trim()
                    .slice(0, 20)
                    .replace(/^[\u200B\u200C\u200D\u200E\u200F\uFEFF]/, '')
                    .replace(/\u002D/g, '')
                )
                .replace(/<\/?[^>]+(>|$)/g, '')
            )
          "
        ></div> -->
        <div class="item-title">
          {{ item.sessionName }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useNewsLmStore } from '@/stores/news-lm'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
defineOptions({ name: 'NewsLmSourcesHistory' })

const newsLmStore = useNewsLmStore()
const { removeHistorySession, setCurrentHistoryId } = newsLmStore
const { historySessions, currentHistoryId } = storeToRefs(newsLmStore)

const showMap = computed(() => {
  // const map = new Map()
  // historySessions.value
  //   .sort((a, b) => {
  //     // 排序一下
  //     const timeA = new Date(a.recentTime).getTime()
  //     const timeB = new Date(b.recentTime).getTime()
  //     return timeB - timeA
  //   })
  //   .forEach(item => {
  //     if (item.histories && item.histories.length >= 2) {
  //       map.set(item.sessionId, item.histories)
  //     }
  //   })
  // return map

  return historySessions.value.sort((a, b) => {
    // 排序一下
    const timeA = new Date(a.recentTime).getTime()
    const timeB = new Date(b.recentTime).getTime()
    return timeB - timeA
  })
})

function handleRemove(key) {
  removeHistorySession(key)
}
</script>

<style lang="less" scoped>
.sources-history {
  display: flex;
  flex-direction: column;
  height: 100%;
  .tips {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    padding-bottom: 50%;
  }
  .list {
    height: 100%;
    overflow-y: scroll;
    // padding-left: 24px;
    padding-left: 5px;
    &::-webkit-scrollbar {
      width: 5px;
      height: 6px;
    }

    &::-webkit-scrollbar-thumb {
      background: rgba(31, 31, 31, 0.2);
      border-radius: 3px;
      box-shadow: inset 0 0 5px rgba(255, 255, 255, 0.05);
    }
    .item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      padding: 8px 5px 8px 0;
      position: relative;
      cursor: pointer;
      &:hover,
      &.active {
        padding-left: 20px;
        background: rgba(0, 0, 0, 0.018);
        transition: all 0.3s;
        .item-icon {
          left: -16px;
        }
      }
      .item-icon {
        position: absolute;
        left: -56px;
        top: 50%;
        transform: translateY(-50%);
        width: 50px;
        height: 50px;
      }
      .item-title {
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-right: 4px;
        font-size: 18px;
        :deep p {
          margin-bottom: 0;
        }
      }
    }
  }
}
</style>
