export interface INewsDetail {
  id: number
  abstractReal: string // 摘要
  explainContent: string // ai解读
  markContent: string // 内容
  title: string
}

export interface INote {
  newsId: number
  start: number
  end: number
}

export interface ISession {
  sessionId: string
  sessionRecordList: ISessionItem[]
  histories: IHistory[]
  newsIdList: number[]
  sessionName: string
  recentTime: string
}
export interface ISessionItem {
  sessionId: string
  fullContent: string
  askUserId: string
  askUserName: string
  newsIds: string
  answerUserId: string
  answerUserName: string
  questionContent: string
  answerContent: string
  referenceId: string
}

export interface IHistory {
  role: string
  content: string
}
