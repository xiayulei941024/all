import MultiTab from './MultiTab'

export default MultiTab
