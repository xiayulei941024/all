<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-02 10:47:26
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-12-15 15:45:42
 * @Description: 报告配置
-->
<template>
  <gl-form ref="form" :model="reportForm" label-width="81px" label-position="right">
    <gl-form-item label="一级品种" name="firstBreed" class="gl-form-item">
      <div class="radio-wrap">
        <gl-radio-group v-model:value="reportForm.firstBreed">
          <gl-radio v-for="(item, index) in firstBreedOption" :value="item" :key="index">{{
            item
          }}</gl-radio>
        </gl-radio-group>
      </div>
    </gl-form-item>
    <gl-form-item label="报告类型" name="reportType" class="gl-form-item">
      <gl-checkbox-group v-model:value="checkList" @change="handleChange">
        <gl-checkbox v-for="item in reportOptions" :value="item" :key="item">{{
          item
        }}</gl-checkbox>
      </gl-checkbox-group>
    </gl-form-item>
    <gl-form-item label="关键词" name="keywords" class="gl-form-item tag-item">
      <keywords-tag v-model:form="reportForm" />
    </gl-form-item>
    <gl-form-item label="展示条数" name="showNum" class="gl-form-item">
      <gl-input-number
        v-model:value="reportForm.showNum"
        style="width: 400px"
        controls-position="right"
        :min="1"
        :max="50"
      ></gl-input-number>
    </gl-form-item>
  </gl-form>
</template>
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import KeywordsTag from './keywords-tag.vue'
import api from '../../api/index'
//props
interface Props {
  reportConfig: any
}
const props = withDefaults(defineProps<Props>(), {
  reportConfig: () => {}
})
//emits
// interface Emits {
//   (e: 'update:reportConfig', val: any): void
// }
// const emits = defineEmits<Emits>()
const firstBreedOption = ref(['钢材', '铁矿石', '焦炭', '煤炭', '废钢', '螺纹钢'])
const reportOptions = ref(['日报', '周报', '月报'])
const checkList = computed(() => props.reportConfig.reportType)
const reportForm = computed(() => props.reportConfig)

const handleChange = (val: any) => {
  reportForm.value.reportType = [...val]
}

const getTagList2 = async () => {
  const { res, err } = await api.queryTagList({ type: 2 })
  if (!err) {
    firstBreedOption.value = res.data.map((item: { moduleName: string }) => item.moduleName)
  }
}

onMounted(() => {
  getTagList2()
})
</script>
<style lang="scss" scoped>
:deep(.gl-form-item-label) {
  width: 80px;
}
</style>
