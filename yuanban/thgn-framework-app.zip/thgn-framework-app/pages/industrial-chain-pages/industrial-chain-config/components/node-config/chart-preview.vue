<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-02 09:14:56
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-02 09:48:44
 * @Description: 
-->
<template>
  <div class="image-preview" :style="{ left: leftPosition + 'px' }">
    <img :src="url" alt="" />
  </div>
</template>
<script setup lang="ts">
interface Props {
  url: string
  leftPosition: number
}
defineProps<Props>()
</script>
<style lang="scss" scoped>
.image-preview {
  position: absolute;
  width: 800px;
  height: 400px;
  top: 113px;
  left: 520px;
  z-index: 100000;
  box-shadow: 0px 12px 20px 0px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  background: #fff;
  display: flex;
  img {
    display: block;
    margin: 0 auto;
    max-width: 800px;
    max-height: 400px;
  }
}
</style>
