<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 13:37:22
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 16:23:15
 * @Description: 产业链编辑配置
-->
<template>
  <div class="industrial-chain-modify-wrap">
    <div class="top-button">
      <edit-name
        :name="panoramaName"
        tip="产业链名称不能为空"
        @back="close"
        @sure-edit="sureEdit"
      />
      <div class="right-btn" v-if="type !== 'stainless'">
        <gl-space :size="8">
          <top-bar @drag-end="dragEnd" />
          <gl-button @click="handleCancel()">
            <icon name="icon-unselect_outlined" />
            <span>取消</span>
          </gl-button>
          <gl-button type="primary" @click="handleSave()" :loading="saveLoading">
            <icon name="icon-save" v-if="!saveLoading" />
            <span>保存</span>
          </gl-button>
        </gl-space>
      </div>
      <div class="right-btn" v-else>
        <gl-space :size="8">
          <gl-button @click="handleCancel()">
            <span>返回</span>
          </gl-button>
        </gl-space>
      </div>
    </div>
    <div class="panorama-wrap industrial-chain-wrap">
      <gl-spin :spinning="loading">
        <!-- 不锈钢 -->
        <div class="map-content" v-if="type === 'stainless'" style="margin-top: 0">
          <StainlessMap :mapData="mapData" @showDetails="editNodeInfo" />
        </div>
        <!-- 配置产业链 -->
        <div class="panorama-content" v-else>
          <industrial-flow
            ref="industrialFlowRef"
            @open-node-info-modal="openNodeInfoModal"
            :formInfo="formInfo"
            @edit-node-info="editNodeInfo"
            :defaultNodeList="defaultNodeList"
          />
        </div>
      </gl-spin>
    </div>
    <!-- 节点信息 -->
    <node-info-modal
      v-if="nodeInfoVisible"
      v-model:nodeInfoVisible="nodeInfoVisible"
      @handle-ok="setNodeInfo"
      :formInfo="formInfo"
      :isEditNodeInfo="isEditNodeInfo"
    />
    <!-- 节点配置 -->
    <node-config-full-modal
      v-if="nodeConfigVisible"
      v-model:nodeConfigVisible="nodeConfigVisible"
      :form="nodeConfigForm"
      ref="nodeConfigRef"
      :loading="nodeConfigLoading"
      :curNodeData="curNodeData"
      @sure-node-config="sureNodeConfig"
      @show-node-info="showNodeInfo"
      :type="type"
    />
  </div>
</template>
<script setup lang="ts">
import { ref, computed, createVNode, watch } from 'vue'
import { Icon } from '@mysteel-standard/components'
import EditName from './edit-name.vue'
import industrialFlow from './industrial-flow/index.vue'
import NodeConfigFullModal from './node-config/node-config-full-modal.vue'
import NodeInfoModal from './industrial-flow/node-info-modal.vue'
import useNodeConfig from '../composables/use-node-config'
import useNodeInfo from '../composables/use-node-info'
import api from '../api'
import { message, Modal } from 'gl-design-vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
import TopBar from './industrial-flow/top-bar.vue'
import StainlessMap from '../../industrial-chain/components/stainless-map.vue'
interface Props {
  configVisible: boolean
  configForm: any
  curEditItem: any //当前编辑行数据
  loading: boolean
  type: string
  mapData?: any
}
interface Emits {
  (e: 'update:configVisible', val: boolean): void
  (e: 'sure-modify-config', flowConfig: any): void
  (e: 'sure-edit-name', params: any): void
  (e: 'reload-table'): void
  (e: 'reload-detail', val: any): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  configVisible: false
})
const panoramaName = computed(() => props.curEditItem.panoramagramName)
const visible = computed({
  get() {
    return props.configVisible
  },
  set(val: boolean) {
    emits('update:configVisible', val)
  }
})

const defaultNodeList = ref('')
watch(
  () => props.configForm,
  (val) => {
    if (val.nodeJson !== '') {
      defaultNodeList.value = val.nodeJson
    }
  },
  { deep: true }
)

const saveLoading = ref(false)
const handleSave = async () => {
  const nodeJson = industrialFlowRef.value.getFlowConfig()
  const params = {
    configId: props.curEditItem.id,
    panoramagramName: props.curEditItem.panoramagramName,
    nodeJson: JSON.stringify(nodeJson)
  }
  saveLoading.value = true
  const { res, err } = await api.addOrUpdateNode(params)
  saveLoading.value = false
  if (res && !err) {
    message.success('配置保存成功')
    visible.value = false
    emits('reload-table')
  }
}
const close = () => {
  visible.value = false
}
const sureEdit = (name: string) => {
  const params = {
    id: props.curEditItem.id,
    panoramagramName: name
  }
  emits('sure-edit-name', params)
}

const industrialFlowRef = ref()

//节点配置
const {
  nodeConfigVisible,
  editNode,
  sureNodeConfig,
  nodeConfigForm,
  nodeConfigLoading,
  curNodeData,
  nodeConfigRef
} = useNodeConfig(emits, industrialFlowRef)

const nodeInfo = ref({})
const { nodeInfoVisible, setNodeInfo, formInfo, isEditNodeInfo, addNodeIdList } = useNodeInfo(
  industrialFlowRef,
  nodeInfo,
  curNodeData
)

const showNodeInfo = () => {
  isEditNodeInfo.value = true
  nodeInfoVisible.value = true
}

const openNodeInfoModal = (data: any) => {
  nodeInfo.value = data
  const { id } = data
  formInfo.id = id
  isEditNodeInfo.value = false
  nodeInfoVisible.value = true
}

//编辑节点
const editNodeInfo = (data: any) => {
  if (props.type === 'stainless') {
    const curNodeInfo = {
      configId: props.curEditItem.id,
      nodeId: data.id
    }
    editNode(curNodeInfo)
  } else {
    nodeInfo.value = data
    const { nodeName, nodeIcon, nodeType, fileList } = data.meta
    formInfo.id = data.id
    formInfo.nodeName = nodeName
    formInfo.nodeIcon = nodeIcon
    formInfo.nodeType = nodeType
    formInfo.fileList = fileList
    const curNodeInfo = {
      configId: props.curEditItem.id,
      nodeId: data.id,
      nodeIcon,
      nodeName,
      nodeType,
      fileList
    }
    if (nodeType === 2) {
      isEditNodeInfo.value = true
      nodeInfoVisible.value = true
    } else {
      editNode(curNodeInfo)
    }
  }
}

//移除未保存节点配置信息
const handleCancel = async () => {
  if (props.type === 'stainless') {
    visible.value = false
  } else {
    Modal.confirm({
      title: '提示',
      content: '确定取消？',
      icon: createVNode(ExclamationCircleOutlined),
      centered: true,
      async onOk() {
        if (addNodeIdList.length !== 0) {
          const params = {
            configId: props.configForm.configId,
            nodeIds: addNodeIdList
          }
          await api.deleteNode(params)
        }
        visible.value = false
      }
    })
  }
}

//拖拽节点
const dragEnd = ({ event, type, offsetLeft, offsetTop }: any) => {
  industrialFlowRef.value.dragEnd({ event, type, offsetLeft, offsetTop })
}
</script>
<style lang="scss">
.industrial-chain-modify-wrap {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  margin: 0 auto;
  z-index: 10;
  background: #f0f2f5;
  .top-button {
    background: #fff;
    display: flex;
    height: 64px;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px;
    border-radius: 6px;
    .gl-btn {
      display: flex;
      align-items: center;
    }
  }
  .panorama {
    &-wrap {
      height: calc(100% - 64px);
      margin-top: 16px;
      .gl-spin-nested-loading {
        height: calc(100% - 16px);
      }
      .gl-spin-container {
        height: 100%;
      }
    }
    &-content {
      height: 100%;
      overflow: auto;
      background: #fff;
      border-radius: 6px;
    }
  }
}

.panorama-content {
  overflow: auto;
}
</style>
