<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-01 15:30:14
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-09 19:42:10
 * @Description: 操作按钮
-->
<template>
  <div class="top-bar">
    <span
      class="btn-item"
      :draggable="true"
      @dragstart="onDragStart"
      @dragend="onDragEnd($event, 'node')"
    >
      <icon name="icon-liucheng"></icon>
      节点组件
    </span>
    <span class="btn-item" :draggable="true" @dragend="onDragEnd($event, 'dashed')">
      <icon name="icon-xukuang"></icon> 虚框组件</span
    >
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'

interface Emits {
  (e: 'drag-end', val: any): void
}

const emits = defineEmits<Emits>()

let offsetLeft = 0
let offsetTop = 0

const onDragStart = (event: any) => {
  const { clientX, clientY, currentTarget } = event
  const { top, left } = currentTarget.getBoundingClientRect()
  offsetLeft = clientX - left
  offsetTop = clientY - top
}

function onDragEnd(event: any, type: string) {
  emits('drag-end', { event, type, offsetLeft, offsetTop })
}
</script>
<style scoped lang="scss">
.top-bar {
  text-align: right;
  height: 50px;
  .btn-item {
    display: inline-block;
    width: 112px;
    height: 32px;
    background: #fafafa;
    border-radius: 3px;
    font-size: 14px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: bold;
    color: #333333;
    line-height: 32px;
    text-align: center;
    margin: 10px;
    cursor: pointer;
    span {
      position: relative;
      top: 1px;
    }
    &:hover {
      background: #ebf4ff;

      color: #0149aa;
    }
  }
}
</style>
