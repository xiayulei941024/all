/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-28 14:27:20
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-29 10:51:05
 * @Description:
 */
import { ref } from 'vue'
export default (elId: string) => {
  const checkRef = ref(null)
  const isArrow = ref(false)
  const showMore = ref(false)
  const reset = (content: any) => {
    content.removeAttribute('style')
    isArrow.value = false
    showMore.value = false
  }
  const setShowMore = (itemId: string | null) => {
    const content = document.getElementById(itemId ? itemId : elId)
    if (content) {
      reset(content)
      showMore.value = content.offsetHeight > 33
      if (showMore.value && !isArrow.value) {
        content.style.height = '33px'
      } else {
        content.style.height = 'auto'
      }
    }
  }
  const handleMore = () => {
    isArrow.value = !isArrow.value
    const content = document.getElementById(elId)
    if (content) {
      content.style.height = isArrow.value ? 'auto' : '33px'
    }
  }
  return {
    showMore,
    checkRef,
    isArrow,
    setShowMore,
    handleMore
  }
}
