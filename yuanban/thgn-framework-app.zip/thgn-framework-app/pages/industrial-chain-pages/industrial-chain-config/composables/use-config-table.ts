/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-28 11:53:53
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 16:38:08
 * @Description:
 */
import api from '../api/index'
import { message } from 'gl-design-vue'
import { useResetData } from '@mysteel-standard/hooks'
import { ConfigListType } from '../types/interface'
import { ref, nextTick } from 'vue'
import { cloneDeep } from 'lodash-es'
export default (getList: Function) => {
  const configId = ref(1)

  //新增修改
  const useAddModifyConfig = () => {
    const type = ref('panorama')
    const mapData = ref([])
    //新增
    const addIndustrialChainVisible = ref(false)
    const { dataState: addIndustrialChainForm, resetDataState: industrialChainFormReset } =
      useResetData({
        panoramagramName: ''
      })
    const sureAddIndustrialChain = async (data: { panoramagramName: string }) => {
      const params = {
        panoramagramName: data.panoramagramName
      }
      const { err, res } = await api.addOrUpdateConfig(params)
      if (!err && res) {
        message.success('新增成功！')
        curEditItem.value = {
          panoramagramName: data.panoramagramName,
          id: res.data
        }
        configVisible.value = true
        await getList()
        await getMenuList()
      }
    }
    //编辑
    const configVisible = ref(false)
    const configLoading = ref(false)
    const isAdd = ref(false)
    const curEditItem = ref({})

    const { dataState: configForm, resetDataState: configFormReset } = useResetData({
      id: undefined,
      nodeJson: ''
    })

    const showConfigModal = (type: boolean, data: ConfigListType | undefined) => {
      isAdd.value = type
      if (type) {
        //新增
        addIndustrialChainVisible.value = true
      } else {
        configVisible.value = true
        curEditItem.value = { ...data }
      }
      nextTick(() => {
        initConfigData(data)
      })
    }
    //编辑
    const initConfigData = async (data: ConfigListType | undefined) => {
      configFormReset()
      if (data) {
        configForm.id = data.id
        configId.value = data.id
        getPanoramagramDetail(null)
      }
    }
    //获取配置详情
    const getPanoramagramDetail = async (defaultNodeJson: any) => {
      if (configId.value === 1) {
        type.value = 'stainless'
        configLoading.value = true
        mapData.value = await getIndexParseInfoFun(1, '')
        configLoading.value = false
      } else {
        type.value = 'panorama'
        const params = { configId: configId.value }
        configLoading.value = true
        const { res, err } = await api.getPanoramagramDetail(params)
        configLoading.value = false
        if (!err && res) {
          const data = cloneDeep(res.data)
          const nodeJson = defaultNodeJson !== null ? defaultNodeJson : JSON.parse(data?.nodeJson)
          const nodeList = nodeJson.nodeList
          const indexList = data.indexList
          nodeList.forEach((item: any) => {
            indexList.forEach((ele: any) => {
              if (item.id === ele.nodeId) {
                item.indexList = ele.indexList
              }
            })
          })
          const indexCodes: any = []
          const deriveIndexes: any = []
          nodeList.forEach((item: any) => {
            if (item.indexList?.length > 0) {
              if (item.indexList[0].isDerive) {
                deriveIndexes.push(item.indexList[0].indexCode)
              } else {
                indexCodes.push(item.indexList[0].indexCode)
              }
              item.indexList[0].dataValue = ''
              item.indexList[0].upDown = ''
            } else {
              item.indexList = [{ dataValue: '', upDown: '' }]
            }
          })
          const params = { indexCodes, deriveIndexes }
          const details: any = await getIndexData(params)
          if (details.data && details.data.length > 0) {
            details.data.forEach((item: any) => {
              nodeList.forEach((i: any) => {
                if (i.indexList.length > 0) {
                  if (item.indexCode === i.indexList[0].indexCode) {
                    i.indexList[0].dataValue =
                      item.dataValue || item.dataValue === 0 ? item.dataValue : ''
                    i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
                  }
                  if (item.indexCode === i.indexList[0].formula) {
                    i.indexList[0].dataValue =
                      item.dataValue || item.dataValue === 0 ? item.dataValue : '-'
                    i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : ''
                  }
                }
              })
            })
          }
          data.nodeJson = JSON.stringify(nodeJson)
          //编辑获取详情
          Object.assign(configForm, data)
        }
      }
    }

    const getIndexParseInfoFun = async (configId: number, date: string) => {
      const { res, err } = await api.getIndexParseInfo({ configId })
      if (err) {
        return null
      }
      const indexCodes: any = []
      const deriveIndexes: any = []
      const data = cloneDeep(res.data)
      data.forEach((item: any) => {
        if (item.indexList.length > 0) {
          if (item.indexList[0].isDerive) {
            deriveIndexes.push(item.indexList[0].indexCode)
          } else {
            indexCodes.push(item.indexList[0].indexCode)
          }

          item.indexList[0].dataValue = ''
          item.indexList[0].upDown = ''
        } else {
          item.indexList = [{ dataValue: '', upDown: '' }]
        }
      })

      const params = { indexCodes, deriveIndexes, date }
      const details: any = await getIndexData(params)
      if (details.data && details.data.length > 0) {
        details.data.forEach((item: any) => {
          data.forEach((i: any) => {
            if (i.indexList.length > 0) {
              if (item.indexCode === i.indexList[0].indexCode) {
                i.indexList[0].dataValue =
                  item.dataValue || item.dataValue === 0 ? item.dataValue : '-'
                i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : '-'
              }
              if (item.indexCode === i.indexList[0].formula) {
                i.indexList[0].dataValue =
                  item.dataValue || item.dataValue === 0 ? item.dataValue : '-'
                i.indexList[0].upDown = item.upDown || item.upDown === 0 ? item.upDown : '-'
              }
            }
          })
        })
      }
      return data
    }

    const getIndexData = async (params: any) => {
      const { res, err } = await api.getIndexDataInfos(params)
      if (err) {
        return null
      }
      return res
    }

    const sureEditName = async (params: any) => {
      const { err, res } = await api.addOrUpdateConfig(params)
      if (!err && res) {
        message.success('修改成功')
        getList()
      }
    }

    //获取用户信息
    const getMenuList = async () => {
      const { res } = await api.getMenuList()
      if (res.code === '200') {
        window.sessionStorage.setItem('menuList', JSON.stringify(res.data || []))
      }
    }

    return {
      configForm,
      configVisible,
      curEditItem,
      showConfigModal,
      configLoading,
      sureEditName,
      //新增
      addIndustrialChainVisible,
      addIndustrialChainForm,
      sureAddIndustrialChain,
      getMenuList,
      type,
      mapData,
      getPanoramagramDetail
    }
  }
  //复制
  const copyConfig = async (record: ConfigListType) => {
    const { id, panoramagramName } = record
    const params = {
      id,
      panoramagramName
    }
    const { err, res } = await api.copyConfig(params)
    if (!err && res) {
      message.success('复制成功！')
      getList()
    }
  }
  //拖拽排序
  const changeSort = async (params: any) => {
    const { res, err } = await api.moveConfig(params)
    if (res && !err) {
      message.success('修改序号成功！')
      getList()
    }
  }
  return {
    useAddModifyConfig,
    copyConfig,
    changeSort
  }
}
