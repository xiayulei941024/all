/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-08 15:45:02
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:53:53
 * @Description:
 */
import { cloneDeep } from 'lodash-es'
import { message } from 'gl-design-vue'
import { ref, reactive } from 'vue'
export default (industrialFlowRef: any, nodeInfo: any, curNodeData: any) => {
  //存储操作新增节点id 用户退出移除
  const addNodeIdList: any = []
  //节点编辑标志
  const isEditNodeInfo = ref(false)
  //节点弹窗
  const nodeInfoVisible = ref(false)
  //表格信息
  const formInfo = reactive({
    id: '',
    nodeName: '',
    nodeIcon: '',
    nodeType: 1,
    fileList: []
  })

  const setNodeInfo = () => {
    const { id, nodeName, nodeIcon, nodeType, fileList } = cloneDeep(formInfo)
    //判断重名
    const { nodeList } = industrialFlowRef.value.getFlowConfig()
    if (
      nodeList.some((item: any) => {
        if (item.id !== id) {
          return item.meta.nodeName === nodeName
        }
      })
    ) {
      message.warn('节点名称重复')
      return
    }
    //替换节点内信息
    nodeInfoVisible.value = false
    nodeInfo.value.meta = { nodeName, nodeIcon, nodeType, fileList, nodeId: id, indexList: [] }
    if (!isEditNodeInfo.value) {
      addNodeIdList.push(nodeInfo.value.id)
      industrialFlowRef.value.addFlowNode(nodeInfo.value)
    }
    //配置弹窗修改节点赋值
    curNodeData.value = {
      ...curNodeData.value,
      nodeName,
      nodeIcon,
      nodeType
    }
    //重置表格信息
    formInfo.id = ''
    formInfo.nodeName = ''
    formInfo.nodeIcon = ''
    formInfo.nodeType = 1
    formInfo.fileList = []
    isEditNodeInfo.value = false
  }
  return {
    nodeInfoVisible,
    setNodeInfo,
    formInfo,
    isEditNodeInfo,
    addNodeIdList
  }
}
