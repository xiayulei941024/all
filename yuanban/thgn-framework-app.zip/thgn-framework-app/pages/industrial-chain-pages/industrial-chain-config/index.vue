<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 16:28:34
 * @Description: 
-->
<template>
  <div class="industrial-chain-config-wrap">
    <div class="search-container">
      <div class="search-form">
        <config-search-form @search="configSearch" />
      </div>
      <div class="table-btn-right">
        <top-button @add-config="() => showConfigModal(true, undefined)" />
      </div>
    </div>
    <div class="table-container">
      <config-table
        :loading="configTableLoading"
        :configTableData="configTableData"
        @delete="deleteConfig"
        @switch-change="switchConfig"
        @copy-config="copyConfig"
        @drag="changeSort"
        @modify-config="(data) => showConfigModal(false, data)"
      />
    </div>
    <div class="pagination" v-if="configPage.total">
      <Pagination v-model:page="configPage" @page-change="configPageChange" />
    </div>
    <!-- 新增产业链 -->
    <add-industrial-chain-modal
      v-if="addIndustrialChainVisible"
      v-model:addIndustrialChainVisible="addIndustrialChainVisible"
      :form="addIndustrialChainForm"
      @sure-add-industrial-chain="sureAddIndustrialChain"
    />
    <!-- 编辑产业链 -->
    <modify-industrial-chain
      v-if="configVisible"
      :loading="configLoading"
      :configForm="configForm"
      v-model:configVisible="configVisible"
      :curEditItem="curEditItem"
      @reload-table="getList"
      @sure-edit-name="sureEditName"
      :type="type"
      :mapData="mapData"
      @reload-detail="getPanoramagramDetail"
    />
  </div>
</template>
<script setup lang="ts">
import { Pagination } from '@mysteel-standard/components'
import { useTableData } from '@mysteel-standard/hooks'
import api from './api/index'
import configSearchForm from './components/config-search-form.vue'
import TopButton from './components/top-button.vue'
import configTable from './components/config-table.vue'
import ModifyIndustrialChain from './components/modify-industrial-chain.vue'
import AddIndustrialChainModal from './components/add-industrial-chain-modal.vue'
import useConfigTable from './composables/use-config-table'
import { ref } from 'vue'
//表格复用逻辑
const {
  getList,
  handlePageChange: configPageChange,
  handleSearch: configSearch,
  tableData: configTableData,
  tableLoading: configTableLoading,
  page: configPage,
  switchChange,
  handleDelete
} = useTableData({
  tableApi: api.getConfigList,
  switchApi: api.enableConfig,
  deleteApi: api.deleteConfig
})

//产业链表格相关逻辑
const { useAddModifyConfig, copyConfig, changeSort } = useConfigTable(getList)

//编辑新增配置
const {
  //编辑
  configForm,
  configVisible,
  curEditItem,
  showConfigModal,
  configLoading,
  sureEditName,
  //新增
  addIndustrialChainVisible,
  addIndustrialChainForm,
  sureAddIndustrialChain,
  getMenuList,
  getPanoramagramDetail,
  type,
  mapData
} = useAddModifyConfig()

const deleteConfig = async (params: any) => {
  await handleDelete(params)
  await getMenuList()
}
const switchConfig = async (params: any) => {
  await switchChange(params)
  await getMenuList()
}
</script>
<style lang="scss" scoped>
@import './style/index.scss';
</style>
