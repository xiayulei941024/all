/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-28 13:49:23
 * @Description:
 */
export * from './industrial-chain'
export * from './industrial-chain-config'
export { default as industrialChainLayout } from './index.vue'
