<template>
  <div
    class="list-item"
    :class="[data.isDefault ? 'is-default' : '', expanded ? 'is-expanded' : '']"
    :style="{ height: expanded ? '590px' : '160px' }"
  >
    <div class="item-title">
      <div class="item-checkbox">
        <gl-checkbox v-model:checked="checked">
          <gl-tooltip :title="data.indexName">
            {{ data.indexName }}
          </gl-tooltip>
        </gl-checkbox>
        <div class="default-tip" v-if="data.isDefault">默认</div>
      </div>
      <gl-button @click="handleExpand">
        {{ expanded ? '收起图表' : '展开图表' }}
        <icon name="icon-up_outlined" />
      </gl-button>
    </div>
    <div class="item-content">
      <gl-row>
        <gl-col :span="8">
          <span class="info-label">数据：</span>
          <span class="info-data">{{ dataFilters(data.dataValue) }}</span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">涨跌：</span>
          <span class="info-data" :class="upDownClass(data.upDown)[0]">
            {{ upDownClass(data.upDown)[1] }}{{ dataFilters(data.upDown) }}
          </span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">频率：</span>
          <span class="info-data">{{ dataFilters(data.frequency) }}</span>
        </gl-col>
      </gl-row>
      <gl-row>
        <gl-col :span="8">
          <span class="info-label">最高：</span>
          <span class="info-data">{{ dataFilters(data.maxData) }}</span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">最低：</span>
          <span class="info-data">{{ dataFilters(data.minData) }}</span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">单位：</span>
          <span class="info-data">{{ dataFilters(data.unit) }}</span>
        </gl-col>
      </gl-row>
      <gl-row>
        <gl-col :span="8">
          <span class="info-label">开始：</span>
          <span class="info-data">{{ dataFilters(data.beginDate) }}</span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">结束：</span>
          <span class="info-data">{{ dataFilters(data.endDate) }}</span>
        </gl-col>
        <gl-col :span="8">
          <span class="info-label">更新：</span>
          <span class="info-data">{{ dataFilters(data.dataDate) }}</span>
        </gl-col>
      </gl-row>
    </div>

    <div style="margin-top: 20px">
      <gl-spin :spinning="chartLoading">
        <ms-chart style="width: 100%; height: 320px" :option="chartOption" />
        <ms-table :columns="tableColumns" :data="tableData" :emptyImg="false"></ms-table>
      </gl-spin>
    </div>
  </div>
</template>
<script setup lang="ts">
import { cloneDeep } from 'lodash-es'
import { useRoute } from 'vue-router'
import { Icon } from '@mysteel-standard/components'
import { dataFilters, upDownClass, indexListOption } from '../../utils/index'
import { _blueTheme, deepClone } from '@mysteel-standard/utils'
import api from '../../api'
import { MsChart, MsTable } from '@mysteel-standard/components'
import { initTableColumns } from '../../types/interface'

interface Props {
  data: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'handle-checked', val: boolean, indexCode: string): void
  (e: 'handle-expand', val: boolean, indexCode: string): void
}
const emits = defineEmits<Emits>()

const checked = computed({
  get() {
    return cloneDeep(props.data.checked)
  },
  set(val) {
    emits('handle-checked', val, props.data.indexCode)
  }
})
const expanded = computed({
  get() {
    return cloneDeep(props.data.expanded)
  },
  set(val) {
    emits('handle-expand', val, props.data.indexCode)
  }
})
const handleExpand = () => {
  expanded.value = !expanded.value
}

const chartLoading = ref(false)
const chartOption = ref({})
const tableColumns = ref(initTableColumns)
const tableData = ref<any[]>([])

const route = useRoute()
const getChartOption = async (indexCodes: string[]) => {
  chartLoading.value = true
  const { res, err } = await api.getIndexChart({ indexCodes })
  chartLoading.value = false
  if (res && !err) {
    const data = res.data.dateList.map((item: any) => item.dataValue)
    const timeX = res.data.dateList.map((item: any) => item.dataDate)
    const chartOptionValue = indexListOption(
      data,
      timeX,
      props.data.indexName,
      props.data.unit,
      props.data.frequency
    )
    chartOption.value = route?.fullPath === '/panorama-screen' ? deepClone(_blueTheme, chartOptionValue) : chartOptionValue
    const list = res.data.dateList.slice(-5).reverse()
    let dataItem: any = { date: '值' }
    let columns = [
      {
        title: '时间',
        dataIndex: 'date',
        key: 'date',
        ellipsis: true,
        width: 90
      }
    ]
    const columnList = list.map((item: any) => {
      dataItem[item.dataDate] = item.dataValue
      return {
        title: item.dataDate,
        dataIndex: item.dataDate,
        key: item.msId,
        ellipsis: true
      }
    })
    columns.push(...columnList)
    tableColumns.value = columns
    tableData.value = [dataItem]
  } else {
    tableColumns.value = initTableColumns
    tableData.value = []
  }
}

watch(
  () => expanded.value,
  (val) => {
    if (val && Object.keys(chartOption.value).length <= 0) {
      getChartOption([props.data.indexCode])
    }
  },
  { immediate: true }
)
</script>
<style lang="scss" scoped>
.list-item {
  padding: 20px 0;
  box-sizing: border-box;
  overflow: hidden;
  transition: 0.3s;
  border-bottom: 1px solid #e8e8e8;

  &.is-default {
    .default-tip {
      width: 40px;
      height: 20px;
      border-radius: 0px 4px 0px 4px;
      margin-left: 8px;
      font-size: 12px;
      // line-height: 20px;
      text-align: center;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(250, 84, 28, 0.1);
      color: #fa541c;
      border: 1px solid #fa541c;
    }
  }
  &.is-expanded {
    .gl-btn .anticon {
      -webkit-transform: rotate(180deg);
      transform: rotate(180deg);
    }
  }

  .item-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;

    .gl-btn .anticon {
      transition: 0.3s;
    }
    .item-checkbox {
      display: flex;
      align-items: center;
      max-width: calc(100% - 120px);
      & .gl-checkbox-wrapper {
        display: flex;
        :deep(:nth-child(2)) {
          max-width: 600px;
          display: flex;
          & > span {
            display: inline-block;
            width: 100%;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
    }
  }

  .item-content {
    font-size: 12px;
    .gl-row {
      margin-top: 16px;
      > .gl-col {
        line-height: 16px;
      }
      &:first-child {
        margin-top: 0;
      }
    }
  }
}
</style>
