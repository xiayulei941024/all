<template>
  <gl-spin :spinning="loading">
    <div class="relevant-news">
      <ul v-if="newsList.length > 0" class="news-list">
        <li v-for="(item, index) in newsList" :key="item.articleId" class="news-list-item">
          <div class="news-main-title" @click="toNewsDetail(item)">
            <!-- <gl-tooltip effect="dark" :title="item.title" placement="top"> -->
              <span class="news-main-title-text" :title="item.title">
                {{ item.title }}
              </span>
            <!-- </gl-tooltip> -->
            <span>{{ timeFilter(item.articleTime) }}</span>
          </div>
          <div
            v-if="item.abstractContent && type === 1 && index === 0"
            class="news-abstract"
            @click="toNewsDetail(item)"
          >
            {{ item.abstractContent }}
          </div>
        </li>
      </ul>
      <div v-else class="nodata">
        <i></i>
        <span>暂无数据</span>
      </div>
      <div class="more-news" @click="toNews" v-if="newsList.length > 0">
        查看更多{{ type === 1 ? '资讯' : '报告' }}
      </div>
    </div>
  </gl-spin>
  <!-- 资讯报告详情弹窗 -->
  <full-modal v-if="newsDetailVisible" v-model:visible="newsDetailVisible" :show-submit="false">
    <news-detail :newsItem="newsItem"></news-detail>
  </full-modal>
</template>

<script lang="ts" setup>
import { onMounted, ref, watch } from 'vue'
import { message } from 'gl-design-vue'
import { useRoute } from 'vue-router'
import moment from 'moment'
import NewsDetail from './newsDetail.vue'
import { FullModal } from '@mysteel-standard/components'
import api from '../../api/index'
import { useRouter } from 'vue-router'
import { useInformation } from '@mysteel-standard/utils/store'
//props
interface Props {
  breed: any
  configId: string
  type: number
}
const props = defineProps<Props>()
//emits
interface Emits {
  (e: 'closeDetails'): void
}
const emits = defineEmits<Emits>()

const newsList: any = ref([])
const loading = ref(false)
const columnName = ref('')

const timeFilter = (n: string) => {
  if (moment(n).year() === moment().year()) {
    return moment(n).format('MM-DD')
  }
  return moment(n).format('YYYY-MM-DD')
}

const router = useRouter()

const toNews = () => {
  emits('closeDetails')
  if (props.type === 1) {
    const store = useInformation()
    store.changeActiveModuleName(columnName.value)
  }
  router.push({
    path: props.type === 1 ? '/home/informationCenter' : '/home/reportCenter',
    query: {
      columnName: columnName.value
    }
  })
}

onMounted(async () => {
  const params = {
    configId: props.configId,
    nodeId: props.breed.nodeId,
    type: props.type
  }
  loading.value = true
  const { res, err } = await api.panoramagramRelevantList(params)
  loading.value = false
  if (res && !err) {
    if (res.data) {
      columnName.value = res.data.columnName
      newsList.value = res.data.dataList || []
    }
  }
})

const route = useRoute()
//展示资讯 报告
const newsDetailVisible = ref(false)
const newsItem = ref({})
const toNewsDetail = (item: any) => {
  if (route?.fullPath === '/panorama-screen') {
    message.warning('暂无权限！')
    return
  }
  newsDetailVisible.value = true
  newsItem.value = item
}
</script>

<style lang="scss" scoped>
.relevant-news {
  height: 100%;
  position: relative;

  .news-list {
    height: calc(100vh - 180px);
    overflow: auto;
    border-bottom: 1px solid #e8e8e8;
    .news-list-item {
      padding: 16px 0;
      font-size: 14px;
      cursor: pointer;

      .news-main-title {
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: relative;
        &:hover {
          color: #023985;
        }
        &-text {
          max-width: calc(100% - 80px);
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          &:hover {
            color: #023985;
          }
          &[title]:hover:after {
            content: attr(title);
            color: #fff;
            padding: 4px 8px;
            position: absolute;
            left: 0;
            top: -160%;
            z-index: 200;
            white-space: nowrap;
            background-color: rgba(37, 39, 42);
          }
        }
      }
      .news-abstract {
        margin-top: 8px;
        cursor: pointer;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
    }
  }

  .nodata {
    height: calc(100% - 40px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: 14px;

    > i {
      display: inline-block;
      height: 172px;
      width: 400px;
    }
  }

  .more-news {
    text-align: center;
    margin-top: 20px;
    height: 20px;
    line-height: 20px;
    font-size: 14px;
    color: #023985;
    cursor: pointer;
  }
}
</style>
