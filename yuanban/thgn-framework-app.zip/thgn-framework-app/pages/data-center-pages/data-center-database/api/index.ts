/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-07 10:01:16
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: any = {
  // 新增目录
  addMenu: {
    method: 'post',
    url: '/database/indexCollect/addCataLog'
  },
  // 编辑目录
  editMenu: {
    method: 'post',
    url: '/database/indexCollect/updateCataLog'
  },
  //删除目录
  deleteMenu: {
    method: 'post',
    url: '/database/indexCollect/delete'
  },
  //收藏的指标树
  getCollectIndexList: {
    method: 'get',
    url: '/database/indexCollect/getCollectIndexList'
  },
  // 拖拽目录或指标
  dragDirectoryOrIndex: {
    method: 'post',
    url: '/database/indexCollect/dragDirectoryOrIndex'
  },
  // 收藏指标
  collectIndexList: {
    method: 'post',
    url: '/database/indexCollect/collectIndexList'
  },
  /* mysteel tree*/
  getCatalogTree: {
    method: 'post',
    url: '/database/datacatalog/getCatalogTree'
  },
  getCatalogNode: {
    method: 'post',
    url: '/database/datacatalog/getCatalogNode'
  },
  //指标搜索列表
  getIndexList: {
    method: 'post',
    url: '/database/es/search'
  },
  //获取指标数据
  getIndexData: {
    method: 'post',
    url: '/database/datacatalog/getIndexData'
  },
  //指标重命名
  updateIndexName: {
    method: 'post',
    url: '/database/datacatalog/updateIndexName'
  },
  // 获取指标详情
  getIndexInfo: {
    method: 'post',
    url: '/database/datacatalog/getIndexInfo'
  },
  // 指标计算衍生公式
  getIndexCalFormula: {
    method: 'post',
    url: '/database/datacatalog/getIndexCalFormula'
  },
  // 数据库工具
  indexDataTools: {
    method: 'post',
    url: '/database/datacatalog/indexDataTools'
  },
  exportIndexData: {
    method: 'post',
    url: '/database/datacatalog/exportIndexData'
  }
}
export default request(apiMap)
