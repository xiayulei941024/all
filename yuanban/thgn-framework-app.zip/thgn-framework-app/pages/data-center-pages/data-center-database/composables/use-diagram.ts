/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-25 20:18:04
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-10-16 15:15:55
 * @Description:
 */

import Vrouter from '@/router'
import { ref, watch, onMounted, Ref } from 'vue'
export default (
  indexTableSelection: any,
  dateForm: any,
  activeTab: Ref,
  getIndexTableData: Function
) => {
  const chartId: Ref = ref(0)
  watch(
    () => Vrouter.currentRoute.value,
    (val) => {
      if (val.query.chartId) {
        indexTableSelection.value = []
        activeTab.value = 2
        chartId.value = parseInt(val.query.chartId as string)
      }
    },
    { immediate: true }
  )
  onMounted(async () => {})
  //图表回显指标
  const extractChartData = (chartData: any) => {
    const { indexCodes, indexData, beginTime, endTime, timeCount, timeType, dateType } = chartData
    const deriveIndexes: any[] = []
    Object.assign(dateForm, {
      date: [beginTime, endTime],
      timeCount,
      timeType,
      dateType
    })
    indexData.map((item: any) => {
      if (item.isDerive === 1) {
        deriveIndexes.push(item.indexCode)
      }
    })
    const indexCodesArr = indexCodes.filter((item: any) => !deriveIndexes.includes(item))
    getIndexTableData(false, true, { indexCodes: indexCodesArr, deriveIndexes }) //添加并提取指标
  }
  return { chartId, extractChartData }
}
