import api from '../../api/index'
import { MysteelDataType, OperationMenuType } from '../../types/interface'
import useTree from '../../hooks/use-tree'
import { ref, watch } from 'vue'
export default (emits: any, props: any) => {
  const treeData = ref([])
  const replaceFields = ref({
    children: 'children',
    title: 'label',
    key: 'id'
  })
  const treeLoading = ref(false)
  //点击展开收起、多选
  const { selectedTreeKeys, selectedTreeNodes, expandedKeys, treeExpand, allCollapse, nodeClick } =
    useTree()
  const getTreeData = async () => {
    treeLoading.value = true
    const { err, res } = await api.getCatalogTree({
      dbType: 1
    })
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      data?.length &&
        data.forEach(
          (item: { isLeaf: boolean; isEnd: number; type: number; hasChildIndex: boolean }) =>
            (item.isLeaf = (!!item.isEnd && !item.hasChildIndex) || item.type === 2)
        )
      treeData.value = data || []
    }
  }

  const onLoadData = (treeNode: any) => {
    const { dataRef } = treeNode
    if (dataRef.type === 2) return
    return new Promise(async (resolve: any) => {
      const params = {
        dbType: 1,
        frameId: Number(dataRef.id)
      }
      const { err, res } = await api.getCatalogNode(params)
      if (!err && res) {
        const { data } = res
        data.forEach(
          (item: any) => (item.isLeaf = (!!item.isEnd && !item.hasChildIndex) || item.type === 2)
        )
        dataRef.children = data || []
        treeData.value = [...treeData.value]
        resolve()
      }
    })
  }
  const collectionData = (item: { label: string }, data: MysteelDataType) => {
    const nodeArray: any[] = [data]
    emits('collect-index', item.label, nodeArray, true)
  }
  //添加、提取指标
  const handleIndex = (item: OperationMenuType, data: MysteelDataType) => {
    emits('extract-or-add-index', selectedTreeNodes.value, item.label === '提取指标')
  }
  const operationMenu: OperationMenuType = {
    添加指标: handleIndex,
    提取指标: handleIndex,
    收藏指标: collectionData,
    全部收起: allCollapse
  }
  const menuClick = (item: { label: string }, data: MysteelDataType) => {
    operationMenu[item.label](item, data)
  }
  const treeMenu = [
    {
      label: '添加指标',
      condition: (data: { type: number }) => data.type === 2,
      handle: menuClick
    },
    {
      label: '提取指标',
      condition: (data: { type: number }) => data.type === 2,
      handle: menuClick
    },
    {
      label: '收藏指标',
      condition: (data: { type: number }) => data.type === 2,
      handle: menuClick
    },
    {
      label: '全部收起',
      handle: menuClick
    }
  ]
  const dbClick = (node: { isLeaf: boolean; type: number; dataRef: Object }) => {
    if (node.type !== 2) {
      return
    }
    selectedTreeNodes.value = []
    selectedTreeKeys.value = []
    emits('db-click-node', [node.dataRef], false, true)
  }

  watch(
    () => props.frameIds,
    (val) => {
      getTreeData()
      expandedKeys.value = val || []
    },
    { immediate: true }
  )
  watch(
    () => props.indexIds,
    (val) => {
      selectedTreeKeys.value = val || []
    },
    { immediate: true }
  )

  return {
    treeData,
    replaceFields,
    selectedTreeKeys,
    expandedKeys,
    treeLoading,
    treeMenu,
    nodeClick,
    menuClick,
    dbClick,
    onLoadData,
    getTreeData,
    treeExpand
  }
}
