/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 16:23:57
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-10 08:18:24
 * @Description:
 */
import api from '../../api/index'
import { message } from 'gl-design-vue'
export default (getTreeData: Function, treeLoading: Ref) => {
  // dropPosition -1是移动到和他平级在他上面    1是移动到和他平级在他下面  0是移动到他下面作为他子集
  const handleDrop = async (info: any) => {
    const { node, dragNode, dropPosition } = info
    const dropKey = node.key
    const dragKey = dragNode.key
    const dropPosArray = node.pos.split('-')
    const dropPos = dropPosition - Number(dropPosArray[dropPosArray.length - 1])
    // console.log(info, dropPos, info.dropToGap)
    let dropType
    let sort
    let targetId = node.pid
    // console.log(node, dragNode)
    // 0是移动到他下面作为他子集
    if (dropPos === 0) {
      // console.log('下面作为他子集')
      targetId = dropKey
      if (node.dataRef.type === 1) {
        dropType = 1
        if (node.children) {
          //有子节点
          sort = node.children[0].sort - 1
        } else {
          sort = 0
        }
      }
    }
    // 1是移动到和他平级在他下面
    if (dropPos === 1) {
      sort = node.sort + 1
      dropType = 2
    }
    //-1是移动到和他平级在他上面
    if (dropPos === -1) {
      sort = node.sort - 1
      dropType = 1
    }
    const params = {
      id: dragKey,
      targetId,
      sort,
      dropType
    }

    treeLoading.value = true
    const { err } = await api.dragDirectoryOrIndex(params)
    treeLoading.value = false
    if (!err) {
      getTreeData()
      message.success('拖拽成功')
    }
  }
  return {
    handleDrop
  }
}
