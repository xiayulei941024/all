<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-16 08:08:31
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-17 10:41:32
 * @Description: 
-->
<template>
  <gl-spin :spinning="loading">
    <vxe-table
      ref="vxeTableRef"
      class="index-table"
      stripe
      height="auto"
      row-id="indexCode"
      auto-resize
      show-overflow
      :data="indexTable"
      :column-config="{ resizable: true }"
      :row-config="{ isHover: true }"
      @checkbox-all="onSelectChange"
      @checkbox-change="onSelectChange"
      :scroll-x="{ enabled: true, gt: 10 }"
      :scroll-y="{ enabled: true, gt: 10 }"
    >
      <template #empty>
        <empty>
          <template v-slot:empty>
            <div class="empty-tip">请从左侧的数据目录中“双击”添加指标至当前区域</div>
          </template>
        </empty>
      </template>
      <vxe-column width="32">
        <template #default>
          <div class="move-icon"><icon name="icon-move_outlined2" /></div>
        </template>
      </vxe-column>
      <vxe-column type="checkbox" width="40"></vxe-column>
      <vxe-column
        v-for="(item, index) in columns"
        :key="index"
        :field="item.dataIndex"
        :title="
          item.dataIndex === 'indexName'
            ? item.title + `  (${tableSelection.length}/${indexTable.length})`
            : item.title
        "
        :min-width="item.width"
        show-header-overflow
        :show-overflow="item.dataIndex === 'indexName' ? false : 'title'"
        show-footer-overflow
      >
        <template v-if="item.dataIndex === 'indexName'" #default="{ row }">
          <div class="text-overflow" :title="row.indexShortName || row.indexName">
            {{ row.indexShortName || row.indexName }}
          </div>
        </template>
        <template v-else-if="item.dataIndex === 'action'" #default="{ row, index }">
          <div class="operation-buttons">
            <gl-space :size="4">
              <gl-button type="text" size="small" @click="handleExtract(row)">
                <template #icon>
                  <icon name="icon-extract_outlined" color="#023985" size="17" />
                </template>
              </gl-button>
              <gl-button type="text" @click="handleDelete(index, row)" size="small">
                <template #icon>
                  <icon name="icon-del" color="#023985" />
                </template>
              </gl-button>
              <gl-dropdown>
                <a shape="circle" class="ant-dropdown-link" @click.prevent>
                  <icon name="icon-more-menu" />
                </a>
                <template #overlay>
                  <gl-menu>
                    <gl-menu-item key="1" @click="handleCopy(row)">复制指标编码</gl-menu-item>
                    <gl-menu-item key="3" @click="handleInvertCheck()">反选</gl-menu-item>
                  </gl-menu>
                </template>
              </gl-dropdown>
            </gl-space>
          </div>
        </template>
        <template v-else #default="{ row }">
          <!-- 衍生指标的指标编码不显示 -->
          {{
            item.dataIndex === 'indexCode' && row.isDerive === 1
              ? row[item.dataIndex]?.includes('$')
                ? '--'
                : row[item.dataIndex] || '--'
              : row[item.dataIndex] || '--'
          }}
        </template>
      </vxe-column>
    </vxe-table>
  </gl-spin>
</template>
<script setup lang="ts">
import { Icon, Empty } from '@mysteel-standard/components'
import Sortable from 'sortablejs'
import { message } from 'gl-design-vue'
import useClipboard from 'vue-clipboard3'
interface Props {
  loading: any
  tableData: any
  tableSelection: any
}
const props = defineProps<Props>()
interface Emits {
  (e: 'update:tableData', val: any[]): void
  (e: 'update:tableSelection', val: any[]): void
  (e: 'select-change', val: any[]): void
  (e: 'invert-check', val: any[]): void
  (e: 'extract', deriveIndexData: any[], extractData: any[]): void
  (e: 'delete-row', index: number, record: any): void
}
const emits = defineEmits<Emits>()
const indexTable = computed({
  get() {
    return props.tableData
  },
  set(val: any[]) {
    emits('update:tableData', val)
  }
})
const selections = computed({
  get() {
    return props.tableSelection
  },
  set(val: any[]) {
    emits('update:tableSelection', val)
  }
})
//列表
const columns = [
  {
    title: '指标名称',
    dataIndex: 'indexName',
    key: 'indexName',
    ellipsis: true,
    width: 150
  },
  {
    title: '单位',
    dataIndex: 'unit',
    key: 'unit',
    width: 60,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '开始日期',
    dataIndex: 'beginDate',
    key: 'beginDate',
    width: 80,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '结束日期',
    dataIndex: 'endDate',
    key: 'endDate',
    width: 80,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '指标编码',
    dataIndex: 'indexCode',
    key: 'indexCode',
    width: 120,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '原始编码',
    dataIndex: 'oldIndexCode',
    key: 'oldIndexCode',
    width: 120,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '来源',
    dataIndex: 'sourceName',
    key: 'sourceName',
    width: 120,
    ellipsis: true,
    align: 'center'
  },
  {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: 120
  }
]

const handleExtract = (record: any) => {
  emits('extract', [], [record])
}
//删除
const handleDelete = (index: number, record: any) => {
  emits('delete-row', index, record)
}
// 使用插件
const { toClipboard } = useClipboard()
// 点击按钮实现复制功能
const handleCopy = async (record: { indexCode: string }) => {
  try {
    // 复制
    await toClipboard(record.indexCode)
    message.success('复制成功')
    // 复制成功
  } catch (e) {
    // 复制失败
  }
}
//反选
const handleInvertCheck = () => {
  indexTable.value.map((item) => {
    vxeTableRef.value?.toggleCheckboxRow(item)
  })
  const records = vxeTableRef.value.getCheckboxRecords()
  emits('invert-check', records)
}

const tableSortable = () => {
  const tbody = document.querySelector('.body--wrapper>.vxe-table--body tbody')
  Sortable.create(tbody, {
    animation: 60,
    handle: '.move-icon',
    onEnd: async ({ newIndex, oldIndex }: { newIndex: number; oldIndex: number }) => {
      const currRow = indexTable.value.splice(oldIndex, 1)[0]
      indexTable.value.splice(newIndex, 0, currRow)
      const newArr: any[] = []
      indexTable.value.forEach((item) => {
        if (selections.value.indexOf(item) !== -1) {
          newArr.push(item)
        }
      })
      selections.value = [...newArr]
    }
  })
}

const vxeTableRef = ref()
const onSelectChange = () => {
  const records = vxeTableRef.value.getCheckboxRecords()
  emits('select-change', records)
}
watch(
  () => props.tableSelection,
  (val) => {
    if (val.length) {
      nextTick(() => {
        vxeTableRef.value?.clearCheckboxRow()
        vxeTableRef.value?.setCheckboxRow(val, true)
      })
    } else {
      vxeTableRef.value?.clearCheckboxRow()
    }
  },
  { deep: true, immediate: true }
)

onMounted(() => {
  tableSortable()
})
</script>
<style lang="scss" scoped>
:deep(.empty-div) {
  padding-top: 0;
  .empty-text {
    margin-top: -20px;
  }
}
.ant-dropdown-link {
  border: 1px solid #023985;
  border-radius: 100%;
  width: 18px;
  height: 18px;
  line-height: 18px;
  display: flex;
  align-items: center;
  margin: 0 4px;
}
.gl-spin-nested-loading {
  height: 100%;
  :deep(.gl-spin-container) {
    height: 100%;
  }
}
.index-table {
  width: 100%;
}
.text-overflow {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
