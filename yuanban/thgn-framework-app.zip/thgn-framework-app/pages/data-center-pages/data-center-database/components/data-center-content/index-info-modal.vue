<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-27 08:17:02
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-12 15:16:25
 * @Description: 
-->
<template>
  <gl-modal v-model:visible="visible" centered :title="visibleTitle" :footer="null">
    <gl-form v-bind="formItemLayout">
      <gl-form-item label="[指标名称]:">
        <span>{{ indexInfoForm.indexName || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[指标编码]:">
        <span>{{ indexInfoForm.indexCode || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[频率]:">
        <span>{{ indexInfoForm.frequency || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[单位]:">
        <span>{{ indexInfoForm.unit || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[起始时间]:">
        <span>{{ indexInfoForm.beginDate || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[结束时间]:">
        <span>{{ indexInfoForm.endDate || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[更新时间]:">
        <span>{{ indexInfoForm.updateDate || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[描述]:">
        <span class="form-detail-dsc">{{ indexInfoForm.description || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[停复发说明]:">
        <span>{{ indexInfoForm.updateStatus || '--' }}</span>
      </gl-form-item>
      <gl-form-item label="[来源]:">
        <span>{{ indexInfoForm.sourceName || '--' }}</span>
      </gl-form-item>
    </gl-form>
    <div style="text-align: center">
      <gl-button type="primary" @click="cancel()"> 知道了 </gl-button>
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
interface Props {
  indexInfoVisible: any
  visibleTitle: any
  indexInfoForm: any
}
interface Emits {
  (e: 'update:indexInfoVisible', val: boolean): void
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 6 }
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 16 }
  }
}
const visible = computed({
  get() {
    return props.indexInfoVisible
  },
  set(val: boolean) {
    emits('update:indexInfoVisible', val)
  }
})
const cancel = () => {
  visible.value = false
}
</script>
<style scoped lang="scss">
.gl-form-item {
  margin-bottom: 4px;
  span {
    color: #aab6ce !important;
  }
}
.form-detail-dsc {
  display: inline-block;
  display: block;
  min-height: 50px;
  background: #efefef;
  border-radius: 7px;
  padding: 0 8px;
  width: 100%;
  box-sizing: border-box;
  white-space: normal;
}
</style>
