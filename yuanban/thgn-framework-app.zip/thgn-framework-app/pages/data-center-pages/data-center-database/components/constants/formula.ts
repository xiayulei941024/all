// 计算公式
export const SCALA_List = [
  {
    id: 0,
    name: '取整'
  },
  {
    id: -1,
    name: '不限制'
  },
  {
    id: 1,
    name: '保留1位'
  },
  {
    id: 2,
    name: '保留2位'
  },
  {
    id: 3,
    name: '保留3位'
  },
  {
    id: 4,
    name: '保留4位'
  }
]
export const TAG_LIST = [
  {
    name: '+',
    colorName: 'color1',
    isFuc: false,
    editName: ' + ',
    sign: true,
    icon: 'plus'
  },
  {
    name: '-',
    colorName: 'color1',
    isFuc: false,
    editName: ' - ',
    sign: true,
    icon: 'minus'
  },
  {
    name: '*',
    colorName: 'color1',
    isFuc: false,
    editName: ' * ',
    sign: true,
    icon: 'multiply'
  },
  {
    name: '/',
    colorName: 'color1',
    isFuc: false,
    editName: ' / ',
    sign: true,
    icon: 'divide'
  },
  {
    name: '(',
    colorName: 'color1',
    isFuc: false,
    editName: '(',
    sign: true,
    icon: 'left-bracket'
  },
  {
    name: ')',
    colorName: 'color1',
    isFuc: false,
    editName: ')',
    sign: true,
    icon: 'right-bracket'
  },
  {
    name: 'ABS',
    nameCN: '绝对值',
    colorName: 'color2',
    isFuc: true,
    editName: 'abs,'
  },
  {
    name: 'Sqrt',
    nameCN: '平方根计算',
    colorName: 'color2',
    isFuc: true,
    mut: false,
    editName: 'sqrt,'
  },
  {
    name: 'Exp',
    nameCN: 'e的x次方',
    colorName: 'color2',
    isFuc: true,
    mut: false,
    editName: 'exp,'
  },
  {
    name: 'Ln',
    nameCN: '自然对数Ln',
    colorName: 'color2',
    isFuc: true,
    mut: false,
    editName: 'ln,'
  },
  {
    name: 'Log10',
    nameCN: '对数函数log',
    colorName: 'color2',
    isFuc: true,
    mut: false,
    editName: 'log10,'
  },
  {
    name: 'Average',
    nameCN: '计算平均值',
    colorName: 'color3',
    isFuc: true,
    mut: true,
    editName: 'mut|avg,'
  },
  {
    name: 'First',
    nameCN: '第一个值',
    colorName: 'color3',
    isFuc: true,
    mut: false,
    editName: 'first,'
  },
  {
    name: 'Last',
    nameCN: '最后一个值',
    colorName: 'color3',
    isFuc: true,
    mut: false,
    editName: 'last,'
  },
  {
    name: 'Max',
    nameCN: '最大值',
    colorName: 'color3',
    isFuc: true,
    mut: true,
    editName: 'mut|max,'
  },
  {
    name: 'Median',
    nameCN: '中位数',
    colorName: 'color3',
    isFuc: true,
    mut: true,
    editName: 'mut|mid,'
  },
  {
    name: 'Min',
    nameCN: '最小值',
    colorName: 'color3',
    isFuc: true,
    mut: true,
    editName: 'mut|min,'
  },
  {
    name: 'Stdev',
    nameCN: '标准偏差',
    colorName: 'color3',
    isFuc: true,
    mut: false,
    editName: 'stdev,'
  },
  {
    name: 'Sum',
    nameCN: '求和',
    colorName: 'color3',
    isFuc: true,
    mut: true,
    editName: 'mut|sum,'
  },
  {
    name: 'Count',
    nameCN: '计数',
    colorName: 'color3',
    isFuc: true,
    mut: false,
    editName: 'count,'
  },
  {
    name: 'Var',
    nameCN: '方差',
    colorName: 'color3',
    isFuc: true,
    mut: false,
    editName: 'var,'
  },
  {
    name: 'Number',
    nameCN: '数值',
    colorName: 'color4',
    isFuc: false,
    isNum: true
  }
]
