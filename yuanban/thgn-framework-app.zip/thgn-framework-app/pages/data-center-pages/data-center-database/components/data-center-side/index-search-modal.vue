<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 10:56:21
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 16:43:12
 * @Description: 
-->
<template>
  <gl-modal v-model:visible="visible" :title="visibleTitle" :footer="null" :width="1200">
    <div class="search-index-wrap">
      <div class="search-container">
        <div class="search-form">
          <gl-form layout="inline" :model="indexQuery">
            <gl-form-item>
              <gl-input
                v-model:value="indexQuery.searchWord"
                placeholder="请输入搜索关键词，多个关键词以空格隔开"
                style="width: 370px"
                allow-clear
                @press-enter="handleSearch"
              ></gl-input>
            </gl-form-item>
            <gl-button type="primary" @click="handleSearch">
              <icon name="icon-search" />
              搜索
            </gl-button>
            <gl-button style="margin: 0 8px" @click="reset">
              <icon name="icon-reset" />
              重置
            </gl-button>
          </gl-form>
        </div>
        <div class="table-btn-right">
          <gl-button
            type="primary"
            @click="handleIndex(true)"
            :disabled="!indexTableSelection.length"
          >
            <icon name="icon-extract_outlined" />
            <span>提取数据</span>
          </gl-button>
          <gl-button
            type="primary"
            @click="handleIndex(false)"
            :disabled="!indexTableSelection.length"
          >
            <icon name="icon-add" />
            <span>添加指标</span>
          </gl-button>
        </div>
      </div>
      <div class="search-filter">
        <div class="chosen flex" v-if="searchWord || chosenTags.length || chosenConditions.length">
          <span>选择条件：</span>
          <div class="chosen-tags flex flex1">
            <div class="item flex-c active" v-if="searchWord">
              {{ searchWord }}
            </div>
            <div class="item active flex-c" v-if="chosenTags.length">
              <template v-for="(item, index) in chosenTags" :key="index">
                {{ item }}
                <icon
                  class="cp"
                  name="icon-unselect_outlined"
                  color="#3f92f3"
                  @click="removeChosenTag(index)"
                />
              </template>
            </div>
            <div class="item active flex-c" v-for="(item, index) in chosenConditions" :key="index">
              <span
                >{{ item.label }}
                <icon
                  class="cp"
                  name="icon-unselect_outlined"
                  color="#3f92f3"
                  @click="removeChosenCondition(item)"
              /></span>
            </div>
          </div>
        </div>
        <search-condition
          v-if="indexQuery.searchWord && tagListData"
          :tagListData="tagListData"
          :keyword="indexQuery.searchWord"
          @query-index="queryIndex"
        />
        <div
          class="conditions flex"
          v-if="indexTableData.length && conditionsList.length && searchWord"
        >
          数据来源：
          <div class="btn" v-for="item in conditionsList" @click="chooseCondition(item)">
            {{ item.label }}
          </div>
        </div>
      </div>
      <div class="table-container">
        <ms-table
          :columns="indexTableColumns"
          :loading="indexTableLoading"
          :data="indexTableData"
          row-key="indexCode"
          :row-selection="{
            onChange: indexSelectChange
          }"
        >
          <template #header="{ column }">
            <span v-if="column.key === 'indexName'">{{
              '指标名称  ' + `(${indexTableSelection.length}/${indexPage.total})`
            }}</span>
          </template>
        </ms-table>
      </div>
      <div class="pagination" v-if="indexPage.total">
        <Pagination v-model:page="indexPage" @page-change="indexPageChange" />
      </div>
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
import api from '../../api/index'
import { MsTable, Icon } from '@mysteel-standard/components'
import { Pagination } from '@mysteel-standard/components'
import { useTableData } from '@mysteel-standard/hooks'
import searchCondition from './search-condition.vue'
import { useResetData } from '@mysteel-standard/hooks'
import { ref, computed } from 'vue'
interface Props {
  indexSearchVisible: boolean
  visibleTitle: string
  searchText: string
}

interface Emits {
  (e: 'update:indexSearchVisible', val: boolean): void
  (e: 'extract-or-add-index', val: any[], isExTract: boolean): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  indexSearchVisible: false,
  visibleTitle: ''
})
const visible = computed({
  get() {
    return props.indexSearchVisible
  },
  set(val: boolean) {
    emits('update:indexSearchVisible', val)
  }
})
const conditions = ref([
  {
    label: '上海钢联',
    value: 1,
    chosen: false
  },
  {
    label: '上海有色',
    value: 2,
    chosen: false
  },
  {
    label: 'InfoLink',
    value: 4,
    chosen: false
  },
  {
    label: '天合光能',
    value: 3,
    chosen: false
  }
])
const conditionsList = computed(() => {
  return conditions.value.filter((item) => !item.chosen)
})
const chosenConditions = ref([])
const indexTableColumns = [
  {
    title: '指标名称',
    dataIndex: 'indexName',
    key: 'indexName',
    ellipsis: true,
    type: 'html',
    width: 400,
    callback: (record: any) => {
      return `<span class="">${record.indexShortName}</span>`
    }
  },
  {
    title: '指标编码',
    dataIndex: 'indexCode',
    key: 'indexCode',
    ellipsis: true,
    width: 100
  },
  {
    title: '开始日期',
    dataIndex: 'beginDate',
    key: 'beginDate',
    width: 100
  },
  {
    title: '结束日期',
    dataIndex: 'endDate',
    key: 'endDate',
    width: 100
  }
]
const searchWord = ref('')
const { dataState: indexQuery, resetDataState: indexQueryReset } = useResetData({
  varietyList: [],
  searchWord: props.searchText,
  cityList: [],
  companyList: [],
  indexList: []
})
//搜索的指标表格
const {
  handlePageChange: indexPageChange,
  handleSearch: indexSearch,
  tableData: indexTableData,
  tableLoading: indexTableLoading,
  page: indexPage,
  allData: tagListData,
  onSelectChange: indexSelectChange,
  tableSelection: indexTableSelection
} = useTableData({
  tableApi: api.getIndexList,
  isInit: false
})

//重置
const reset = () => {
  indexQueryReset()
  searchWord.value = ''
  indexQuery.searchWord = ''
  indexQuery.dataFromList = []
  chosenTags.value = []
  indexPage.total = 0
  chosenConditions.value = []
  conditions.value.forEach((item) => (item.chosen = false))
  // indexTableData.length = 0
  // indexSearch({ dataFromList: [], searchWord: '' })
}

const chosenTags = ref<string[]>([])
const curType = ref('')
const queryIndex = (key: string, val: any[]) => {
  indexQuery[key] = [...val]
  chosenTags.value = [...val]
  curType.value = key
  indexTableSelection.value = []
  indexSearch(indexQuery)
}
//移除标签
const removeChosenTag = (index: number) => {
  chosenTags.value.splice(index, 1)
  indexQuery[curType.value].splice(index, 1)
  indexSearch(indexQuery)
}
//搜索
const handleSearch = () => {
  searchWord.value = indexQuery.searchWord
  indexSearch(indexQuery)
}
//提取数据、添加指标
const handleIndex = (isAdd: boolean) => {
  emits('extract-or-add-index', indexTableSelection.value, isAdd)
  visible.value = false
}

const chooseCondition = (condition: any) => {
  chosenConditions.value.push(condition)
  conditions.value.filter((item) => item.value === condition.value)[0].chosen = true
  indexSearch({
    dataFromList: chosenConditions.value.map((item) => item.value)
  })
}
const removeChosenCondition = (condition: any) => {
  chosenConditions.value = chosenConditions.value.filter((item) => item.value !== condition.value)
  conditions.value.filter((item) => item.value === condition.value)[0].chosen = false
  indexSearch({
    dataFromList: chosenConditions.value.map((item) => item.value)
  })
}
defineExpose({ handleSearch })
</script>
<style scoped lang="scss">
@import '../../style/index-search.scss';
</style>
