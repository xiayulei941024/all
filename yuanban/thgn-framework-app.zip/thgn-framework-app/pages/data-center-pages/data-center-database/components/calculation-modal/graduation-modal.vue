<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-04 18:08:08
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="visibleTitle"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <gl-form :model="form" labelAlign="right" ref="formRef">
      <gl-form-item>
        <gl-radio-group v-model:value="form.fromSmoothing.type">
          <gl-radio :style="radioStyle" value="1">中心移动平均值</gl-radio>
          <gl-form-item label="周期数">
            <gl-input-number
              :min="0"
              :disabled="form.fromSmoothing.type != '1'"
              v-model:value="form.fromSmoothing.cycle"
            />
          </gl-form-item>
          <gl-radio :style="radioStyle" value="2">指数求匀</gl-radio>
          <gl-form-item label="Alpha(0-1)">
            <gl-input-number
              :min="0"
              :max="1"
              :step="0.1"
              :disabled="form.fromSmoothing.type != '2'"
              v-model:value="form.fromSmoothing.index"
            />
          </gl-form-item>
          <gl-radio :style="radioStyle" value="3">移动平均</gl-radio>
          <gl-form-item label="周期数">
            <gl-input-number
              :min="0"
              :disabled="form.fromSmoothing.type != '3'"
              v-model:value="form.fromSmoothing.average"
            />
          </gl-form-item>
          <gl-radio value="3" :disabled="form.fromSmoothing.seasonal">
            季节性调整(对月度和季度指标有效)
          </gl-radio>
        </gl-radio-group>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
interface FromSmoothing {
  type: string
  cycle: string
  index: string
  average: string
  seasonal: boolean
}
interface CalculationForm {
  fromSmoothing: FromSmoothing
}
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: CalculationForm
}
const radioStyle = reactive({
  display: 'flex',
  height: '30px',
  lineHeight: '30px'
})
interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})
const form = computed(() => props.calculationForm)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

const handleOk = () => {
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
<style lang="scss" scoped>
.gl-radio-group {
  flex-direction: column;
}
</style>
