<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-03 11:47:01
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="visibleTitle"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <gl-form :model="form" labelAlign="right" ref="formRef">
      <gl-radio-group v-model:value="form.standardType">
        <gl-form-item>
          <gl-radio :style="radioStyle" :value="1"> 最小值-最大值 </gl-radio>
        </gl-form-item>
        <gl-form-item>
          <gl-form-item label="最小值" name="standardMinValue">
            <gl-input-number v-model:value="form.standardMinValue"></gl-input-number>
          </gl-form-item>
          <gl-form-item label="最大值" name="standardMaxValue">
            <gl-input-number v-model:value="form.standardMaxValue" />
          </gl-form-item>
        </gl-form-item>
        <gl-form-item>
          <gl-radio :style="radioStyle" :value="2"> 平均值,标准差 </gl-radio>
        </gl-form-item>
      </gl-radio-group>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
interface CalculationForm {
  standardMinValue: number | string
  standardMaxValue: number | string
  standardType: number
}
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: CalculationForm
}

interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})
const radioStyle = reactive({
  display: 'flex',
  height: '30px',
  lineHeight: '30px'
})
const form = computed(() => props.calculationForm)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

const handleOk = () => {
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
<style lang="scss" scoped>
.gl-radio-group {
  flex-direction: column;
}
</style>
