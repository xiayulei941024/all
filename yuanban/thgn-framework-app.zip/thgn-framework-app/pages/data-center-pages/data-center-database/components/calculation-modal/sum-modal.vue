<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-06-28 14:14:09
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="visibleTitle"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <gl-form :model="form" labelAlign="right" ref="formRef">
      <gl-form-item>
        <gl-radio-group v-model:value="form.type">
          <gl-radio v-for="(item, i) in typeArr" :value="item.value" :key="item + i">
            {{ item.label }}
          </gl-radio>
        </gl-radio-group>
      </gl-form-item>
      <gl-form-item label="周期数">
        <gl-input-number
          :disabled="form.type === 2 || form.type === 3"
          v-model:value="form.period"
        />
      </gl-form-item>
      <gl-form-item>
        <gl-checkbox v-model:checked="form.checked" :disabled="form.type === 1">
          限于当年
        </gl-checkbox>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
import { enumToArray } from '@mysteel-standard/utils'
interface calculationFormType {
  type: number
  checked: boolean
  period: number
}
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: calculationFormType
}
enum TypeArr {
  滚动求和 = 1,
  累计值 = 2,
  累计平均值 = 3
}
interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: Object): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})

const form = computed(() => props.calculationForm)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})
const typeArr = ref(enumToArray(TypeArr))
const handleOk = () => {
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
