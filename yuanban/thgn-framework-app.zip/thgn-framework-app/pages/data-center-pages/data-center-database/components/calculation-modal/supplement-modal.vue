<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-19 11:04:48
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-15 11:23:46
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="visible"
    centered
    :title="visibleTitle"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <gl-form :model="form" labelAlign="right" ref="formRef">
      <gl-form-item>空白区域数据补充采用</gl-form-item>
      <!-- Todo -->
      <gl-radio-group v-model:value="form.intervalType">
        <gl-form-item>
          <gl-radio :value="1">前一个观察值</gl-radio>
        </gl-form-item>
        <gl-form-item>
          <gl-radio :value="2">前后平均值</gl-radio>
        </gl-form-item>
        <gl-form-item>
          <gl-radio :value="3">后一个观察值</gl-radio>
        </gl-form-item>
      </gl-radio-group>
      <gl-form-item>
        <gl-checkbox v-model:checked="form.ignoreWeekend">忽略周末观察值</gl-checkbox>
      </gl-form-item>
    </gl-form>
  </gl-modal>
</template>
<script setup lang="ts">
interface Props {
  calculationVisible: boolean
  visibleTitle: string
  calculationForm: any
}

interface Emits {
  (e: 'update:calculationVisible', val: boolean): void
  (e: 'submit', form: any): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  calculationVisible: false,
  visibleTitle: ''
})
const form = computed(() => props.calculationForm)
const visible = computed({
  get() {
    return props.calculationVisible
  },
  set(val: boolean) {
    emits('update:calculationVisible', val)
  }
})

const handleOk = () => {
  emits('submit', form.value)
  handleCancel()
}
const handleCancel = () => {
  visible.value = false
}
</script>
