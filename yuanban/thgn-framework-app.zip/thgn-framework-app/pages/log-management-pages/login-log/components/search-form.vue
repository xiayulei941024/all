<template>
  <div class="search-form">
    <gl-form ref="formRef" layout="inline" :model="form">
      <gl-form-item label="日期">
        <gl-range-picker
          v-model:value="form.date"
          format="YYYY-MM-DD"
          value-format="YYYY-MM-DD"
          separator="~"
        />
      </gl-form-item>
      <gl-form-item label="部门">
        <gl-select
          v-model:value="form.department"
          placeholder="全部"
          :options="options"
          style="width: 180px"
        ></gl-select>
      </gl-form-item>
      <gl-button type="primary" @click="search">
        <icon name="icon-search" />
        搜索
      </gl-button>
      <gl-button style="margin: 0 8px" @click="reset">
        <icon name="icon-reset" />
        重置
      </gl-button>
    </gl-form>
    <gl-button type="primary" @click="handleExport">
      <icon name="icon-export2" />
      导出
    </gl-button>
  </div>
</template>
<script setup lang="ts">
import { useResetData } from '@mysteel-standard/hooks'
import { Icon } from '@mysteel-standard/components'
import { Form } from '../types/interface'
import api from '../../api'
import { useDownload } from '@mysteel-standard/hooks'
import dayjs from 'dayjs'

interface Props {
  options: object[]
  searchForm: Form
}
const props = defineProps<Props>()
interface Emits {
  (e: 'search', form: Form): void
}
const emits = defineEmits<Emits>()

const { dataState: form, resetDataState } = useResetData(props.searchForm)
const search = () => {
  emits('search', form)
}
const reset = () => {
  resetDataState()
  emits('search', form)
}

const handleExport = async () => {
  const params = {
    dateFrom: form.date[0],
    dateTo: form.date[1],
    departmentName: form.department
  }
  const config = {
    responseType: 'arraybuffer'
  }
  const { res, err } = await api.exportUserLoginDetail(params, config)
  if (!err && res) {
    console.log(res,'ssss')
    const config = {
      res,
      fileName: `运营数据${dayjs().format("YYYYMMDDHHmmss")}.xls`
    }
    useDownload(config)
  }
}
</script>

<style lang="scss" scoped></style>
