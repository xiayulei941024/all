<template>
  <div class="department-visit">
    <MSTitle title="本月部门访问量" />
    <data-item
      :data="{
        visit: departmentVisitData.visitNumber,
        qoq: departmentVisitData.qoq,
        yoy: departmentVisitData.yoy
      }"
    />
    <ms-chart class="chart" :option="departmentVisitData.option" autoresize />
  </div>
</template>
<script setup lang="ts">
import { MSTitle } from '@mysteel-standard/components'
import { MsChart } from '@mysteel-standard/components'
import DataItem from './data-item.vue'

interface Props {
  departmentVisitData: any
}
const props = defineProps<Props>()
</script>
<style lang="scss" scoped></style>
