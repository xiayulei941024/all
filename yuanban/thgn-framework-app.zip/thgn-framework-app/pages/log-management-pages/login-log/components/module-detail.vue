<template>
  <gl-modal
    v-model:visible="detailVisible"
    :title="title"
    :body-style="{
      height: '380px'
    }"
    width="1225px"
    centered
    destroyOnClose
    :footer="null"
  >
    <div class="detail-wrap">
      <ms-table
        class="table"
        :loading="tableLoading"
        :data="tableData"
        :columns="columns"
        :scroll="{ y: 284 }"
        :pagination="false"
        :rowKey="(record: any) => record.id"
        @handleClick="handleClick"
      ></ms-table>
      <ms-chart class="chart" :loading="chartLoading" :option="option" autoresize />
    </div>
  </gl-modal>
</template>
<script setup lang="ts">
import { MsChart, MsTable } from '@mysteel-standard/components'
import { computed, ref, watch } from 'vue'
import api from '../../api'
import { getNullOption } from '@mysteel-standard/utils'
import { Form } from '../types/interface'

interface Props {
  title: string
  visible: boolean
  tableData: any[]
  tableLoading: boolean
  searchForm: Form
  moduleName: string
}
const props = defineProps<Props>()

interface Emits {
  (e: 'update:visible', val: boolean): void
}
const emits = defineEmits<Emits>()

const detailVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})

const columns = [
  {
    title: '访问人员',
    dataIndex: 'name',
    type: 'textButton',
    align: 'center'
  },
  {
    title: '部门',
    dataIndex: 'department',
    align: 'center',
    type: 'function',
    callback: (record: any) => {
      return record.department || '--'
    }
  },
  {
    title: '访问次数',
    dataIndex: 'visitTimes',
    sorter: (a: any, b: any) => a.visitTimes - b.visitTimes,
    align: 'center'
  },
  {
    title: '停留时长',
    dataIndex: 'stayTime',
    sorter: (a: any, b: any) => a.stayTimeSeconds - b.stayTimeSeconds,
    align: 'center'
  }
]

watch(
  () => props.tableData,
  (val: any[]) => {
    if (val.length > 0) {
      handleClick(val[0])
    } else {
      option.value = getNullOption('line')
    }
  },
  { deep: true }
)

const option = ref({})
const chartLoading = ref(false)

const handleClick = async (record: any) => {
  const params = {
    userName: record.name,
    dateFrom: props.searchForm.date[0],
    dateTo: props.searchForm.date[1]
  }
  chartLoading.value = true
  const { res, err } = await api.getModuleUseDetailTrend(params)
  chartLoading.value = false
  if (res && !err) {
    option.value = {
      color: ['#F69333', '#008AFF'],
      title: {
        text: props.moduleName,
        left: 'center'
      },
      legend: {
        bottom: 12
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'line'
        },
        formatter: (params: any) => {
          const { data: data1, marker: marker1, seriesName: seriesName1, axisValue } = params[0]
          const { data: data2, marker: marker2, seriesName: seriesName2 } = params[1]
          const str = ` <div style="margin: 0px 0 0; line-height: 1">
                          <div style="font-size: 14px; color: #666; font-weight: 400; line-height: 1">${axisValue}</div>
                          <div style="margin: 10px 0 0; line-height: 1">
                            <div style="margin: 0px 0 0; line-height: 1">
                              ${marker1}
                              <span style="font-size: 14px; color: #666; font-weight: 400; margin-left: 2px">
                                ${seriesName1}
                              </span>
                              <span style="float: right; margin-left: 20px; font-size: 14px; color: #666; font-weight: 900">
                                ${data1} <span style="font-weight: 400">次</span>
                              </span>
                              <div style="clear: both"></div>
                            </div>
                            <div style="margin: 10px 0 0; line-height: 1">
                              ${marker2}
                              <span style="font-size: 14px; color: #666; font-weight: 400; margin-left: 2px">
                                ${seriesName2}
                              </span>
                              <span style="float: right; margin-left: 20px; font-size: 14px; color: #666; font-weight: 900">
                                ${data2} <span style="font-weight: 400">min</span>
                              </span>
                              <div style="clear: both"></div>
                            </div>
                            <div style="clear: both"></div>
                          </div>
                        </div>`
          return str
        }
      },
      xAxis: {
        type: 'category',
        axisTick: {
          alignWithLabel: true
        },
        data: res.data.map((item: any) => item.date)
      },
      yAxis: [
        {
          type: 'value',
          axisLine: {
            show: true
          },
          axisTick: {
            show: true
          },
          alignTicks: true,
          position: 'left',
          name: '单位：次'
        },
        {
          type: 'value',
          axisLine: {
            show: true
          },
          axisTick: {
            show: true
          },
          alignTicks: true,
          position: 'right',
          name: '单位：min'
        }
      ],
      series: [
        {
          name: '访问次数',
          symbol: 'circle',
          data: res.data.map((item: any) => item.visitTimes),
          type: 'line',
          smooth: true,
          yAxisIndex: 0
        },
        {
          name: '停留时长',
          symbol: 'circle',
          data: res.data.map((item: any) => item.stayTime),
          type: 'line',
          smooth: true,
          yAxisIndex: 1
        }
      ]
    }
  } else {
    option.value = getNullOption('line')
  }
}
</script>
<style lang="scss" scoped>
.detail-wrap {
  display: flex;
  height: 100%;
  .table {
    width: 55%;
  }
  .chart {
    width: 45%;
  }
}
</style>
