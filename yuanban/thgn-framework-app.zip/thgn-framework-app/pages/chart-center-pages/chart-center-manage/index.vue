<template>
  <gl-spin :spinning="loading">
    <div style="padding: 16px">
      <div class="chart-center-wrap">
        <ChartTree
          @update-loading="updateLoading"
          @get-catalogue-item="getCatalogueItem"
          @handle-search="handleSearch"
        />
        <ManageList
          ref="listDom"
          :select-item="selectItem"
          :search-value="searchValue"
          @update-loading="updateLoading"
        />
      </div>
    </div>
  </gl-spin>
</template>
<script setup lang="ts">
import ChartTree from './components/chart-tree.vue'
import ManageList from './components/manage-list.vue'

const selectItem = ref<any>({})
const loading = ref(false)
const searchValue = ref<string>('')
const listDom = ref()

const updateLoading = (flag: boolean) => {
  loading.value = flag
}

const getCatalogueItem = (item: any) => {
  selectItem.value = item
}
const handleSearch = (str: string, search: boolean) => {
  searchValue.value = str
  nextTick(() => {
    search && listDom.value.reset()
  })
}
</script>
<style lang="scss">
@import './style/index.scss';
</style>
