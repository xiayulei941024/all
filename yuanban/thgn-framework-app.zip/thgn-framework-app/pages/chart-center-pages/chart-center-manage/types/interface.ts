export enum TabList {
  公司图表库 = 1,
  我的图表库 = 2
}

export interface TabItem {
  label: string
  value: number
}

export interface FilterList {
  id: number
  label: string
}

export interface MenuData {
  name: string
  key: number
  disabled: boolean
  permit: boolean
}
