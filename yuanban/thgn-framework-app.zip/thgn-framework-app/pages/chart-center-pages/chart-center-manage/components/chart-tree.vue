<template>
  <div class="chart-tree">
    <div class="tab-group">
      <ms-tabs
        class="tab"
        v-model:value="tabIndex"
        :tabs="tabData"
        @change="(e:any) => tabClick(e)"
      />
    </div>
    <div class="search-box">
      <input-search
        v-model:value="searchValue"
        placeholder="输入关键字"
        @search="searchIndex"
        @change="change"
      />
    </div>
    <div class="tree-wrap">
      <chart-tree
        ref="treeRef"
        :tabItem="tabItem"
        @update-loading="updateLoading"
        @get-catalogue-item="getCatalogueItem"
      />
    </div>
  </div>
</template>
<script setup lang="ts">
import { MsTabs, InputSearch } from '@mysteel-standard/components'
import { ChartTree } from '@mysteel-standard/components-business'
import { TabList, TabItem } from '../types/interface'
import { enumToArray } from '@mysteel-standard/utils'

interface Emits {
  (e: 'get-catalogue-item', val: boolean): void
  (e: 'update-loading', val: boolean): void
  (e: 'handle-search', val: string, search: boolean): void
}
const emits = defineEmits<Emits>()

const treeRef = ref()
const tabData = ref(enumToArray(TabList))
const tabIndex = ref(TabList['公司图表库'])
const tabItem = computed(() => {
  return tabData.value.filter((item: TabItem) => item.value === tabIndex.value)[0]
})
const selectItem = ref<any>({})

const updateLoading = (flag: boolean) => {
  emits('update-loading', flag)
}
// 切换树
const tabClick = (e: { target: { value: number } }) => {
  const { value } = e.target
  nextTick(() => {
    let label = ''
    if (value === 1) {
      label = '公司图表库'
    } else if (value === 2) {
      label = '我的图表库'
    }
    let parent = [{ label: label, id: 0, isLeaf: false, children: [] }]
    treeRef.value.getTree(parent)
  })
}
const getCatalogueItem = (item: any) => {
  selectItem.value = item
  emits('get-catalogue-item', item)
}

onMounted(() => {
  treeRef.value.getTree([{ label: '公司图表库', id: 0, isLeaf: false, children: [] }])
})

//指标搜索弹框
const searchValue = ref<string>('')
const searchIndex = () => {
  emits('handle-search', searchValue.value, true)
}
const change = () => {
  emits('handle-search', searchValue.value, false)
}
</script>
<style lang="scss" scoped>
.gl-spin-nested-loading {
  height: 100%;

  & :deep(> div > .gl-spin) {
    max-height: none;
  }
}
</style>
