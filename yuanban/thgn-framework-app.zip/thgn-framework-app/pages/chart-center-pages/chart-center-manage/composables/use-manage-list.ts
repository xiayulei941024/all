import api from '../api/index'
import { FilterList } from '../types/interface'
import { Modal, message } from 'gl-design-vue'
import { TabList } from '../types/interface'
import { enumToArray } from '@mysteel-standard/utils'
import Vrouter from '@/router'
import { checkPermit } from '@mysteel-standard/hooks'
import { ref, reactive, watch, computed } from 'vue'

export default (props: any, emits: Function) => {
  const tabData = ref(enumToArray(TabList))
  const state = reactive({
    chartList: [],
    loading: false,
    pageNum: 1,
    pageSize: 50,
    total: 0,
    pages: 0,
    busy: false,
    menuKey: 0,
    chartItem: null as any,
    previewVisible: false,
    collectVisible: false,
    showChartObj: { id: 0, label: '全部' },
    showSortObj: { id: 4, label: '按创建时间倒序' },
    treeTitle: '收藏图表',
    tabItem: tabData.value[1],
    previewId: 0
  })
  const latest = computed(() => {
    const num = state.chartList.length % 4 || 4
    let arr = state.chartList.map((v, i) => i)
    arr = arr.slice(-num)
    return arr
  })
  watch(
    () => state.loading,
    (val) => {
      emits('update-loading', val)
    }
  )

  watch(
    () => props.selectItem,
    (val) => {
      if (val && val.id !== undefined) reset()
    },
    { deep: true }
  )

  // 筛选
  const handleFilter = ({
    showChartObj,
    showSortObj
  }: {
    showChartObj: FilterList
    showSortObj: FilterList
  }) => {
    state.showChartObj = showChartObj
    state.showSortObj = showSortObj
    reset()
  }
  //重置
  const reset = () => {
    state.pageNum = 1
    state.chartList = []
    getChartsList()
  }

  const getChartsList = async () => {
    const params = {
      catalogueId: props.selectItem.id,
      queryType: state.showChartObj.id,
      name: props.searchValue,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      sortType: state.showSortObj.id,
      type: props.selectItem.tabValue
    }
    state.busy = true
    state.loading = true
    const { res, err } = await api.queryChartsCatalogueList(params)
    state.loading = false
    if (res && !err) {
      state.chartList = state.chartList.concat(res.data?.list || [])
      state.pageNum = res.data.pageNum
      state.pages = res.data.pages
      if (state.pageNum < state.pages) {
        state.busy = false
      }
    }
  }

  const router = Vrouter
  // 预览
  const handlePreview = async (item: any) => {
    state.previewId = item.id
    nextTick(() => {
      state.previewVisible = true
    })
  }
  // 编辑
  const handleEdit = (item: any) => {
    const permit = checkPermit(['sjzx:sjk']) // 数据库菜单权限
    if (permit) {
      router.push({
        path: '/home/dataCenter/database',
        query: { chartId: item.id, key: Math.floor(Math.random() * 100) }
      })
    } else {
      message.warn('暂无数据库权限，请联系管理员！')
    }
  }
  // 更多操作
  const menuClick = async (item: any, menuKey: number) => {
    state.menuKey = menuKey
    state.chartItem = item

    switch (menuKey) {
      case 1:
        state.treeTitle = '收藏图表'
        state.tabItem = tabData.value[1]
        state.collectVisible = true
        break
      case 2:
        state.treeTitle = '申请至公司图表库'
        state.tabItem = tabData.value[0]
        state.collectVisible = true
        break
      case 3:
        Modal.confirm({
          title: '提示',
          content: '确认移除此图表?',
          async onOk() {
            state.loading = true
            const { res, err } = await api.deleteChart({ chartId: item.id })
            state.loading = false
            if (res && !err) {
              message.success('移除成功！')
              reset()
            }
          }
        })
        break
      case 4:
        state.treeTitle = '移动到'
        if (item.myCreate && checkPermit(['sjzx:tbk:gstbkydd'])) {
          state.tabItem = tabData.value[0]
        } else {
          state.tabItem = tabData.value[1]
        }
        state.collectVisible = true
        break
    }
  }

  const handleSubmit = async (item: any) => {
    if (!item) {
      message.error('请选择目录')
    }
    const params: any = {
      catalogueId: item.id,
      chartId: state.chartItem.id
    }
    switch (state.menuKey) {
      case 1:
        params.type = 1
        api.collectChart(params).then((response: any) => {
          if (response.res && !response.err) {
            message.success(response.res.message)
            state.collectVisible = false
          }
        })

        break
      case 2:
        api.addCompanyChart(params).then((response: any) => {
          if (response.res && !response.err) {
            message.success(response.res.message)
            state.collectVisible = false
            state.chartList.forEach((v: any) => {
              if (v.id === params.chartId) {
                v.approvalStatus = 1
                return
              }
            })
          }
        })

        break
      case 4:
        delete params.chartId
        params.id = state.chartItem.id
        api.moveChart(params).then((response: any) => {
          if (response.res && !response.err) {
            message.success(response.res.message)
            reset()
            state.collectVisible = false
          }
        })

        break
    }
  }

  //编辑名称
  const updateName = async (item: any) => {
    const params = {
      chartId: item.id,
      name: item.name
    }
    state.loading = true
    const { res, err } = await api.updateChart(params)
    state.loading = false
    if (res && !err) {
      message.success(res.message)
      state.chartList.forEach((v: any) => {
        if (v.id === item.id) {
          v.name = item.name
        }
      })
    }
  }
  // 删除
  const handleDel = (id: number) => {
    Modal.confirm({
      title: '提示',
      content: '确认删除此图表?',
      async onOk() {
        state.loading = true
        const { res, err } = await api.deleteChart({ chartId: id })
        state.loading = false
        if (res && !err) {
          message.success('删除成功！')
          // reset()
          const index = state.chartList.findIndex((v: any) => v.id === id)
          if (index !== -1) {
            state.chartList.splice(index, 1)
          }
        }
      }
    })
  }
  // 复制
  const handleCopy = async (id: number) => {
    state.loading = true
    const { res, err } = await api.copyChart({ chartId: id })
    state.loading = false
    if (res && !err) {
      message.success(res.message)
      reset()
    }
  }
  // 取消收藏
  const cancelCollect = async (id: number) => {
    Modal.confirm({
      title: '提示',
      content: '确认取消收藏此图表?',
      async onOk() {
        const params: any = {
          catalogueId: 1,
          chartId: id,
          type: 0
        }
        state.loading = true
        const { res, err } = await api.collectChart(params)
        state.loading = false
        if (res && !err) {
          message.success('取消收藏成功！')
          // reset()
          const index = state.chartList.findIndex((v: any) => v.id === id)
          if (index !== -1) {
            state.chartList.splice(index, 1)
          }
        }
      }
    })
  }

  const listRef = ref()
  const onScroll = () => {
    const scrollTop = listRef.value.scrollTop // 滚动高度
    const clientHeight = listRef.value.clientHeight // 窗口高度
    const scrollHeight = listRef.value.scrollHeight // 真正高度

    if (scrollTop + clientHeight >= scrollHeight) {
      loadMore()
    }
  }
  const loadMore = () => {
    if (state.pageNum >= state.pages) {
      state.busy = true
      return
    }
    state.busy = false
    state.pageNum++
    getChartsList()
  }

  return {
    latest,
    ...toRefs(state),
    handlePreview,
    handleEdit,
    menuClick,
    handleFilter,
    loadMore,
    updateName,
    handleDel,
    handleCopy,
    handleSubmit,
    reset,
    cancelCollect,
    onScroll,
    listRef
  }
}
