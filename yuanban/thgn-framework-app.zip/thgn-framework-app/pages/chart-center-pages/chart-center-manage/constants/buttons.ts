/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-14 19:09:39
 * @Description:
 */
// 按钮权限
export const BUTTON_LIST = [
  {
    name: '申请至公司图表库',
    permit: ['sjzx:tbk:sqzgstbk']
  },
  {
    name: '从公司图表库移除',
    permit: ['sjzx:tbk:cgstbkyc']
  },
  {
    name: '编辑',
    permit: ['sjzx:tbk:gstbkbj']
  },
  {
    name: '删除',
    permit: ['sjzx:tbk:gstbksc']
  },
  {
    name: '移动到',
    permit: ['sjzx:tbk:gstbkydd']
  },
  {
    name: '复制',
    permit: ['sjzx:tbk:gstbkfz']
  },
  {
    name: '删除文件夹',
    permit: ['sjzx:tbk:gstbkmlscwjj']
  },
  {
    name: '编辑文件夹',
    permit: ['sjzx:tbk:gstbkmlbjwjj']
  },
  {
    name: '新建文件夹',
    permit: ['sjzx:tbk:gstbkmlxjwjj']
  }
]

// 公司图表库-目录排序	3-按钮	tbzx:tbk:gstbkmlpx
