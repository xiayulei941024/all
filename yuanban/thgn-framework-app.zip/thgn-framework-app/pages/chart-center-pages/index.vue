<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-17 10:24:53
 * @Description: 
-->

<template>
  <page-layout class="chart-center-index" />
</template>
<script setup lang="ts">
import { PageLayout } from '@mysteel-standard/components'
</script>
<style lang="scss" scoped></style>
