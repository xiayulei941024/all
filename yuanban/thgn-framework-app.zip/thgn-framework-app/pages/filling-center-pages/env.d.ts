/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-06 17:20:49
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}

declare module 'gl-design-vue'
declare module '@mysteel-standard/components'
declare module '@mysteel-standard/hooks'
declare module 'lodash'
declare module 'moment'
declare module 'js-cookie'
