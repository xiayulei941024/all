export * from './custom-model'

export { default as CustomModelPages } from './index.vue'
export { default as PublicModelDetail } from './custom-model/components/public-model-detail.vue'
