export interface searchForm {
  name: string,
  parentBreedName: string,
  breedName: string,
  areaName: string,
  status: string,
  createUserName: string
}
export interface Page {
  total: number
  pageNum: number
  pageSize: number
}
export interface detailForm {
  id:number,
  name: string,
  parentBreedName: string,
  breedName: string,
  areaName: string,
  executeMechanism:number,
  isPublic:number
}