<template>
  <gl-modal
    v-model:visible="detailVisible"
    title="选择模型"
    :maskClosable="false"
    :width="`700px`"
    centered
    :destroyOnClose="true"
    :closable="false"
    @ok="commit"
    @cancel="closed"
  >
    <gl-spin :spinning="state.loading" class="treeDialog">
      <div class="headerArea">
        <ul class="activeModule">
          <li
            class="activeModule-li"
            v-for="(item, index) in state.activeList"
            :key="item.indexCode"
          >
            <gl-tooltip class="item" :title="item.indexName" placement="bottom">
              <span>{{ item.indexName }}</span>
            </gl-tooltip>
            <close-outlined class="remove" @click="removeSelected(item, index)" />
            <!-- <i class="gl-icon-close remove" @click="removeSelected(item, index)"></i> -->
          </li>
        </ul>
      </div>
      <gl-tabs v-model:activeKey="state.activeName">
        <gl-tab-pane key="0" tab="Mysteel数据库">
          <div class="mainTree">
            <gl-tree
              :tree-data="state.mySteelTreeData"
              ref="mySteelTree"
              :fieldNames="state.defaultProps"
              :load-data="loadNode"
              v-model:checkedKeys="state.mySteelTreeIds"
              checkable
              @check="TreeChecked"
            >
            </gl-tree>
          </div>
        </gl-tab-pane>
        <gl-tab-pane key="1" tab="企业数据库">
          <div class="mainTree">
            <gl-tree
              :tree-data="state.companyTreeData"
              ref="companyTree"
              :load-data="loadNode"
              :fieldNames="state.defaultProps"
              v-model:checkedKeys="state.companyTreeIds"
              checkable
              @check="TreeChecked"
            >
            </gl-tree>
          </div>
        </gl-tab-pane>
        <gl-tab-pane key="2" tab="我的收藏">
          <div class="mainTree">
            <gl-tree
              :tree-data="state.collectionTreeData"
              ref="collectionTree"
              :fieldNames="state.defaultProps1"
              v-model:checkedKeys="state.collectTreeIds"
              v-model:expandedKeys="state.collectExpandIds"
              checkable
              @check="TreeChecked"
            >
            </gl-tree>
          </div>
        </gl-tab-pane>
      </gl-tabs>
    </gl-spin>
  </gl-modal>
</template>
<script setup lang="ts">
import { CloseOutlined } from '@ant-design/icons-vue'
import api from '../api/index'
interface Props {
  visible: boolean
}
const props = defineProps<Props>()

const state = reactive({
  loading: false,
  activeList: [],
  defaultProps: {
    children: 'children',
    title: 'label',
    key: 'id'
  },
  defaultProps1: {
    children: 'children',
    title: 'label',
    key: 'id'
  },

  mySteelTreeData: [],
  companyTreeData: [],
  collectionTreeData: [
    {
      moduleType: 1,
      label: '我的收藏',
      type: 1,
      pid: -1,
      id: 0,
      children: null
    }
  ],

  activeName: '0',
  mySteelTreeIds: [],
  companyTreeIds: [],
  collectTreeIds: [],
  mySteelTreeItems: [],
  companyTreeItems: [],
  collectTreeItems: [],
  collectExpandIds: []
})
interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'addCheckedIndex', val: Array<object>): void
}
const emits = defineEmits<Emits>()
const detailVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const mySteelTree = ref<any>(null)
const companyTree = ref<any>(null)
const collectionTree = ref<any>(null)
const commit = () => {
  detailVisible.value = false
  if (state.activeList.length) {
    emits('addCheckedIndex', state.activeList)
  }
}
const closed = () => {
  detailVisible.value = false
  state.activeList = []
}
// 懒加载
const loadNode = async (node: any): Promise<void> => {
  if (node.dataRef.level !== 0) {
    const dbType = state.activeName === '0' ? 0 : 1
    const frameId = node.dataRef.id
    const params = {
      dbType: dbType,
      frameId: frameId,
      frequency: '周度'
    }
    const { res, err } = await api.getCatalogNode(params)

    if (!err) {
      const { data } = res
      if (data.length > 0) {
        nodeDisable(data)
      } else {
        node.dataRef.isLeaf = true
      }

      return new Promise((resolve) => {
        if (node.dataRef.children) {
          resolve()
          return
        }
        setTimeout(() => {
          node.dataRef.children = [...data]
          if (state.activeName === '0') {
            state.mySteelTreeData = [...state.mySteelTreeData]
          } else {
            state.companyTreeData = [...state.companyTreeData]
          }
          resolve()
        }, 1000)
      })
    }
  }
}

// 禁用父节点
const nodeDisable = (dataList: any) => {
  dataList.filter((item: any) => {
    if (!(item.isLeaf && item.type === 2)) {
      item.disabled = true
    }
  })
}
// 查询收藏夹列表接口
const getCollectIndexList = async () => {
  const params = {
    isDirectory: 0,
    frequency: '周度'
  }

  const { res, err } = await api.getCollectIndexList(params)

  if (!err) {
    state.collectionTreeData[0].children = res.data
    state.collectExpandIds = [0]
  }
}
const TreeChecked = (checkedKeys: any, e: any) => {
  const items = e.checkedNodes
    .filter((item: any) => item.isLeaf && item.type === 2)
    .map((item: any) => {
      if (state.activeName === '2') {
        return {
          indexCode: item.indexCode,
          indexName: item.label,
          id: item.id
        }
      } else {
        return {
          indexCode: item.code,
          indexName: item.label,
          id: item.id
        }
      }
    })
  if (state.activeName === '0') {
    state.mySteelTreeItems = items
  }
  if (state.activeName === '1') {
    state.companyTreeItems = items
  }
  if (state.activeName === '2') {
    state.collectTreeItems = items
  }
  checkChange()
}
const checkChange = () => {
  const collectionCodes = state.collectTreeItems.map((item: any) => item.indexCode)
  let mergeArr = state.mySteelTreeItems.concat(state.companyTreeItems)
  mergeArr = mergeArr.filter((item: any) => !collectionCodes.includes(item.indexCode)) // 去重，去掉收藏夹里面的重复数据
  state.activeList = mergeArr.concat(state.collectTreeItems)
}

const removeSelected = (item: any, index: any) => {
  state.activeList.splice(index, 1)
  const mySteelTree = state.mySteelTreeItems.filter((val: any) => val.indexCode === item.indexCode)
  const companyTree = state.companyTreeItems.filter((val: any) => val.indexCode === item.indexCode)
  const collectionTree = state.collectTreeItems.filter(
    (val: any) => val.indexCode === item.indexCode
  )

  if (mySteelTree.length > 0) {
    const items = state.mySteelTreeIds.filter(
      (item: any) => Number(item) !== Number(mySteelTree[0].id)
    )
    state.mySteelTreeIds = items
  }
  if (companyTree.length > 0) {
    const items1 = state.companyTreeIds.filter(
      (item: any) => Number(item) !== Number(companyTree[0].id)
    )
    state.companyTreeIds = items1
  }
  if (collectionTree.length > 0) {
    const items2 = state.collectTreeIds.filter(
      (item: any) => Number(item) !== Number(collectionTree[0].id)
    )
    state.collectTreeIds = items2
  }
}
// 查MySteel询目录树接口
const getMySteelTree = async () => {
  const params = {
    dbType: 0
  }

  const { res, err } = await api.getCatalogTree(params)

  if (!err) {
    state.mySteelTreeData = res.data
  }
}
// 查yf询目录树接口
const getCompanyTree = async () => {
  const params = {
    dbType: 1
  }
  const { res, err } = await api.getCatalogTree(params)

  if (!err) {
    state.companyTreeData = res.data
  }
}

watch(
  () => state.mySteelTreeData,
  (newVal) => {
    nodeDisable(newVal)
  }
)
watch(
  () => state.companyTreeData,
  (newVal) => {
    nodeDisable(newVal)
  }
)
watch(
  () => state.collectionTreeData,
  (newVal) => {
    nodeDisable(newVal)
  }
)

onMounted(() => {
  getCollectIndexList()
  nextTick(() => {
    getMySteelTree()
    getCompanyTree()
  })
})
</script>
<style lang="scss" scoped>
@import '../style/index.scss';
ul li {
  display: inline-block;
}
.mainTree {
  border: 1px solid #e6f7ff;
  height: 40vh;
  overflow: auto;
}
.headerArea {
  ul {
    // max-height: 130px;
    overflow-y: auto;
  }
}

.activeModule {
  .activeModule-li {
    margin: 0px 2px 0 0;
    border: 1px solid #cfd6dc;
    padding: 5px 30px 5px 5px;
    // width: 104px;
    margin-right: 10px;
    height: 28px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    word-break: break-all;

    line-height: 18px;
    border-radius: 4px;
    position: relative;

    background: #e6f7ff;
    border: #91d5ff 1px solid;
    border-radius: 4px;
    color: #3f92f3;
  }

  .remove {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    cursor: pointer;
  }
}

.tree-dialog {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;

  .mainTree {
    height: 40vh;
    overflow: auto;
  }
}
:deep(.gl-tree-treenode-switcher-open .gl-tree-checkbox) {
  display: none;
}
:deep(.gl-tree-treenode-switcher-close .gl-tree-checkbox) {
  display: none;
}
:deep(.gl-tree-checkbox-disabled) {
  display: none;
}
:deep(.gl-tree .gl-tree-treenode-disabled .gl-tree-node-content-wrapper) {
  color: #333;
  cursor: pointer;
}
</style>
