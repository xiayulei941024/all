<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 10:47:18
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-22 11:32:45
 * @Description: 
-->
<template>
  <gl-row type="flex" justify="end">
    <gl-button type="primary" @click="handleAdd()"> <icon name="icon-add" /> 新建分类 </gl-button>
  </gl-row>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'

interface Emit {
  (e: 'add-classification'): void
}
const emits = defineEmits<Emit>()
const handleAdd = () => {
  emits('add-classification')
}
</script>
<style lang="scss" scoped></style>
