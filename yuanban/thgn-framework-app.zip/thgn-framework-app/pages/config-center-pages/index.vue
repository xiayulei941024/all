<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 11:40:45
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-13 19:58:35
 * @Description: 配置中心
-->
<template>
  <page-layout class="config-center-layout" :keepAlive="false" />
</template>
<script setup lang="ts">
import { PageLayout } from '@mysteel-standard/components'
</script>
<style lang="scss" scoped>
.config-center-layout :deep(.view-container) {
  padding: 16px;
}
</style>
