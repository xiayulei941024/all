<!--
 * @Autor: zhouwanwan
 * @Date: 2023-09-01 10:37:41
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-01 11:14:33
 * @Description: 
-->
<template>
  <gl-button type="primary" @click="handleAdd()"> <icon name="icon-add" /> 新增表单 </gl-button>
</template>
<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
interface Emits {
  (e: 'add-form-config'): void
}
const emits = defineEmits<Emits>()
const handleAdd = () => {
  emits('add-form-config')
}
</script>
<style lang="scss" scoped></style>
