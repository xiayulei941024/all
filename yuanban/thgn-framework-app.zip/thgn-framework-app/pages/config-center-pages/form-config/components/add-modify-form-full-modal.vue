<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 13:37:22
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-10-16 14:51:14
 * @Description: 新增编辑表单弹窗
-->
<template>
  <full-modal v-model:visible="visible" @handle-ok="handleSave">
    <gl-spin :spinning="loading">
      <div class="node-config-content">
        <gl-tabs v-model:activeKey="activeKey" :forceRender="true">
          <gl-tab-pane tab="基本设置" :key="1">
            <base-config
              ref="baseConfigRef"
              v-model:form="addModifyForm"
              :typeList="typeList"
              :processesList="processesList"
              :visibleUsers="visibleUsers"
            />
          </gl-tab-pane>
          <gl-tab-pane tab="指标设置" :key="2">
            <index-config
              ref="indexConfigRef"
              v-model:indexCodesConfig="addModifyForm.indexCodesConfig"
              :id="addModifyForm.id"
            />
          </gl-tab-pane>
        </gl-tabs>
      </div>
    </gl-spin>
  </full-modal>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue'
import { FullModal } from '@mysteel-standard/components'
import BaseConfig from './base-config.vue'
import IndexConfig from './index-config.vue'
import { message } from 'gl-design-vue'
import { throttle } from 'lodash-es'
interface Props {
  addModifyFormVisible: boolean
  typeList: any[]
  processesList: any[]
  visibleUsers: any[]
  loading: boolean
  form: any
}
interface Emits {
  (e: 'update:addModifyFormVisible', val: boolean): void
  (e: 'update:form', val: any): void
  (e: 'sure-add-form-config', val: any): void
}
const emits = defineEmits<Emits>()
const props = withDefaults(defineProps<Props>(), {
  addModifyFormVisible: false
})

const visible = computed({
  get() {
    return props.addModifyFormVisible
  },
  set(val: boolean) {
    emits('update:addModifyFormVisible', val)
  }
})
const addModifyForm = computed({
  get() {
    return props.form
  },
  set(val: any) {
    emits('update:form', val)
  }
})
const activeKey = ref(1)

const curUserId = JSON.parse(localStorage.getItem('userInfo') as string).id
const initData = () => {
  addModifyForm.value.typeId = 0
  addModifyForm.value.typeName = '我的表单'
  addModifyForm.value.visibleUsers = curUserId === 1 ? undefined : [curUserId]
}
const baseConfigRef = ref()
const handleSave = throttle(() => {
  baseConfigRef.value
    .isValidate()
    .then(async () => {
      const params = {
        ...addModifyForm.value
      }
      emits('sure-add-form-config', params)
    })
    .catch(() => {
      if (!addModifyForm.value.name) {
        message.warning('表单名称不能为空')
        return
      }
      if (!addModifyForm.value.visibleUsers.length) {
        message.warning('可见人不能为空')
        return
      }
      return false
    })
}, 3000)
defineExpose({ initData })
</script>
<style lang="scss">
.industrial-chain-modify-wrap {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  margin: 0 auto;
  z-index: 10;
  background: #f0f2f5;
  .top-button {
    background: #fff;
    display: flex;
    height: 64px;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px;
    border-radius: 6px;
    .gl-btn {
      display: flex;
      align-items: center;
    }
  }
  .panorama {
    &-warp {
      height: calc(100% - 64px);
      margin-top: 16px;
      .gl-spin-nested-loading {
        height: calc(100% - 16px);
      }
      .gl-spin-container {
        height: 100%;
      }
    }
    &-content {
      height: 100%;
      overflow: auto;
      background: #fff;
      border-radius: 6px;
    }
  }
}

.panorama-content {
  overflow: auto;
}
</style>
