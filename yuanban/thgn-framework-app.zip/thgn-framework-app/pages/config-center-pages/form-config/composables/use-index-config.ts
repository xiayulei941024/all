/*
 * @Autor: zhouwanwan
 * @Date: 2023-09-04 09:00:46
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-09 23:48:39
 * @Description:
 */
import { uniqBy } from 'lodash-es'
import { ref, reactive } from 'vue'
import api from '../api/index'
import { createVNode } from 'vue'
import { Modal } from 'gl-design-vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
export default (formConfigTableData: any, props: any) => {
  const addIndexVisible = ref(false)
  const addIndexTitle = ref('')
  const addIndexLoading = ref(false)
  const tableSelectedKeys = ref([])
  const removeIndex = () => {
    //二次确认提示
    Modal.confirm({
      title: '是否删除?',
      icon: createVNode(ExclamationCircleOutlined),
      onOk: async () => {
        formConfigTableData.value = formConfigTableData.value.filter(
          (item: any) => !tableSelectedKeys.value.includes(item.indexCode)
        )
      }
    })
  }
  const handleMove = (index: number) => {
    formConfigTableData.value.splice(index, 1)
  }
  const addIndex = () => {
    addIndexVisible.value = true
    addIndexTitle.value = '添加指标'
  }
  const sureAddIndex = async (selections: any) => {
    indexConfigTableLoading.value = true
    addIndexLoading.value = true
    const indexCodeList = selections.value.map((item: any) => {
      return item.indexCode
    })
    const params = {
      id: props.id || undefined,
      indexCodeList
    }
    const { res, err } = await api.checkIndexCodeUsed(params)
    addIndexLoading.value = false
    indexConfigTableLoading.value = false
    addIndexVisible.value = false
    if (!err && res) {
      let list = [...formConfigTableData.value, ...selections.value]
      list = uniqBy(list, 'indexCode')
      formConfigTableData.value = [...list]
    }
  }

  const indexConfigTableLoading = ref(false)

  const selectedChange = (val: any[]) => {
    tableSelectedKeys.value = val
  }
  return {
    addIndexVisible,
    addIndexTitle,
    addIndexLoading,
    tableSelectedKeys,
    indexConfigTableLoading,
    addIndex,
    sureAddIndex,
    removeIndex,
    handleMove,
    selectedChange
  }
}
