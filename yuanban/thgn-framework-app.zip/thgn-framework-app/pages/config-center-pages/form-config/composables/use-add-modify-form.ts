/*
 * @Autor: zhouwanwan
 * @Date: 2023-09-04 08:17:50
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-11 15:23:44
 * @Description:
 */
import { ref, onMounted } from 'vue'
import { message } from 'gl-design-vue'
import { useResetData } from '@mysteel-standard/hooks'
import { FormListType } from '../types/interface'
import api from '../api/index'
import { nextTick } from 'vue'
export default (getList: Function) => {
  const addModifyFormLoading = ref(false)
  const addModifyFormVisible = ref(false)
  const typeList = ref([{ label: '我的表单', value: 0 }])
  const processesList = ref([])
  const visibleUsers = ref([])
  const addModifyRef = ref()
  const isEdit = ref(false)

  const { dataState: addModifyForm, resetDataState: resetAddModifyForm } = useResetData({
    name: '',
    typeId: '',
    typeName: '',
    remark: '',
    visibleUsers: [],
    procId: undefined,
    indexCodesConfig: [],
    id: undefined
  })
  //分类
  const getTypeList = async () => {
    const { res, err } = await api.typeList({ type: 1, isEnable: 1 })
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        const newData = data.map((item: any) => {
          return {
            label: item.name,
            value: item.id
          }
        })
        typeList.value = [...typeList.value, ...newData]
      }
    }
  }
  // 审批流
  const getProcesses = async () => {
    const { res, err } = await api.getProcesses({
      applicationModule: 1
    })
    if (!err && res) {
      const { data } = res
      const options =
        data &&
        data.length &&
        data.map((item: any) => {
          return {
            label: item.processName,
            value: item.id
          }
        })
      processesList.value = options || []
    }
  }
  const getVisibleUser = async () => {
    const { res, err } = await api.getAllUser({ isEnable: 1 })
    if (!err && res) {
      const { data } = res
      if (data && data.length) {
        visibleUsers.value = data.map((item: any) => {
          return {
            label: item.userName,
            value: item.id
          }
        })
      }
    }
  }
  const getIndexCodeList = async (detail: any) => {
    const params = {
      configId: detail.id
    }
    const { res, err } = await api.getFormIndexConfig(params)
    if (!err && res) {
      const { data } = res
      detail.indexCodesConfig = data || []
    }
  }
  //编辑表单
  const modifyFormConfig = async (data: any) => {
    const params = {
      id: data?.id
    }
    addModifyFormLoading.value = true
    const { res, err } = await api.getFormConfigDetail(params)
    addModifyFormLoading.value = false
    if (!err && res) {
      const { data } = res
      data.visibleUsers = data.visibleUsers?.split(',').map((item: string) => Number(item))
      if (data.indexCodeList) {
        await getIndexCodeList(data)
      }
      Object.assign(addModifyForm, data || addModifyForm)
    }
  }
  const showConfigModal = async (isAdd: boolean, data: FormListType) => {
    addModifyFormVisible.value = true
    nextTick(() => {
      addModifyRef.value.initData()
    })
    resetAddModifyForm()
    isEdit.value = !isAdd
    if (!isAdd) {
      modifyFormConfig(data)
    }
  }
  onMounted(async () => {
    await getTypeList()
    await getProcesses()
    await getVisibleUser()
  })
  const sureAddFormConfig = async (data: any) => {
    addModifyFormLoading.value = true
    const params = {
      id: data.id || undefined,
      name: data.name,
      typeId: data.typeId,
      remark: data.remark,
      visibleUsers: data.visibleUsers.join(','),
      procId: data.procId,
      indexCodesConfig: data.indexCodesConfig
    }
    const submitApi = isEdit.value ? api.updateFormConfig(params) : api.addFormConfig(params)
    const { res, err } = await submitApi
    addModifyFormLoading.value = false
    addModifyFormVisible.value = false
    if (!err && res) {
      message.success(isEdit.value ? '编辑成功！' : '新增成功！')
      getList()
    }
  }
  return {
    addModifyFormVisible,
    addModifyForm,
    addModifyFormLoading,
    typeList,
    processesList,
    visibleUsers,
    addModifyRef,
    sureAddFormConfig,
    showConfigModal
  }
}
