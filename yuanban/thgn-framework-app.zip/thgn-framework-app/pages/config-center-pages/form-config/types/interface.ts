/*
 * @Autor: zhouwanwan
 * @Date: 2023-09-01 10:56:52
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-01 10:58:32
 * @Description:
 */
export interface FormListType {
  id: number // 表单id	integer
  indexCodeList: string[] // 指标编码集合	array	string
  indexCodesConfig: any[] //	表单指标配置信息	array	FillingConfigIndexVO
  indexCode: string //  指标编码	string
  priority: number //    排序	integer
  isEnable: number //  状态 1启用 0禁用	integer
  name: string //   表单名称	string
  procId: number //审批流id	integer
  remark: string // 说明	string
  typeId: number //表单分类id	integer
  typeName: string // 表单分类中文	string
  updateName: string // 修改人	string
  updateTime: string //  修改时间	string
  visibleUsers: string //可见人id，多个用逗号隔开	string
}
