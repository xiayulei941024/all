<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-07-17 14:03:21
 * @Description: 
-->
<template>
  <gl-spin :spinning="companyTreeLoading">
    <MsTree
      v-model:selectedKeys="companySelectedKeys"
      v-model:expandedKeys="companyExpandedKeys"
      autoExpandParent
      block-node
      disabled-key="isPublish"
      :tree-data="companyData"
      :fieldNames="companyFields"
      :node-menus="companyMenu"
      @select="companyNodeClick"
      @menu-click="companyMenuClick"
      @drop="dropCompanyTree"
      @expand="treeExpand"
    />
    <add-modify-menu-modal
      v-if="addModifyMenuVisible"
      :addModifyMenuForm="addModifyMenuForm"
      v-model:addModifyMenuVisible="addModifyMenuVisible"
      :loading="addModifyMenuLoading"
      :visibleTitle="addModifyMenuTitle"
      @sure-add-modify-menu="sureAddModifyMenu"
    />
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useTree from '../composables/use-tree'
import useTreeMenu from '../composables/use-tree-menu'
import useTreeDrag from '../composables/use-tree-drag'
import AddModifyMenuModal from './add-modify-menu-modal.vue'
import { onMounted } from 'vue'
interface Emits {
  (e: 'choose-node', data: any): void
}
const emits = defineEmits<Emits>()
// 公司数据库树
const {
  treeData: companyData,
  replaceFields: companyFields,
  selectedTreeKeys: companySelectedKeys,
  expandedKeys: companyExpandedKeys,
  getTreeData: getCompanyTree,
  treeLoading: companyTreeLoading,
  nodeClick: companyNodeClick,
  treeExpand
} = useTree(emits)
//树菜单操作
const {
  treeMenu: companyMenu,
  menuClick: companyMenuClick,
  //新增编辑目录
  addModifyMenuTitle,
  addModifyMenuForm,
  addModifyMenuVisible,
  sureAddModifyMenu,
  addModifyMenuLoading
} = useTreeMenu(getCompanyTree, emits)
//树拖拽
const { handleDrop: dropCompanyTree } = useTreeDrag(getCompanyTree, companyTreeLoading)
onMounted(() => {
  getCompanyTree()
})
</script>
