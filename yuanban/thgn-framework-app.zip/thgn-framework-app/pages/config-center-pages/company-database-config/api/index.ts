/*
 * @Autor: zouchuanfeng
 * @Date: 2023-08-22 10:42:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 09:26:11
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap: object = {
  // 新增接口
  getDatabaseTree: {
    method: 'get',
    url: '/database/api/database/config/getFrameworkTree'
  },
  addCatalog: {
    method: 'post',
    url: '/database/api/database/config/saveFrameworkNode'
  },
  updateCatalog: {
    method: 'post',
    url: '/database/api/database/config/editFrameworkNode'
  },
  //删除目录、页面
  deleteCatalog: {
    method: 'post',
    url: '/database/api/database/config/deleteNodeBatch'
  },
  // 启用禁用指标、目录
  enableCatalog: {
    method: 'post',
    url: '/database/api/database/config/enableNode'
  },
  // 拖拽
  dragCatalog: {
    method: 'post',
    url: '/database/api/database/config/changeIndexPriorityOrPid'
  },
  //新增指标
  addIndex: {
    method: 'post',
    url: '/database/api/database/config/saveIndexInfo'
  },
  //查询框架子节点
  getDatabaseList: {
    method: 'post',
    url: '/database/api/database/config/getFrameworkChildren'
  },
  // 查询修改人列表
  getUpdateUserList: {
    method: 'get',
    url: '/database/api/database/config/getUpdateUserList'
  },
  //指标详情
  getIndexDetail: {
    method: 'get',
    url: '/database/api/database/config/getIndexDetail'
  },
  //编辑指标
  editIndexInfo: {
    method: 'post',
    url: '/database/api/database/config/editIndexInfo'
  },
  // 搜索框架指标
  searchIndexInfo: {
    method: 'post',
    url: '/database/api/database/config/searchIndexInfo'
  },
  //移动指标
  moveIndex: {
    method: 'post',
    url: '/database/api/database/config/moveIndexsToNewNode'
  },
  //指标新增模板下载
  downloadTemplate: {
    method: 'get',
    url: '/database/api/database/config/downloadTemplate'
  },
  // 导入框架指标
  importIndexInfo: {
    method: 'post',
    url: '/database/api/database/config/importIndexInfo'
  },
  //导出框架指标
  exportIndexInfo: {
    method: 'get',
    url: '/database/api/database/config/exportIndexInfo'
  },
  //刷新编码
  refreshIndexCode: {
    method: 'get',
    url: '/database/api/database/config/refreshIndexCode'
  },
  //指标来源枚举
  sourceNameList: {
    method: 'get',
    url: '/database/api/database/config/sourceNameList'
  },
  //指标频率枚举
  frequencyList: {
    method: 'get',
    url: '/database/api/database/config/frequencyList'
  },
  //指标频率枚举
  getCategoryList: {
    method: 'get',
    url: '/database/api/database/config/getCategoryList'
  }
}

export default request(apiMap)
