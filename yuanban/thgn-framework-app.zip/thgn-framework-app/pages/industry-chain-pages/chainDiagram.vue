<template>
  <div id="chainContainer">
    <div id="chainDiagram"></div>
    <preview-modal v-model:visible="previewVisible" :previewNode="previewNode" />
  </div>
</template>

<script setup>
import { Rect as RectGeometry, HTML } from '@antv/g'
import { renderToMountedElement, stdlib } from '@antv/g2'
import {
  Badge,
  NodeEvent,
  CommonEvent,
  GraphEvent,
  ExtensionCategory,
  Graph,
  Rect,
  register,
  BaseEdge
} from '@antv/g6'
import nomarlHeader from './assets/nomarlHeader.png'
import yellowHeader from './assets/yellowHeader.png'
import redHeader from './assets/redHeader.png'
import greyHeader from './assets/greyHeader.png'
import arrowUp from './assets/arrowUp.png'
import arrowDown from './assets/arrowDown.png'
import * as echarts from 'echarts'
import PreviewModal from './preview-modal.vue'
import axios from 'axios'
import { message } from 'gl-design-vue'

const emit = defineEmits(['update:loading'])
const props = defineProps({
  loading: Boolean,
  noData: Boolean,
  supplyDemandRatio: Boolean,
  priceFilter: Boolean,
  nodeList: Array
})

let treeGraph = null

const getColor = (alarmLevel, name) => {
  if (name == '背板') {
    return {
      header: 'linear-gradient(90deg, #a6a6a6, #073070)',
      background: 'linear-gradient(90deg, #6A7485, #041E42)',
      headerImg: greyHeader,
      stroke: '#99BBE4'
    }
  } else {
    if (alarmLevel == '1') {
      return {
        header: 'linear-gradient(90deg, #f3c800, #073070);',
        background: 'linear-gradient(90deg, #A28918, #2C2724)',
        headerImg: yellowHeader,
        stroke: '#FFCA28'
      }
    } else if (alarmLevel == '2') {
      return {
        header: 'linear-gradient(90deg, #fa4251, #073070)',
        background: 'linear-gradient(90deg, #AC343E, #2B2724)',
        headerImg: redHeader,
        stroke: '#B93D46'
      }
    } else {
      return {
        header: 'linear-gradient(90deg, #2cadff, #073070)',
        background: 'linear-gradient(90deg, #0B45AE, #041E42)',
        headerImg: nomarlHeader,
        stroke: '#2CADFF'
      }
    }
  }
}

class NodeChart extends Rect {
  getCollapseStyle(attributes) {
    const { name, collapsed } = attributes
    if (name == '光伏玻璃') {
      const [width, height] = this.getSize(attributes)
      return {
        backgroundFill: 'rgba(255,255,255,0.7)',
        backgroundHeight: 40,
        backgroundLineWidth: 1,
        backgroundRadius: '50%',
        backgroundStroke: '#CED4D9',
        backgroundWidth: 40,
        cursor: 'pointer',
        fill: 'rgba(0,0,0,0.5)',
        fontSize: 30,
        fontWeight: 'bold',
        text: collapsed ? '-' : '+',
        textAlign: 'center',
        textBaseline: 'middle',
        zIndex: 2,
        x: -width / 2 - 25,
        y: 0
      }
    } else {
      return false
    }
  }

  drawCollapseShape(attributes, container) {
    const collapseStyle = this.getCollapseStyle(attributes)
    const btn = this.upsert('collapse', Badge, collapseStyle, container)
    if (btn && !Reflect.has(btn, '__bind__')) {
      Reflect.set(btn, '__bind__', true)
      btn.addEventListener(CommonEvent.CLICK, async () => {
        const { collapsed } = this.attributes
        const treeConatiner = document.getElementById('treeConatiner')

        if (collapsed) {
          this.attributes.collapsed = !collapsed
          collapseStyle.text = this.attributes.collapsed ? '-' : '+'
          this.upsert('collapse', Badge, collapseStyle)
          treeConatiner.style.display = 'none'
        } else {
          emit('update:loading', true)
          const { nodesArr } = (await axios.get(`/getTree`)).data

          const { x, y } = attributes
          const [width, height] = this.getSize(attributes)
          const treeConatinerWidth =
            x + document.getElementById('chainContainer').offsetLeft - width / 2 - 80 - 45
          treeConatiner.style.display = 'block'
          treeConatiner.style.width = treeConatinerWidth + 'px'
          treeConatiner.style.height = '1926px'

          const nodes = nodesArr.map((item) => {
            if (item.id == 'boli') {
              item.style = { x: treeConatinerWidth, y: y - 100 }
            }
            return {
              ...item,
              style: {
                size: [450, 200],
                x: item.style?.x || treeConatinerWidth - item.col * (450 + 200),
                y: item.style?.y || y - 100 + (item.row - 1) * (200 + 100),
                innerHTML: `
                      <div class='tree-node'>
                        <div class='tree-node-item'>
                          <div class='title'>${item.name}</div>
                        </div>
                        <div class='tree-node-item'>
                          <div class='name'>成本占比</div>
                          <div class='value'>${item.cost}</div>
                        </div>
                        ${item.price ? "<div class='tree-node-item'><div class='name'>价格</div><div class='value'>" + item.price + '</div></div>' : ''}
                      </div>`
              }
            }
          })

          if (treeGraph) treeGraph.destroy()
          treeGraph = new Graph({
            container: 'treeConatiner',
            width: treeConatinerWidth,
            height: 1926,
            data: {
              nodes,
              edges: [
                { source: 'tianranqi', target: 'boli' },
                { source: 'yanghuati', target: 'boli' },
                { source: 'chunjian', target: 'boli' },
                { source: 'shiyingsha', target: 'boli' },
                { source: 'yanghualv', target: 'boli' },
                { source: 'yean', target: 'chunjian' },
                { source: 'donglimei', target: 'chunjian' },
                { source: 'yuanyan', target: 'chunjian' },
                { source: 'shihuishi', target: 'chunjian' },
                { source: 'zhengqi', target: 'chunjian' }
              ]
            },
            node: {
              type: 'html',
              style: {
                ports: [{ placement: 'right' }, { placement: 'left' }]
              }
            },
            edge: {
              type: 'polyline-edge',
              style: {
                stroke: '#2cadff',
                lineWidth: 10,
                router: {
                  type: 'orth'
                }
              }
            }
          })
          treeGraph.render()
          this.attributes.collapsed = !collapsed
          collapseStyle.text = this.attributes.collapsed ? '-' : '+'
          this.upsert('collapse', Badge, collapseStyle)
          emit('update:loading', false)
        }
      })
    }
  }

  getBackgroundStyle(attributes) {
    const { col, info } = attributes
    const [width, height] = this.getSize(attributes)
    if (col == 1 || col == 2) {
      return {
        x: -width / 2,
        y: -height / 2 + 6.34 + 57.22,
        width,
        height: 213.44,
        fill: getColor(info.alarmLevel, info.name).background,
        stroke: getColor(info.alarmLevel, info.name).stroke,
        lineWidth: 2
      }
    } else if (col == 3 || col == 4) {
      return {}
    }
  }

  drawBackgroundShape(attributes, container) {
    const backgroundStyle = this.getBackgroundStyle(attributes)
    this.upsert('rect', RectGeometry, backgroundStyle, container)
  }

  drawOpacityShape(attributes, container) {
    const { col, info } = attributes
    const { priceLineList, ratioList } = info
    if (col == 1 || col == 2) {
      const [width, height] = this.getSize(attributes)
      let infoHeight = 0
      if (
        (ratioList?.length > 6 && props.supplyDemandRatio && !props.priceFilter) ||
        (priceLineList?.length > 6 && props.priceFilter && !props.supplyDemandRatio) ||
        ((priceLineList?.length > 6 || ratioList?.length > 6) &&
          props.priceFilter &&
          props.supplyDemandRatio)
      ) {
        infoHeight = 106
      } else {
        infoHeight = 213.44
      }
      this.upsert(
        'clickArea',
        RectGeometry,
        {
          x: -width / 2,
          y: -height / 2 + 6.34 + 57.22,
          width,
          height: infoHeight,
          cursor: 'pointer',
          fill: 'transparent',
          zIndex: 2
        },
        container
      )
    }
  }

  onCreate() {
    const { name, row, col, info } = this.attributes
    const [width, height] = this.getSize()
    if (col == 1 || col == 2) {
      const { priceLineList, ratioList, monthList, price } = info
      let typePrice = ''
      if (price) {
        switch (name) {
          case '电池片':
            typePrice = Number(price).toFixed(2)
            break
          case 'EVA':
            typePrice = Number(price).toFixed(0)
            break
          case '光伏玻璃':
            typePrice = Number(price).toFixed(1)
            break
          case '多晶硅':
            typePrice = Number(price).toFixed(0)
            break
          default:
            typePrice = price
            break
        }
      }
      let infoHeight = 0
      let infoTop = 0
      if (
        (ratioList?.length > 6 && props.supplyDemandRatio && !props.priceFilter) ||
        (priceLineList?.length > 6 && props.priceFilter && !props.supplyDemandRatio) ||
        ((priceLineList?.length > 6 || ratioList?.length > 6) &&
          props.priceFilter &&
          props.supplyDemandRatio)
      ) {
        infoHeight = 6.34 + 57.22 + 106
        infoTop = 20
      } else {
        infoHeight = height
        infoTop = 0
      }
      this.upsert(
        'html',
        HTML,
        {
          x: -width / 2,
          y: -height / 2,
          width,
          height: infoHeight,
          innerHTML: `
    <div class='node-card common-node' style='height:${infoHeight}px'>
      <img src="${getColor(info.alarmLevel, info.name).headerImg}" />
      <div class="title" style='background:${getColor(info.alarmLevel, info.name).header}'>${name}</div>
      <div class="info" style='padding-top:${infoTop}px'>
        <div class="info-item price">
          <div class="item-title">价格</div>
          <div class="item-info">
            <div class="num">${typePrice || '-'}</div>
            <div class="unit">${info.unit || '/'}</div>
            ${info.priceThan == 1 ? '<img src="' + arrowDown + '" />' : info.priceThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
          </div>
        </div>
        <div class="info-item supply">
          <div class="item-title">供需比</div>
          <div class="item-info">
            <div class="num">${info.supply ? (info.supply * 100).toFixed(0) : ''}</div>
            ${info.supply ? '<div class="unit">%</div>' : ''}
            ${info.supplyThan == 1 ? '<img src="' + arrowDown + '" />' : info.supplyThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
          </div>
        </div>
        <div class="info-item rate">
          <div class="item-title">毛利率</div>
          <div class="item-info">
            <div class="num">${info.rate ? (Number(info.rate) * 100).toFixed(0) : ''}</div>
            ${info.rate ? '<div class="unit">%</div>' : ''}
            ${info.rateThan == 1 ? '<img src="' + arrowDown + '" />' : info.rateThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
          </div>
        </div>
      </div>
    </div>
    `
        },
        this.shapeMap.key
      )

      const group = this.upsert(
        'chart-container',
        RectGeometry,
        {
          transform: `translate(${-225}, ${40})`,
          width: 450,
          height: 90,
          fill: 'transparent'
        },
        this.shapeMap.key
      )

      let valueList = []
      let maxRatio = 0
      let minRatio = 0
      let maxPrice = 0
      let minPrice = 0
      valueList = monthList
        ?.map((month, i) => {
          const entry = {}
          if (i < ratioList?.length && ratioList?.length > 6 && props.supplyDemandRatio) {
            entry.ratio = Number((Number(ratioList[i]) * 100).toFixed(0))
          }
          if (i < priceLineList?.length && priceLineList?.length > 6 && props.priceFilter) {
            switch (name) {
              case '电池片':
                entry.price = Number(priceLineList[i]).toFixed(2)
                break
              case 'EVA':
                entry.price = Number(priceLineList[i]).toFixed(0)
                break
              case '光伏玻璃':
                entry.price = Number(priceLineList[i]).toFixed(1)
                break
              case '多晶硅':
                entry.price = Number(priceLineList[i]).toFixed(0)
                break
              default:
                entry.price = Number(priceLineList[i])
                break
            }
          }
          if (Object.keys(entry).length > 0) {
            entry.month = month
            return entry
          }
          return null
        })
        .filter((entry) => entry !== null)
      const ratios =
        valueList?.length &&
        valueList.map((entry) => entry.ratio).filter((ratio) => ratio !== undefined)
      const prices =
        valueList?.length &&
        valueList.map((entry) => entry.price).filter((price) => price !== undefined)
      maxRatio = ratios?.length && Math.max(...ratios)
      minRatio = ratios?.length && Math.min(...ratios)
      maxPrice = prices?.length && Math.max(...prices)
      minPrice = prices?.length && Math.min(...prices)
      let children = []
      const ratioLine = {
        type: 'line',
        style: {
          shape: (option, context) => {
            return (points, value, defaults) => {
              const { document } = context.canvas
              const g = document.createElement('g', {})
              const points1 = points.slice(0, 6)
              const points2 = points.slice(5)
              points1.forEach((p, index) => {
                const line1 = document.createElement('line', {
                  style: {
                    x1: p[0],
                    y1: p[1],
                    x2: points1[index + 1]?.[0],
                    y2: points1[index + 1]?.[1],
                    lineWidth: 5,
                    stroke: '#2CADFF'
                  }
                })
                g.appendChild(line1)
              })
              points2.forEach((p, index) => {
                const line = document.createElement('line', {
                  style: {
                    x1: p[0],
                    y1: p[1],
                    x2: points2[index + 1]?.[0],
                    y2: points2[index + 1]?.[1],
                    lineWidth: 5,
                    lineDash: [3, 4],
                    stroke: '#2CADFF'
                  }
                })
                g.appendChild(line)
              })
              return g
            }
          }
        },
        encode: {
          x: 'month',
          y: 'ratio',
          color: '#2CADFF',
          size: 5
        },
        scale: {
          y: {
            independent: true,
            domain: [minRatio, maxRatio]
          }
        }
      }
      const priceLine = {
        type: 'line',
        style: {
          shape: (option, context) => {
            return (points, value, defaults) => {
              const { document } = context.canvas
              const g = document.createElement('g', {})
              const points1 = points.slice(0, 6)
              const points2 = points.slice(5)
              points1.forEach((p, index) => {
                const line1 = document.createElement('line', {
                  style: {
                    x1: p[0],
                    y1: p[1],
                    x2: points1[index + 1]?.[0],
                    y2: points1[index + 1]?.[1],
                    lineWidth: 5,
                    stroke: '#FF9D19'
                  }
                })
                g.appendChild(line1)
              })
              points2.forEach((p, index) => {
                const line = document.createElement('line', {
                  style: {
                    x1: p[0],
                    y1: p[1],
                    x2: points2[index + 1]?.[0],
                    y2: points2[index + 1]?.[1],
                    lineWidth: 5,
                    lineDash: [3, 4],
                    stroke: '#FF9D19'
                  }
                })
                g.appendChild(line)
              })
              return g
            }
          }
        },
        encode: {
          x: 'month',
          y: 'price',
          color: '#FF9D19',
          size: 5
        },
        scale: {
          y: {
            independent: true,
            domain: [minPrice, maxPrice]
          }
        }
      }
      const ratioPoint = {
        type: 'point',
        style: {
          fill: '#fff',
          lineWidth: 2
        },
        encode: {
          x: 'month',
          y: 'ratio',
          color: '#2CADFF',
          size: 4
        },
        scale: {
          y: {
            independent: true,
            domain: [minRatio, maxRatio]
          }
        },
        tooltip: false
      }
      const pricePoint = {
        type: 'point',
        style: {
          fill: '#fff',
          lineWidth: 2
        },
        encode: {
          x: 'month',
          y: 'price',
          color: '#FF9D19',
          size: 4
        },
        scale: {
          y: {
            independent: true,
            domain: [minPrice, maxPrice]
          }
        },
        tooltip: false
      }
      if (props.supplyDemandRatio && ratioList?.length > 6) {
        children = [ratioLine, ratioPoint]
      }
      if (props.priceFilter && priceLineList?.length > 6) {
        children = [...children, priceLine, pricePoint]
      }
      renderToMountedElement(
        {
          width: 450,
          height: 90,
          data: { value: valueList || [] },
          type: 'view',
          style: {
            shape: {}
          },
          children,
          axis: {
            x: false,
            y: false
          },
          legend: { color: false },
          interaction: {
            tooltip: {
              shared: true,
              render: (event, { title, items }) => {
                let html = `<div><h3 style="height:70px;line-height:70px;padding:0 30px;margin:0;font-size:40px">${title}</h3>`
                items.forEach((e) => {
                  html += `
                      <h4 style="height:50px;line-height:50px;padding:0 30px;margin:0;font-size:30px">
                        <span>${e.name == 'ratio' ? '供需比' : '价格'}</span> ${e.value}${e.name == 'ratio' ? '%' : ''}
                      </h4>
                      `
                })
                return html + `</div>`
              }
            }
          }
        },
        {
          group,
          library: stdlib()
        }
      )
    } else if (col == 3 && row != 1) {
      this.upsert(
        'html',
        HTML,
        {
          x: -width / 2,
          y: -height / 2,
          width,
          height,
          innerHTML: `<div class='col3-card'>${name}</div>`
        },
        this.shapeMap.key
      )
    } else if (col == 4) {
      this.upsert(
        'html',
        HTML,
        {
          x: -width / 2,
          y: -height / 2,
          width,
          height,
          innerHTML: `<div class='col4-card'>${name}</div>`
        },
        this.shapeMap.key
      )
    }
  }

  render(attributes, container) {
    this.drawBackgroundShape(attributes, container)
    this.drawOpacityShape(attributes, container)
    this.drawCollapseShape(attributes, container)
    super.render(attributes, container)
  }
}

register(ExtensionCategory.NODE, 'node-chart', NodeChart)

class PolylineEdge extends BaseEdge {
  getKeyPath(attributes) {
    const [sourcePoint, targetPoint] = this.getEndpoints(attributes)
    const { sourceNode, targetNode } = attributes

    if (
      (sourceNode == 'gongyegui' && targetNode == 'duojinggui') ||
      (sourceNode == 'duojinggui' && targetNode == 'guipian')
    ) {
      return [
        ['M', sourcePoint[0], sourcePoint[1]],
        ['L', targetPoint[0], targetPoint[1]]
      ]
    } else {
      return [
        ['M', sourcePoint[0], sourcePoint[1]],
        ['L', targetPoint[0] / 2 + (1 / 2) * sourcePoint[0], sourcePoint[1]],
        ['L', targetPoint[0] / 2 + (1 / 2) * sourcePoint[0], targetPoint[1]],
        ['L', targetPoint[0], targetPoint[1]]
      ]
    }
  }
}

register(ExtensionCategory.EDGE, 'polyline-edge', PolylineEdge)

const previewNode = ref(null)
const previewVisible = ref(false)

let graph = null

const initGraph = async () => {
  const treeConatiner = document.getElementById('treeConatiner')
  treeConatiner.style.display = 'none'

  emit('update:loading', true)

  if (graph) graph.destroy()
  graph = new Graph({
    container: 'chainDiagram',
    width: 3043,
    height: 1926,
    data: {
      nodes: props.nodeList.map((item) => {
        if (item.type == 'frame') {
          switch (item.id) {
            case 'frame1':
              item.style = {
                x: 450,
                y: 965,
                size: [650, 1900],
                stroke: 'rgba(0,117,169,0.9)',
                lineWidth: 3,
                lineDash: 20,
                fill: 'rgba(22,33,74,0.7)',
                radius: 20
              }
              break
            case 'frame2':
              item.style = {
                x: 1250,
                y: 965,
                size: [650, 1900],
                stroke: 'rgba(0,117,169,0.9)',
                lineWidth: 3,
                lineDash: 20,
                fill: 'rgba(22,33,74,0.7)',
                radius: 20
              }
              break
            case 'frame3':
              item.style = {
                x: 2150,
                y: 965,
                size: [900, 1900],
                stroke: 'rgba(0,117,169,0.9)',
                lineWidth: 3,
                lineDash: 20,
                fill: 'rgba(22,33,74,0.7)',
                radius: 20
              }
              break
            default:
              break
          }
        } else {
          if (item.col == 1) {
            item.style = {
              x: 450 + (item.col - 1) * 750,
              y: 170 + (item.row - 1) * 380,
              size: [550.47, 277]
            }
          } else if (item.col == 2) {
            item.style = {
              x: 500 + (item.col - 1) * 750,
              y: 170 + (item.row - 1) * 316,
              size: [550.47, 277]
            }
          } else if (item.col == 3) {
            if (item.row == 1) {
              item.style = {
                x: 276 + (item.col - 1) * 750,
                y: item.row == 1 ? 382 : (item.row - 1) * 150 + 1300,
                size: item.row == 1 ? [748, 836.03] : [748, 97.76]
              }
            } else {
              item.style = {
                x: 650 + (item.col - 1) * 750,
                y: item.row == 1 ? 800 : (item.row - 1) * 150 + 1300,
                size: item.row == 1 ? [748, 836.03] : [748, 97.76]
              }
            }
          } else if (item.col == 4) {
            item.style = {
              x: 600 + (item.col - 1) * 750,
              y: item.row == 1 ? 1100 : (item.row - 1) * 250 + 1100,
              size: [242.34, 185.12]
            }
          }
        }

        return {
          ...item,
          style: {
            ...item.style,
            innerHTML:
              item.id == 'guangfuzujian'
                ? `
    <div class='node-card big'>
      <img src="${getColor(item.alarmLevel, item.name).headerImg}" />
      <div class="title" style='background:${getColor(item.alarmLevel, item.name).header}'>${item.name}</div>
      <div class='node-background'>
        <div class="info">
          <div class="info-item">
            <div class="item-title">成本</div>
            <div class="item-info">
              <div class="num">${item.materialCost ? Number(item.materialCost).toFixed(2) : '-'}</div>
              <div class="unit">${item.unit || '/'}</div>
            ${item.materialCostThan == 1 ? '<img src="' + arrowDown + '" />' : item.materialCostThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
            </div>
          </div>
          <div class="info-item">
            <div class="item-title">价格</div>
            <div class="item-info">
              <div class="num">${item.price || '-'}</div>
              <div class="unit">${item.unit || '/'}</div>
            ${item.priceThan == 1 ? '<img src="' + arrowDown + '" />' : item.priceThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
            </div>
          </div>
          <div class="info-item">
            <div class="item-title">利润</div>
            <div class="item-info">
              <div class="num">${item.materialCostRatio ? Number(item.materialCostRatio).toFixed(2) : '-'}</div>
              <div class="unit">${item.unit || '/'}</div>
            ${item.materialCostRatioThan == 1 ? '<img src="' + arrowDown + '" />' : item.materialCostRatioThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
            </div>
          </div>
          <div class="info-item">
            <div class="item-title">毛利率</div>
            <div class="item-info">
              <div class="num">${item.rate ? (Number(item.rate) * 100).toFixed(0) : ''}</div>
            ${item.rate ? '<div class="unit">%</div>' : ''}
            ${item.rateThan == 1 ? '<img src="' + arrowDown + '" />' : item.rateThan == 2 ? '<img src="' + arrowUp + '" />' : '<div class="no-arrow">-</div>'}
            </div>
          </div>
        </div>
        <div class='chart-container'>
          ${
            item.name == 'annotation'
              ? '<div class="chart-item"><div class="chart-title"><div class="title-before"></div><div class="desc">供需分析</div></div><div id="supplyDemandAnalysis"></div></div>'
              : ''
          }
          <div class='chart-item'>
            <div class='chart-title'>
              <div class='title-before'></div>
              <div class='desc'>成本评估<span>（基于原料价格预测）</span></div>
            </div>
            <div id='costAssessment'></div>
          </div>
        </div>
      </div>
    </div>
    `
                : '',
            ports:
              item.id == 'gongyegui'
                ? [{ placement: [0.5, 1] }]
                : item.id == 'duojinggui'
                  ? [{ placement: [0.5, 0] }, { placement: [0.5, 1] }]
                  : item.id == 'guipian'
                    ? [{ placement: [0.5, 0] }, { placement: [1, 0.5] }]
                    : [{ placement: [0, 0.5] }, { placement: [1, 0.5] }]
          },
          data: {
            value: item.value
          }
        }
      }),
      edges: [
        { source: 'gongyegui', target: 'duojinggui' },
        { source: 'duojinggui', target: 'guipian' },
        { source: 'guipian', target: 'dianchi' },
        { source: 'yinjiang', target: 'dianchi' },
        { source: 'boli', target: 'guangfuzujian' },
        { source: 'beiban', target: 'guangfuzujian' },
        { source: 'rezhabanjuan', target: 'zhijia' }
      ]
      // combos: [{ id: 'combo-1' }, { id: 'combo-2' }, { id: 'combo-3' }]
    },
    node: {
      type: (item) =>
        item.type == 'frame' ? 'rect' : item.id == 'guangfuzujian' ? 'html' : 'node-chart',
      style: {
        fillOpacity: (d) => (d.type == 'frame' ? 1 : 0),
        name: (d) => d.name,
        col: (d) => d.col,
        row: (d) => d.row,
        collapsed: false,
        info: (d) => d
      }
    },
    edge: {
      type: 'polyline-edge',
      style: {
        stroke: 'linear-gradient(0deg, #00ff00, #46d4f3)',
        lineWidth: 10,
        zIndex: 1,
        endArrow: true,
        router: {
          type: 'orth'
        }
      }
    }
    // combo: {
    //   type: 'rect',
    //   style: {
    //     stroke: 'rgba(0,117,169,0.7)',
    //     lineWidth: 3,
    //     lineDash: 20
    //   }
    // }
  })
  graph.render()

  graph.on(GraphEvent.AFTER_RENDER, () => {
    let infoNode = null
    props.nodeList.forEach((element) => {
      if (element.name == '光伏组件') {
        infoNode = element
      }
    })
    if (document.getElementById('supplyDemandAnalysis')) {
      const dottedSupply = infoNode.ratioList?.map((item, index) =>
        index >= 6 ? null : (Number(item) * 100).toFixed(0)
      )
      const supplyList = infoNode.supplyList?.map((item, index) =>
        index >= 6 ? { value: item, itemStyle: { opacity: 0.5 } } : item
      )
      const demandList = infoNode.demandList?.map((item, index) =>
        index >= 6 ? { value: item, itemStyle: { opacity: 0.5 } } : item
      )
      const analysisChart = echarts.init(document.getElementById('supplyDemandAnalysis'))
      analysisChart.setOption({
        title: {
          show: false
        },
        tooltip: {
          trigger: 'axis',
          backgroundColor: 'rgba(50,50,50,0.7)',
          textStyle: {
            fontWeight: 700,
            fontSize: 24,
            color: '#fff'
          },
          formatter: (params) => {
            let html = params[0].name + '<br>'
            params.forEach((element) => {
              html += `${
                element.seriesName === '供应'
                  ? `<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background:linear-gradient(180deg, #28F7E1, #1A80FF);"></span>`
                  : element.marker
              }${element.seriesName}:&nbsp;${element.value}${
                element.seriesName === '供需比' ? '%</br>' : '</br>'
              }`
            })
            return html
          }
        },
        legend: {
          data: ['供应', '需求', '供需比'],
          right: '5%',
          top: '5%',
          textStyle: {
            fontWeight: 700,
            fontSize: 20,
            color: '#fff'
          }
        },
        grid: {
          top: '30%',
          left: '5%',
          right: '5%',
          bottom: '5%',
          containLabel: true
        },
        xAxis: {
          data: infoNode.monthList?.map((date) => {
            const [year, month] = date.split('-')
            return `${year.slice(-2)}.${month}`
          }),
          axisLine: {
            lineStyle: {
              color: '#fff',
              width: 3
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            fontWeight: 700,
            fontSize: 20,
            color: '#fff',
            rotate: 35
          }
        },
        yAxis: [
          {
            name: '单位：' + infoNode.unit.split('/')[1],
            nameTextStyle: {
              fontWeight: 700,
              color: '#fff'
            },
            type: 'value',
            axisLine: {
              show: false
            },
            splitLine: {
              show: false
            },
            axisLabel: {
              fontWeight: 700,
              fontSize: 20,
              color: '#fff'
            }
          },
          {
            type: 'value',
            axisLine: {
              show: false
            },
            splitLine: {
              show: false
            },
            axisLabel: {
              fontWeight: 700,
              fontSize: 20,
              color: '#fff',
              formatter: '{value}%'
            }
          }
        ],
        series: [
          {
            name: '供应',
            type: 'bar',
            barWidth: 40,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#28F7E1' },
                { offset: 1, color: '#1A80FF' }
              ])
            },
            data: supplyList
          },
          {
            name: '需求',
            type: 'scatter',
            symbol: 'triangle',
            symbolSize: 25,
            itemStyle: {
              color: '#FF9D19'
            },
            data: demandList
          },
          {
            name: '供需比',
            type: 'line',
            yAxisIndex: 1,
            symbol: 'circle',
            symbolSize: 12,
            itemStyle: {
              color: '#00FFFF',
              borderColor: '#fff',
              borderWidth: 3
            },
            lineStyle: {
              width: 3,
              color: '#00FFFF',
              type: 'solid'
            },
            tooltip: { show: false },
            data: dottedSupply
          },
          {
            name: '供需比',
            type: 'line',
            yAxisIndex: 1,
            symbol: 'circle',
            symbolSize: 12,
            itemStyle: {
              color: '#00FFFF',
              borderColor: '#fff',
              borderWidth: 3
            },
            lineStyle: {
              width: 3,
              color: '#00FFFF',
              type: 'dashed'
            },
            data: infoNode.ratioList?.map((item) => (Number(item) * 100).toFixed(0))
          }
        ]
      })
    }
    if (document.getElementById('costAssessment')) {
      const dottedCost = infoNode.monthsPvModuleCostList?.map((item, index) =>
        index >= 6 ? null : item
      )
      let adjustedMin, adjustedMax
      if (infoNode.monthsPvModuleCostList?.length) {
        const min = Math.min(...infoNode.monthsPvModuleCostList)
        const max = Math.max(...infoNode.monthsPvModuleCostList)
        const range = max - min
        adjustedMin = Math.floor((min - range * 0.1) * 10) / 10
        adjustedMax = Math.ceil((max + range * 0.1) * 10) / 10
      }
      const assessmentChart = echarts.init(document.getElementById('costAssessment'))
      assessmentChart.setOption({
        title: {
          show: false
        },
        tooltip: {
          trigger: 'axis',
          backgroundColor: 'rgba(50,50,50,0.7)',
          textStyle: {
            fontWeight: 700,
            fontSize: 24,
            color: '#fff'
          }
        },
        grid: {
          top: '20%',
          left: '5%',
          right: '5%',
          bottom: '5%',
          containLabel: true
        },
        xAxis: {
          data: infoNode.monthList
            ?.map((date) => {
              const [year, month] = date.split('-')
              return `${year.slice(-2)}.${month}`
            })
            ?.slice(0, infoNode.monthsPvModuleCostList?.length),
          axisLine: {
            lineStyle: {
              color: '#fff',
              width: 3
            }
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            fontWeight: 700,
            fontSize: 20,
            color: '#fff',
            rotate: 35,
            margin: 30
          }
        },
        yAxis: {
          name: '单位：' + infoNode.unit,
          nameTextStyle: {
            fontWeight: 700,
            color: '#fff',
            fontSize: 24
          },
          min: adjustedMin,
          max: adjustedMax,
          interval: 0.05,
          axisLine: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            fontWeight: 700,
            fontSize: 20,
            color: '#fff'
          }
        },
        series: [
          {
            name: '成本评估',
            type: 'line',
            symbol: 'circle',
            symbolSize: 12,
            itemStyle: {
              color: '#00FFFF',
              borderColor: '#fff',
              borderWidth: 3
            },
            lineStyle: {
              width: 3,
              color: '#00FFFF',
              type: 'solid'
            },
            tooltip: { show: false },
            data: dottedCost
          },
          {
            name: '成本评估',
            type: 'line',
            symbol: 'circle',
            symbolSize: 12,
            itemStyle: {
              color: '#00FFFF',
              borderColor: '#fff',
              borderWidth: 3
            },
            lineStyle: {
              width: 3,
              color: '#00FFFF',
              type: 'dashed'
            },
            data: infoNode.monthsPvModuleCostList
          }
        ]
      })
    }
    emit('update:loading', false)
    if (props.noData) {
      emit('update:loading', false)
    }
  })

  graph.on(NodeEvent.CLICK, (event) => {
    const { target, originalTarget } = event
    const { col } = target.config.style
    if (col == 1 || col == 2) {
      if (originalTarget.className === 'clickArea') {
        props.nodeList.forEach((element) => {
          if (element.id == target.id) {
            previewNode.value = element
          }
        })
        nextTick(() => {
          if (
            previewNode.value.ratioList?.length > 6 ||
            previewNode.value.priceLineList?.length > 6
          ) {
            previewVisible.value = true
          } else {
            message.warning('当前类型没有供需比和价格预测!')
          }
        })
      }
    }
  })
}

defineExpose({
  initGraph
})
</script>
<style lang="scss" scoped>
#chainContainer {
  #chainDiagram {
    width: 100%;
    height: 100%;
    :deep(.node-card) {
      width: 550.47px;
      &.common-node {
        display: flex;
        flex-direction: column;
        .info {
          flex: 1;
        }
      }
      &.big {
        width: 748px;
        height: 100%;
        display: flex;
        flex-direction: column;

        .node-background {
          flex: 1;
          display: flex;
          flex-direction: column;
          background-image: url('./assets/guangfuBackground.png');
          background-size: 100% 100%;
          padding-top: 35px;

          .chart-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin-top: 40px;

            .chart-item {
              flex: 1;
              position: relative;
              & + .chart-item {
                margin-top: 40px;
              }
              .chart-title {
                display: flex;
                position: absolute;
                top: 0;
                left: 30px;

                .title-before {
                  width: 4.19px;
                  height: 50px;
                  background: #00c6ff;
                  margin-right: 6px;
                }

                .desc {
                  width: 349px;
                  height: 50px;
                  line-height: 50px;
                  background: linear-gradient(-90deg, #0c2f59, #0069f0);
                  font-weight: 700;
                  font-size: 24px;
                  color: #fff;
                  padding-left: 18px;

                  span {
                    font-size: 18px;
                  }
                }
              }

              #supplyDemandAnalysis,
              #costAssessment {
                width: 100%;
                height: 100%;
              }
            }
          }
        }
      }
      img {
        width: 174.34px;
        height: 6.34px;
        display: block;
      }
      .title {
        padding-left: 25px;
        width: 100%;
        height: 57.22px;
        line-height: 57.22px;
        color: #fff;
        font-weight: 700;
        font-size: 36.09px;
      }
      .info {
        width: 100%;
        padding-top: 20px;
        display: flex;
        justify-content: space-around;
        align-items: center;

        .info-item {
          display: flex;
          flex-direction: column;
          align-items: center;

          &.price {
            flex: 3;
          }
          &.supply,
          &.rate {
            flex: 2;
          }

          .item-title {
            font-weight: 600;
            font-size: 22px;
            color: #fff;
          }
          .item-info {
            margin-top: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            .num {
              font-weight: 400;
              font-size: 28px;
              color: #fff;
            }
            .unit {
              font-weight: 400;
              font-size: 26px;
              color: #fff;
              margin-left: 6px;
            }
            .no-arrow {
              margin-left: 8px;
              font-size: 28px;
              color: #fff;
            }

            img {
              margin-left: 8px;
              width: 21px;
              height: 27px;
            }
          }
        }
      }
    }
    :deep(.col3-card) {
      width: 748px;
      height: 97.76px;
      line-height: 97.76px;
      background: linear-gradient(180deg, #0b45ae, #072e70);
      font-weight: 700;
      font-size: 36px;
      text-align: center;
      color: #fff;
    }

    :deep(.col4-card) {
      width: 242.34px;
      height: 185.12px;
      line-height: 185.12px;
      background: linear-gradient(0deg, #030620, #9fa0a0);
      font-weight: 700;
      font-size: 36px;
      text-align: center;
      color: #fff;
    }
  }
}
</style>
