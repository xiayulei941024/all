<template>
  <gl-modal
    class="preview-modal"
    v-model:visible="previewVisible"
    :footer="null"
    :width="800"
    :closable="false"
    :bodyStyle="{
      background: 'linear-gradient(180deg, #0b45ae, #041E42)',
      border: '1px solid #2CADFF',
      color: '#fff'
    }"
  >
    <template v-if="previewNode.ratioList?.length > 6">
      <div class="header">
        <div class="chart-title">
          <div class="title-before"></div>
          <div class="title-desc">{{ previewNode.name }}供需评估</div>
        </div>
        <!-- <div class="select-requirements">
          选择需求版本
          <gl-select v-model:value="version" @change="(value) => versionChange(item, value)">
            <gl-select-option value="1">乐观版</gl-select-option>
            <gl-select-option value="2">中性版</gl-select-option>
          </gl-select>
        </div> -->
        <div class="close-button" @click="closeModal"></div>
      </div>
      <div v-if="previewNode.supplyAlarmWarn" class="warning-content">
        <div class="title">预警内容：</div>
        <div class="warning">{{ previewNode.supplyAlarmWarn }}</div>
      </div>
      <div class="desc">未来供需比走势图：</div>
      <div id="analysisChart"></div>
    </template>
    <template v-if="previewNode.priceLineList?.length > 6">
      <div class="chart-title">
        <div class="title-before"></div>
        <div class="title-desc">{{ previewNode.name }}价格评估</div>
      </div>
      <div
        class="assessment-content"
        :style="{ 'justify-content': previewNode.priceAlarmWarn ? 'space-between' : 'flex-end' }"
      >
        <div v-if="previewNode.priceAlarmWarn" class="warning-content">
          <div class="title">预警内容：</div>
          <div class="warning">{{ previewNode.priceAlarmWarn }}</div>
        </div>
        <div v-if="viewDetailsVisible" class="view-details" @click="viewDetails">点击查阅详情</div>
      </div>
      <div id="assessmentChart"></div>
    </template>
  </gl-modal>
</template>
<script setup>
import * as echarts from 'echarts'
import { nextTick } from 'vue'
import Vrouter from '@/router'

const props = defineProps({
  visible: Boolean,
  previewNode: Object
})

const emits = defineEmits(['update:visible'])

const viewDetailsVisible = computed(() => {
  const name = props.previewNode.name
  return (
    name == '光伏玻璃' ||
    name == 'EVA' ||
    name == '热轧板卷' ||
    name == '多晶硅' ||
    name == '工业硅'
  )
})

const previewVisible = computed({
  get() {
    return props.visible
  },
  set(val) {
    emits('update:visible', val)
  }
})

watch(
  () => props.visible,
  async (val) => {
    if (val) {
      nextTick(() => {
        if (document.getElementById('analysisChart')) {
          const dottedSupply = props.previewNode.ratioList?.map((item, index) =>
            index >= 6 ? null : (Number(item) * 100).toFixed(0)
          )
          const supplyList = props.previewNode.supplyList?.map((item, index) =>
            index >= 6 ? { value: item, itemStyle: { opacity: 0.5 } } : item
          )
          const demandList = props.previewNode.demandList?.map((item, index) =>
            index >= 6 ? { value: item, itemStyle: { opacity: 0.5 } } : item
          )
          const analysisChart = echarts.init(document.getElementById('analysisChart'))
          analysisChart.setOption({
            title: {
              show: false
            },
            tooltip: {
              trigger: 'axis',
              textStyle: {
                fontWeight: 700,
                color: '#fff'
              },
              backgroundColor: 'rgba(50,50,50,0.7)',
              formatter: (params) => {
                let html = params[0].name + '<br>'
                params.forEach((element) => {
                  html += `${
                    element.seriesName === '供应'
                      ? `<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background:linear-gradient(180deg, #28F7E1, #1A80FF);"></span>`
                      : element.marker
                  }${element.seriesName}:&nbsp;${element.value}${
                    element.seriesName === '供需比' ? '%</br>' : '</br>'
                  }`
                })
                return html
              }
            },
            legend: {
              data: ['供应', '需求', '供需比'],
              right: '5%',
              top: '0%',
              textStyle: {
                fontWeight: 700,
                color: '#fff'
              }
            },
            grid: {
              top: '20%',
              left: '5%',
              right: '5%',
              bottom: '5%',
              containLabel: true
            },
            xAxis: {
              data: props.previewNode.monthList?.map((date) => {
                const [year, month] = date.split('-')
                return `${year.slice(-2)}.${month}`
              }),
              axisLine: {
                lineStyle: {
                  color: '#fff'
                }
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                fontWeight: 700,
                color: '#fff'
              }
            },
            yAxis: [
              {
                name: '单位：' + props.previewNode.unit.split('/')[1],
                nameTextStyle: {
                  fontWeight: 700,
                  color: '#fff'
                },
                type: 'value',
                axisLine: {
                  show: false
                },
                splitLine: {
                  show: false
                },
                axisLabel: {
                  fontWeight: 700,
                  color: '#fff'
                }
              },
              {
                type: 'value',
                axisLine: {
                  show: false
                },
                splitLine: {
                  show: false
                },
                axisLabel: {
                  fontWeight: 700,
                  color: '#fff',
                  formatter: '{value}%'
                }
              }
            ],
            series: [
              {
                name: '供应',
                type: 'bar',
                barWidth: 20,
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#28F7E1' },
                    { offset: 1, color: '#1A80FF' }
                  ])
                },
                data: supplyList
              },
              {
                name: '需求',
                type: 'scatter',
                symbol: 'triangle',
                symbolSize: 15,
                itemStyle: {
                  color: '#FF9D19'
                },
                data: demandList
              },
              {
                name: '供需比',
                type: 'line',
                yAxisIndex: 1,
                symbol: 'circle',
                symbolSize: 8,
                itemStyle: {
                  color: '#00FFFF',
                  borderColor: '#fff',
                  borderWidth: 2
                },
                lineStyle: {
                  color: '#00FFFF',
                  type: 'solid'
                },
                tooltip: { show: false },
                data: dottedSupply
              },
              {
                name: '供需比',
                type: 'line',
                yAxisIndex: 1,
                symbol: 'circle',
                symbolSize: 8,
                itemStyle: {
                  color: '#00FFFF',
                  borderColor: '#fff',
                  borderWidth: 2
                },
                lineStyle: {
                  color: '#00FFFF',
                  type: 'dashed'
                },
                data: props.previewNode.ratioList?.map((item) => (Number(item) * 100).toFixed(0))
              }
            ]
          })
        }

        if (document.getElementById('assessmentChart')) {
          const dottedCost = props.previewNode.priceLineList?.map((item, index) =>
            index >= 6 ? null : item
          )

          let adjustedMin, adjustedMax, interval
          if (props.previewNode.priceLineList?.length) {
            const min = Math.min(...props.previewNode.priceLineList)
            const max = Math.max(...props.previewNode.priceLineList)
            const range = max - min
            adjustedMin = Math.floor(min - range * 0.1)
            adjustedMax = Math.ceil(max + range * 0.1)
            interval = Math.ceil((adjustedMax - adjustedMin) / 6)
          }
          const assessmentChart = echarts.init(document.getElementById('assessmentChart'))
          assessmentChart.setOption({
            title: {
              show: false
            },
            tooltip: {
              trigger: 'axis',
              textStyle: {
                fontWeight: 700,
                color: '#fff'
              },
              backgroundColor: 'rgba(50,50,50,0.7)'
            },
            grid: {
              top: '15%',
              left: '5%',
              right: '5%',
              bottom: '5%',
              containLabel: true
            },
            xAxis: {
              data: props.previewNode.monthList
                ?.map((date) => {
                  const [year, month] = date.split('-')
                  return `${year.slice(-2)}.${month}`
                })
                .slice(0, props.previewNode.priceLineList?.length),
              axisLine: {
                lineStyle: {
                  color: '#fff'
                }
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                fontWeight: 700,
                color: '#fff'
              }
            },
            yAxis: {
              name: '单位：' + props.previewNode.unit,
              nameTextStyle: {
                fontWeight: 700,
                color: '#fff'
              },
              min: adjustedMin,
              max: adjustedMax,
              interval,
              axisLine: {
                show: false
              },
              splitLine: {
                show: false
              },
              axisLabel: {
                fontWeight: 700,
                color: '#fff'
              }
            },
            series: [
              {
                name: '成本评估',
                type: 'line',
                symbol: 'circle',
                symbolSize: 8,
                itemStyle: {
                  color: '#00FFFF',
                  borderColor: '#fff',
                  borderWidth: 2
                },
                lineStyle: {
                  color: '#00FFFF',
                  type: 'solid'
                },
                tooltip: { show: false },
                data: dottedCost
              },
              {
                name: '成本评估',
                type: 'line',
                symbol: 'circle',
                symbolSize: 8,
                itemStyle: {
                  color: '#00FFFF',
                  borderColor: '#fff',
                  borderWidth: 2
                },
                lineStyle: {
                  color: '#00FFFF',
                  type: 'dashed'
                },
                data: props.previewNode.priceLineList
              }
            ]
          })
        }
      })
    }
  },
  { immediate: true }
)

const version = ref('1')
const versionChange = () => {}

const router = Vrouter
const closeModal = () => {
  emits('update:visible', false)
}
const viewDetails = () => {
  closeModal()
  router.push({
    path: '/home/predictiveModel/index',
    query: {
      breed: props.previewNode.name
    }
  })
}
</script>
<style lang="scss" scoped>
.preview-modal {
  .chart-title {
    display: flex;
    .title-before {
      width: 5px;
      height: 40px;
      background: #00c6ff;
      margin-right: 6px;
    }
    .title-desc {
      width: 349px;
      height: 40px;
      line-height: 40px;
      background: linear-gradient(-90deg, #0c2f59, #0069f0);
      color: #fff;
      padding-left: 18px;
      font-size: 20px;
      font-weight: bold;
    }
  }

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .select-requirements {
      .gl-select {
        width: 200px;
      }
    }
    .close-button {
      position: relative;
      width: 30px;
      height: 30px;
      cursor: pointer;
      &::before,
      &::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 30px;
        height: 4px;
        background-color: #fff;
        border-radius: 2px;
        transform-origin: center;
      }
      &::before {
        transform: translate(-50%, -50%) rotate(45deg);
      }
      &::after {
        transform: translate(-50%, -50%) rotate(-45deg);
      }
    }
  }
  .warning-content {
    display: flex;
    margin-top: 10px;
    .warning {
      flex: 1;
      color: #f3c800;
      font-weight: bold;
    }
  }
  .desc {
    margin-top: 10px;
  }

  .assessment-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .warning-content {
      flex: 1;
    }
    .view-details {
      padding: 10px 15px;
      border: 1px solid #fff;
      color: #fff;
      border-radius: 10px;
      cursor: pointer;
    }
  }
  #analysisChart,
  #assessmentChart {
    width: 100%;
    height: 200px;
    margin-top: 20px;
  }
}
</style>
