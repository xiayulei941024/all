<template>
  <div id="industry-chain-cockpit">
    <gl-spin :spinning="loading">
      <scale-screen :width="3840" :height="2160" fullScreen>
        <div class="cockpit">
          <div class="header">
            <div class="date">
              <span>年月：</span>
              <gl-date-picker
                format="YYYY-MM-DD"
                valueFormat="YYYY-MM-DD"
                :disabled-date="disabledDate"
                v-model:value="date"
                @change="dateChange"
                :allowClear="false"
                :showToday="false"
                inputReadOnly
              />
            </div>
            <div class="filter">
              <span>筛选：</span>
              <div
                class="filter-item"
                :style="{
                  backgroundImage: supplyDemandRatio
                    ? `url(${filterSelected})`
                    : `url(${filterUnselect})`
                }"
                @click="supplyDemandRatioChange"
              >
                供需比
              </div>
              <div
                class="filter-item"
                :style="{
                  backgroundImage: priceFilter ? `url(${filterSelected})` : `url(${filterUnselect})`
                }"
                @click="priceFilterChange"
              >
                价格
              </div>
            </div>
          </div>
          <div class="main">
            <div class="chart-legend">
              <div class="legend-item">
                <div class="legend"></div>
                供需比
              </div>
              <div class="legend-item">
                <div class="legend price"></div>
                价格
              </div>
            </div>
            <div id="treeConatiner"></div>
            <div class="reminder-section">
              <div class="reminder-item">
                <div class="reminder-header">风险提醒</div>
                <div class="reminder-card">
                  <div class="reminder-tip">
                    <div class="rect"></div>
                    <div class="line">
                      <div class="desc">供需比下降，可能存在供应不足， 从而带来涨价风险：</div>
                      <div class="types">玻璃、EVA</div>
                    </div>
                  </div>
                  <div class="reminder-tip">
                    <div class="rect"></div>
                    <div class="line">
                      <div class="desc">供需比增加，存在降价可能，关注库存：</div>
                      <div class="types">电池片、背板</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="reminder-item">
                <div class="reminder-header">机会点提醒</div>
                <div class="reminder-card">
                  <div class="reminder-tip">
                    <div class="rect"></div>
                    <div class="line">
                      <div class="desc">存在涨价可能的原材料， 可能存在战略备货机会：</div>
                      <div class="types">玻璃、EVA</div>
                    </div>
                  </div>
                  <div class="reminder-tip">
                    <div class="rect"></div>
                    <div class="line">
                      <div class="desc">供需比增加，存在降价可能，关注库存：</div>
                      <div class="types">电池片、背板</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <chain-diagram
              ref="chainDiagram"
              class="chain-diagram"
              v-model:loading="loading"
              :noData="noData"
              :date="date"
              :supplyDemandRatio="supplyDemandRatio"
              :priceFilter="priceFilter"
              :nodeList="nodeList"
            ></chain-diagram>
          </div>
        </div>
      </scale-screen>
    </gl-spin>
  </div>
</template>
<script setup>
import ScaleScreen from './scaleScreen.vue'
import ChainDiagram from './chainDiagram.vue'
import filterSelected from './assets/filterSelected.png'
import filterUnselect from './assets/filterUnselect.png'
import { message } from 'gl-design-vue'
import { onMounted } from 'vue'
import api from './api/index'
import { nextTick } from 'vue'

const getLastWorkingDay = () => {
  // 创建一个新的日期对象，表示当前日期
  let date = new Date()

  // 获取今天是星期几，0代表星期天，1代表星期一，依次类推
  let dayOfWeek = date.getDay()

  // 检查今天是否是工作日（周一到周五）
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    // 如果今天是周六或周日，循环找到最近的周五
    while (dayOfWeek === 0 || dayOfWeek === 6) {
      date.setDate(date.getDate() - 1)
      dayOfWeek = date.getDay()
    }
  } else {
    // 如果今天是工作日，则找到前一个工作日
    date.setDate(date.getDate() - 1)
    dayOfWeek = date.getDay()
    while (dayOfWeek === 0 || dayOfWeek === 6) {
      date.setDate(date.getDate() - 1)
      dayOfWeek = date.getDay()
    }
  }
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0') // 月份从0开始，需要加1
  const day = String(date.getDate()).padStart(2, '0')
  const formattedDate = `${year}-${month}-${day}`
  return formattedDate
}
const date = ref(getLastWorkingDay())
const disabledDate = (current) => {
  const startDate = new Date('2024-01-01').setHours(0, 0, 0, 0)
  const today = new Date().setHours(0, 0, 0, 0)
  // 当前日期及之后的日期不可选
  if (current && (current >= today || current < startDate)) {
    return true
  }
  // 非工作日（周末）不可选
  const day = current.day()
  if (day === 0 || day === 6) {
    return true
  }
  return false
}
const dateChange = () => {
  getSupplyList()
}

const loading = ref(false)
const noData = ref(false)

const supplyDemandRatio = ref(true)
const priceFilter = ref(false)
const chainDiagram = ref()
const supplyDemandRatioChange = () => {
  if (supplyDemandRatio.value && !priceFilter.value) {
    message.warning('供需比和价格至少选中一个!')
  } else {
    supplyDemandRatio.value = !supplyDemandRatio.value
    chainDiagram.value.initGraph()
  }
}
const priceFilterChange = () => {
  if (!supplyDemandRatio.value && priceFilter.value) {
    message.warning('供需比和价格至少选中一个!')
  } else {
    priceFilter.value = !priceFilter.value
    chainDiagram.value.initGraph()
  }
}

const nodeList = ref([])
const getSupplyList = async () => {
  const { res, err } = await api.getSupplyList({
    startDate: date.value.replace(/\//g, '-')
  })
  nodeList.value = [
    {
      id: 'frame1',
      type: 'frame'
    },
    {
      id: 'frame2',
      type: 'frame'
    },
    {
      id: 'frame3',
      type: 'frame'
    },
    {
      row: 1,
      col: 1,
      name: '工业硅',
      id: 'gongyegui'
    },
    {
      row: 2,
      col: 1,
      name: '多晶硅',
      id: 'duojinggui'
    },
    {
      row: 3,
      col: 1,
      name: '硅片',
      id: 'guipian'
    },
    {
      row: 4,
      col: 1,
      name: '银浆',
      id: 'yinjiang'
    },
    {
      row: 1,
      col: 2,
      name: '光伏玻璃',
      id: 'boli'
    },
    {
      row: 2,
      col: 2,
      name: 'EVA',
      id: 'EVA'
    },
    {
      row: 3,
      col: 2,
      name: '铝边框',
      id: 'lvbiankuang'
    },
    {
      row: 4,
      col: 2,
      name: '电池片',
      id: 'dianchi'
    },
    {
      row: 6,
      col: 2,
      name: '热轧板卷',
      id: 'rezhabanjuan'
    },
    {
      row: 1,
      col: 3,
      name: '光伏组件',
      id: 'guangfuzujian'
    },
    {
      name: '背板',
      row: 5,
      col: 2,
      id: 'beiban'
    },
    {
      name: '逆变器',
      row: 2,
      col: 3,
      id: 'nibianqi'
    },
    {
      name: '汇流器',
      row: 3,
      col: 3,
      id: 'huiliuqi'
    },
    {
      name: '支架',
      row: 4,
      col: 3,
      id: 'zhijia'
    },
    {
      name: '地面电站',
      row: 1,
      col: 4,
      id: 'dimiandianzhan'
    },
    {
      name: '工商业',
      row: 2,
      col: 4,
      id: 'gongshangye'
    },
    {
      name: '户用',
      row: 3,
      col: 4,
      id: 'huyong'
    }
  ]
  if (res && !err) {
    noData.value = false
    const { data } = res
    nodeList.value.forEach((element, index) => {
      data.forEach((item) => {
        if (item.material == element.name) {
          nodeList.value[index] = {
            ...element,
            ...item
          }
        }
      })
    })
    nextTick(() => {
      chainDiagram.value.initGraph()
    })
  } else {
    noData.value = true
    nextTick(() => {
      chainDiagram.value.initGraph()
    })
  }
}
onMounted(() => {
  getSupplyList()
})
</script>
<style lang="scss" scoped>
#industry-chain-cockpit {
  height: 100%;

  .cockpit {
    width: 100%;
    height: 100%;
    background-image: url(./assets/background.png);
    background-size: 100% 100%;
    display: flex;
    flex-direction: column;

    .header {
      height: 174px;
      background-image: url(./assets/header.png);
      background-size: 100% 100%;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding-right: 100px;
      .date {
        display: flex;
        align-items: center;
        span {
          font-weight: 400;
          font-size: 28px;
          color: #fff;
          margin-right: 20px;
        }
        :deep(.gl-picker) {
          width: 220px;
          height: 58px;
          background: transparent;
          border: 3px solid #fff;

          .gl-picker-input {
            input,
            .gl-picker-suffix {
              font-weight: 400;
              font-size: 28px;
              color: #fff;
            }
          }
        }
      }
      .filter {
        display: flex;
        align-items: center;
        margin-left: 40px;
        span {
          font-weight: 400;
          font-size: 28px;
          color: #fff;
          margin-right: 20px;
        }
        .filter-item {
          width: 176px;
          height: 61px;
          line-height: 61px;
          cursor: pointer;
          background-size: 100% 100%;
          font-weight: 400;
          font-size: 28px;
          text-align: center;
          color: #fff;
        }
      }
    }

    .main {
      flex: 1;
      position: relative;

      .chart-legend {
        position: absolute;
        z-index: 2;
        right: 80px;
        top: 30px;
        .legend-item {
          display: flex;
          align-items: center;
          font-weight: 400;
          font-size: 28px;
          color: #fff;

          & + .legend-item {
            margin-top: 40px;
          }

          .legend {
            width: 30px;
            height: 30px;
            border: 5px solid #2cadff;
            background: #fff;
            border-radius: 50%;
            margin-right: 40px;
            display: flex;
            align-items: center;
            position: relative;

            &::before {
              position: absolute;
              display: block;
              width: 20px;
              height: 5px;
              background: #2cadff;
              content: '';
              left: -20px;
            }
            &::after {
              position: absolute;
              display: block;
              width: 20px;
              height: 5px;
              background: #2cadff;
              content: '';
              right: -20px;
            }

            &.price {
              border-color: #ff9d19;

              &::before,
              &::after {
                background: #ff9d19;
              }
            }
          }
        }
      }

      :deep(#treeConatiner) {
        display: none;
        position: absolute;
        z-index: 2;
        left: 80px;
        top: 30px;
        background-color: #011e42;

        .tree-node {
          background: linear-gradient(180deg, #0b45ae, #072e70);
          width: 450px;
          height: 200px;
          display: flex;
          justify-content: space-around;
          align-items: center;

          .tree-node-item {
            display: flex;
            flex-direction: column;
            align-items: center;

            .title {
              font-weight: 400;
              font-size: 28px;
              color: #fff;
            }

            .name,
            .value {
              font-weight: 400;
              font-size: 28px;
              color: #fff;
            }
          }
        }
      }

      .reminder-section {
        position: absolute;
        z-index: 1;
        left: 80px;
        top: 30px;
        margin-top: 60px;

        .reminder-item {
          & + .reminder-item {
            margin-top: 110px;
          }

          .reminder-header {
            width: 637px;
            height: 85px;
            line-height: 85px;
            background-image: url(./assets/reminderHeader.png);
            background-size: 100% 100%;
            font-weight: 700;
            font-size: 40px;
            color: #ffffff;
            padding-left: 120px;
          }

          .reminder-card {
            width: 637px;
            height: 622.88px;
            background-image: url(./assets/reminderCard.png);
            background-size: 100% 100%;
            margin-top: 26px;
            padding: 60px;

            .reminder-tip {
              width: 100%;
              display: flex;

              .rect {
                margin-top: 6px;
                margin-right: 20px;
                width: 25.59px;
                height: 25.59px;
                background: linear-gradient(0deg, #1692fa, #62c2ff);
              }

              .line {
                flex: 1;

                .desc {
                  color: #ffffff;
                  font-weight: 400;
                  font-family: Source Han Sans CN;
                  font-size: 28px;
                  line-height: 40px;
                }

                .types {
                  font-weight: 700;
                  font-size: 28px;
                  color: #00ffff;
                  margin-top: 10px;
                }
              }
              & + .reminder-tip {
                margin-top: 69px;
              }
            }
          }
        }
      }

      .chain-diagram {
        position: absolute;
        z-index: 1;
        left: 717px;
        top: 30px;
      }
    }
  }
}
</style>
