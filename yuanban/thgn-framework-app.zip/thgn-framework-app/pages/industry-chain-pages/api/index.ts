import request from '@mysteel-standard/apis'
const apiMap: object = {
  // 查询首页数据
  getSupplyList: {
    method: 'post',
    url: '/homepage/supply/getSupplyList'
  }
}

export default request(apiMap)
