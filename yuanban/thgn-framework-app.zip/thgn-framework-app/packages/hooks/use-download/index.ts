/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-21 17:29:50
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-03 17:43:17
 * @Description:
 */
const typeToMime = {
  excel: 'application/vnd.ms-excel',
  pdf: 'application/pdf;charset=utf8',
  word: 'application/msword',
  ppt: 'application/vnd.ms-powerpoint',
  png: 'image/png',
  jpeg: 'image/jpeg',
  jpg: 'image/jpeg',
  json: 'application/json'
}

export const useDownload = ({
  res,
  type = 'excel',
  fileName = '指标数据明细.xls',
  useBlob = true
}) => {
  let blob = res
  if (useBlob) {
    blob = new Blob([res], { type: typeToMime[type] }) // 构造一个blob对象来处理数据
  }
  if ('download' in document.createElement('a')) {
    // 支持a标签download的浏览器
    const link = document.createElement('a') // 创建a标签
    link.download = fileName // a标签添加属性
    link.style.display = 'none'
    link.href = useBlob ? URL.createObjectURL(blob) : blob
    document.body.appendChild(link)
    link.click() // 执行下载
    URL.revokeObjectURL(link.href) // 释放url
    document.body.removeChild(link) // 释放标签
  } else {
    // 其他浏览器
    navigator.msSaveBlob(blob, fileName)
  }
}
