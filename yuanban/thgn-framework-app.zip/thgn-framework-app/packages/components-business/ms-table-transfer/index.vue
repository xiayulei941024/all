<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-07-21 16:25:13
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-01 17:51:46
 * @Description: 
-->
<template>
  <div class="index-table-transfer">
    <!-- 左侧选择 -->
    <div class="left-box">
      <div class="top-title">
        <span>待选列表</span>
        <span class="title-right">{{ leftSelectedList.length }}/{{ leftIndexList.length }}项</span>
      </div>
      <div class="main-content">
        <!-- 树 -->
        <div class="index-tree">
          <ms-tabs-tree :frequency="frequency" @extract-index="extractIndex" />
        </div>
        <!-- 表 -->
        <div class="left-table">
          <div class="search-box">
            <input-search
              v-model:value="leftSearchValue"
              placeholder="请输入指标ID或者指标名称"
              @search="leftSearchIndex"
            />
          </div>
          <gl-table
            :loading="loading"
            :row-selection="leftRowSelection"
            :columns="columns"
            :data-source="leftIndexList"
            :pagination="false"
            :bordered="true"
            :rowKey="(record: any) => record.code"
          ></gl-table>
        </div>
      </div>
    </div>

    <!--中间按钮 -->
    <div class="middle-box"></div>
    <!-- 右侧选择 -->
    <div class="right-box">
      <div class="top-title">
        <span>已选列表</span>
        <span class="title-right"
          >{{ rightSelectedList.length }}/{{ rightIndexList.length }}项</span
        >
      </div>
      <!-- 表 -->
      <div class="right-table">
        <div class="search-box">
          <input-search
            v-model:value="rightSearchValue"
            placeholder="请输入指标ID或者指标名称"
            @search="rightSearchIndex"
          />
        </div>
        <gl-table
          :loading="loading"
          :row-selection="rightRowSelection"
          :columns="columns"
          :data-source="rightIndexList"
          :pagination="false"
          :bordered="true"
          :rowKey="(record: any) => record.code"
        ></gl-table>
        <div class="del-btn">
          <gl-button @click="multipleDel" :disabled="rightIndexList.length === 0">
            批量删除
          </gl-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { InputSearch } from '@mysteel-standard/components'
import { MsTabsTree } from '../index'
import useInitTable from './composables/use-init-table'
import { cloneDeep } from 'lodash-es'
//props
interface Props {
  indexList: any[]
  frequency?: string
}
const props = defineProps<Props>()

const loading = ref(false)
//表格初始化
const {
  columns,
  leftIndexList,
  rightIndexList,
  leftIndexList_temp,
  rightIndexList_temp,
  leftRowSelection,
  rightRowSelection,
  leftSelectedList,
  rightSelectedList,
  multipleDel
} = useInitTable()
const selectedNodes = ref<any>([])
//左侧表格
const extractIndex = (data: any, nodes: any) => {
  leftIndexList.value = data
  leftIndexList_temp.value = data
  selectedNodes.value = nodes
  leftSelectedList.value = []
  // console.log('selectedNodes.value', selectedNodes.value)
}

//左侧搜索
const leftSearchValue = ref('')
const leftSearchIndex = () => {
  leftIndexList.value = leftIndexList_temp.value
  if (leftSearchValue.value.trim() !== '') {
    leftSearchValue.value.split(' ').forEach((ele) => {
      leftIndexList.value = leftIndexList.value.filter(
        (item: { code: string; label: string }) =>
          item.code.includes(ele) || item.label.includes(ele)
      )
    })
  }
}
//右侧搜索
const rightSearchValue = ref('')
const rightSearchIndex = () => {
  rightIndexList.value = rightIndexList_temp.value
  if (rightSearchValue.value.trim() !== '') {
    rightSearchValue.value.split(' ').forEach((ele) => {
      rightIndexList.value = rightIndexList.value.filter(
        (item: { code: string; label: string }) =>
          item.code.includes(ele) || item.label.includes(ele)
      )
    })
  }
}

onMounted(() => {
  if (props.indexList && props.indexList.length > 0) {
    props.indexList.forEach(
      (item: { indexCode: string; indexName: string; code: string; label: string }) => {
        rightIndexList.value.push({
          code: item.indexCode || item.code,
          label: item.indexName || item.label
        })
        rightIndexList_temp.value = cloneDeep(rightIndexList.value)
      }
    )
  }
})
defineExpose({ rightIndexList, selectedNodes })
</script>

<style lang="scss" scoped>
.index-table-transfer {
  height: 584px;
  display: flex;
  .left-box {
    width: 844px;
    height: 586px;
    border: 1px solid #ddd;
    .main-content {
      display: flex;
      height: 550px;
      .index-tree {
        height: calc(100% - 6px);
        width: 310px;
        padding-top: 8px;
        padding-left: 8px;
        :deep(.tab-group) {
          padding: 0 3px;
        }
        border-right: 1px solid #ddd;
      }
      .left-table {
        // width: 500px;
        flex: 1;
        // padding-top: 8px;
        // padding-left: 4px;
        // margin-left: 4px;
        padding: 8px;
        // border-left: 1px solid #ddd;
        overflow: hidden;
        :deep(.gl-table-wrapper) {
          height: 475px;
          overflow: auto;
        }
      }
    }
  }
  .middle-box {
    width: 16px;
  }
  .right-box {
    width: 545px;
    border: 1px solid #dcdcdc;
    height: 586px;
    .right-table {
      width: 528px;
      padding: 8px;
      :deep(.gl-table-wrapper) {
        height: 431px;
        overflow: auto;
      }
      :deep(.gl-table-container) {
        // border-bottom: 1px solid #dcdcdc;
      }
    }
    .del-btn {
      width: 88px;

      height: 32px;
      background: #ffffff;
      border-radius: 3px;
      font-size: 14px;
      font-family:
        PingFangSC-Medium,
        PingFang SC;
      font-weight: bold;
      color: #333333;
      line-height: 20px;
      cursor: pointer;
      text-align: center;
      span {
        line-height: 32px;
      }
      margin-top: 8px;
    }
  }
  .top-title {
    height: 40px;
    line-height: 40px;
    background-color: #eee;
    padding: 0 16px;
    font-size: 14px;
    font-family:
      PingFangSC-Semibold,
      PingFang SC;
    font-weight: 600;
    .title-right {
      float: right;
      font-weight: 400;
      color: rgba(0, 0, 0, 0.9);
    }
  }
  .search-box {
    margin-bottom: 8px;
  }
  :deep(.gl-table-body) {
    height: 450px;
  }
  :deep(.gl-table table),
  :deep(.gl-table-container) {
    border-left: 0;
    border-radius: 0;
    table > thead > tr:first-child th:first-child {
      border-radius: 0;
    }
  }
  :deep(.gl-table-header) {
    > table {
      border-top: 0;
    }
  }
  :deep(.gl-table-thead) {
    tr > th {
      background-color: #eee;
    }
  }
  :deep(.gl-table-cell) {
    border-radius: 0 !important;
  }
}
</style>
