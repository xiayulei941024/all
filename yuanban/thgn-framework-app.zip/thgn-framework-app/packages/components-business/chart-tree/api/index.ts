import request from '@mysteel-standard/apis'
const apiMap = {
  // 图表管理目录
  queryChartsCatalogueList: {
    method: 'post',
    // url: '/database/catalogue/list' // 懒加载
    url: '/database/catalogue/listTree'
  },
  // 新增文件夹
  queryCatalogueAdd: {
    method: 'post',
    url: '/database/catalogue/add'
  },
  // 删除文件夹
  queryCatalogueDelete: {
    method: 'post',
    url: '/database/catalogue/delete'
  },
  // 重命名文件夹
  queryCatalogueRename: {
    method: 'post',
    url: '/database/catalogue/rename'
  },
  // 拖动
  queryCatalogueMove: {
    method: 'post',
    url: '/database/catalogue/move'
  }
}
export default request(apiMap)
