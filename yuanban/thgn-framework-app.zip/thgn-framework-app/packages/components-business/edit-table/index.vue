<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-21 11:42:32
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-28 17:22:06
 * @Description: 表格底层
-->
<template>
  <div class="editable-table">
    <table
      class="theme"
      :id="tableId"
      :style="`min-width:${data[0] && data[0].length * 60}px;
        width: 100%;
        position: relative;
        table-layout: fixed;
        border-collapse: collapse;
        border-spacing: 0;
        border: 0;
        word-wrap: break-word;
        user-select: none;`"
    >
      <tbody>
        <tr v-for="(rowCells, rowIndex) in tableCells" :key="rowIndex + rowCells">
          <td
            v-for="(cell, colIndex) in rowCells"
            v-show="!hideCells.includes(`${rowIndex}_${colIndex}` as never)"
            :key="cell.id + colIndex + cell"
            v-contextmenu="(el: any) => contextMenus(el, cell)"
            class="cell"
            :class="{
              selected:
                selectedCells?.includes(`${rowIndex}_${colIndex}`) && selectedCells?.length > 1,
              active: activedCell === `${rowIndex}_${colIndex}`
            }"
            :style="{
              borderStyle: outline.style,
              borderColor: outline.color,
              borderWidth: outline.width + 'px',
              backgroundColor: cell.itemStyle.backgroundColor,
              ...getFilterStyle(cell.filters, cell.text)
            }"
            :rowspan="cell.rowSpan"
            :colspan="cell.colSpan"
            :data-cell-index="`${rowIndex}_${colIndex}`"
            @mousedown="($event: any) => handleCellMousedown($event, rowIndex, colIndex)"
            @mouseenter="handleCellMouseenter(rowIndex, colIndex)"
          >
            <div
              class="cell-text-wrapper"
              :style="{
                ...getCommonStyle(cell.itemStyle),
                ...getFilterStyle(cell.filters, cell.text),
                backgroundColor: 'transparent'
              }"
            >
              <CustomTextarea
                v-if="editable && activedCell === `${rowIndex}_${colIndex}`"
                class="cell-text"
                :class="{ active: activedCell === `${rowIndex}_${colIndex}` }"
                contenteditable="plaintext-only"
                :value="cell.text"
                @update-value="(value) => handleInput(value, rowIndex, colIndex)"
                @insert-excel-data="(value) => insertExcelData(value, rowIndex, colIndex)"
              />
              <div v-else class="cell-text" v-html="formatText(cell.text)" />
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script setup lang="ts">
import CustomTextarea from './custom-textarea.vue'
import {
  getCommonStyle,
  getFilterStyle,
  formatText,
  createRandomCode
} from '@mysteel-standard/utils'
import { debounce, isEqual, cloneDeep } from 'lodash-es'
import useInitTable from './composables/use-init-table'
import { ref, watch, computed, Ref, onUnmounted, onMounted } from 'vue'
//props
interface Props {
  data: any[]
  width?: number
  outline: any
  editable: boolean
  tableId?: string
}
const props = withDefaults(defineProps<Props>(), {
  data: () => [],
  width: 0,
  outline: () => ({}),
  editable: true
})
//emits
interface Emits {
  (e: 'change', val: any): void
  (e: 'change-selected-cells', val: any): void
  (e: 'calculation-fn', indexItem: any, indicatorsType: any): void
}
const emits = defineEmits<Emits>()

const { INIT_ITEM } = useInitTable()
const isStartSelect: Ref = ref(false)
const startCell: Ref = ref([])
const endCell: Ref = ref([])
const hideCells: Ref = ref([])

const tableCells = computed({
  get() {
    return cloneDeep(props.data)
  },
  set(newData) {
    emits('change', newData)
  }
})

// 监听数据变化，合并单元格||取消合并单元格要把里面的内容隐藏||显示
watch(
  () => props.data,
  (cells) => {
    const hideCellArr = []
    for (let i = 0; i < cells.length; i++) {
      const rowCells: any = cells[i]
      for (let j = 0; j < rowCells.length; j++) {
        const cell = rowCells[j]
        if (cell.colSpan > 1 || cell.rowSpan > 1) {
          for (let row = i; row < i + cell.rowSpan; row++) {
            for (let col = row === i ? j + 1 : j; col < j + cell.colSpan; col++) {
              hideCellArr.push(`${row}_${col}`)
            }
          }
        }
      }
    }
    hideCells.value = hideCellArr
    return cells
  },
  { deep: true }
)

// 清除全部单元格的选中状态
// 表格处于不可编辑状态时也需要清除
const removeSelectedCells = () => {
  startCell.value = []
  endCell.value = []
}

// 当前选中的单元格集合
const selectedCells = computed(() => {
  if (!startCell.value.length) return []
  const [startX, startY] = startCell.value

  if (!endCell.value.length) return [`${startX}_${startY}`]
  const [endX, endY] = endCell.value

  if (startX === endX && startY === endY) return [`${startX}_${startY}`]

  const selectedCells = []

  const minX = Math.min(startX, endX)
  const minY = Math.min(startY, endY)
  const maxX = Math.max(startX, endX)
  const maxY = Math.max(startY, endY)

  for (let i = 0; i < tableCells.value.length; i++) {
    const rowCells = tableCells.value[i]
    for (let j = 0; j < rowCells.length; j++) {
      if (i >= minX && i <= maxX && j >= minY && j <= maxY) selectedCells.push(`${i}_${j}`)
    }
  }
  return selectedCells
})

watch(selectedCells, (value, oldValue) => {
  if (isEqual(value, oldValue)) return
  emits('change-selected-cells', selectedCells.value)
})

// 当前激活的单元格：当且仅当只有一个选中单元格时，该单元格为激活的单元格
const activedCell = computed(() => {
  if (selectedCells.value.length > 1) return null
  return selectedCells.value[0]
})

// 当前选中的单元格位置范围
const selectedRange = computed(() => {
  if (!startCell.value.length) return null
  const [startX, startY] = startCell.value

  if (!endCell.value.length) return { row: [startX, startX], col: [startY, startY] }
  const [endX, endY] = endCell.value

  if (startX === endX && startY === endY) return { row: [startX, startX], col: [startY, startY] }

  const minX = Math.min(startX, endX)
  const minY = Math.min(startY, endY)
  const maxX = Math.max(startX, endX)
  const maxY = Math.max(startY, endY)

  return {
    row: [minX, maxX],
    col: [minY, maxY]
  }
})

// 设置选中单元格状态（鼠标点击或拖选）
const handleMouseup = () => {
  isStartSelect.value = false
}

const handleCellMousedown = (e: { button: number }, rowIndex: any, colIndex: any) => {
  if (e.button === 0) {
    endCell.value = []
    isStartSelect.value = true
    startCell.value = [rowIndex, colIndex]
  }
}

const handleCellMouseenter = (rowIndex: any, colIndex: any) => {
  if (!isStartSelect.value) return
  endCell.value = [rowIndex, colIndex]
}

onMounted(() => {
  document.addEventListener('mouseup', handleMouseup)
})
onUnmounted(() => {
  document.removeEventListener('mouseup', handleMouseup)
})

// 判断某位置是否为无效单元格（被合并掉的位置）
const isHideCell = (rowIndex: number, colIndex: number) =>
  hideCells.value.includes(`${rowIndex}_${colIndex}`)

// 选中指定的列
const selectCol = (index: number) => {
  const maxRow = tableCells.value.length - 1
  startCell.value = [0, index]
  endCell.value = [maxRow, index]
}

// 选中指定的行
const selectRow = (index: number) => {
  const maxCol = tableCells.value[index].length - 1
  startCell.value = [index, 0]
  endCell.value = [index, maxCol]
}

// 选中全部单元格
const selectAll = () => {
  const maxRow = tableCells.value.length - 1
  const maxCol = tableCells.value[maxRow].length - 1
  startCell.value = [0, 0]
  endCell.value = [maxRow, maxCol]
}

// 删除一行
const deleteRow = (rowIndex: number) => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  const targetCells = tableCells.value[rowIndex]
  const hideCellsPos = []
  for (let i = 0; i < targetCells.length; i++) {
    if (isHideCell(rowIndex, i)) hideCellsPos.push(i)
  }

  for (const pos of hideCellsPos) {
    for (let i = rowIndex; i >= 0; i--) {
      if (!isHideCell(i, pos)) {
        _tableCells[i][pos].rowSpan = _tableCells[i][pos].rowSpan - 1
        break
      }
    }
  }

  _tableCells.splice(rowIndex, 1)
  tableCells.value = _tableCells
}

// 删除一列
const deleteCol = (colIndex: number) => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  const hideCellsPos = []
  for (let i = 0; i < tableCells.value.length; i++) {
    if (isHideCell(i, colIndex)) hideCellsPos.push(i)
  }

  for (const pos of hideCellsPos) {
    for (let i = colIndex; i >= 0; i--) {
      if (!isHideCell(pos, i)) {
        _tableCells[pos][i].colSpan = _tableCells[pos][i].colSpan - 1
        break
      }
    }
  }

  tableCells.value = _tableCells.map((item: any[]) => {
    item.splice(colIndex, 1)
    return item
  })
}

// 插入一行
const insertRow = (rowIndex: number) => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  const rowCells = []
  for (let i = 0; i < _tableCells[0].length; i++) {
    rowCells.push({
      ...INIT_ITEM(''),
      id: createRandomCode()
    })
  }
  _tableCells.splice(rowIndex, 0, rowCells)
  tableCells.value = _tableCells
  removeSelectedCells()
}

// 插入一列
const insertCol = (colIndex: number) => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  _tableCells.forEach((item: any[], index: number) => {
    const cell = {
      ...INIT_ITEM(index === 0 ? '#F4F4F4' : ''),
      id: createRandomCode()
    }
    item.splice(colIndex, 0, cell)
  })
  tableCells.value = _tableCells
  // 插入列后重新排宽度,恢复默认等宽的样式
}

// 填充指定的行/列数
const fillTable = (rowCount: number, colCount: number) => {
  let _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  if (rowCount) {
    const newRows = []
    for (let i = 0; i < rowCount; i++) {
      const rowCells = []
      for (let j = 0; j < _tableCells[0].length; j++) {
        rowCells.push({
          ...INIT_ITEM(''),
          id: createRandomCode()
        })
      }
      newRows.push(rowCells)
    }
    _tableCells = [..._tableCells, ...newRows]
  }
  if (colCount) {
    _tableCells = _tableCells.map((item: any) => {
      const cells = []
      for (let i = 0; i < colCount; i++) {
        const cell = {
          ...INIT_ITEM(''),
          id: createRandomCode()
        }
        cells.push(cell)
      }
      return [...item, ...cells]
    })
  }

  tableCells.value = _tableCells
}

// 合并单元格
const mergeCells = () => {
  const [startX, startY] = startCell.value
  const [endX, endY] = endCell.value

  const minX = Math.min(startX, endX)
  const minY = Math.min(startY, endY)
  const maxX = Math.max(startX, endX)
  const maxY = Math.max(startY, endY)

  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  _tableCells[minX][minY].rowSpan = maxX - minX + 1
  _tableCells[minX][minY].colSpan = maxY - minY + 1

  tableCells.value = _tableCells
  removeSelectedCells()
}

// 拆分单元格
const splitCells = (rowIndex: number, colIndex: number) => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))
  // _tableCells[rowIndex][colIndex].rowSpan = 1
  // _tableCells[rowIndex][colIndex].colSpan = 1
  selectedCells.value.map((item) => {
    const rowIndex = +item.split('_')[0]
    const colIndex = +item.split('_')[1]
    _tableCells[rowIndex][colIndex].rowSpan = 1
    _tableCells[rowIndex][colIndex].colSpan = 1
    return true
  })

  tableCells.value = _tableCells
  removeSelectedCells()
}

// 清空选中单元格内的文字
const clearSelectedCellText = () => {
  const _tableCells = JSON.parse(JSON.stringify(tableCells.value))

  for (let i = 0; i < _tableCells.length; i++) {
    for (let j = 0; j < _tableCells[i].length; j++) {
      if (selectedCells.value.includes(`${i}_${j}`)) {
        _tableCells[i][j].text = ''
      }
    }
  }
  tableCells.value = _tableCells
}

// 单元格文字输入时更新表格数据
const handleInput = debounce(
  (value: any, rowIndex: string | number, colIndex: string | number) => {
    tableCells.value[rowIndex][colIndex].text = value
    emits('change', [...tableCells.value])
  },
  300,
  { trailing: true }
)

// 插入来自Excel的数据，表格的行/列数不够时自动补足
const insertExcelData = (data: string | any[], rowIndex: number, colIndex: number) => {
  const maxRow = data.length
  const maxCol = data[0].length

  let fillRowCount = 0
  let fillColCount = 0
  if (rowIndex + maxRow > tableCells.value.length) {
    fillRowCount = rowIndex + maxRow - tableCells.value.length
  }
  if (colIndex + maxCol > tableCells.value[0].length) {
    fillColCount = colIndex + maxCol - tableCells.value[0].length
  }
  if (fillRowCount || fillColCount) fillTable(fillRowCount, fillColCount)

  nextTick(() => {
    for (let i = 0; i < maxRow; i++) {
      for (let j = 0; j < maxCol; j++) {
        if (tableCells.value[rowIndex + i][colIndex + j]) {
          tableCells.value[rowIndex + i][colIndex + j].text = data[i][j]
        }
      }
    }
    emits('change', [...tableCells.value])
  })
}

// 获取有效的单元格（排除掉被合并的单元格）
const getEffectiveTableCells = () => {
  const effectiveTableCells = []

  for (let i = 0; i < tableCells.value.length; i++) {
    const rowCells = tableCells.value[i]
    const _rowCells = []
    for (let j = 0; j < rowCells.length; j++) {
      if (!isHideCell(i, j)) _rowCells.push(rowCells[j])
    }
    if (_rowCells.length) effectiveTableCells.push(_rowCells)
  }

  return effectiveTableCells
}

// 检查是否可以删除行和列：有效的行/列数大于1
const checkCanDeleteRowOrCol = () => {
  const effectiveTableCells = getEffectiveTableCells()
  const canDeleteRow = effectiveTableCells.length > 1
  const canDeleteCol = effectiveTableCells[0].length > 1

  return { canDeleteRow, canDeleteCol }
}

// 检查是否可以合并或拆分
// 必须多选才可以合并
// 必须单选且所选单元格为合并单元格才可以拆分
const checkCanMergeOrSplit = (rowIndex: number, colIndex: number) => {
  const isMultiSelected = selectedCells.value.length > 1
  // const targetCell = tableCells.value[rowIndex][colIndex]
  let allUnMerge = true // 判断选择的单元格是否都是未合并的
  selectedCells.value.map((item) => {
    const rowIndex = +item.split('_')[0]
    const colIndex = +item.split('_')[1]
    const targetCell = tableCells.value[rowIndex][colIndex]
    if (targetCell.rowSpan > 1 || targetCell.colSpan > 1) {
      allUnMerge = false
    }
  })
  const canMerge = allUnMerge && isMultiSelected // 选中的单元格都是未合并的且是多个
  const canSplit = !allUnMerge && !canMerge // 选中的单元格有合并了的

  return { canMerge, canSplit }
}
//指标计算
const calculation = (indexItem: any, indicatorsType: number) => {
  emits('calculation-fn', indexItem, indicatorsType)
}

const contextMenus = (el: { dataset: { cellIndex: any } }, cell: any) => {
  if (!props.editable) return
  const index = el?.dataset?.cellIndex
  const rowIndex = +index.split('_')[0]
  const colIndex = +index.split('_')[1]
  const { indexItem } = tableCells.value[rowIndex][colIndex]
  const { isTimeFilter } = tableCells.value[rowIndex][colIndex]
  const { filters } = tableCells.value[rowIndex][colIndex]
  if (!selectedCells.value.includes(`${rowIndex}_${colIndex}`)) {
    startCell.value = [rowIndex, colIndex]
    endCell.value = []
  }

  const { canMerge, canSplit } = checkCanMergeOrSplit(rowIndex, colIndex)
  const { canDeleteRow, canDeleteCol } = checkCanDeleteRowOrCol()

  return ref([
    {
      text: '插入列',
      children: [
        { text: '到左侧', handler: () => insertCol(colIndex) },
        { text: '到右侧', handler: () => insertCol(colIndex + 1) }
      ]
    },
    {
      text: '插入行',
      children: [
        {
          text: '到上方',
          disable: rowIndex === 0,
          handler: () => insertRow(rowIndex)
        },
        { text: '到下方', handler: () => insertRow(rowIndex + 1) }
      ]
    },
    {
      text: '设置计算公式',
      disable: isTimeFilter || selectedCells.value.length > 1,
      children: [
        {
          text: '同环比',
          disable: isTimeFilter || !indexItem.indexCode || selectedCells.value.length > 1,
          handler: () => calculation(indexItem, 2)
        },
        {
          text: '累计求和',
          disable: isTimeFilter || !indexItem.indexCode || selectedCells.value.length > 1,
          handler: () => calculation(indexItem, 4)
        }
      ]
    },
    {
      text: '添加数据筛选器',
      disable: isTimeFilter,
      handler: () => calculation(indexItem, 6)
    },
    {
      text: '添加时间筛选器',
      disable: isTimeFilter || filters.length,
      handler: () => calculation(indexItem, 9)
    },
    {
      text: '移除时间筛选器',
      disable: !isTimeFilter,
      handler: () => calculation(indexItem, 10)
    },
    {
      text: '删除列',
      disable: !canDeleteCol,
      handler: () => deleteCol(colIndex)
    },
    {
      text: '删除行',
      disable: !canDeleteRow,
      handler: () => deleteRow(rowIndex)
    },
    { divider: true },
    {
      text: '排序',
      children: [
        {
          text: '从大到小',
          handler: () => calculation(indexItem, 7)
        },
        {
          text: '从小到大',
          handler: () => calculation(indexItem, 8)
        }
      ]
    },
    { divider: true },
    {
      text: '合并单元格',
      disable: !canMerge,
      handler: mergeCells
    },
    {
      text: '取消合并单元格',
      disable: !canSplit,
      handler: () => splitCells(rowIndex, colIndex)
    },
    { divider: true },
    {
      text: '选中当前列',
      handler: () => selectCol(colIndex)
    },
    {
      text: '选中当前行',
      handler: () => selectRow(rowIndex)
    },
    {
      text: '选中全部单元格',
      handler: selectAll
    }
  ])
}
</script>
<style lang="scss" scoped>
$themeColor: #d14424;
$tborderColor: #eee;
$tlightGray: #f9f9f9;
$textColor: #41464b;
//$tboxShadow: 3px 3px 3px rgba(#000, 0.15);
$ttransitionDelay: 0.2s;
$ttransitionDelayFast: 0.1s;
$ttransitionDelaySlow: 0.3s;
$tborderRadius: 2px;

//默认表头背景文字颜色表身背景颜色文字颜色
$headerTextColor: #ffffff;
$headerBgColor: #005bac;
$BodyTextColor: #000000;
$bodyBgColor: #ffffff;

.editable-table {
  position: relative;
  user-select: none;
}

.theme {
  tr .cell {
    background-color: $bodyBgColor;
    color: $BodyTextColor;
  }
  tr:nth-child(1) .cell {
    color: $headerTextColor;
  }
  .row-header {
    tr:first-child .cell {
      background-color: var(--themeColor);
    }
  }
  .row-footer {
    tr:last-child .cell {
      background-color: var(--themeColor);
    }
  }
  .col-header {
    tr .cell:first-child {
      background-color: var(--themeColor);
    }
  }
  .col-footer {
    tr .cell:last-child {
      background-color: var(--themeColor);
    }
  }
}
//==table样式==
table {
  width: 100%;
  position: relative;
  table-layout: fixed;
  border-collapse: collapse;
  border-spacing: 0;
  border: 0;
  word-wrap: break-word;
  user-select: none;

  --themeColor: $themeColor;
  --subThemeColor1: $themeColor;
  --subThemeColor2: $themeColor;

  // ========
  tr {
    height: 36px;
  }
  .cell {
    position: relative;
    white-space: normal;
    word-wrap: break-word;
    vertical-align: middle;
    font-size: 14px;
    cursor: default;
  }
  .selected::after {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: #80add5;
    opacity: 0.5;
  }
  .cell-text {
    padding: 5px;
    user-select: none;
    cursor: text;
  }
  .active {
    user-select: text;
  }
}

// 右键菜单
.menuWrap {
  margin: 0px;
  padding: 5px 0px;
  background-color: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 4px;
  list-style: none;
  font-size: 14px;
  white-space: nowrap;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  position: relative;
  p {
    margin: 0px !important;
    padding: 0px !important;
  }
  .menuItem {
    cursor: pointer;
    padding: 2px 10px;
    font-size: 12px;
    p {
      font-size: 12px;
    }
  }
  .menuItem:hover {
    background: #ef5350;
    p {
      color: #fff;
    }
    .secondaryMenuWrap {
      display: block;
    }
  }
  //二级菜单
  .secondaryMenuWrap {
    display: none;
    position: absolute;
    top: 0px;
    right: -59px;
    margin: 0px;
    padding: 5px 0px;
    background-color: #fff;
    border: 1px solid #e8e8e8;
    border-radius: 4px;
    list-style: none;
    font-size: 14px;
    white-space: nowrap;
    cursor: pointer;
    z-index: 2800;
    -webkit-tap-highlight-color: transparent;
    .secondaryMenuItem {
      cursor: pointer;
      padding: 2px 10px;
      font-size: 12px;
    }
    .secondaryMenuItem:hover {
      background: #ef5350;
      color: #fff;
    }
  }
}
</style>
