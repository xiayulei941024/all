/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 14:06:15
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-25 17:01:22
 * @Description:
 */
export { default as MsTabsTree } from './index.vue'
