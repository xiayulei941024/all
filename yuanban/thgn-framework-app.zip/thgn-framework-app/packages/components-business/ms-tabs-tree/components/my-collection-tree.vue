<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 11:23:44
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2024-11-28 16:47:04
 * @Description: 
-->
<template>
  <!-- 我的收藏 -->
  <gl-spin :spinning="collectionTreeLoading" style="margin-top: 50px">
    <ms-tree
      v-model:expandedKeys="myCollectionKeys"
      autoExpandParent
      block-node
      :tree-data="myCollectionTreeData"
      :fieldNames="myCollectionFields"
      @select="myCollectionNodeClick"
      @expand="myCollectionTreeExpand"
    />
  </gl-spin>
</template>
<script setup lang="ts">
import { MsTree } from '@mysteel-standard/components'
import useMyCollectionTree from '../composables/use-my-collection-tree'
interface Emits {
  (e: 'extract-index', nodes: any[]): void //添加提取指标
}
const emits = defineEmits<Emits>()
//props
interface Props {
  frequency?: string
}
const props = defineProps<Props>()
// 我的收藏树
const {
  treeData: myCollectionTreeData,
  replaceFields: myCollectionFields,
  getTreeData: getMyCollectionTree,
  treeLoading: collectionTreeLoading,
  nodeClick: myCollectionNodeClick,
  treeExpand: myCollectionTreeExpand,
  expandedKeys: myCollectionKeys
} = useMyCollectionTree(emits, true, props.frequency)

defineExpose({ getMyCollectionTree })
</script>
