/*
 * @Autor: zhouwanwan
 * @Date: 2023-06-14 10:38:19
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-01 11:34:46
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  //收藏的指标树
  getCollectIndexList: {
    method: 'get',
    url: '/database/indexCollect/getCollectIndexList'
  },
  // 收藏指标
  collectIndexList: {
    method: 'post',
    url: '/database/indexCollect/collectIndexList'
  },
  /* mysteel tree*/
  getCatalogTree: {
    method: 'post',
    url: '/database/datacatalog/getCatalogTree'
  },
  getCatalogNode: {
    method: 'post',
    url: '/database/datacatalog/getCatalogNode'
  }
}
export default request(apiMap)
