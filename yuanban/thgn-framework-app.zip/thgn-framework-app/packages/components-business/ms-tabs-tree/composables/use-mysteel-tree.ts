/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-25 13:53:19
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 17:17:06
 * @Description:
 */
import api from '../api/index'
import { useTreeExpand } from '@mysteel-standard/hooks'
export default (emits: any) => {
  const treeData = ref([])
  const replaceFields = ref({
    children: 'children',
    title: 'label',
    key: 'id'
  })

  const treeLoading = ref(false)
  const mySteelSelectedNodes = ref<any>([])
  const getTreeData = async () => {
    treeLoading.value = true
    const { err, res } = await api.getCatalogTree({
      dbType: 0
    })
    treeLoading.value = false
    if (!err && res) {
      const { data } = res
      treeData.value = data || []
    }
  }

  const onLoadData = (treeNode: any, isLazyLoad = true) => {
    const { dataRef } = treeNode
    if (dataRef.isEnd && isLazyLoad) return
    return new Promise((resolve: any) => {
      const params = {
        dbType: 0,
        frameId: Number(dataRef.id)
      }
      api.getCatalogNode(params).then((data: { err: any; res: any }) => {
        const { err, res } = data
        if (!err && res) {
          const { data } = res
          data.forEach((item: { isLeaf: boolean; isEnd: number }) => (item.isLeaf = !!item.isEnd))
          //判断目录和指标
          if (data.length > 0 && data[0].type === 2) {
            resolve()
            const addData = data.map((item: any) => {
              const obj = {
                ...item,
                dbType: 0
              }
              return obj
            })
            emits('extract-index', addData, mySteelSelectedNodes.value)
          } else {
            dataRef.children = data || []
            treeData.value = [...treeData.value]
            resolve()
          }
        }
      })
    })
  }

  const { expandedKeys, treeExpand, nodeExpand } = useTreeExpand()
  //树选中
  const nodeClick = (
    selectedKeys: number[],
    {
      node,
      selectedNodes
    }: {
      node: {
        isLeaf: boolean
        isEnd: boolean
      }
      selectedNodes: any[]
    }
  ) => {
    mySteelSelectedNodes.value = [...mySteelSelectedNodes.value, node]
    const { isEnd } = node
    if (isEnd) {
      onLoadData(node, false)
    } else {
      nodeExpand(node)
    }
  }
  return {
    treeData,
    replaceFields,
    treeLoading,
    onLoadData,
    getTreeData,
    expandedKeys,
    nodeClick,
    treeExpand
  }
}
