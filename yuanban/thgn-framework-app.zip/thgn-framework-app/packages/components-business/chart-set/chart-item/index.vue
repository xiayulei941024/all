<!--
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 09:04:34
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-21 16:50:23
 * @Description: 
-->
<template>
  <div class="element-wrapper" :style="{ borderWidth: isPreview ? 0 : '1px' }">
    <slot name="title"></slot>
    <div
      class="operate"
      v-if="showOperation && (elementName === 'table' || elementName === 'chart')"
    >
      <span>
        {{ element.name || element?.propsValue?.param?.name }}
      </span>

      <gl-space :size="10" v-if="showOperation">
        <gl-tooltip
          class="item"
          title="编辑"
          placement="top"
          v-if="isConfig && element?.propsValue?.param?.chartType === 2"
        >
          <!-- 我的图表库的图才可以修改chartType === 2， 配置页面展示编辑 -->
          <gl-button @click="handleEdit(element)" size="small">
            <icon name="icon-edit" color="#333" />
          </gl-button>
        </gl-tooltip>
        <gl-tooltip class="item" title="收藏" placement="top" v-if="collectAble">
          <gl-button @click="handleCollect(element)" size="small">
            <icon name="icon-wodeshoucang" color="#333" />
          </gl-button>
        </gl-tooltip>
        <gl-tooltip class="item" title="下载" placement="top" v-if="!isConfig && !isPreview">
          <gl-button @click="handleDownload(element, elementName)" size="small">
            <icon name="icon-download" color="#333" size="14" />
          </gl-button>
        </gl-tooltip>
        <gl-tooltip class="item" title="全屏" placement="top" v-if="!isPreview">
          <gl-button @click="enlargeClick(element)" size="small">
            <icon name="icon-full" color="#333" />
          </gl-button>
        </gl-tooltip>
      </gl-space>
    </div>
    <gl-spin :spinning="loading">
      <div
        class="filters"
        v-if="
          showFilters &&
          curEl?.componentName === 'chart' &&
          !seasonChecked &&
          curEl?.id !== 'chart-radar'
        "
      >
        <gl-form layout="inline">
          <gl-form-item label="指标筛选">
            <ms-collapse-select
              v-model:selected="indexValue"
              mode="multiple"
              placeholder="请选择"
              :max-tag-count="1"
              :options="options"
              :style="{
                width: '250px'
              }"
            />
          </gl-form-item>
          <gl-form-item label="日期">
            <calendar-picker :form="dateForm" @change-time="handleDateChange"></calendar-picker>
          </gl-form-item>
        </gl-form>
      </div>
      <chart-component
        v-bind="{
          element,
          seasonChecked,
          curEl,
          indexDataSeason,
          tableData,
          isPhone
        }"
        :style="{
          height: isPreview ? 'calc(100vh - 334px)' : '100%',
          flex: isPreview ? 'unset' : 1
        }"
      />
    </gl-spin>
    <!-- 收藏 -->
    <collect-chart-modal
      v-if="collectVisible"
      v-model:visible="collectVisible"
      :title="treeTitle"
      @handle-submit="handleSubmit"
    />
    <!-- 编辑弹窗 -->
    <full-modal v-if="editVisible" v-model:visible="editVisible" :show-submit="false">
      <ms-diagram
        :chartId="chartId"
        :type="2"
        @sure-save-chart="sureSaveChart"
        :extractData="extractData"
        @extract="getExtractData"
      />
    </full-modal>
    <!-- 全屏 -->
    <full-modal v-model:visible="elementVisible" :show-submit="false">
      <chart-set-full is-large isPreview :element="chartSetItem" />
    </full-modal>
  </div>
</template>
<script setup lang="ts">
import ChartComponent from './chart-component.vue'
import { FullModal, Icon, MsCollapseSelect } from '@mysteel-standard/components'
import MsDiagram from '../../ms-diagram/index.vue'
import CollectChartModal from './collect-chart-modal.vue'
import useChartItem from '../composables/use-chart-item'
import useButtonOperation from '../composables/use-button-operation'
import ChartSetFull from '../../chart-set/chart-item/index.vue'
import CalendarPicker from './calendar-picker.vue'
interface Props {
  element: any
  isPreview?: boolean //预览
  collectAble?: boolean //是否可以收藏
  isConfig?: boolean //配置
  showOperation?: boolean //是否显示操作栏
  showFilters?: boolean //是否显示筛选栏
  isPhone?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  isPreview: false,
  collectAble: false,
  isConfig: false,
  showOperation: true,
  showFilters: true,
  isPhone: false
})

//获取、更新图表数据
const {
  loading,
  seasonChecked,
  indexDataSeason,
  tableData,
  curEl,
  indexValue,
  options,
  handleDateChange,
  elementName,
  initChart,
  state,
  dateForm
} = useChartItem(props)
//操作栏
const {
  //编辑图表
  extractData,
  getExtractData,
  chartId,
  editVisible,
  //图表收藏
  collectVisible,
  treeTitle,
  handleCollect,
  handleSubmit,
  handleEdit,
  handleDownload,
  //全屏
  enlargeClick,
  elementVisible,
  chartSetItem
} = useButtonOperation(state)
const sureSaveChart = () => {
  editVisible.value = false
  initChart(chartId.value)
}

defineExpose({ handleDownload, enlargeClick })
</script>

<style scoped lang="scss">
$borderColor: #e8e8e8;
.element-wrapper {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid $borderColor;
  background: transparent;
  .operate {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 52px;
    border-bottom: 1px solid $borderColor;
    padding: 0 16px;
    flex-shrink: 0;
    .gl-btn-sm {
      width: 28px;
      height: 28px;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .gl-space {
      height: 24px;
    }
  }
}
.gl-spin-nested-loading {
  height: calc(100% - 52px);
  :deep(.gl-spin-container) {
    height: 100%;
  }
}
.filters {
  height: 32px;
  margin: 16px 16px 0;

  .gl-form {
    height: 100%;
  }
}
</style>
