/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-09 17:35:30
 * @Description:
 */
import { message } from 'gl-design-vue'
import api from '../api/index'
export default () => {
  const collectVisible = ref(false)
  const treeTitle = ref('')
  const chartId = ref()
  const handleCollect = (data: any) => {
    collectVisible.value = true
    treeTitle.value = '收藏图表'
    chartId.value = data.id || data.propsValue?.param?.id
  }
  const handleSubmit = async (data: any) => {
    const params = {
      catalogueId: data.id,
      chartId: chartId.value,
      type: 1
    }
    const { res, err } = await api.collectChart(params)
    if (!err && res) {
      message.success(res.message)
      collectVisible.value = false
    }
  }
  return {
    collectVisible,
    treeTitle,
    handleCollect,
    handleSubmit
  }
}
