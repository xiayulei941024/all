/*
 * @Autor: zhouwanwan
 * @Date: 2023-07-21 17:31:24
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-27 17:23:17
 * @Description:
 */
import request from '@mysteel-standard/apis'
const apiMap = {
  // 收藏图表
  collectChart: {
    method: 'post',
    url: '/database/chart/collect'
  },
  // 查询图表
  queryChartInfo: {
    method: 'post',
    url: '/database/chart/info'
  }
}
export default request(apiMap)
