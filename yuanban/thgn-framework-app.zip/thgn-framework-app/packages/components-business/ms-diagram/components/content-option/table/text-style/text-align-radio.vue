<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-07-03 10:25:00
 * @Description: 字体布局组件
-->
<template>
  <ul class="position-radio text-align-radio">
    <li
      v-for="item in posArr"
      :key="item"
      :class="['radio-item', item, active === item ? 'active' : '']"
      @click="handleClick(item)"
    >
      <component :is="components[`align-${item}-outlined`]" />
    </li>
  </ul>
</template>

<script setup lang="ts">
import { AlignLeftOutlined, AlignCenterOutlined, AlignRightOutlined } from '@ant-design/icons-vue'
const components: any = {
  'align-left-outlined': AlignLeftOutlined,
  'align-center-outlined': AlignCenterOutlined,
  'align-right-outlined': AlignRightOutlined
}
//props
interface Props {
  value: string
}
const props = withDefaults(defineProps<Props>(), { value: '' })
//emits
interface Emits {
  (e: 'update:value', val: any): void
  (e: 'change-style', val: any): void
}
const emits = defineEmits<Emits>()

const posArr = ref(['left', 'center', 'right'])

const active = computed(() => {
  return props.value
})

const handleClick = (item: string) => {
  emits('update:value', item)
  emits('change-style', { textAlign: item })
}
</script>

<style lang="scss" scoped>
.position-radio {
  display: flex;
  .radio-item {
    width: 32px;
    height: 32px;
    line-height: 32px;
    text-align: center;
    border: 1px solid #eeeeee;
    cursor: pointer;
    &:first-child {
      border-radius: 2px 0px 0px 2px;
    }
    &:last-child {
      border-radius: 0px 2px 2px 0px;
    }

    &:not(:first-child) {
      border-left: none;
    }

    &.active {
      background-color: #e5eff8;
      border-color: #80add5;
      border: 1px solid #80add5;
      .icon {
        color: #005bac;
      }
    }
  }
}
</style>
