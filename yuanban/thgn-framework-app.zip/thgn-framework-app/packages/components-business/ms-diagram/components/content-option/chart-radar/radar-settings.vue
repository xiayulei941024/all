<template>
  <div class="radar-setting">
    <gl-collapse
      accordion
      expand-icon-position="left"
      :bordered="false"
      v-model:activeKey="collapseKey"
    >
      <template #expandIcon="{ isActive }">
        <caret-right-outlined :rotate="isActive ? 90 : 0" />
      </template>
      <gl-collapse-panel v-for="(item, index) in indexList" :key="index" :disabled="item.disabled">
        <template #header>
          <gl-checkbox v-model:checked="item.checked"></gl-checkbox>
          <gl-tooltip placement="top" :title="item.xAxisValue" trigger="hover">
            <span class="option-collapse-title ellipsis"> {{ item.xAxisValue }}</span>
          </gl-tooltip>
        </template>
        <gl-form
          :model="item"
          :colon="false"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 18 }"
          label-align="left"
        >
          <gl-form-item label="线型">
            <gl-select v-model:value="item.lineStyleType" class="wid-240" placeholder="请选择线型">
              <gl-select-option v-for="i in lineStyleTypeArr" :key="i.value" :value="i.value">{{
                i.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="宽度">
            <gl-input-number
              v-model:value="item.lineStyleWidth"
              :min="1"
              :step="1"
              :precision="0"
              placeholder="请输入宽度"
              class="wid-240"
            />
          </gl-form-item>
          <gl-form-item label="颜色">
            <color-input v-model:value="item.itemColor" class="wid-240" />
          </gl-form-item>
          <gl-form-item label="数据格式">
            <gl-select v-model:value="item.dataFormat" class="wid-240" placeholder="请选择线型">
              <gl-select-option v-for="i in dataFormatArr" :key="i.value" :value="i.value">{{
                i.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
          <gl-form-item label="数据频度">
            <gl-select v-model:value="item.dataFrequency" class="wid-240" placeholder="请选择线型">
              <gl-select-option v-for="i in dataFrequencyArr" :key="i.value" :value="i.value">{{
                i.label
              }}</gl-select-option>
            </gl-select>
          </gl-form-item>
        </gl-form>
      </gl-collapse-panel>
    </gl-collapse>
  </div>
</template>

<script setup lang="ts">
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { ColorInput } from '@mysteel-standard/components'
import { BORDER_TYPE, DATA_FORMAT_LIST, DATA_FREQUENCY_LIST } from '../../../constants'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const dataFormatArr = ref(DATA_FORMAT_LIST)
const dataFrequencyArr = ref(DATA_FREQUENCY_LIST)
const lineStyleTypeArr = ref(BORDER_TYPE)

const indexList = computed(() => props.contentOption.radarSettings)
//选中指标
const collapseKey = ref(0)
</script>
<style lang="scss" scoped>
.radar-setting {
  .option-collapse-title {
    display: inline-block;
    max-width: 300px;
    vertical-align: middle;
    margin-left: 8px;
  }
}
</style>
