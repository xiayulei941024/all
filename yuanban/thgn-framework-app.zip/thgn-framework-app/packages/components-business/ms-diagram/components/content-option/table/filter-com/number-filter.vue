<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-04 19:46:18
 * @Description: 范围过滤框
-->
<template>
  <span class="number-filter">
    <filter-with-relation
      :relation="filterData.relation"
      @change="handleChange('relation', $event)"
    >
      <gl-input
        class="no-right-radius"
        :placeholder="placeholder"
        :value="filterData.value"
        @change="handleChange('value', $event.target.value)"
      />
    </filter-with-relation>
  </span>
</template>

<script lang="ts" setup>
import FilterWithRelation from './filter-with-relation.vue'
//props
interface Props {
  filterData: any
  placeholder?: string
}
const props = withDefaults(defineProps<Props>(), {
  filterCollection: () => {},
  placeholder: ''
})
//emits
interface Emits {
  (e: 'update:filterData', val: any): void
}
const emits = defineEmits<Emits>()

const collection = ref({
  value: 0,
  relation: 'gt'
})

watch(
  () => props.filterData,
  (newVal) => {
    collection.value = Object.assign({}, newVal)
  },
  { deep: true, immediate: true }
)
const handleChange = (key: string, value: string) => {
  emits('update:filterData', { ...collection.value, [key]: value })
}
</script>

<style lang="scss" scoped>
.no-right-radius {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
</style>
