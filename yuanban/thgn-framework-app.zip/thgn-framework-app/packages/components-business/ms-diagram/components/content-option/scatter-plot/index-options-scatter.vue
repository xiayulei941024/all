<!--
 * @Author: zouchuanfeng
 * @LastEditTime: 2023-07-07 17:26:22
 * @Description: 指标chart配置
-->
<template>
  <div class="index-options-scatter">
    <gl-collapse
      accordion
      expand-icon-position="left"
      :bordered="false"
      v-model:activeKey="collapseKey"
    >
      <template #expandIcon="{ isActive }">
        <caret-right-outlined :rotate="isActive ? 90 : 0" />
      </template>
      <gl-collapse-panel v-for="(item, index) in indexList" :key="index">
        <template #header>
          <span @click.stop="() => {}">
            <gl-checkbox v-model:checked="item.checked"></gl-checkbox>
          </span>
          <gl-tooltip placement="top" :title="item.legendName" trigger="hover">
            <span class="option-collapse-title ellipsis"> {{ item.legendName }}</span>
          </gl-tooltip>
        </template>
        <gl-form
          :model="item"
          :colon="false"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 18 }"
          label-align="left"
        >
          <gl-form-item label="名称">
            <gl-input v-model:value="item.labelName" class="wid-240" placeholder="请输入名称" />
          </gl-form-item>
          <gl-form-item label="半径">
            <gl-input-number
              v-model:value="item.symbolSize"
              :min="0"
              class="wid-240"
              placeholder="请输入半径"
            />
          </gl-form-item>

          <gl-form-item label="颜色">
            <color-input v-model:value="item.itemColor" class="wid-240" />
          </gl-form-item>
          <gl-form-item label="关联指标">
            <gl-select
              v-model:value="item.relatedIndexCode"
              class="wid-240"
              placeholder="请选择关联指标"
              allow-clear
            >
              <gl-select-option
                v-for="relation in relations(item)"
                :key="relation.indexCode"
                :value="relation.indexCode"
                >{{ relation.legendName }}</gl-select-option
              >
            </gl-select>
          </gl-form-item>
          <gl-form-item label="坐标轴">
            <gl-radio-group v-model:value="item.axis" @change="changeAxis">
              <gl-radio-button v-for="axis in AXIS_ARR" :key="axis.value" :value="axis.value">
                {{ axis.label }}
              </gl-radio-button>
            </gl-radio-group>
          </gl-form-item>
        </gl-form>
      </gl-collapse-panel>
    </gl-collapse>
  </div>
</template>
<script setup lang="ts">
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { AXIS_ARR } from '../../../constants'
import { ColorInput } from '@mysteel-standard/components'
import { bus } from '@mysteel-standard/utils'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

//选中指标
const collapseKey = ref(0)

const indexList = computed(() => props.contentOption.indexOptionsScatter)

const relations = (item: { indexCode: string }) => {
  return props.contentOption.indexOptionsScatter.filter(
    (relate: { indexCode: string }) => item.indexCode !== relate.indexCode
  )
}

const changeAxis = () => {
  bus.emit('resetValue')
}
</script>
<style lang="scss" scoped>
.index-options-scatter {
  .option-collapse-title {
    display: inline-block;
    max-width: 300px;
    vertical-align: middle;
    margin-left: 8px;
  }
}
</style>
