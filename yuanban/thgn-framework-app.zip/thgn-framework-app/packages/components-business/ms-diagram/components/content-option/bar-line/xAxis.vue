<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-08-17 14:00:23
 * @Description: 指标chart配置
-->
<template>
  <div class="x-axis">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 18 }"
      label-align="left"
    >
      <gl-form-item label="单位">
        <gl-input v-model:value="form.name" :maxlength="50" placeholder="请输入单位" />
      </gl-form-item>
      <gl-form-item label="字体">
        <font-collection v-model:font="form.nameTextStyle" />
      </gl-form-item>
      <gl-form-item label="线型">
        <gl-select v-model:value="form.axisLine.lineStyle.type" placeholder="请选择线型">
          <gl-select-option
            v-for="item in lineStyleTypeArr"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</gl-select-option
          >
        </gl-select>
      </gl-form-item>
      <gl-form-item label="宽度">
        <gl-input-number
          v-model:value="form.axisLine.lineStyle.width"
          :min="0"
          placeholder="请输入宽度"
        />
      </gl-form-item>
      <gl-form-item label="颜色">
        <color-input v-model:value="form.axisLine.lineStyle.color" />
      </gl-form-item>
      <!-- <gl-form-item label="数据范围">
        <range-date-modal :content-option="contentOption" :season-checked="seasonChecked" />
      </gl-form-item> -->
      <gl-form-item label="数据格式">
        <gl-select
          v-model:value="form.dataFormat"
          placeholder="请选择线型"
          :disabled="seasonChecked || contentOption.xAxis.rangeDate.dateType === 1"
        >
          <gl-select-option v-for="item in dataFormatArr" :key="item.value" :value="item.value">{{
            item.label
          }}</gl-select-option>
        </gl-select>
      </gl-form-item>
      <gl-form-item label="数据频度">
        <gl-select
          v-model:value="form.dataFrequency"
          placeholder="请选择线型"
          :disabled="seasonChecked || contentOption.xAxis.rangeDate.dateType === 1"
        >
          <gl-select-option
            v-for="item in dataFrequencyArr"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</gl-select-option
          >
        </gl-select>
      </gl-form-item>
    </gl-form>
  </div>
</template>
<script lang="ts" setup>
import { ColorInput } from '@mysteel-standard/components'
import FontCollection from '../font-collection.vue'
import RangeDateModal from '../range-date-modal.vue'
import { BORDER_TYPE, DATA_FORMAT_LIST, DATA_FREQUENCY_LIST } from '../../../constants'
//props
interface Props {
  contentOption: any
  seasonChecked: boolean
}
const props = withDefaults(defineProps<Props>(), {
  seasonChecked: false
})

const lineStyleTypeArr = reactive(BORDER_TYPE)
const dataFormatArr = reactive(DATA_FORMAT_LIST)
const dataFrequencyArr = reactive(DATA_FREQUENCY_LIST)

const form = computed(() => props.contentOption.xAxis)
</script>
<style lang="scss" scoped>
.x-axis {
  padding-top: 20px;
  padding-left: 20px;
  .gl-input-number {
    width: 100% !important;
  }
}
</style>
