<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-17 14:00:34
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-06-27 11:59:14
 * @Description: 
-->
<template>
  <div class="radar-axis-line">
    <gl-form
      :model="form"
      :colon="false"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      label-align="left"
    >
      <gl-form-item label="线型">
        <gl-select v-model:value="form.lineStyleType" class="wid-240" placeholder="请选择线型">
          <gl-select-option
            v-for="item in lineStyleTypeArr"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</gl-select-option
          >
        </gl-select>
      </gl-form-item>
      <gl-form-item label="宽度">
        <gl-input-number
          v-model:value="form.lineStyleWidth"
          :min="1"
          :step="1"
          :precision="0"
          placeholder="请输入宽度"
          class="wid-240"
        />
      </gl-form-item>

      <gl-form-item label="颜色">
        <color-input v-model:value="form.color" class="wid-240" />
      </gl-form-item>
      <gl-form-item label="最小值">
        <gl-input-number v-model:value="form.min" placeholder="请输入最小值" class="wid-240" />
      </gl-form-item>
      <gl-form-item label="最大值">
        <gl-input-number v-model:value="form.max" placeholder="请输入最大值" class="wid-240" />
      </gl-form-item>
      <gl-form-item label="分割段数">
        <gl-input-number v-model:value="form.splitNumber" :min="5" :max="20" class="wid-240" />
      </gl-form-item>
      <gl-form-item label="刻度">
        <gl-radio-group v-model:value="form.mark">
          <gl-radio-button value="1">显示</gl-radio-button>
          <gl-radio-button value="0">不显示</gl-radio-button>
        </gl-radio-group>
      </gl-form-item>
    </gl-form>
  </div>
</template>

<script setup lang="ts">
import { ColorInput } from '@mysteel-standard/components'
import { BORDER_TYPE } from '../../../constants'
//props
interface Props {
  contentOption: any
}
const props = defineProps<Props>()

const lineStyleTypeArr = ref(BORDER_TYPE)

const form = computed(() => props.contentOption.radarAxisLine)
</script>
<style lang="scss" scoped>
.radar-axis-line {
  padding-left: 20px;
}
</style>
