<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-06-29 16:32:03
 * @Description: 
-->
<template>
  <gl-input v-bind="$attrs" v-model:value="input" :placeholder="placeholder" @input="handleInput" />
</template>

<script setup lang="ts">
import { computed } from 'vue'
const props = defineProps({
  placeholder: {
    type: String,
    default: '请输入'
  },
  value: {
    type: String,
    default: ''
  },
  regex: {
    type: RegExp,
    default: /[^\u4E00-\u9FA5A-Za-z0-9]/g
  }
})

const emit = defineEmits(['update:value', 'input'])

const input = computed(() => props.value)

const handleInput = (e: any) => {
  const val = e.target.value
  const newValue = val.replace(props.regex, '')
  emit('update:value', newValue)
  emit('input', newValue)
}
</script>
