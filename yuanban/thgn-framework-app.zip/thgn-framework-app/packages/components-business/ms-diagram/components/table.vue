<!--
 * @Author:zouchuanfeng
 * @LastEditTime: 2023-10-09 10:47:24
 * @Description: 图表展示模块-表
-->
<template>
  <div class="table-container">
    <div class="title">
      <div v-if="title.headerTitle.show" class="info header">
        <p :style="headerTitleStyle" v-html="title.headerTitle.name"></p>
        <icon name="icon-edit" @click="textEdit(title.headerTitle, 'headerTitle')" />
      </div>
    </div>
    <div class="table-indicator title">
      <div class="info header">
        <div class="drag-item">
          <div v-if="isTimeFilter" class="title-item">
            <div class="text ellipsis">时间选择器</div>
            <close-outlined @click="handleDeleteTime()" />
          </div>
          <div
            v-if="calculationItem && calculationItem.calculation.name"
            class="title-item"
            :title="calculationItem && calculationItem.calculation.name"
          >
            <div class="text ellipsis">
              {{ calculationItem && calculationItem.calculation.name }}
            </div>
            <CloseOutlined @click="handleDeleteCal(curEl.contentOption)" />
          </div>
          <div
            v-for="item in indexList.filter((item: any) => item.checked)"
            :key="item.indexCode"
            class="title-item"
            :title="item.legendName"
          >
            <div class="text ellipsis">{{ item.legendName }}</div>
            <CloseOutlined @click="handleDeleteIndex(curEl.contentOption)" />
          </div>
        </div>

        <icon class="icon" name="icon-delete" @click="handleDeleteIndex(curEl.contentOption)" />
      </div>
    </div>
    <div class="content">
      <table-plus :cur-el="curEl" :extract-param="extractParam" />
    </div>
    <div class="title">
      <div v-if="title.footerTitle.show" class="info footer">
        <p :style="footerTitleStyle" v-html="title.footerTitle.name"></p>
        <icon class="icon" name="icon-edit" @click="textEdit(title.footerTitle, 'footerTitle')" />
      </div>
    </div>
  </div>
  <rich-editor v-model:visible="textVisible" v-model:font="font" title="编辑标题" />
</template>

<script setup lang="ts">
import { Icon } from '@mysteel-standard/components'
import { CloseOutlined } from '@ant-design/icons-vue'
import TablePlus from './table-plus/index.vue'
import { RichEditor } from '../../rich-editor'
import { LAYOUT_TYPE } from '../constants'
import { cloneDeep } from 'lodash-es'
import useEditTable from '../composables/table/use-edit-table'
//props
interface Props {
  curEl: any
  seasonChecked: boolean
  indexDataSeason: any[]
  extractParam: any
}
const props = defineProps<Props>()

//指标
const indexList = computed(() => {
  return cloneDeep(props.curEl.contentOption.indexOptionsTable || [])
})

//计算公式
const calculationItem = computed(() => {
  return indexList.value.filter((item: { checked: boolean }) => item.checked)[0]
})

//时间选择器
const isTimeFilter = computed(() => {
  return cloneDeep(props.curEl.contentOption.isTimeFilter)
})

//标题
const textVisible = ref(false)
const titleType: any = ref({})
const font = ref({})
const title = computed(() => {
  return props.curEl.contentOption.layoutTable.titleFont
})
const headerTitleStyle = computed(() => ({
  ...title.value.headerTitle,
  fontSize: `${title.value.headerTitle.fontSize}px`
}))
const footerTitleStyle = computed(() => ({
  ...title.value.footerTitle,
  fontSize: `${title.value.footerTitle.fontSize}px`
}))
const textEdit = (item: {}, title: {}) => {
  titleType.value = title
  font.value = item
  textVisible.value = true
}
watch(
  () => font.value,
  (newVal) => {
    const { contentOption } = props.curEl
    contentOption[LAYOUT_TYPE[props.curEl.id]].titleFont[titleType.value] = newVal
  }
)
//表格功能
const { handleDeleteIndex, handleDeleteTime, handleDeleteCal } = useEditTable()
</script>
<style lang="scss" scoped>
.table-container {
  height: calc(100vh - 190px);
  width: 100%;
  display: flex;
  flex-direction: column;
  .title {
    height: 48px;
    padding: 0 28px 0 20px;
    .info {
      .drag-item {
        display: flex;
        .title-item {
          margin-right: 2px;
        }
      }
      height: 100%;
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      &.header {
        border-bottom: 1px solid #e8e8e8;
      }
      &.footer {
        border-top: 1px solid #e8e8e8;
      }
      p {
        font-size: 14px;
        width: 100%;
        padding-right: 10px;
      }
    }

    .icon {
      &:hover {
        color: #005bac;
      }
    }
  }
  .table-indicator {
    .title-item {
      width: 160px;
      height: 28px;
      line-height: 28px;
      font-size: 14px;
      color: #005bac;
      border-radius: 1px;
      padding: 0 8px;
      background: #e5eff8;
      display: flex;
      align-items: center;
      .text {
        width: 120px;
        margin-right: 8px;
      }
    }
  }
  .content {
    width: 100%;
    height: calc(100% - 225px);
    overflow: auto;
    position: relative;
    padding: 20px;
  }
}

.ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
}
</style>
