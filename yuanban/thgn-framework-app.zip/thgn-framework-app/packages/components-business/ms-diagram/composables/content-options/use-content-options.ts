/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 10:54:59
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-09-15 15:07:23
 * @Description: 图表右侧属性组合函数
 */
import { IndexOption, CurEl } from '../../types/interface'
import { generateImage, downloadEchart } from '@mysteel-standard/utils'
import { ref, nextTick, Ref } from 'vue'
export default () => {
  const tabActive: any = ref('indexOptionsBarLine')
  const activeKey = ref('0')
  const seasonChecked = ref(false)
  const spinning = ref(false)
  //季节性内容
  const indexDataSeason: any = ref([])
  //季节性指标编码

  const changeChartType = (type: string, curEl: CurEl) => {
    curEl.eckhartType = type
  }

  //季节性分析
  const changeSeason = (
    data: { checked: false; item: IndexOption },
    state: any,
    getSeasonChart: Function,
    getChartTableData: Function
  ) => {
    if (data.checked) {
      seasonChecked.value = true
      state.curEl.contentOption.seasonChecked = true
      state.curEl.contentOption.seasonIndexCode = data.item.indexCode
      getSeasonChart(data.item, indexDataSeason)
    } else {
      seasonChecked.value = false
      indexDataSeason.value = []
      state.curEl.contentOption.seasonChecked = false
      state.curEl.contentOption.seasonIndexCode = ''
      getChartTableData()
    }
  }

  // radar 最新数据
  const changeRadarNew = (checked: boolean, getRadarData: Function) => {
    if (checked) {
      getRadarData()
    }
  }
  //下载导出图片
  const editRef: Ref = ref(null)
  const downloadChart = async (curEl: any, chartTitle: string, isEmpty: boolean) => {
    if (isEmpty) return
    let baseUrl = ''
    if (
      curEl.id === 'bar-line' ||
      curEl.id === 'chart-pie' ||
      curEl.id === 'chart-radar' ||
      curEl.id === 'scatter-plot'
    ) {
      if (curEl.id === 'bar-line') {
        editRef.value.editChart.chartOption.dataZoom[1].show = false
      }
      nextTick(async () => {
        const chartDom = document.querySelector('.chart-container')
        baseUrl = await generateImage(chartDom)
        downloadEchart(baseUrl, chartTitle)
        if (curEl.id === 'bar-line') {
          editRef.value.editChart.chartOption.dataZoom[1].show = true
        }
      })
    } else if (curEl.id === 'sequence-table' || curEl.id === 'free-table') {
      const tableDom = document.querySelector('.plus-table')
      baseUrl = await generateImage(tableDom)
      downloadEchart(baseUrl, chartTitle)
    }
  }

  return {
    activeKey,
    tabActive,
    spinning,
    seasonChecked,
    indexDataSeason,
    changeChartType,
    changeSeason,
    changeRadarNew,
    downloadChart,
    editRef
  }
}
