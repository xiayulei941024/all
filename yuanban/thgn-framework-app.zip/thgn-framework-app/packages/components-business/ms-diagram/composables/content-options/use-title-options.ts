/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-20 10:03:30
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-18 15:54:13
 * @Description: 图表标题
 */

export default () => {
  const font = ref({})
  const textVisible: any = ref(false)
  const titleType: any = ref({})
  const richEditorTitle: any = ref('')
  const textEdit = (item: any, title: string) => {
    titleType.value = title
    font.value = item
    textVisible.value = true
    richEditorTitle.value = title === 'footerTitle' ? '编辑数据来源' : '编辑标题'
  }

  return { textEdit, font, textVisible, richEditorTitle, titleType }
}
