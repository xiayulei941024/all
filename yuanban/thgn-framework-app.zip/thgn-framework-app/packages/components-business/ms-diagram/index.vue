<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-12 14:06:02
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-10-16 15:44:48
 * @Description: 数据中心-指标作图模块
-->
<template>
  <div class="diagram">
    <header class="diagram-header">
      <div class="btn-container">
        <span :class="{ 'btn-disabled': isEmpty, 'btn-item': true }" @click="resetChart">
          <icon name="icon-reset" :size="'14'" />
          重置
        </span>
        <span
          type="primary"
          :class="{ 'btn-disabled': state.chartId === 0 || isEmpty, 'btn-item': true }"
          @click="updateDiagram(type)"
        >
          <icon name="icon-save" :size="'14'" />
          保存
        </span>
        <span
          type="primary"
          :class="{ 'btn-disabled': isEmpty, 'btn-item': true }"
          @click="saveDiagram(chartTitle)"
        >
          <icon name="icon-saveto" />
          另存为
        </span>
        <span
          :class="{ 'btn-disabled': isEmpty, 'btn-item': true }"
          @click="downloadChart(state.curEl, chartTitle, isEmpty)"
          v-if="checkPermit(['sjzx:sjk:dc'])"
        >
          <icon name="icon-export" :size="'14'" />
          导出
        </span>
      </div>
    </header>
    <main class="diagram-main">
      <!-- 图表切换 -->
      <aside class="main-aside">
        <diagram-tabs
          :id="state.curEl.id"
          :isEmpty="isEmpty"
          :extract-param="state.extractParam"
          @change-component="changeComponent"
        />
      </aside>
      <section class="main-content" v-if="!isEmpty">
        <div :class="`main-left ${isExpand ? 'expand' : ''}`">
          <gl-spin :spinning="spinning">
            <component
              :is="components[state.curEl.componentName]"
              ref="editRef"
              :cur-el="state.curEl"
              :season-checked="seasonChecked"
              :index-data-season="indexDataSeason"
              :extract-param="state.extractParam"
            ></component>
          </gl-spin>
        </div>
        <!-- 展开收起 -->
        <div :class="`arrow-setting ${isExpand ? 'expand' : ''}`" @click="handleArrow">
          <icon name="icon-right_outlined" v-if="!isExpand" />
          <icon name="icon-left_outlined" v-if="isExpand" />
        </div>
        <!-- 图表属性区-->
        <section v-show="!isExpand" class="main-right">
          <header class="main-right-header">
            <div
              v-for="item in tabOptions"
              :key="item.key"
              :class="`tab-title ${tabActive === item.key ? 'active' : ''}`"
              :style="`width:${100 / tabOptions.length}%`"
              @click="() => (tabActive = item.key)"
            >
              {{ item.title }}
            </div>
          </header>
          <section class="main-right-body">
            <component
              :is="components[tabActive]"
              v-model:active-key="activeKey"
              :content-option="contentOption"
              :season-checked="seasonChecked"
              :index-data-season="indexDataSeason"
              @change-chart-type="
                (type: string) => {
                  changeChartType(type, state.curEl)
                }
              "
              @change-season="
                (data: any) => {
                  changeSeason(data, state, getSeasonChart, getChartTableData)
                }
              "
              @change-radar="
                (checked: boolean) => {
                  changeRadarNew(checked, getRadarData)
                }
              "
            />
          </section>
        </section>
      </section>
      <div class="empty" v-else>
        <Empty :emptyText="'暂无图表'"></Empty>
        <p>请先在数据页提取数据</p>
      </div>
    </main>
  </div>
  <!-- 收藏图表 -->
  <collect-diagram-modal
    v-if="collectVisible"
    v-model:collectVisible="collectVisible"
    :folderForm="state.folderForm"
    :cur-el="state.curEl"
    :seasonChecked="seasonChecked"
    :extract-param="state.extractParam"
    :indexDataSeason="indexDataSeason"
    :chartId="chartId"
    @add-and-update-diagram="addAndUpdateDiagram"
  ></collect-diagram-modal>
</template>

<script setup lang="ts">
import { bus } from '@mysteel-standard/utils'
import { Icon } from '@mysteel-standard/components'
import DiagramTabs from './components/diagram-tabs/index.vue'
import collectDiagramModal from './components/collect-diagram-modal/index.vue'
import componentArr from './components'
import { DIAGRAM_LIST, LAYOUT_TYPE } from './constants/index'
import useContentOptions from './composables/content-options/use-content-options'
import { useUpdateDiagramTable } from '@mysteel-standard/hooks'
import { ExtractParam } from './types/interface'
import { cloneDeep } from 'lodash-es'
import api from './api/index'
import { Empty } from '@mysteel-standard/components'
import useRequestData from './composables/use-request-data'
import { checkPermit } from '@mysteel-standard/hooks'
import { ref, reactive, computed, onMounted, watch } from 'vue'
const components: any = componentArr

interface Props {
  chartId: number
  extractData?: ExtractParam
  type?: number
}
const props = withDefaults(defineProps<Props>(), {
  type: 1 //数据中心 2、品种研究
})
//emits
interface Emits {
  (e: 'extract', val: any): void
  (e: 'sure-save-chart'): void //品种研究编辑图表
}
const emits = defineEmits<Emits>()

//所有属性对象
const state: any = reactive({
  chartId: 0,
  extractParam: {},
  curEl: DIAGRAM_LIST[0],
  config: {},
  folderForm: {
    name: '',
    imageUrl: '',
    label: '',
    checked: true
  }
})

//判断是有有选中指标
const isEmpty = ref(true)

//展开收齐标志
const isExpand = ref(false)
const handleArrow = () => {
  isExpand.value = !isExpand.value
}

//右侧属性tabs
const tabOptions: any = computed(() => state.curEl.configTabs)
//右侧属性配置
const contentOption: any = computed(() => state.curEl.contentOption)
//标题
const chartTitle: any = computed({
  get() {
    const { contentOption } = state.curEl
    return contentOption[LAYOUT_TYPE[state.curEl.id]].titleFont?.headerTitle?.name
  },
  set() {}
})
//右侧属性composables
const {
  spinning,
  tabActive,
  activeKey,
  seasonChecked,
  indexDataSeason,
  changeChartType,
  changeSeason,
  changeRadarNew,
  downloadChart,
  editRef
} = useContentOptions()

//切换图表类型
const changeComponent = (id: string) => {
  if (isEmpty.value) return
  seasonChecked.value = false
  indexDataSeason.value = []
  state.curEl = cloneDeep(DIAGRAM_LIST).filter((item: { id: string }) => item.id === id)[0]
  tabActive.value = tabOptions.value[0].key
  queryChart()
}

//图表请求
const {
  queryChart,
  getChartTableData,
  getRadarData,
  getSeasonChart,
  addAndUpdateDiagram,
  saveDiagram,
  updateDiagram,
  collectVisible
} = useRequestData({
  state,
  props,
  seasonChecked,
  spinning,
  indexDataSeason,
  isEmpty,
  emits
})

//重置
const resetChart = () => {
  if (isEmpty.value) return
  state.curEl = cloneDeep(DIAGRAM_LIST)?.filter(
    (item: { id: string }) => item.id === state.curEl.id
  )[0]
  seasonChecked.value = false
  state.chartId = 0
  queryChart()
}

//表格更新
const { updateTableData } = useUpdateDiagramTable(spinning)

onMounted(async () => {
  //监听修改表格tableData数据
  bus.on('update-table-data', (tableData: any) => {
    state.curEl.tableData = tableData
  })
  //监听修改右侧属性数据
  bus.on('update-content-option', (contentOption: any) => {
    state.curEl.contentOption = { ...state.curEl.contentOption, ...contentOption }
  })
  //数据范围更新表格数据
  bus.on('date-update', (rangeDate: any) => {
    //判断季节性
    if (seasonChecked.value) {
      const indexData = state.curEl.contentOption.indexOptionsBarLine.filter(
        (item: any) => item.indexCode === state.curEl.contentOption.seasonIndexCode
      )[0]
      getSeasonChart(indexData, indexDataSeason)
    } else {
      getChartTableData(rangeDate)
    }
  })
})
const initChartData = async (newVal: any) => {
  if (newVal) {
    state.extractParam = cloneDeep(newVal)
    if (!state.extractParam.indexCodes.length && !state.extractParam.deriveIndexObjs.length) {
      isEmpty.value = true
    } else {
      isEmpty.value = false
      //保存range范围
      if (state.curEl.id === 'bar-line') {
        const { dateType, intervalType, timeCount, timeType, beginTime, endTime, indexData } =
          newVal
        state.curEl.contentOption.xAxis.rangeDate = {
          dateType,
          intervalType,
          timeCount,
          timeType,
          beginTime,
          endTime
        }
        //判断使用季节性指标是否还在队列中
        if (seasonChecked.value) {
          if (
            !indexData.some((item) => item.indexCode === state.curEl.contentOption.seasonIndexCode)
          ) {
            seasonChecked.value = false
          }
        }
      }
      queryChart()
      //表格更新
      if (
        props.chartId !== 0 &&
        (state.curEl.id === 'free-table' || state.curEl.id === 'sequence-table')
      ) {
        const newTableData = await updateTableData(
          state.curEl,
          state.curEl.tableData,
          state.extractParam
        )
        state.curEl.tableData = newTableData
        bus.emit('echo-table-data', newTableData)
      }
    }
  }
}
//监听请求入参变化 更新图表数据
watch(
  () => props.extractData,
  async (newVal) => {
    initChartData(newVal)
  },
  { deep: true, immediate: true }
)

//回显图表
watch(
  () => props.chartId,
  async (newVal: any) => {
    if (newVal === 0) return
    spinning.value = true
    isEmpty.value = false
    state.chartId = newVal
    const { res, err } = await api.queryChart({ chartId: newVal })
    spinning.value = false
    if (!err && res) {
      const { extractParam, curEl } = JSON.parse(res.data.config)
      state.extractParam = extractParam
      state.curEl = curEl
      state.folderForm.name = res.data.name
      seasonChecked.value = !!curEl.contentOption.seasonChecked
      tabActive.value = tabOptions.value[0].key
      //提供指标代码供表格显示  同时触发 props.extractData,监听
      emits('extract', extractParam)
    }
  },
  {
    immediate: true
  }
)
defineExpose({ initChartData })
</script>

<style lang="scss" scoped>
.gl-tabs-nav {
  margin: 0 !important;
}
.diagram {
  width: 100%;
  height: calc(100vh - 210px);

  .diagram-header {
    background-color: #eff2f5;
    height: 32px;
    line-height: 32px;
    cursor: pointer;
    .btn-container {
      .btn-item {
        margin: 0 10px;
        color: #333333;
        font-size: 14px;
        font-family:
          PingFangSC-Medium,
          PingFang SC;
      }
      .btn-disabled {
        color: #797979;
        cursor: not-allowed;
      }
    }
  }
  .diagram-main {
    width: 100%;
    height: calc(100% - 58px);
    position: relative;
    display: flex;
    .main-aside {
      width: 100px;
      height: 100%;
    }
    .main-content {
      width: calc(100% - 100px);
      height: 100%;
      display: flex;
      .main-left {
        width: calc(100% - 400px);
        background-color: #fff;
        height: 100%;
        border: 1px solid #e8e8e8;
        &.expand {
          width: 100%;
        }
      }
      .arrow-setting {
        position: absolute;
        top: 50%;
        right: 385px;
        transform: translate(-50%, -50%);
        width: 16px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        border-radius: 8px;
        border: 1px solid #e8e8e8;
        cursor: pointer;
        background-color: #fff;
        &.expand {
          right: 0;
        }
      }
      .main-right {
        overflow: auto;
        width: 400px;
        height: 100%;
        background-color: #fff;
        border: 1px solid #e8e8e8;
        display: flex;
        flex-direction: column;
        border-left: none;
        .main-right-header {
          display: flex;
          justify-content: space-around;
          .tab-title {
            width: 100px;
            height: 48px;
            line-height: 48px;
            font-size: 14px;
            text-align: center;
            font-weight: 500;
            color: #333333;
            background-color: #fafafa;
            cursor: pointer;
            &.active {
              background-color: #fff;
              color: #005bac;
            }
          }
        }
        .main-right-body {
          padding-top: 10px;
          flex: 1;
          overflow-y: auto;
          .gl-form-item {
            align-items: flex-start;
          }
        }
      }
    }
  }
  .empty {
    margin: 160px auto;
    text-align: center;
    font-size: 12px;
    font-family:
      PingFangSC-Medium,
      PingFang SC;
    font-weight: 500;
    color: #999999;
    line-height: 17px;
    p {
      margin-top: 5px;
    }
  }

  :deep(.gl-spin-container) {
    height: 100%;
  }
  :deep(.gl-spin-nested-loading) {
    height: 100%;
  }

  :deep(.gl-collapse-item) {
    border: none;
  }
  :deep(.gl-collapse-content-box) {
    background: #ffffff;
  }
  :deep(.gl-collapse-header) {
    background-color: #ffffff;
  }
  :deep(.gl-input-number) {
    width: 100% !important;
  }
  :deep(.gl-switch) {
    float: right;
  }
}
</style>
