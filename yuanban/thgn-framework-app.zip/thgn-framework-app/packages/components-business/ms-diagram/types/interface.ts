/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-15 09:43:09
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-07-04 11:49:40
 * @Description:
 */
export interface CurEl {
  id: string
  componentName: string
  title: { name: string }
  configTabs: Array<{ key: string; title: string }>
  contentOption: { indexOptionsBarLine: Array<IndexOption>; [propName: string]: any }
  eckhartType?: string
  [propName: string]: any
}

//指标配置
export interface IndexOption {
  checked: boolean
  dateList: Array<string>
  data: Array<string>
  legendName: string
  indexCode: string
  type: string
  lineStyleType: string
  lineStyleWidth: number
  barWidth: number
  itemColor: string
  yAxisIndex: number
  isSeason: boolean
  isLabel: boolean
  labelPosition: string
}
//提取指标参数
export interface ExtractParam {
  beginTime: string
  endTime: string
  indexCodes: Array<string>
  timeCount: number
  timeType: string
  dateType: number
  deriveIndexObjs: any
  indexData: any[]
  intervalType: string
}

export enum TabList {
  公司图表库 = 1,
  我的图表库 = 2
}

export interface TabItem {
  label: string
  value: number
}
