/**
 * ajax请求配置
 */
import axios from 'axios'
import { message } from 'gl-design-vue'

import cookie from './cookie'

const goLoginPage = () => {
  window.location.href = window.location.origin + window.location.pathname
  cookie.del('accessToken')
  cookie.del('account')
  cookie.del('id')
  cookie.del('isAdmin')
}
const goLoginPage2 = () => {
  window.location.href = window.location.origin + '/#/decision-board/login'
  cookie.del('accessToken')
  cookie.del('account')
  cookie.del('id')
  cookie.del('isAdmin')
}

const goMobileLoginPage = () => {
  window.location.href = window.location.origin + '/#/mobile/login'
  cookie.del('accessToken')
  cookie.del('account')
  cookie.del('id')
  cookie.del('isAdmin')
}

// const _this = this
// axios默认配置
axios.defaults.timeout = 60000 // 超时时间
// 路由请求拦截
// http request 拦截器
axios.interceptors.request.use(
  (config) => {
    // config.data = JSON.stringify(config.data);
    // config.headers['Content-Type'] = 'application/json;charset=UTF-8';
    // 判断是否存在ticket，如果存在的话，则每个http header都加上ticket
    if (cookie.get('accessToken') && config.headers) {
      // 用户每次操作，都将cookie设置成2小时
      // cookie.set("token",cookie.get("token") ,1/12)
      config.headers['accessToken'] = cookie.get('accessToken')
      // axios.defaults.headers.common["accessToken"] = cookie.get("token");
    }

    return config
  },
  (error) => {
    return Promise.reject(error.response)
  }
)

// 路由响应拦截
// http response 拦截器
axios.interceptors.response.use(
  (response) => {
    if (response.data.accessTokenStatus === 'false' && !window.location.href.includes('?excel')) {
      localStorage.removeItem('code');
      if (window.location.href.includes('/reportPreview') && window.top) {
        window.top.window.postMessage('login', '*')
      } else {
        message.error(response.data.message)

        if (window.location.href.includes('/mobile')) {
          message.error(response.data.message)
          goMobileLoginPage()
        } else if(window.location.href.includes('/decision-board')){
          
          goLoginPage2()
        }else{
          goLoginPage()
        }
      }
      // 返回 错误代码-1 清除token信息并跳转到登录页面
      return
    } else {
      if (
        response.status === 200 &&
        (response.config.responseType === 'arraybuffer' || response.config.responseType === 'blob')
      ) {
        console.log(response)
        // 文件类型特殊处理
        return response.data
      } else {
        if (response.status === 200) {
          if (
            response.data.code === '200' ||
            response.data.code === 'K00001' ||
            response.data.code === '400004' ||
            response.data.code === 200
          ) {
            return response.data
          } else if (response.data.code === '100004') {
            localStorage.removeItem('code');
            message.error(response.data.message)
            if (window.location.href.includes('/mobile')) {
              message.error(response.data.message)
              goMobileLoginPage()
            } else if(window.location.href.includes('/decision-board')){
             
              goLoginPage2()
            }else {
              goLoginPage()
            }
          } else {
            // eslint-disable-next-line no-debugger
            const duration = 1.5
            message.error({
              duration,
              content: response.data.message
            })
            return Promise.reject(response.data)
          }
        }
      }
    }
  },
  (error) => {
    // 返回接口返回的错误信息
    if (error.message.includes('timeout')) {
      // 判断请求异常信息中是否含有超时timeout字符串
      message.error({
        duration: 1.5,
        content: '连接超时，请刷新重试！'
      })
      return Promise.reject(error.message) // reject这个错误信息
    }
    message.error({
      duration: 1.5,
      content: error.message
    })
    return Promise.reject(error.message)
  }
)
export default axios
