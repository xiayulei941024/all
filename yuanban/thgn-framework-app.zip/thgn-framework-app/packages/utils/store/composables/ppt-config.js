import { createUUID } from './utils'
// import Logo from '../assets/logo.png'
import { computed } from 'vue'
export const logoElement = {
  uuid: createUUID(),
  elName: 'image',
  valueType: 'String',
  commonStyle: {
    rotate: 0,
    boxShadow: '',
    borderColor: '',
    color: '#000000',
    backgroundImage: '',
    paddingRight: 0,
    marginRight: 0,
    paddingBottom: 0,
    overflow: 'hidden',
    top: 16,
    borderWidth: 0,
    backgroundSize: 'cover',
    paddingTop: 0,
    borderStyle: 'solid',
    fontWeight: 400,
    height: 60,
    zIndex: 1,
    backgroundColor: '',
    letterSpacing: 0,
    marginLeft: 0,
    borderRadius: 0,
    left: 1439,
    width: 54,
    marginBottom: 0,
    position: 'absolute',
    opacity: 1,
    paddingLeft: 0,
    marginTop: 0
  },
  attrs: [
    {
      formList: [
        {
          layout: 1,
          component: 'number',
          defaultValue: 500,
          isCommon: true,
          label: '宽度',
          evalValue: 'width'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '高度',
          evalValue: 'height'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '水平位置',
          evalValue: 'left'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '垂直位置',
          evalValue: 'top'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 1,
          isCommon: true,
          label: '图层层级',
          evalValue: 'zIndex'
        }
      ],
      label: '组件大小',
      uuid: createUUID()
    },
    {
      formList: [
        {
          layout: '',
          component: 'image',
          isCommon: false,
          label: '',
          evalValue: 'image'
        }
      ],
      label: '',
      uuid: createUUID(),
      element: ['image']
    }
  ],
  propsValue: {
    image: {
      src: '',
      width: 100,
      height: 100
    },
    scale: 1
  }
}
const bgImage = computed(() => new URL('../assets/bg.png', import.meta.url).href)
export const bgElement = {
  uuid: createUUID(),
  elName: 'image',
  valueType: 'String',
  commonStyle: {
    rotate: 0,
    boxShadow: '',
    borderColor: '',
    color: '#000000',
    backgroundImage: '',
    paddingRight: 0,
    marginRight: 0,
    paddingBottom: 0,
    overflow: 'hidden',
    top: 112,
    borderWidth: 0,
    backgroundSize: 'cover',
    paddingTop: 0,
    borderStyle: 'solid',
    fontWeight: 400,
    height: 319,
    zIndex: 1,
    backgroundColor: '',
    letterSpacing: 0,
    marginLeft: 0,
    borderRadius: 0,
    left: 0,
    width: 1532,
    marginBottom: 0,
    position: 'absolute',
    opacity: 1,
    paddingLeft: 0,
    marginTop: 0
  },
  attrs: [
    {
      formList: [
        {
          layout: 1,
          component: 'number',
          defaultValue: 500,
          isCommon: true,
          label: '宽度',
          evalValue: 'width'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '高度',
          evalValue: 'height'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '水平位置',
          evalValue: 'left'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 40,
          isCommon: true,
          label: '垂直位置',
          evalValue: 'top'
        },
        {
          layout: 1,
          component: 'number',
          defaultValue: 1,
          isCommon: true,
          label: '图层层级',
          evalValue: 'zIndex'
        }
      ],
      label: '组件大小',
      uuid: createUUID()
    },
    {
      formList: [
        {
          layout: '',
          component: 'image',
          isCommon: false,
          label: '',
          evalValue: 'image'
        }
      ],
      label: '图片设置',
      uuid: createUUID(),
      element: ['image']
    }
  ],
  propsValue: {
    image: {
      src: bgImage,
      width: 100,
      height: 100
    },
    scale: 1
  }
}

export const titleElement = {
  uuid: createUUID(),
  elName: 'texteditor',
  commonStyle: {
    position: 'absolute',
    width: 1180,
    height: 188,
    top: 242,
    left: 340,
    rotate: 0,
    paddingTop: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingBottom: 0,
    marginTop: 0,
    marginLeft: 0,
    marginRight: 0,
    marginBottom: 0,
    borderWidth: 0,
    borderColor: '',
    borderStyle: 'solid',
    borderRadius: 0,
    boxShadow: '',
    fontSize: 100,
    fontFamily: '微软雅黑',
    fontWeight: 400,
    letterSpacing: 0,
    color: '#000000',
    backgroundColor: '',
    backgroundImage: '',
    backgroundSize: 'cover',
    overflow: 'hidden',
    opacity: 1,
    zIndex: 2
  },
  attrs: [
    {
      uuid: '9b03c1dd-d0dc-461b-933d-3048918c98fe',
      label: '组件大小',
      formList: [
        {
          label: '宽度',
          component: 'number',
          isCommon: true,
          evalValue: 'width',
          defaultValue: 500,
          layout: 1
        },
        {
          label: '高度',
          component: 'number',
          isCommon: true,
          evalValue: 'height',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '水平位置',
          component: 'number',
          isCommon: true,
          evalValue: 'left',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '垂直位置',
          component: 'number',
          isCommon: true,
          evalValue: 'top',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '图层层级',
          component: 'number',
          isCommon: true,
          evalValue: 'zIndex',
          defaultValue: 1,
          layout: 1
        }
      ]
    }
  ],
  propsValue: {
    innerHtml:
      '<p><span style="color: rgb(255, 255, 255); font-size: 100px;"><strong>市场部框架体系汇报</strong></span></p>',
    scale: 1
  },
  valueType: 'String'
}

export const secondTitleElement = {
  uuid: createUUID(),
  elName: 'texteditor',
  commonStyle: {
    position: 'absolute',
    width: 530,
    height: 158,
    top: 470,
    left: 340,
    rotate: 0,
    paddingTop: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingBottom: 0,
    marginTop: 0,
    marginLeft: 0,
    marginRight: 0,
    marginBottom: 0,
    borderWidth: 0,
    borderColor: '',
    borderStyle: 'solid',
    borderRadius: 0,
    boxShadow: '',
    fontSize: 80,
    fontWeight: 400,
    fontFamily: '微软雅黑',
    letterSpacing: 0,
    color: '#000000',
    backgroundColor: '',
    backgroundImage: '',
    backgroundSize: 'cover',
    overflow: 'hidden',
    opacity: 1,
    zIndex: 2
  },
  attrs: [
    {
      uuid: createUUID(),
      label: '组件大小',
      formList: [
        {
          label: '宽度',
          component: 'number',
          isCommon: true,
          evalValue: 'width',
          defaultValue: 500,
          layout: 1
        },
        {
          label: '高度',
          component: 'number',
          isCommon: true,
          evalValue: 'height',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '水平位置',
          component: 'number',
          isCommon: true,
          evalValue: 'left',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '垂直位置',
          component: 'number',
          isCommon: true,
          evalValue: 'top',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '图层层级',
          component: 'number',
          isCommon: true,
          evalValue: 'zIndex',
          defaultValue: 1,
          layout: 1
        }
      ]
    }
  ],
  propsValue: {
    innerHtml:
      '<p><span style="color: rgb(47, 46, 63); font-size: 80px;"><strong>---煤焦专题</strong></span></p>',
    scale: 1
  },
  valueType: 'String'
}

export const contentElement = {
  uuid: createUUID(),
  elName: 'texteditor',
  commonStyle: {
    position: 'absolute',
    width: 540,
    height: 50,
    top: 128,
    left: 40,
    rotate: 0,
    paddingTop: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingBottom: 0,
    marginTop: 0,
    marginLeft: 0,
    marginRight: 0,
    marginBottom: 0,
    borderWidth: 0,
    borderColor: '',
    borderStyle: 'solid',
    borderRadius: 0,
    boxShadow: '',
    fontWeight: 400,
    letterSpacing: 0,
    color: '#000000',
    backgroundColor: '',
    backgroundImage: '',
    backgroundSize: 'cover',
    overflow: 'hidden',
    opacity: 1,
    zIndex: 2
  },
  attrs: [
    {
      uuid: createUUID(),
      label: '组件大小',
      formList: [
        {
          label: '宽度',
          component: 'number',
          isCommon: true,
          evalValue: 'width',
          defaultValue: 500,
          layout: 1
        },
        {
          label: '高度',
          component: 'number',
          isCommon: true,
          evalValue: 'height',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '水平位置',
          component: 'number',
          isCommon: true,
          evalValue: 'left',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '垂直位置',
          component: 'number',
          isCommon: true,
          evalValue: 'top',
          defaultValue: 40,
          layout: 1
        },
        {
          label: '图层层级',
          component: 'number',
          isCommon: true,
          evalValue: 'zIndex',
          defaultValue: 1,
          layout: 1
        }
      ]
    }
  ],
  propsValue: {
    innerHtml: '<p></p>',
    scale: 1,
    reportPublicTime: '',
    store: ''
  },
  valueType: 'String'
}
