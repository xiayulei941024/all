/*
 * @Autor: zhouwanwan
 * @Date: 2023-09-19 09:20:07
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-20 14:26:47
 * @Description:富文本
 */
import { defineStore } from 'pinia'
const defaultRichTextAttrs = {
  bold: false,
  em: false,
  underline: false,
  strikethrough: false,
  superscript: false,
  subscript: false,
  code: false,
  color: '#000',
  backcolor: '',
  fontsize: 16,
  fontname: '微软雅黑',
  link: '',
  align: 'left',
  bulletList: false,
  orderedList: false,
  blockquote: false
}

const useRichText = defineStore('richText', {
  state: () => ({
    richTextAttrs: defaultRichTextAttrs
  }),
  actions: {
    changeRichtextAttrs(attrs: any) {
      this.richTextAttrs = attrs
    }
  },
  getters: {
    getRichtextAttrs(): any {
      return this.richTextAttrs
    }
  }
})
export default useRichText
