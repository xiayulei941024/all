/** crypto 方法start */

import CryptoJS from 'crypto-js'
const CRYPTO_KEY = 'pptist'
/**
 * 加密
 * @param msg 待加密字符串
 */
const encrypt = (msg: any) => CryptoJS.AES.encrypt(msg, CRYPTO_KEY).toString()

/**
 * 解密
 * @param ciphertext 待解密字符串
 */
const decrypt = (ciphertext: any) => {
  const bytes = CryptoJS.AES.decrypt(ciphertext, CRYPTO_KEY)
  return bytes.toString(CryptoJS.enc.Utf8)
}

/** crypto 方法end */
/** clipboard 方法start */

import Clipboard from 'clipboard'

/**
 * 复制文本到剪贴板
 * @param text 文本内容
 */
export const copyText = (text: string) =>
  new Promise((resolve, reject) => {
    const fakeElement = document.createElement('button')
    const clipboard = new Clipboard(fakeElement, {
      text: () => text,
      action: () => 'copy',
      container: document.body
    })
    clipboard.on('success', (e) => {
      clipboard.destroy()
      resolve(e)
    })
    clipboard.on('error', (e) => {
      clipboard.destroy()
      reject(e)
    })
    document.body.appendChild(fakeElement)
    fakeElement.click()
    document.body.removeChild(fakeElement)
  })

// 读取剪贴板
export const readClipboard = () =>
  new Promise((resolve, reject) => {
    if (navigator.clipboard?.readText) {
      navigator.clipboard.readText().then((text) => {
        if (!text) reject('剪贴板为空或者不包含文本')
        return resolve(text)
      })
    } else reject('浏览器不支持或禁止访问剪贴板，请使用快捷键 Ctrl + V')
  })

// 解析加密后的剪贴板内容
export const pasteCustomClipboardString = (text: string) => {
  let clipboardData
  try {
    clipboardData = JSON.parse(decrypt(text))
  } catch {
    clipboardData = text
  }
  return clipboardData
}

// 尝试解析剪贴板内容是否为Excel表格（或类似的）数据格式
export const pasteExcelClipboardString = (text: string) => {
  const lines = text.split('\r\n')
  if (lines[lines.length - 1] === '') lines.pop()
  let colCount = -1
  const data: any = []
  for (const index in lines) {
    data[index] = lines[index].split('\t')
    if (data[index].length === 1) return null
    if (colCount === -1) colCount = data[index].length
    else if (colCount !== data[index].length) return null
  }
  return data
}

/** clipboard 方法end */

import { padStart } from 'lodash-es'

/**
 * 生成随机码
 * @param len 随机码长度
 */
export const createRandomCode = (len = 6) => {
  const charset = '_0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
  const maxLen = charset.length
  let ret = ''
  for (let i = 0; i < len; i++) {
    const randomIndex = Math.floor(Math.random() * maxLen)
    ret += charset[randomIndex]
  }
  return ret
}

/**
 * 补足数字位数
 * @param digit 数字
 * @param len 位数
 */
export const fillDigit = (digit: any, len: any) => padStart(`${digit}`, len, '0')

//快捷键相关
export const KEYS = {
  C: 'C',
  X: 'X',
  Z: 'Z',
  Y: 'Y',
  A: 'A',
  G: 'G',
  L: 'L',
  F: 'F',
  D: 'D',
  B: 'B',
  MINUS: '-',
  EQUAL: '=',
  DIGIT_0: '0',
  DELETE: 'DELETE',
  UP: 'ARROWUP',
  DOWN: 'ARROWDOWN',
  LEFT: 'ARROWLEFT',
  RIGHT: 'ARROWRIGHT',
  ENTER: 'ENTER',
  SPACE: ' ',
  TAB: 'TAB',
  BACKSPACE: 'BACKSPACE'
}
//菜单相关
export const HOTKEY_DOC = [
  {
    type: '通用',
    children: [
      { label: '剪切', value: 'Ctrl + X' },
      { label: '复制', value: 'Ctrl + C' },
      { label: '粘贴', value: 'Ctrl + V' },
      { label: '快速复制粘贴', value: 'Ctrl + D' },
      { label: '全选', value: 'Ctrl + A' },
      { label: '撤销', value: 'Ctrl + Z' },
      { label: '恢复', value: 'Ctrl + Y' },
      { label: '删除', value: 'Delete / Backspace' },
      { label: '多选', value: '按住 Ctrl 或 Shift' }
    ]
  },
  {
    type: '幻灯片放映',
    children: [
      { label: '开始放映幻灯片', value: 'Ctrl + F' },
      { label: '切换上一页', value: '↑ / ←' },
      { label: '切换下一页', value: '↓ / → / Enter / Space' },
      { label: '退出放映', value: 'ESC' }
    ]
  },
  {
    type: '幻灯片编辑',
    children: [
      { label: '新建幻灯片', value: 'Enter' },
      { label: '缩放画布', value: 'Ctrl + 鼠标滚动' },
      { label: '放大画布', value: 'Ctrl + =' },
      { label: '缩小画布', value: 'Ctrl + -' },
      { label: '缩放画布到合适大小', value: 'Ctrl + 0' },
      { label: '编辑上一页', value: '↑ / ← / 鼠标上滚' },
      { label: '编辑下一页', value: '↓ / → / 鼠标下滚' }
    ]
  },
  {
    type: '元素操作',
    children: [
      { label: '移动', value: '↑ / ← / ↓ / →' },
      { label: '锁定', value: 'Ctrl + L' },
      { label: '组合', value: 'Ctrl + G' },
      { label: '取消组合', value: 'Ctrl + Shift + G' },
      { label: '置顶层', value: 'Alt + F' },
      { label: '置底层', value: 'Alt + B' },
      { label: '锁定宽高比例', value: '按住 Ctrl 或 Shift' },
      { label: '创建水平 / 垂直线条', value: '按住 Ctrl 或 Shift' },
      { label: '切换焦点元素', value: 'Tab' },
      { label: '确认图片裁剪', value: 'Enter' }
    ]
  },
  {
    type: '表格编辑',
    children: [
      { label: '聚焦到下一个单元格', value: 'Tab' },
      { label: '在上方插入一行', value: 'Ctrl + ↑' },
      { label: '在下方插入一行', value: 'Ctrl + ↓' },
      { label: '在左侧插入一列', value: 'Ctrl + ←' },
      { label: '在右侧插入一列', value: 'Ctrl + →' }
    ]
  },
  {
    type: '图表数据编辑',
    children: [{ label: '聚焦到下一行', value: 'Enter' }]
  },
  {
    type: '文本编辑',
    children: [
      { label: '加粗', value: 'Ctrl + B' },
      { label: '斜体', value: 'Ctrl + I' },
      { label: '下划线', value: 'Ctrl + U' },
      { label: '删除线', value: 'Ctrl + D' }
    ]
  }
]

/**
 * 计算单元格文本样式
 * @param style 单元格文本样式原数据
 */
export const getTextStyle = (style: {
  bold: any
  em: any
  underline: any
  strikethrough: any
  color: any
  backcolor: any
  fontsize: any
  fontname: any
  textAlign: any
  lineheight: any
}) => {
  if (!style) return {}
  const {
    bold,
    em,
    underline,
    strikethrough,
    color,
    backcolor,
    fontsize,
    fontname,
    textAlign,
    lineheight
  } = style
  let textDecoration = `${underline ? 'underline' : ''} ${strikethrough ? 'line-through' : ''}`
  if (textDecoration === ' ') textDecoration = 'none'
  //console.log(style,bold,em,underline);
  return {
    fontWeight: bold ? 'bold' : 'normal',
    fontStyle: em ? 'italic' : 'normal',
    textDecoration,
    color: color || '#000',
    backgroundColor: backcolor || '',
    fontSize: fontsize || '14px',
    fontFamily: fontname || '微软雅黑',
    textAlign: textAlign || 'left',
    lineHeight: lineheight || '20px'
  }
}
export const formatText = (text: string) => text.replace(/\n/g, '</br>').replace(/ /g, '&nbsp;')

/**
 * 获取元素样式
 * @param styleObj
 * @param scalePoint 缩放比例
 */
export const getCommonStyle = (styleObj: { [x: string]: any }, scalingRatio = 1) => {
  const needUnitStr = [
    'width',
    'height',
    'top',
    'left',
    'lineHeight',
    'paddingTop',
    'paddingLeft',
    'paddingRight',
    'paddingBottom',
    'marginTop',
    'marginLeft',
    'marginRight',
    'marginBottom',
    'borderWidth',
    'fontSize',
    'borderRadius',
    'letterSpacing'
  ]
  const style: any = {}

  for (const key in styleObj) {
    if (needUnitStr.includes(key)) {
      style[key] = `${styleObj[key] * scalingRatio}px`
    } else {
      style[key] = styleObj[key]
    }
  }
  // style.transform = `rotate(${style.rotate}deg)`
  // style.backgroundImage = style.backgroundImage ? `url(${style.backgroundImage})` : ''
  return style
}

export const getFilterStyle = (filters: string | any[], text: any) => {
  if (!filters) return
  let style = {}
  for (let i = 0; i < filters.length; i++) {
    const collects = filters[i]?.filterCollection || []
    for (let j = 0; j < collects.length; j++) {
      const collect = collects[j]
      if (
        contrastFun(text, collect.condition.start.relation, collect.condition.start.value) &&
        contrastFun(text, collect.condition.end.relation, collect.condition.end.value)
      ) {
        style = {
          color: collect.fontColor.checked ? collect.fontColor.color : '',
          backgroundColor: collect.backgroundColor.checked ? collect.backgroundColor.color : ''
        }
      }
    }
  }
  return style
}
//关系比对
export const contrastFun = (val: number, relation: any, value: number) => {
  val = +val
  value = +value
  if (isNaN(val)) return false
  switch (relation) {
    case 'lt':
      return val < value
    case 'lte':
      return val <= value
    case 'e':
      return val == value
    case 'gt':
      return val > value
    case 'gte':
      return val >= value
    default:
      return false
  }
}
