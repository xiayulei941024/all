<template>
  <div class="side-bar">
    <gl-menu
      v-model:openKeys="state.openKeys"
      v-model:selectedKeys="current"
      theme="dark"
      mode="inline"
      @click="handleClick"
      :inline-collapsed="state.collapsed"
    >
      <template v-for="item in leftNavList" :key="item.id">
        <gl-sub-menu :key="item.menuUrl" v-if="item.children" class="menu-item-default">
          <template #title>{{ item.menuName }}</template>
          <gl-menu-item :key="i.menuUrl" v-for="i in item.children">{{ i.menuName }}</gl-menu-item>
        </gl-sub-menu>
        <gl-menu-item v-else class="menu-item-default" :key="item.menuUrl + ''">
          <span class="name">{{ item.menuName }}</span>
        </gl-menu-item>
      </template>
    </gl-menu>
  </div>
</template>

<script setup lang="ts">
// import { PieChartOutlined } from '@ant-design/icons-vue'
import { useRouter } from 'vue-router'
import { ref, watch, reactive, onMounted } from 'vue'
interface IleftNav {
  menuUrl: string
  menuName: string
  children: { menuUrl: string; menuName: string }[]
}
interface Props {
  leftNavList: IleftNav[]
}

const state = reactive({
  collapsed: false,
  selectedKeys: [],
  openKeys: [],
  preOpenKeys: []
})

const router = useRouter()
const current = ref<string[]>([])

//porps
withDefaults(defineProps<Props>(), {
  leftNavList: () => []
})

//菜单点击
const handleClick = (item: { key: string }) => {
  router.push(item.key)
}

//获取菜单信息
const getLeftNav = () => {}

watch(
  () => router.currentRoute.value,
  (newValue: any) => {
    current.value = [newValue.path]
  },
  { immediate: true }
)

onMounted(() => {
  getLeftNav()
})
</script>

<style lang="scss" scoped></style>
