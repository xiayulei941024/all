export { default as InputSearch } from './index.vue'
