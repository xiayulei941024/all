<!--
 * @Autor: zouchuanfeng
 * @Date: 2023-06-17 18:05:36
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-06-27 14:15:25
 * @Description: 
-->
<template>
  <gl-input v-bind="$attrs" @press-enter="onSearch">
    <template #suffix>
      <icon name="icon-search" @click="onSearch({ target: $attrs.value })" color="#bfbfbf" />
    </template>
  </gl-input>
</template>

<script setup lang="ts">
import Icon from '../Icon/index.vue'
interface Emits {
  (e: 'search', val: { target: string }): void
}
const emits = defineEmits<Emits>()
const onSearch = (e: any) => {
  emits('search', e)
}
</script>

<style scoped></style>
