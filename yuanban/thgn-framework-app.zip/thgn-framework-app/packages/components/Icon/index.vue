<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-22 10:51:33
 * @Description: 
-->
<template>
  <MyIcon
    :type="name"
    :style="{ fontSize: `${size}px`, width: `${size}px`, height: `${size}px`, color: color }"
    :class="className"
  />
</template>
<script setup lang="ts">
import { createFromIconfontCN } from '@ant-design/icons-vue'
const iconFontUrl = import('./iconfont.js')
const MyIcon = createFromIconfontCN({
  scriptUrl: iconFontUrl // 在 iconfont.cn 上生成
})
interface Props {
  name: string
  className?: string
  size?: string
  color?: string
}
withDefaults(defineProps<Props>(), {
  name: '',
  className: '',
  size: '16',
  color: ''
})
</script>

<style scoped></style>
