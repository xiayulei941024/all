<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-13 15:40:27
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-08-28 15:49:40
 * @Description: 
-->
<template>
  <gl-radio-group class="tab-group-style" v-bind="$attrs">
    <gl-radio-button v-for="(item, index) in tabs" :key="index" :value="item.value">
      {{ item.label }}
    </gl-radio-button>
  </gl-radio-group>
</template>
<script setup lang="ts">
interface Props {
  tabs: any[]
}
const props = defineProps<Props>()
const tabwidth = 100 / props.tabs.length + '%'
</script>
<style scoped lang="scss">
$radio-group-bg_color: #eeeeee;
$radio_group_radius: 4px;
$radio_button_color: #023985;
$radio_button_active_bg_color: #fff;
$radio_button_height: 34px;
.gl-radio-group {
  background: $radio-group-bg_color;
  border-radius: $radio_group_radius;
  .gl-radio-button-wrapper {
    width: v-bind(tabwidth);
    text-align: center;
    height: $radio_button_height;
    line-height: $radio_button_height;
    margin: 2px;
    border: none;
    background: unset;
    &:first-child {
      border: none;
    }
    &:not(:first-child):before {
      width: 0;
    }
    &:not(:last-child):after {
      content: none;
    }
    &:hover {
      border-radius: 4px;
    }
  }
  .gl-radio-button-wrapper-checked {
    background-color: $radio_button_active_bg_color !important;
    border-radius: 4px;
    &:not(.gl-radio-button-wrapper-disabled) {
      background: $radio_button_active_bg_color;
      color: $radio_button_color;
      border: none;
    }
    &:hover {
      color: $radio_button_color;
    }
  }
}
</style>
