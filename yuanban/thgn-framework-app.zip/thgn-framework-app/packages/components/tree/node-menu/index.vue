<!--
 * @Autor: zhouwanwan
 * @Date: 2023-06-12 15:20:25
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-09-18 11:03:14
 * @Description: 
-->
<template>
  <div class="node-menu" v-if="showDrop" @click.stop>
    <gl-dropdown>
      <div class="hover-bg">
        <div class="shadow"></div>
        <div class="more">
          <icon name="icon-drop_menu" color="#1890ff" />
        </div>
      </div>
      <template #overlay>
        <gl-menu>
          <div
            v-for="(item, index) in list"
            :key="index"
            v-show="!item.condition || item.condition(data.dataRef)"
          >
            <gl-menu-item :key="index" :disabled="item.disabled && item.disabled(data.dataRef)">
              <span v-if="item.disabled && item.disabled(data.dataRef)">{{ item.label }}</span>
              <span v-else @click="item.handle(item, data.dataRef)">{{ item.label }}</span>
            </gl-menu-item>
          </div>
        </gl-menu>
      </template>
    </gl-dropdown>
  </div>
</template>
<script setup lang="ts">
import Icon from '../../Icon/index.vue'
import { NodeMenuType, NodeType } from '../interface'
interface Props {
  list: NodeMenuType[]
  data: NodeType
}
const props = defineProps<Props>()
const showDrop = computed(() => {
  return props.list.some(
    (item) => !item.condition || (item.condition && item.condition(props.data))
  )
})
</script>
<style lang="scss" scoped>
.node-menu {
  position: absolute;
  right: 0;
  top: 0;
  z-index: 100;
  .more {
    width: 20px;
    height: 20px;
    border-radius: 3px;
    text-align: center;
    line-height: 22px;
    margin-right: 10px;
    margin: 0 auto;
    &:hover {
      background-color: #d1e1ef;
    }
  }
}
.hover-bg {
  display: none;
  position: absolute;
  right: 0;
  width: 36px;
  height: 42px;
  background: #e5eff8;
  .shadow {
    display: none;
    width: 10px;
    height: 40px;
    background: linear-gradient(270deg, rgba(0, 0, 0, 0.18) 0%, rgba(0, 0, 0, 0) 78%);
    opacity: 0.19;
    position: absolute;
    left: -10px;
  }

  &:hover {
    .shadow {
      display: block;
    }
  }
}
.gl-tree-node-content-wrapper {
  &.gl-tree-node-selected {
    &:hover {
      .hover-bg {
        display: flex;
        align-items: center;
        justify-content: center;
        .shadow {
          display: block;
        }
      }
    }
  }
}
// }
</style>
