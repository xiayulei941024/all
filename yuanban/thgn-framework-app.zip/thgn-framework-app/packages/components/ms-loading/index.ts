export { default as MsLoading } from './index.vue'
