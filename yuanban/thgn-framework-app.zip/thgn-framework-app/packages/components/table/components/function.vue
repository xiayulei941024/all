<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-04 16:08:16
 * @Description: 
-->
<template>
  <!-- 通过回调函数回显文字 -->
  <span :title="column.callback(record)">{{ column.callback(record) }}</span>
</template>

<script setup lang="ts">
interface Props {
  record: Object
  column: { callback: Function }
}
defineProps<Props>()
</script>

<style scoped></style>
