/*
 * @Autor: zouchuanfeng
 * @Date: 2023-06-13 11:54:01
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-07-02 16:21:20
 * @Description: 组件导出入口文件
 */
import Switch from './switch.vue'
import Function from './function.vue'
import TextButton from './text-button.vue'
import Html from './html.vue'
export default {
  switch: Switch,
  function: Function,
  textButton: TextButton,
  html: Html
}
