<template>
  <gl-form :model="formState" labelAlign="right" ref="formRef" v-bind="$attrs">
    <gl-form-item
      v-for="item in formItems"
      :key="item.label"
      :label="item.label"
      :name="item.name"
      :rules="item.rules || []"
      :controls="item.controls"
      :label-col="item.labelCol"
    >
      <gl-input-password
        v-if="item.type === 'password'"
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.label}`"
      />
      <gl-input
        v-else-if="item.type === 'password-2'"
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.label}`"
        type="password"
      />
      <gl-select
        v-else-if="item.type === 'select'"
        v-model:value="formState[item.name]"
        :placeholder="`请选择${item.label}`"
        :mode="item.mode"
        :disabled="item.disabled || false"
        :allowClear="item.allowClear"
        @change="(value: any) => handleChange(item, value)"
        :style="item.style"
      >
        <gl-select-option
          v-for="(option, index) in item.options"
          :value="option.value"
          :key="index"
          >{{ option.name }}</gl-select-option
        >
      </gl-select>
      <gl-select
        v-else-if="item.type === 'select-default'"
        v-model:value="formState[item.name]"
        :placeholder="`请选择${item.label}`"
        :disabled="item.disabled || false"
        :options="item.options"
        :allowClear="item.allowClear"
        @change="(value: any) => handleChange(item, value)"
        :style="item.style"
      />
      <gl-input-number
        v-else-if="item.type === 'number'"
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.label}`"
        style="width: 100%"
        :min="item.min"
        :max="item.max"
        :precision="item.precision"
      />
      <gl-radio-group
        v-else-if="item.type === 'radioGroup'"
        v-model:value="formState[item.name]"
        :style="item.groupStyle"
        @change="(value: any) => handleChange(item, value)"
      >
        <gl-radio
          v-for="(option, index) in item.options"
          :value="option.value"
          :key="index"
          :disabled="item.disabled || false"
          :style="item.radioStyle"
          >{{ option.name }}
        </gl-radio>
      </gl-radio-group>
      <gl-checkbox-group
        v-else-if="item.type === 'checkboxGroup'"
        v-model:value="formState[item.name]"
        :options="item.options"
      />
      <gl-date-picker
        v-else-if="item.type === 'datePicker'"
        v-model:value="formState[item.name]"
        :show-today="item.showToday || false"
        :placeholder="`请选择${item.label}`"
        :style="{ width: item.width }"
      ></gl-date-picker>
      <gl-input
        v-else-if="item.type === 'input-number'"
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.label}`"
        :disabled="item.disabled || false"
        onkeyup="value=value.replace(/[^\d{1,}\.\d{1,}|\d{1,}]/g,'')"
      />
      <gl-range-picker
        v-else-if="item.type === 'date-range'"
        v-model:value="formState[item.name]"
        separator="~"
        :style="item.style"
      />
      <ms-collapse-select
        v-else-if="item.type === 'collapse-select'"
        v-model:selected="formState[item.name]"
        mode="multiple"
        :placeholder="`请选择${item.label}`"
        :max-tag-count="item.maxCount"
        :options="item.options"
        :style="item.style"
      />
      <slot v-else-if="item.slotName" :name="item.slotName" :item="item"></slot>
      <gl-textarea
        v-else-if="item.type === 'textarea'"
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.label}`"
        :style="item.style"
      />
      <gl-input
        v-else
        v-model:value="formState[item.name]"
        :placeholder="`请输入${item.placeholder || item.label}`"
        :disabled="item.disabled || false"
        :maxlength="item.maxLength"
        :style="item.style"
      />

      <gl-tooltip :title="item.tooltip" v-if="item.tooltip" class="tool-tip">
        <icon name="icon-tip" color="#d9d9d9" />
      </gl-tooltip>
    </gl-form-item>
  </gl-form>
</template>
<script setup lang="ts">
import { Icon } from '../index'
import MsCollapseSelect from '../ms-collapse-select/index.vue'
interface formItem {
  type?: string
  name: string
  label: string
  rules?: any
  tooltip?: string
  options?: any
  disabled?: boolean
}
interface Props {
  formParams: any
  formItems: Array<formItem>
}
const props = defineProps<Props>()

interface Emits {
  (e: 'update:formParams', val: any): void
  (e: 'handle-change', item: any, value: any): void
}
const emits = defineEmits<Emits>()

const formRef = ref()
const formState = computed({
  get() {
    return props.formParams
  },
  set(val: any) {
    emits('update:formParams', val)
  }
})

const validate = () => {
  return formRef.value.validate()
}

const resetFields = () => {
  formRef.value.resetFields()
}
const handleChange = (item: any, value: any) => {
  emits('handle-change', item, value)
}
defineExpose({
  validate,
  resetFields
})
</script>
<style lang="scss" scoped>
:deep(.gl-form-item-label) {
  width: 120px;
}
:deep(.gl-form-item) {
  padding-right: 20px;
  position: relative;
  .tool-tip {
    position: absolute;
    right: -16px;
    top: 7px;
  }
}
</style>
