<!--
 * @Autor: zhouwanwan
 * @Date: 2023-05-26 09:10:35
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-30 11:59:36
 * @Description: 
-->
<template>
  <gl-modal
    v-model:visible="isVisible"
    v-bind="$attrs"
    :confirmLoading="loading"
    centered
    :title="title"
    @ok="handleOk"
    @cancel="handleCancel"
    :destroyOnClose="true"
  >
    <ms-form
      v-model:formParams="formState"
      :formItems="formItems"
      ref="msFormRef"
      @handle-change="changeData"
      :labelCol="formConfig?.labelCol"
      :wrapperCol="formConfig?.wrapperCol"
    />
  </gl-modal>
</template>
<script setup lang="ts">
import { MsForm } from '../index'
import { throttle } from 'lodash-es'
import { ref, computed } from 'vue'
interface formItem {
  type?: string
  name: string
  label: string
  rules?: any
  tooltip?: string
  options?: any
  disabled?: boolean
}

interface Props {
  visible: boolean
  title: string
  formParams: any
  formItems: Array<formItem>
  formConfig?: any
  loading?: boolean
}
const props = defineProps<Props>()

interface Emits {
  (e: 'update:visible', val: boolean): void
  (e: 'update:formParams', val: any): void
  (e: 'change-item', item: any, value: any): void
  (e: 'ok'): void
}
const emits = defineEmits<Emits>()

const msFormRef = ref()

const isVisible = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    msFormRef.value.resetFields()
    emits('update:visible', val)
  }
})

const formState = computed({
  get() {
    return props.formParams
  },
  set(val) {
    emits('update:formParams', val)
  }
})

const handleOk = throttle(() => {
  msFormRef.value
    .validate()
    .then(async () => {
      emits('ok')
    })
    .catch(() => {
      return false
    })
}, 3000)

const changeData = (item: any, value: any) => {
  emits('change-item', item, value)
}
const handleCancel = () => {
  emits('update:visible', false)
}
</script>
<style lang="scss" scoped></style>
