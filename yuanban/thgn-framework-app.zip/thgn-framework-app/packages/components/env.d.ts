/*
 * @Autor: zouchuanfeng
 * @Date: 2023-07-13 15:35:12
 * @LastEditors: zouchuanfeng
 * @LastEditTime: 2023-08-02 11:59:35
 * @Description:
 */
/// <reference types="vite/client" />
declare module '*.vue' {
  import { defineComponent } from 'vue'
  const Component: ReturnType<typeof defineComponent>
  export default Component
}
declare module 'gl-design-vue'
declare module 'moment'
declare module 'vue3-super-flow'
