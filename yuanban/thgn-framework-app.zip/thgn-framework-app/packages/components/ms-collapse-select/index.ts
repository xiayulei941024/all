export { default as MsCollapseSelect } from './index.vue'
