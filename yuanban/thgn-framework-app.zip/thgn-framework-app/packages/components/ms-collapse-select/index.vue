<!--
 * @Autor: zhouwanwan
 * @Date: 2023-08-18 17:33:32
 * @LastEditors: zhouwanwan
 * @LastEditTime: 2023-10-07 16:41:43
 * @Description: 多选折叠下拉
-->
<template>
  <gl-select v-bind="$attrs" v-model:value="data" class="ms-count-select" :style="style">
    <template #maxTagPlaceholder="omittedValues">
      <span style="color: #333">+{{ omittedValues.length }}</span>
    </template>
  </gl-select>
</template>
<script setup lang="ts">
import { computed } from 'vue'

interface Props {
  selected: any
  style: any
}
interface Emits {
  (e: 'update:selected', val: any): void
}
const props = defineProps<Props>()
const emits = defineEmits<Emits>()
const data = computed({
  get() {
    return props.selected
  },
  set(val: any) {
    emits('update:selected', val)
  }
})
</script>
<style scoped lang="scss">
.ms-count-select {
  :deep(.gl-select-selection-item) {
    background: #f1f1f1;
    color: #333;
    border: none;
    font-size: 12px;
    height: 26px;
    line-height: 26px;
    margin-top: 1px;
    margin-bottom: 1px;
  }
  :deep(.gl-select-multiple) {
    .gl-select-selection-item-content {
      margin-right: 0;
    }
  }
  :deep(.gl-select-selector) {
    // width: 250px;
    height: 32px;
    display: flex;
    align-items: center;
    .anticon-close {
      display: flex;
      align-items: center;
      height: 100%;
    }

    .gl-select-selection-overflow {
      .gl-select-selection-overflow-item {
        max-width: 80%;
        &-rest {
          width: 20%;
        }
      }
    }
  }
}
</style>
