export { default as FullModal } from './index.vue'
