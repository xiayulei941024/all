<template>
  <gl-modal
    v-model:visible="isShow"
    v-if="isShow"
    :closable="false"
    :maskClosable="false"
    :width="fullWidth"
    :wrap-class-name="title ? 'full-modal' : 'full-modal no-title'"
    v-bind="$attrs"
    :footer="null"
  >
    <template #title>
      <div class="hd" v-if="title">{{ title }}</div>
      <slot name="title" v-else></slot>
    </template>
    <div class="btn-box">
      <slot name="ft">
        <slot name="extra-btn"></slot>
        <gl-button
          v-if="showSubmit"
          class="btn-box-content"
          @click="submit"
          :loading="saveLoading"
          type="primary"
        >
          <icon name="icon-comform_outlined" />
          {{ submitName || '确定' }}
        </gl-button>
        <gl-button
          class="btn-box-content"
          type="primary"
          :confirmTitle="confirmTitle"
          @click="close"
          v-if="!closeDisabled"
        >
          <icon name="icon-unselect_outlined" />
        </gl-button>
      </slot>
    </div>
    <slot />
  </gl-modal>
</template>
<script setup lang="ts">
import Icon from '../Icon/index.vue'
import { createVNode, computed } from 'vue'
import { Modal } from 'gl-design-vue'
import { ExclamationCircleOutlined } from '@ant-design/icons-vue'
import { throttle } from 'lodash-es'
interface Props {
  visible: boolean
  showSubmit?: boolean
  saveLoading?: boolean
  submitName?: string //是否显示确定按钮
  confirmTitle?: string //取消二次提示文字
  title?: string
  sideWidth?: number
  closeDisabled?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  visible: false,
  showSubmit: true, //是否显示确定按钮
  saveLoading: false,
  submitName: '',
  confirmTitle: '', //取消二次提示文字
  title: '',
  sideWidth: 32,
  closeDisabled: false
})
const fullWidth = computed(() => {
  '`${((1920 - 240) / 1920) * 100}vw`'
  const fullWidth = ((1920 - props.sideWidth) / 1920) * 100
  return `${fullWidth}vw`
})
interface Emits {
  (e: 'handle-ok'): void
  (e: 'handle-cancel'): void
  (e: 'update:visible', visible: boolean): void
}
const emits = defineEmits<Emits>()
const isShow = computed({
  get() {
    return props.visible
  },
  set(val: boolean) {
    emits('update:visible', val)
  }
})
const submit = throttle(() => {
  emits('handle-ok')
}, 3000)

const close = () => {
  if (props.confirmTitle) {
    //二次确认提示
    Modal.confirm({
      title: props.confirmTitle,
      icon: createVNode(ExclamationCircleOutlined),
      onOk() {
        emits('handle-cancel')
        emits('update:visible', false)
      }
    })
  } else {
    emits('handle-cancel')
    emits('update:visible', false)
  }
}
</script>
<style lang="scss">
$gap: 16px;
$headerHeight: 55px;
$top: 110px;
.full-modal {
  &.gl-modal-wrap {
    overflow: hidden;
  }
  .gl-modal {
    right: $gap;
    position: absolute;
    top: $top;
    padding: 0 0 $gap;
    height: calc(100% - $top);
  }
  .gl-modal-body {
    height: calc(100% - $headerHeight);
    overflow: auto;
  }
  &.report-view-full-modal {
    .gl-modal {
      top: 16px;
      height: calc(100% - 16px);
    }
    .gl-modal-body {
      height: calc(100% - 55px);
    }
  }
  .gl-modal-content {
    height: 100%;
  }
  &.no-title {
    .gl-modal-body {
      height: 100%;
    }
    .gl-modal-header {
      padding: 0;
    }
  }
  .btn-box {
    height: 40px;
    display: flex;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-pack: end;
    justify-content: flex-end;
    position: absolute;
    right: 0;
    top: -34px;
    right: 20px;
    z-index: -1;
    &-content {
      margin-left: 6px;
      color: #fff;
    }
  }
}
</style>
