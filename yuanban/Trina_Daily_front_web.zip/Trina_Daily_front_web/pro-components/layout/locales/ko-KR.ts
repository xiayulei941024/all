import settingDrawer from './ko-KR/settingDrawer'

export default {
  ...settingDrawer
}
