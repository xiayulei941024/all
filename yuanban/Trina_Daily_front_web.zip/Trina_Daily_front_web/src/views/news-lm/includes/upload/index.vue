<template>
  <div class="upload">
    <slot :show-modal="showModal">
      <a-button @click="showModal"> 上传文件 </a-button>
    </slot>

    <a-modal v-model:visible="visible" title="Title" @ok="handleOk" :footer="null">
      <a-upload-dragger
        :fileList="_fileList"
        name="file"
        :multiple="true"
        @change="handleChange"
        @drop="handleDrop"
        :customRequest="handleCustomRequest"
      >
        <p class="ant-upload-drag-icon">
          <inbox-outlined></inbox-outlined>
        </p>
        <p class="ant-upload-text">上传文件</p>
        <p class="ant-upload-hint">点击或者拖住按文件到该区域以上传文件</p>
      </a-upload-dragger>
    </a-modal>
  </div>
</template>

<script lang="ts" setup>
import { InboxOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import type { UploadChangeParam, UploadRequestOption } from 'ant-design-vue'
import { ref } from 'vue'
import { useNewsLmStore } from '@/stores/news-lm'
import { storeToRefs } from 'pinia'

const newsLmStore = useNewsLmStore()
const { fileList } = storeToRefs(newsLmStore)
const _fileList = computed(() => {
  return fileList.value.map(item => item.file)
})
const { setFileList } = newsLmStore
defineOptions({ name: 'NewsLmUpload' })

const loading = ref<boolean>(false)
const visible = ref<boolean>(false)

const showModal = () => {
  visible.value = true
}

const handleOk = () => {
  loading.value = true
  setTimeout(() => {
    loading.value = false
    visible.value = false
  }, 2000)
}

const handleCancel = () => {
  visible.value = false
}

const handleDrop = (e: DragEvent) => {
  console.log(e)
}
const handleChange = (info: UploadChangeParam) => {
  const status = info.file.status
  if (status !== 'uploading') {
    console.log(info.file, info.fileList)
  }
  if (status === 'done') {
    message.success(`${info.file.name} file uploaded successfully.`)
  } else if (status === 'error') {
    message.error(`${info.file.name} file upload failed.`)
  }
}

let id = 1
function handleCustomRequest(uploadRequestOption: UploadRequestOption) {
  const file = uploadRequestOption.file
  file.status = 'done'
  uploadRequestOption.onProgress({
    percent: 100,
  })
  setFileList([...fileList.value, { file, id: id++, checked: false }])
}
</script>

<style lang="less" scoped>
.upload {
  width: 100%;
}
</style>
