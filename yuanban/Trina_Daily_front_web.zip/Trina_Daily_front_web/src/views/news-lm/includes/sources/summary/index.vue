<template>
  <div class="summary"></div>
</template>

<script lang="ts" setup>
defineOptions({ name: 'NewsLmSourcesSummary' })
</script>
