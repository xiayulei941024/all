<template>
  <div class="sources-container">
    <a-card
      :bordered="false"
      class="page-content"
      :body-style="{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }"
    >
      <template v-if="false">
        <div class="header-title">
          要闻
          <menu-fold-outlined />
        </div>
        <!-- 操作区 -->
        <!-- <div class="operation-container">
        <NewsLmUpload>
          <template #default="{ showModal }">
            <a-button class="upload-btn" @click="showModal" shape="round" size="large">
              <template #icon>
                <cloud-upload-outlined />
              </template>
              上传文件
            </a-button>
          </template>
        </NewsLmUpload>
      </div> -->

        <a-card
          :bordered="false"
          style="flex: 1; overflow: hidden"
          :body-style="{
            height: '100%',
            paddingBottom: 0,
            paddingLeft: 0,
          }"
        >
          <NewsLmSourcesList />
        </a-card>
      </template>
      <a-tabs
        :active-key="activeKey"
        :tab-bar-style="{
          marginBottom: 0,
        }"
        @update:active-key="setActiveKey"
      >
        <template #rightExtra>
          <div style="font-size: 20px; cursor: pointer">
            <menu-fold-outlined v-if="colMode === Modes.SOURCES" @click="setColMode(Modes.DEFAULT)" />
            <menu-unfold-outlined v-else @click="() => setColMode(Modes.SOURCES)" />
          </div>
        </template>
        <a-tab-pane v-for="item in tabs" :key="item.key" :tab="item.label">
          <a-card
            :bordered="false"
            style="height: 100%; overflow: hidden"
            :body-style="{
              height: '100%',
              paddingBottom: 0,
              paddingLeft: 0,
              paddingRight: 0,
            }"
          >
            <component :is="item.children"></component>
          </a-card>
        </a-tab-pane>
      </a-tabs>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import NewsLmUpload from '../upload/index.vue'
import NewsLmSourcesList from './list/index.vue'
import NewsLmSourcesHistory from './history/index.vue'
import { useNewsLmStore, Modes } from '@/stores/news-lm'

defineOptions({ name: 'NewsLmSources' })

const newsLmStore = useNewsLmStore()
// tabs - 要闻/历史记录
const { activeKey, colMode } = storeToRefs(newsLmStore)
const { setActiveKey, setColMode } = newsLmStore

const tabs = [
  {
    key: '1',
    label: '要闻',
    children: NewsLmSourcesList,
  },
  {
    key: '2',
    label: '历史会话',
    children: NewsLmSourcesHistory,
  },
]
</script>

<style lang="less" scoped>
@import url(../../index.less);
.sources-container {
  overflow: hidden;
  height: 100%;
  .page-content {
    height: 100%;
    .header-title {
      #header-title;
    }
    .operation-container {
      height: 80px;
      display: flex;
      align-items: center;
      justify-content: center;
      .upload-btn {
        width: 100%;
      }
    }
    :deep .ant-tabs {
      height: 100%;
      .ant-tabs-tab {
        padding: 0;
        #header-title;
      }
      .ant-tabs-content-holder {
        flex: 1;
        .ant-tabs-content {
          height: 100%;
          .tabpanel {
            height: 100%;
          }
        }
      }
    }
  }
}
</style>
