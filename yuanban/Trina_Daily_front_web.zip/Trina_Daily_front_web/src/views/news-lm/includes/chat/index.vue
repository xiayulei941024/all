<template>
  <div class="chat-container">
    <a-card
      :bordered="false"
      class="page-content"
      :body-style="{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }"
    >
      <div class="header-title">
        <div>
          <span @click="changeStream">会话</span>
          <!-- {{ currentHistoryId ? `(${currentHistoryId})` : '' }} -->

          <a-button v-if="!!currentHistoryId" @click="setCurrentHistoryId(null)" style="margin-left: 8px">
            <PlusOutlined />
            新建会话</a-button
          >
        </div>
        <menu-fold-outlined v-if="colMode === Modes.CHAT" @click="setColMode(Modes.DEFAULT)" />
        <menu-unfold-outlined v-else @click="() => setColMode(Modes.CHAT)" />
      </div>
      <a-card
        :bordered="false"
        style="flex: 1; overflow: hidden"
        :body-style="{
          height: '100%',
          paddingBottom: 0,
        }"
      >
        <div class="chat-main">
          <NewsLmChatContent :is-loading="isLoading" :history="history" />
          <NewsLmChatCompletion :is-loading="isLoading" v-model:inputValue="inputValue" @submit="handleSubmit" />
        </div>
      </a-card>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import NewsLmChatContent from './content/index.vue'
import NewsLmChatCompletion from './completion/index.vue'
import { chatApi, setUserSessionApi } from '@/api/news'
import { useNewsLmStore, Modes } from '@/stores/news-lm'
import { useUserStore } from '@/stores/user-store'
import type { ISession, ISessionItem } from '../../types'
import useChat from './content/hooks/useChat'

defineOptions({ name: 'NewsLmChat' })

const userStore = useUserStore()
const { userInfo } = userStore
const newsLmStore = useNewsLmStore()
const { currentHistoryId, colMode, selectedNewsSources, currentHistory, historySessions } = storeToRefs(newsLmStore)
const { setColMode, setCurrentHistoryId, addHistorySessions } = newsLmStore
const history = ref([])

const chat = useChat({ queryAgentURL: '/api/chat-stream' })

// 是否使用流式传输
const isStream = ref(true)
// 用于跟踪点击次数和时间的变量
let clickCount = 0
let firstClickTime = 0
function changeStream() {
  // 如果是第一次点击，记录时间
  if (clickCount === 0) {
    firstClickTime = Date.now()
  }

  // 增加点击次数
  clickCount++

  // 如果点击次数达到 3 次并且时间间隔小于 3 秒，切换状态
  if (clickCount === 3) {
    if (Date.now() - firstClickTime <= 1000) {
      isStream.value = !isStream.value
      console.log('您已成功切换至: ', isStream.value ? '流式传输' : '普通传输')
    }
    // 重置点击次数和时间
    clickCount = 0
    firstClickTime = 0
  } else {
    // 如果没有满足条件，设置定时器重置
    setTimeout(() => {
      clickCount = 0
      firstClickTime = 0
    }, 1000)
  }
}

watch(
  () => currentHistoryId.value,
  () => {
    if (currentHistoryId.value) {
      history.value = [...currentHistory.value.histories]
    } else {
      history.value = []
    }
  },
  {
    immediate: true, // 每次切换页面也需要更新历史记录到最新
  }
)
const inputValue = ref('')
const isLoading = ref(false)

async function handleSubmit() {
  let sessionId
  const recentTime = new Date().getTime()
  if (currentHistoryId.value) {
    sessionId = currentHistoryId.value
  } else {
    sessionId = recentTime + '-' + userInfo?.userId
  }
  isLoading.value = true
  const _inputValue = inputValue.value

  const tempHistory = [
    ...history.value,
    { role: 'user', content: _inputValue },
    {
      role: 'assistant',
      content: '正在思考中...',
      // content:
      //   '天合公司成立于1997年[^1]。\n\n参考来源：\n[^1]: [[123321,0,15]]\n[^2]: [[123321,0,12]]\n[^3]: [[123321,0,12]]',
    },
  ]

  const _history = [...history.value]
  // history.value = tempHistory
  history.value = [...tempHistory]
  const index = history.value.length - 1
  const lastHistory = history.value[index]
  await nextTick()

  if (isStream.value) {
    chatStream(sessionId, _inputValue, selectedNewsSources.value, history, _history, recentTime, lastHistory)
  } else {
    chatNormal(sessionId, _inputValue, selectedNewsSources.value, history, _history, recentTime, lastHistory)
  }
}

// 流式传输
function chatStream(sessionId, newInputValue, selectedNewsSources, history, oldHistory, recentTime, lastHistory) {
  chat({
    data: {
      query: newInputValue,
      news_id: selectedNewsSources.map(item => item + ''),
      histories: oldHistory.map(item => {
        const rule = /\n\n参考来源：[\s\S]*$/
        const answerContent = item.content.replace(rule, '')
        return {
          role: item.role,
          content: answerContent,
        }
      }),
    },
    onOpen() {
      lastHistory.content = ''
    },
    onMessage(message) {
      console.log(message)
      lastHistory.content += message
      history.value = [...history.value]
    },

    onDone: async () => {
      await handleEnd(sessionId, newInputValue, selectedNewsSources, lastHistory.content, recentTime, history.value)
      isLoading.value = false
      console.log('done')
    },
    onClose: () => {
      // isLoading.value = false
      console.log('close')
    },
    onError: async message => {
      lastHistory.content = message || '出错了'
      history.value = [...history.value]
      await handleEnd(sessionId, newInputValue, selectedNewsSources, lastHistory.content, recentTime, history.value)
      isLoading.value = false
      console.log('error')
    },
  })
}
// 普通传输
async function chatNormal(sessionId, newInputValue, selectedNewsSources, history, oldHistory, recentTime, lastHistory) {
  const assistantContent = await handleSend(newInputValue, selectedNewsSources, oldHistory)

  const str = assistantContent
  await simulateStream(str, output => {
    lastHistory.content = output
    history.value = [...history.value]
    // Object.assign(tempHistory[index], lastHistory)
    // console.log(history.value)
  })

  // 结束回调
  await handleEnd(sessionId, newInputValue, selectedNewsSources, assistantContent, recentTime, history.value)
  isLoading.value = false
}

async function handleEnd(sessionId, inputValue, selectedNewsSources, fullContent, recentTime, newHistory) {
  const rule = /\n\n参考来源：[\s\S]*$/
  const answerContent = fullContent.replace(rule, '')

  const reg = /\[\^(\d+)\]:\s\[\[(\d+),(\d+),(\d+)\]\]+/g

  const matchs: RegExpStringIterator<RegExpMatchArray> = fullContent.matchAll(reg)
  const referenceIdList = []
  matchs.forEach((item: RegExpMatchArray) => {
    const [_, id, newsId, start, end] = item
    // console.log('item', id, newsId, start, end)
    referenceIdList.push(newsId)
  })

  // 保存会话
  const data: ISessionItem = {
    sessionId,
    fullContent,
    askUserId: userInfo?.userId,
    askUserName: userInfo?.userName,
    newsIds: selectedNewsSources.join(','),
    answerUserId: null,
    answerUserName: null,
    questionContent: inputValue,
    answerContent: answerContent,
    referenceId: referenceIdList.join(','),
  }
  // 存入数据库
  const res = await setUserSessionApi(data)
  // 存入本地库
  if (currentHistoryId.value) {
    // 更新历史会话
    // 是在操作历史记录的情况下 需要更新时间
    currentHistory.value.recentTime = recentTime
  } else {
    // 新增历史会话
    const session: ISession = {
      sessionId: sessionId,
      sessionRecordList: [{ ...data }],
      histories: newHistory,
      newsIdList: [...selectedNewsSources],
      recentTime: recentTime,
      sessionName: res?.data || inputValue,
    }
    addHistorySessions(session)
    setCurrentHistoryId(sessionId)
  }
}

// 发送消息
async function handleSend(inputValue, selectedNewsSources, histories) {
  const res = await chatApi({
    query: inputValue,
    news_id: selectedNewsSources.map(item => item + ''),
    histories: histories.map(item => {
      const rule = /\n\n参考来源：[\s\S]*$/
      const answerContent = item.content.replace(rule, '')
      return {
        role: item.role,
        content: answerContent,
      }
    }),
  })
  return res.response
}

// 模拟流式
function simulateStream(text, callback) {
  let output = ''
  let index = 0

  return new Promise((resolve, reject) => {
    function typeText() {
      if (index < text.length) {
        output += text[index]
        // document.getElementById("output").innerText = output;
        // console.log(output)
        callback(output)
        index++
        setTimeout(typeText, 20) // 递归调用
      } else {
        console.log('结束')
        return resolve()
      }
    }
    setTimeout(typeText, 20)
  })
  // requestAnimationFrame(typeText)
}
</script>

<style lang="less" scoped>
@import url(../../index.less);
.chat-container {
  height: 100%;
  .page-content {
    height: 100%;
    .header-title {
      #header-title;
    }
    .chat-main {
      height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      gap: 8px;
    }
  }
}
</style>
