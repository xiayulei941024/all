export enum LOV_SEARCH_TYPE_ENUM {
  INPUT = 'input',
  NUMBER_INPUT = 'number-input',
  SELECT = 'select',
  DICT_SELECT = 'dict-select'
}
