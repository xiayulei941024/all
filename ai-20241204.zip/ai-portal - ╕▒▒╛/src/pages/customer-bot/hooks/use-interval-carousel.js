import { useState, useEffect, useRef } from "react";

export default function useIntervalCarousel(length, interval = 3000) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const timerRef = useRef(null);

  const start = () => {
    if (timerRef.current) return;
    timerRef.current = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % length);
    }, interval);
  };

  const stop = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const manualChange = () => {
    stop();
    setCurrentIndex((prevIndex) => (prevIndex + 1) % length);
    start();
  };

  useEffect(() => {
    start();
    return stop; // 清理计时器
  }, []);

  return { currentIndex, start, stop, manualChange };
}
