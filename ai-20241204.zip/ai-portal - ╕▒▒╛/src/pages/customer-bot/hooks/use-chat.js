import { EventStreamContentType, fetchEventSource } from '@microsoft/fetch-event-source';
import { message } from 'antd';
import { useCallback, useEffect, useMemo } from 'react';

// type Props = {
//   queryAgentURL?: string;
// };

// type ChatParams = {
//   chatId: string;
//   data?: Record<string, any>;
//   query?: Record<string, string>;
//   onMessage: (message: string) => void;
//   onClose?: () => void;
//   onDone?: () => void;
//   onError?: (content: string, error?: Error) => void;
// };

const useChat = ({ queryAgentURL = '/api/event-stream' }) => {
  const ctrl = useMemo(() => new AbortController(), []);

  const chat = useCallback(
    async ({ data, chatId, onMessage, onClose, onDone, onError }) => {
      if (!data?.user_input) {
        message.warning("请输入你的问题");
        return;
      }

      const parmas = {
        ...data,
        conv_uid: chatId,
      };

      if (!parmas.conv_uid) {
        message.error('conv_uid 不存在，请刷新后重试');
        return;
      }

      try {
        await fetchEventSource(`${queryAgentURL}`, {
          method: 'GET',
          // headers: {
          //   'Content-Type': 'application/json',
          // },
          // body: JSON.stringify(parmas),
          signal: ctrl.signal,
          openWhenHidden: true,
          async onopen(response) {
            if (response.ok && response.headers.get('content-type') === EventStreamContentType) {
              return;
            }
          },
          onclose() {
            ctrl.abort();
            onClose?.();
          },
          onerror(err) {
            throw new Error(err);
          },
          onmessage: (event) => {
            let message = event.data;
            try {
              message = JSON.parse(message).vis;
            } catch (e) {
              message.replaceAll('\\n', '\n');
            }
            console.log('message', message);
            if (message === '[DONE]') {
              onDone?.();
            } else if (message?.startsWith('[ERROR]')) {
              onError?.(message?.replace('[ERROR]', ''));
            } else {
              onMessage?.(message);
            }
          },
        });
      } catch (err) {
        ctrl.abort();
        onError?.('Sorry, We meet some error, please try agin later.', err);
      }
    },
    [queryAgentURL],
  );

  useEffect(() => {
    return () => {
      ctrl.abort();
    };
  }, []);

  return chat;
};

export default useChat;
