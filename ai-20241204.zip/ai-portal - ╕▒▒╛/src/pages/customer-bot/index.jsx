// react-markdown
import "./index.css"
import { Input, Button } from 'antd';
import { useState, useCallback, useEffect, useMemo } from 'react';
import { SendOutlined } from '@ant-design/icons';
import classNames from 'classnames';
import PromptList from './PromptList';
import useChat from "./hooks/use-chat";
import CompletionContainer from "./completion-container/index";
import ChatContainer from './chat-container/index';
import LogoMat from '../../images/logo-mat.png'
import FilterPanel from "./filter-panel";

export default function CustomerBot({...props}) {
  console.log('CustomerBot render');
  const chat = useChat({ queryAgentURL: '/api/event-stream' });

  // 历史记录
  const [history, setHistory] = useState([]);
  const [ hasBody, setHasBody] = useState(false);
  
  // 聊天操作
  const handleChat = useCallback(
    (content, data = {
      incremental: false,
    }) => {
      if (!hasBody) setHasBody(true);
      return new Promise((resolve) => {
        const tempHistory = [
          ...history,
          { role: 'human', context: content, order: 0, time_stamp: 0 },
          { role: 'view', context: '', order: 0, time_stamp: 0 },
        ];
        const index = tempHistory.length - 1;
        setHistory([...tempHistory]);
        chat({
          data: { ...data, user_input: content },
          chatId: "chatId123",
          onMessage: (message) => {
            if (data?.incremental) {
              tempHistory[index].context += message;
            } else {
              tempHistory[index].context = message;
            }
            setHistory([...tempHistory]);
          },
          onDone: () => {
            // getChartsData(tempHistory);
            resolve();
          },
          onClose: () => {
            // getChartsData(tempHistory);
            resolve();
          },
          onError: (message) => {
            tempHistory[index].context = message;
            setHistory([...tempHistory]);
            resolve();
          },
        });
      });
    },
    [chat],
  );

  // // 是否有history
  // const hasBody = useMemo(() => {
  //   return history.length > 0;
  // }, [history]);

  return (
    <div className='w-full h-screen  bg-slate-100 relative flex flex-col h-screen'>
      <header className='shrink-0 w-full bg-white fixed shadow-md shadow-slate-200 z-10' style={{height: '60px', padding: '0 40px'}}>
        <div className='flex items-center h-full'>
          <img src={LogoMat} style={{width: '30px', height: '30px'}}></img>
          <span className='font-bold tracking-wider' style={{marginLeft: '10px'}}>图像生成</span>
        </div>
      </header>
      <div className={classNames("flex flex-col flex-1 bg-slate-100 overflow-hidden", {
        "justify-center": !hasBody,
        "items-center": !hasBody
      })}>
        <ChatContainer hasBody={hasBody} history={history} />
        <div className={classNames("shrink-0 p-4 rounded-t-xl", {
            "w-3/6": !hasBody,
            "bg-white": hasBody,
            "shadow-sm": hasBody
        })}>
          <div className={classNames("mb-4", {
            // "w-3/6": !hasBody
          })}>
            <PromptList />
          </div>
          {/* 筛选项 */}
          {/* <div className='flex justify-between items-center'>
          </div> */}
          <CompletionContainer maxLength={100} hasBody={hasBody} onSubmit={handleChat} />
        </div>
      </div>
    </div>
  );
}