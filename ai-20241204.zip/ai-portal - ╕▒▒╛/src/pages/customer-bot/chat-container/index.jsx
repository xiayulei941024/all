import classNames from "classnames";
import PromptList from "../PromptList";
import ChatContent from "./chat-content";
import { useEffect, useRef } from "react";

function ChatContainer(props) {
  const { hasBody, history } = props;

  const scrollableRef = useRef(null);

  useEffect(() => {
    setTimeout(() => {
      scrollableRef.current?.scrollTo(0, scrollableRef.current.scrollHeight);
    }, 50);
  }, [history]);

  return (
    <div ref={scrollableRef} className={classNames("overflow-y-auto px-4",{
      "flex-1": hasBody,
      "w-3/6": !hasBody,
      "mb-4": hasBody
    })}>
      <div className="flex flex-col">
        {!hasBody && (
          <div>
            <h1 className="text-4xl font-bold mb-4">图像生成！</h1>
            <p className="text-lg text-gray-600">基于Dall-E-3模型，包含图像生成和图像风格迁移</p>
          </div>
        )}
        {
          hasBody && (
            history.map((content, index) => <ChatContent key={index} content={content} />)
          )
        }
        
    
        {/* <div className="w-full max-w-2xl">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            rehypePlugins={[rehypeRaw]}
          >{ markdown }</ReactMarkdown>
        </div> */}
      </div>
    </div>
  );
}

export default ChatContainer;