import { SendOutlined } from '@ant-design/icons';
import React, { useState, useCallback } from 'react';
import classNames from 'classnames';
import { Input, Button } from 'antd';
import { omit } from 'lodash';
import FilterPanel from '../filter-panel';
import CompletionInput from './CompletionInput';

const CompletionContainer = React.memo((props) => {
  console.log('CompletionContainer render');
  const { hasBody, onSubmit } = props;

  // 输入内容
  const [userInput, setUserInput] = useState('');
  function handleSubmit() {
    // console.log('userInput', userInput);
    // console.log('selectedValues', selectedValues)
    onSubmit(userInput)
  }

  
  // 管理子组件的 selected 值
  const [selectedValues, setSelectedValues] = useState({});
  
  return (
    <>
      <FilterPanel setSelectedValues={setSelectedValues} />
      <CompletionInput hasBody={hasBody} setUserInput={setUserInput} handleSubmit={handleSubmit} />
    </>
  );
})

export default CompletionContainer;