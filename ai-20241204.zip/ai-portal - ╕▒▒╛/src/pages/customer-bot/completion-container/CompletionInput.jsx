import { Input, Button } from 'antd';
import { SendOutlined } from '@ant-design/icons';
import { omit } from 'lodash';
import { useState } from 'react';
import classNames from 'classnames';

function CompletionInput(props) {
  console.log('CompletionInput render')
  const { hasBody, handleSubmit, setUserInput } = props;
  
  const [ value, setValue ] = useState('');
  
  function setInputValue(val) {
    setUserInput(val);
    setValue(val);
  }

  function handleKeyDown(e) {
    if (!value.trim()) return;
    if (e.keyCode === 13) {
      if (e.shiftKey) {
        setInputValue((state) => state + '\n');
        return;
      }
      handleSubmit();
      setTimeout(() => {
        setInputValue('');
      }, 0);
    }
  }


  function handleChange(e) {
    // if (typeof props.maxLength === 'number') {
    //   setInputValue(e.target.value.substring(0, props.maxLength));
    //   return;
    // }
    setInputValue(e.target.value);
  }


  return (
    <div className={
      classNames("shrink-0 customer-textarea-container bg-white", {
        // "w-3/6": !hasBody,
        flex: hasBody
      })}
    >
      <Input.TextArea
        className="w-full h-full"
        placeholder="请输入内容"
        size="large"
        style={{ border: "none", "outline": "none", boxShadow: "none" }}
        value={value}
        autoSize={{
          minRows: hasBody ? 1 : 3,
          maxRows: 4
        }}
        // {...omit(props, ['hasBody'])}
        onPressEnter={handleKeyDown}
        onChange={handleChange}
      />
      <div className={
        classNames("flex", {
          "justify-end": !hasBody,
          "items-end": hasBody
        })
      }>
        <Button
          className="ml-2 flex items-center justify-center"
          size="large"
          type="text"
          // loading={loading}
          icon={<SendOutlined />}
          onClick={handleSubmit}
        />
      </div>
    </div>
  )
}

export default CompletionInput;