import React , { useEffect }from 'react';

import Header from '../partials/Header';
import Hero from '../partials/Hero';
import Inspiration from '../partials/Inspiration';
import Carousel from '../partials/Carousel';
import Creatives from '../partials/Creatives';
import Pricing from '../partials/Pricing';
import Testimonials from '../partials/Testimonials';
import Faqs from '../partials/Faqs';
import Blog from '../partials/Blog';
import Cta from '../partials/Cta';
import Footer from '../partials/Footer';
import Done from "../partials/Done";
import { useNavigate } from 'react-router-dom';
function Home() {
  const navigate = useNavigate();
  const params = new URLSearchParams(new URL(location.href).searchParams)
  if (params.get('code')) {
    localStorage.setItem('code',params.get('code'))
    location.href = location.origin
  }

  useEffect(() => {
    if (localStorage.getItem('pathname')) {
      const pathname = localStorage.getItem('pathname')
      navigate(pathname)
    }
  }, [])

  useEffect(() => {
    document.title = "天合光能AI算法平台"; // 设置初始标题
    // return () => {
    //   document.title = "天合光能AI算法平台"; // 组件卸载前重置标题
    // };
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen overflow-hidden">
      {/*  Site header */}
      <Header />

      {/*  Page content */}
      <main className="grow">
        {/*  Page sections */}
        <Hero />
        <Inspiration />
        <Done />
        {/*<Carousel />*/}
        {/*<Creatives />*/}
        {/*<Pricing />*/}
        {/*  可以用，用户使用站台*/}
        {/*<Testimonials />*/}
        <Faqs />
        <Blog />
        {/*<Cta />*/}
      </main>

      {/*  Site footer */}
      <Footer />
    </div>
  );
}

export default Home;