import React , { useEffect, useState }from 'react';
import { StyleProvider,legacyLogicalPropertiesTransformer } from '@ant-design/cssinjs';
import { SunOutlined ,MoonOutlined, ArrowUpOutlined} from '@ant-design/icons';
import { ConfigProvider, Timeline , Tag, FloatButton, Tabs, Divider} from 'antd';
import StickyBox from 'react-sticky-box';
import AiImg from '../images/ai-title.png'
import {service} from "../axios";

const pathname = new URL(location.href).pathname
if (!localStorage.getItem('login')) {
  localStorage.setItem('pathname',pathname)
}


const AiNews = () => {

  const [visitedLinks, setVisitedLinks] = useState([]);
  const defaultKey = Number(localStorage.getItem('defaultKey')) || 0

  const [isMobile, setIsMobile] = useState(false);
  const [blackTheme, setBlackTheme] = useState(false)
  const [news, setNews] = useState([])
  const [xwlist, setXwlist] = useState([])
  const [ctlist, setCwlist] = useState([])
  const [hylist, setHwlist] = useState([])
  const [lwlist, setLwlist] = useState([])

  const fetchData = async () => {
    try {
      const res = await service.get('/getNews')
      // console.log(res);
      const xwlistTemp = []
      const ctlistTemp = []
      const hylistTemp = []
      const lwlistTemp = []
      Array.isArray(res.data) && res.data.forEach((item) => {
          if (item.anchor) {
            xwlistTemp.push(item)
            ctlistTemp.push(item)
            hylistTemp.push(item)
            lwlistTemp.push(item)
          } else {
            if (item.topic === '新闻') {
              xwlistTemp.push(item)
            } else if (item.topic === '创投') {
              ctlistTemp.push(item)
            } else if (item.topic === '行业') {
              hylistTemp.push(item)
            } else {
              lwlistTemp.push(item)
            }
          }
      })
      setNews(res.data)
      setXwlist(xwlistTemp)
      setCwlist(ctlistTemp)
      setHwlist(hylistTemp)
      setLwlist(lwlistTemp)
    } catch (error) {
      console.log('fetdata error', error);
    }
  }
  useEffect(() => {
    return () => {
      if (localStorage.getItem('login') === 'true') {
        localStorage.setItem('pathname', '')
      }
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [news.length])
  

  const tabList = [
    {
      name: '全部',
      list: news
    },
    {
      name: '新闻',
      list: xwlist
    },
    {
      name: '创投',
      list: ctlist
    },
    {
      name: '行业',
      list: hylist
    },
    {
      name: '论文',
      list: lwlist
    },
  ]

  const newsStyle = {
    fontSize: '0.875rem',
    color: blackTheme ? 'rgb(198 201 207 / 75%)' :'rgb(29 35 43 / 75%)',
    lineHeight: 1.65
  }

  
  const fromStyle = {
    marginTop: '10px',
    fontSize: '0.75rem',
    color: blackTheme ? 'rgb(198 201 207 / 75%)' :'rgb(29 35 43 / 86%)'
  }

  const timeStyle = {
    // padding: '12px 20px',
    // marginTop: '40px',
    paddingBottom: '8px',
    fontSize: '20px',
    lineHeight: '26px',
    fontWeight: 700,
    color: '#008BD6',
  }

  const titleStyle = {
    fontSize: '18px',
    lineHeight: 1.4,
    color: blackTheme ? '#c6c9cf':'#282a2d',
    marginBottom: '1rem'
  }

  const layoutStyle = {
    width: '100%',
    minHeight: '100vh',
    paddingTop: isMobile ? '24px' :'24px',
    backgroundColor: blackTheme ? '#1b1d1f':'#f9f9f9',
  }
  
  const contentStyle = {
    width: isMobile ? '95%' : '35%',
    backgroundColor: blackTheme ? '#2c2e2f' :'white',
    margin: '0 auto',
    padding: isMobile ? '0.75rem' :'1.25rem',
    minHeight: '100vh',
    border: '1px solid rgba(0,0,0,.125)',
    borderWidth: 0,
    boxShadow: '0px 0px 20px -5px rgba(158,158,158,.2)'
  }

  const abstractTitle = {
    paddingBottom: '.5rem',
    paddingRight: '.5rem'
  }

  const totalTitle = {
    display: 'flex',
    // width: '100%',
    // backgroundColor: blackTheme ? '#c6c9cf' : 'rgb(246, 246, 246)', 
    borderRadius: '.25rem', 
    margin: '.25rem 0',
    padding: '.75rem 1rem .75rem 6px'
  }

  const changeTheme = () => {
    setBlackTheme(!blackTheme)
  }

  const onChangeTab = (key) => {
    localStorage.setItem('defaultKey', key)
  };

  const tabClick = () => {
    window.scrollTo({
      top: isMobile ? 330 : 360,
      behavior: 'smooth'
    })
  }

  useEffect(() => {
    document.title = "AI 资讯 backup"; // 设置初始标题
  }, []);

  useEffect(() => {
    const visited = JSON.parse(localStorage.getItem('visitedLinks')) || [];
    setVisitedLinks(visited);
  }, []);

  const handleClick = (e) => {
    const link = e.target.href;
    const updatedLinks = [...visitedLinks, link];
    setVisitedLinks(updatedLinks);
    localStorage.setItem('visitedLinks', JSON.stringify(updatedLinks));
  }

  const isVisited = (link) => {
    return visitedLinks.includes(link);
  };

  const items = tabList.map((e, i) => {
    
    return {
      label: e.name,  
      key: i,
      children: <div style={{paddingTop: '20px'}}>
        <ConfigProvider
          theme={{
            components: {
              Timeline: {
                tailColor: '#c3c8fe',
                tailWidth: '1px',
                dotBg: blackTheme ? '#2c2e2f' :'white'
              },
            },
          }}
        >
          {e.name === '创投' ? <div style={{fontSize: '20px', marginBottom: '45px', paddingBottom: '1rem', width: '100%', backgroundColor: blackTheme ? '#c6c9cf' : 'rgb(246, 246, 246)'}}>
            <div style={totalTitle}>
              <img aria-label="💡, bulb" src="https://baiyunshan.flowus.net.cn/emoji/google/u1f4a1.svg" style={{width: '1em', height: '1em', marginTop: '5px'}}/>
              <div style={{marginLeft: '.5rem', letterSpacing: '1px'}}>
                <a href='https://docs.qq.com/sheet/DZnFUUkNmcGNlUmVJ?tab=BB08J2' 
                style={{color: '#18a0fb', fontWeight: 'bold',textDecorationLine: 'underline', textUnderlineOffset: '4px',lineHeight:'1.5rem'}}
                >
                  AI创投融资数据库
                </a>
              </div>
            </div>
            <div style={{marginLeft: '1.85rem', letterSpacing: '1px', fontSize: '15px'}}>
              国内外AI创业公司融资最新趋势和详细数据（本专栏自2024年8月1日起停止更新）。
            </div>
          </div> : ''}
          <Timeline
            style={{marginLeft: '3px'}}
            mode="left"
            items={e.list.length && e.list.map((item, index) => {
              if (item.anchor) {
                return  {
                  dot: <div style={{width: '16px', height: '16px', backgroundColor: '#008BD6', borderRadius: '1px'}}></div>,
                  children: e.name === '全部'? 
                  <div style={index == 0 ? timeStyle : {...timeStyle, marginTop: '1.5rem'}}>
                    <Divider style={{positon: 'relative', top: '-3px',fontSize: '20px', fontWeight: 700, color: '#008BD6', lineHeight: '26px'}}>{item.week_title}（{item.week}）</Divider>
                    <div style={{fontSize: '15px', marginBottom: '5px', width: '100%', backgroundColor: blackTheme ? '#c6c9cf' : 'rgb(246, 246, 246)'}}>
                      <h3 style={{marginLeft: '.75rem', paddingTop: '.5rem', fontSize: '16px'}}>本期提要：</h3>
                      <div style={abstractTitle}>
                        <div style={{marginLeft: '1.1rem',color: '#1d232b', fontWeight: 400}}>
                          <div style={{display:'inline-block', height: '5px', width: '5px', borderRadius:'50%', backgroundColor: 'black', verticalAlign: 'middle', marginRight:'7px'}}></div>
                          <span style={{fontWeight: 'bold'}}>新闻：</span>
                          <span style={{color: '#1d232b'}}>{item.week_abs_long["新闻"]}</span>
                          <br></br>
                          <div style={{display:'inline-block', height: '5px', width: '5px', borderRadius:'50%', backgroundColor: 'black', verticalAlign: 'middle', marginRight:'7px'}}></div>
                          <span style={{fontWeight: 'bold'}}>创投：</span>
                          <span style={{color: '#1d232b'}}>{item.week_abs_long["创投"]}</span>
                          <br></br>
                          <div style={{display:'inline-block', height: '5px', width: '5px', borderRadius:'50%', backgroundColor: 'black', verticalAlign: 'middle', marginRight:'7px'}}></div>
                          <span style={{fontWeight: 'bold'}}>行业：</span>
                          <span style={{color: '#1d232b'}}>{item.week_abs_long["行业"]}</span>
                          <br></br>
                          <div style={{display:'inline-block', height: '5px', width: '5px', borderRadius:'50%', backgroundColor: 'black', verticalAlign: 'middle', marginRight:'7px'}}></div>
                          <span style={{fontWeight: 'bold'}}>论文：</span>
                          <span style={{color: '#1d232b'}}>{item.week_abs_long["论文"]}</span>
                          <br></br>
                        </div>
                      </div>
                    </div>
                  </div> 
                  : <div style={index == 0 ? timeStyle : {...timeStyle, marginTop: '1.5rem'}}>
                    {item.week_title}（{item.week}）
                  </div>,
                }
              } else {
                return {
                  dot: <div style={{width: '14px', height: '14px', borderRadius: '14px', border: '4px solid #008BD6'}}></div>,
                  children: <div style={{marginBottom:'1rem'}}>
                    <h3 style={titleStyle}>
                      <Tag color={item.color} style={{borderRadius: '50px',verticalAlign: 'text-bottom'}}>{item.topic}</Tag>
                      {/* <a href={item.link} style={{color: blackTheme ? '#c6c9cf':'#1d232b', visited: 'red'}} >{item.title}</a> */}
                      <a
                      style={{color: isVisited(item.link) ? (blackTheme ? '#c6c9cf':'#666') : '', fontWeight:'500'}}
                      href={item.link} 
                      onClick={handleClick}>{item.title}</a>
                      {item.effect && <Tag color='red' style={{borderRadius: '50px',verticalAlign: 'text-bottom', marginLeft: '8px'}}>{item.effect}</Tag>}
                    </h3>
                    <span style={newsStyle}>
                      {item.abstract}
                    </span>
                    <div style={fromStyle}>
                      来源：
                      <img src={item.source_logo} style={{width: '16px', borderRadius: '2px', display: 'inline', marginRight:'5px'}}></img>
                      {item.source_name}
                    </div>
                  </div>,
                }
              }
            })}
          />
        </ConfigProvider>
      </div>
    };
  });

  const renderTabBar = (props, DefaultTabBar) => {
    return (<StickyBox
      // offsetTop={18}
      offsetBottom={20}
      style={{
        zIndex: 10,
      }}
    >
      <DefaultTabBar
        {...props}
      />
    </StickyBox>)
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1000) {
        setIsMobile(true)
      } else {
        setIsMobile(false)
      }
    }
    handleResize();
    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [isMobile]);
  
  return <StyleProvider hashPriority='high' transformers={[legacyLogicalPropertiesTransformer]}>
    <div style={layoutStyle}>
    <div style={contentStyle}>
      <p style={{lineHeight: 1.8,fontSize: '1rem', color: blackTheme ? '#c6c9cf':'#1d232b', paddingBottom: '1rem'}}>
        <img src={AiImg} style={{marginBottom: '1.25rem', width: '100%'}}></img>
        每周AI资讯收集与AI相关的新闻、行业动态、创投信息、前沿论文等内容，让你随时了解人工智能领域的最新趋势、更新突破和热门大事件。
      </p>
      <div style={{height: '10px', width: '100%', backgroundColor: '#f6f6f6'}}></div>
      <ConfigProvider
          theme={{
            components: {
              Tabs: {
                itemColor: blackTheme ? '#c6c9cf':'#282a2d',
                itemSelectedColor: '#008BD6',
                titleFontSize: '17px',
                inkBarColor: '#008BD6'
              }
            },
          }}
        >
        <Tabs 
          defaultActiveKey={defaultKey}
          renderTabBar={renderTabBar} 
          items={items}
          tabBarStyle={{backgroundColor: blackTheme ? '#2c2e2f' :'white'}}
          centered={true} 
          onChange={onChangeTab}
          onTabClick={tabClick}
          indicator={{size: 44}} 
          // tabBarGutter={40}
          />
      </ConfigProvider>
    </div>
    <FloatButton.Group shape="circle" style={{ right: 24}}>
      <FloatButton icon={blackTheme ? <SunOutlined /> : <MoonOutlined />} onClick={changeTheme}/>
      <FloatButton.BackTop visibilityHeight={0} icon={<ArrowUpOutlined />}/>
    </FloatButton.Group>
  </div>
  </StyleProvider>
}

export default AiNews;
