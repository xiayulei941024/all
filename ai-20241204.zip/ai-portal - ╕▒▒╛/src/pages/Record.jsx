import React, { useEffect, useRef, useState } from "react";
import * as echarts from "echarts";
import {service} from "../axios";
import { DatePicker, Radio, Space, Col, Row, Statistic,ConfigProvider , Tag} from "antd";
import { ArrowDownOutlined, ArrowUpOutlined } from "@ant-design/icons";
import locale from 'antd/es/date-picker/locale/zh_CN';
import dayjs from 'dayjs';

const { RangePicker } = DatePicker;

const BarChart = () => {
  const chartRef = useRef(null);
  const chartRef1 = useRef(null);
  // let myChart = null;
  const [date, setDate] = useState('day')
  // const [rangeDate, setRangeDate] = useState(['', '']);
  const [chartInstance, setChartInstance] = useState(null);
  const [chartInstance1, setChartInstance1] = useState(null);
  const [totalUserNum, setTotalUserNum] = useState();
  const [totalVisitNum, setTotalVisitNum] = useState();
  const [limit5, setLimit5] = useState();
  const [legendDate, setLegendDate] = useState(["今日", "昨日"]);
  const [lastStartTime, setLastStartTime] = useState(dayjs().subtract(1, 'day').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
  const [startTime, setStartTime] = useState(dayjs().startOf('day').format('YYYY-MM-DD HH:mm:ss'))
  const [endTime, setEndTime] = useState(dayjs().endOf('day').format('YYYY-MM-DD HH:mm:ss'))
  const [selectedDate, setSelectedDate] = useState(null);
  const [viewNum, setViewNum] = useState(0)
  const [userNum, setUserNum] = useState(0)
  const [viewStatistic, setViewStatistic] = useState(0)
  const [userStatistic, setUserStatistic] = useState(0)
  const [viewArrowUp, setViewArrowUp] = useState(null)
  const [userArrowUp, setUserArrowUp] = useState(null)
  const onChange = (e) => {
    setDate(e.target.value)
  };
  const choseDate = (dates, dateStrings) => {
    if (dateStrings[0]) {
      // setRangeDate(dateStrings)
      setSelectedDate(dates)
      setLegendDate([`${dateStrings[0]} ~ ${dateStrings[1]}`])
      setDate(undefined)
      setStartTime(dayjs(dateStrings[0]).startOf('day').format('YYYY-MM-DD HH:mm:ss'))
      setEndTime(dayjs(dateStrings[1]).endOf('day').format('YYYY-MM-DD HH:mm:ss'))
      setLastStartTime(null)
      fetchData()
      
    } else {
      setDate('day')
    }
  }

  const getLegend = (value) => {
    if (!value) {
      
      // setLegendDate([`${rangeDate[0]} ~ ${rangeDate[1]}`])
      // setStartTime(dayjs(rangeDate[0]).startOf('day').format('YYYY-MM-DD HH:mm:ss'))
      // setEndTime(dayjs(rangeDate[1]).endOf('day').format('YYYY-MM-DD HH:mm:ss'))
      // setLastStartTime(null)
    } else {
      setSelectedDate(null)
      switch (date) {
        case "day":
          setLegendDate(["今日", "昨日"]);
          setStartTime(dayjs().startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setLastStartTime(dayjs().subtract(1, 'day').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setEndTime(dayjs().endOf('day').format('YYYY-MM-DD HH:mm:ss'))
          break;
        case "week":
          setLegendDate(["本周", "上周"]);
          setStartTime(dayjs().subtract(7, 'day').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setLastStartTime(dayjs().subtract(14, 'day').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setEndTime(dayjs().endOf('day').format('YYYY-MM-DD HH:mm:ss'))
          break;
        case "month":
          setLegendDate(["本月", "上月"]);
          setStartTime(dayjs().subtract(1, 'month').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setLastStartTime(dayjs().subtract(2, 'month').startOf('day').format('YYYY-MM-DD HH:mm:ss'))
          setEndTime(dayjs().endOf('day').format('YYYY-MM-DD HH:mm:ss'))
          break;
        default:
          break;
      }
    }
  }

  const fetchData = async () => {
    let xData = [];
    let yData = [];
    let yData2 = [];
    let lxData = [];
    let lyData = [];
    const userRecord = await service.post("/getUserCount" ,{
      start_time: startTime,
      end_time: endTime,
      last_start_time: lastStartTime
    });
    if (userRecord.data.current) {
      setUserNum(userRecord.data.current)
      setUserStatistic((userRecord.data.current / (userRecord.data.last || 1) * 100).toFixed(2))
      if (userRecord.data.current >= userRecord.data.last) {
        setUserArrowUp(true)
      } else {
        setUserArrowUp(false)
      }
    }
    const visitRecord = await service.post("/getVisits", {
      start_time: startTime,
      end_time: endTime,
      last_start_time: lastStartTime
    })
    if (visitRecord.data.current) {
      setViewNum(visitRecord.data.current)
      setViewStatistic((visitRecord.data.current / (visitRecord.data.last || 1) * 100).toFixed(2))
      if (visitRecord.data.current >= visitRecord.data.last) {
        setViewArrowUp(true)
      } else {
        setViewArrowUp(false)
      }
    }

    const getTotalUser = await service.get("/getTotalUserNum")
    setTotalUserNum(getTotalUser.data.total_count + 60)
    
    const getTotalVisits = await service.get("/getTotalVisitNum")
    setTotalVisitNum(getTotalVisits.data.totalweb_count + 3800)

    const getLimit5 = await service.get("/getLimit5click")
    // setLimit5(getLimit5.data)
    console.log('gt', getLimit5.data);
    if (Array.isArray(getLimit5.data)) {
      lxData = getLimit5.data.map((obj) => obj.page_tag);
      lyData = getLimit5.data.map((obj) => obj.limit_count);
    }
    if (chartInstance1) {
      chartInstance1.setOption({
        title: {
          text: '页面点击总量排名',
          left: '7%',
          textStyle: {
            color: 'black',
          }
        },
        // legend: {
        //   // data: ['今日', '昨日']，
        //   data: legendDate
        // },
        xAxis: {
          type: "category",
          data: lxData,
          axisLabel: {
            interval: 0,
            rotate: 45,
            textStyle: {
              color: 'black'
            }
          },
          
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            // name: legendDate[0],
            data: lyData,
            type: "bar",
            barMaxWidth: date ? 20 : 40,
            itemStyle: {
              color: "#40a9ff",
            },
            label: {
              show: true,
              position: 'top'
              // distance: 10,
            },
          },
        ],
      });
    }
    const pageRecord = await service.post("/getRecord" ,{
      start_time: startTime,
      end_time: endTime,
      last_start_time: lastStartTime
    });
    if (Array.isArray(pageRecord.data)) {
      xData = pageRecord.data[0].map((obj) => obj.tag);
      yData = pageRecord.data[0].map((obj) => obj.count);
      yData2 = pageRecord.data[1].map((obj) => obj.count);
    }
    // 使用 ECharts 渲染柱状图
    // const chartDom = document.getElementById('chart');
    
    if (chartInstance) {
      chartInstance.setOption({
        title: {
          text: '页面点击量统计',
          left: '7%',
          textStyle: {
            color: 'black',
          }
        },
        legend: {
          // data: ['今日', '昨日']，
          data: legendDate
        },
        xAxis: {
          type: "category",
          data: xData,
          axisLabel: {
            interval: 0,
            rotate: 45,
            textStyle: {
              color: 'black'
            }
          },
          
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: legendDate[0],
            data: yData,
            type: "bar",
            barMaxWidth: date ? 20 : 40,
            itemStyle: {
              color: "#c659bb",
            },
          },
          {
            name: legendDate[1] || '',
            data: yData2 || [],
            type: "bar",
            barMaxWidth: date ? 20 : 0,
            itemStyle: {
              color: "#63c798",
            },
          },
        ],
      });
    }
    
  };
  useEffect(() => {
    getLegend(date)
  }, [date])
  useEffect(() => {
    if (!chartInstance) {
      const myChart = echarts.init(chartRef.current);
      setChartInstance(myChart)
    }
    if (!chartInstance1) {
      const myChart1 = echarts.init(chartRef1.current);
      setChartInstance1(myChart1)
    }
   fetchData();
  }, [date, chartInstance,chartInstance1, legendDate[0]]);

  return (
    <div style={{backgroundColor: '#f5f5f5', height: '100vh'}}>
      <header className="text-gray-600 body-font">
        <div className="container px-5 py-8 mx-auto flex items-center sm:flex-row flex-col">
          <a className="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="w-10 h-10 text-white p-2 bg-yellow-500 rounded-full"
              viewBox="0 0 24 24"
            >
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
            </svg>
            <span className="ml-3 text-xl">后台监控</span>
          </a>
          <p className="text-sm text-gray-500 sm:ml-4 sm:pl-4 sm:border-l-2 sm:border-gray-200 sm:py-2 sm:mt-0 mt-4">
            © 2024 算法平台 — tao.gao03@trinasolar.com
          </p>
        </div>
      </header>

      <div className="flex flex-col text-center w-full mb-5">
        <div className="flex mx-auto rounded overflow-hidden mt-6">
          <Space direction="horizontal" size={20}>
            <Radio.Group value={date} buttonStyle="solid" onChange={onChange}>
              <Radio.Button value="day">今日</Radio.Button>
              <Radio.Button value="week">本周</Radio.Button>
              <Radio.Button value="month">本月</Radio.Button>
            </Radio.Group>
            <RangePicker locale={locale} onChange={choseDate} value={selectedDate}/>
          </Space>
        </div>
      </div>
      {/* <section className="text-gray-600 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap -m-4 text-center">
          <div className="p-4 sm:w-1/4 w-1/4">
              <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">536</h2>
              <p className="leading-relaxed">总用户量</p>
            </div>
            <div className="p-4 sm:w-1/4 w-1/4">
              <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{totalUserNum}</h2>
              <p className="leading-relaxed">总用户量</p>
            </div>
            <div className="p-4 sm:w-1/4 w-1/4">
              <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{viewNum}</h2>
              <p className="leading-relaxed">访问量</p>
              {date && <Statistic
                // title="Active"
                value={viewStatistic}
                precision={2}
                valueStyle={{
                  color: viewArrowUp ? '#cf1322' : '#3f8600',
                }}
                prefix={viewArrowUp ? <ArrowUpOutlined /> : <ArrowDownOutlined />}
                suffix="%"
              />}
            </div>
            <div className="p-4 sm:w-1/4 w-1/4">
              <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{userNum}</h2>
              <p className="leading-relaxed">用户量</p>
              {date && <Statistic
                // title="Idle"
                value={userStatistic}
                precision={2}
                valueStyle={{
                  color: userArrowUp ? '#cf1322' : '#3f8600',
                }}
                prefix={userArrowUp ? <ArrowUpOutlined /> : <ArrowDownOutlined />}
                suffix="%"
              />}
            </div>
          </div>
        </div>
      </section> */}
      <div style={{padding: '0 10%', margin: '40px 0'}}>
        <div style={{display: 'inline-block',width: "47%", backgroundColor: 'white', borderRadius: '8px'}}>
        <div
            style={{width: "100%", height: "150px", backgroundColor: "#25a4aw", padding:'18px 0'}}
          >
            <Tag color="magenta" style={{marginLeft: '10px'}}>埋点统计历史总量</Tag>
            <div className="container px-5 py-4 mx-auto">
            <div className="flex flex-wrap -m-4 text-center">
            <div className="p-4 sm:w-1/2 w-1/2">
                <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{totalVisitNum}</h2>
                <p className="leading-relaxed" style={{color: 'rgb(89 89 89)'}}>总访问量</p>
              </div>
              <div className="p-4 sm:w-1/2 w-1/2">
                <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{totalUserNum}</h2>
                <p className="leading-relaxed" style={{color: 'rgb(89 89 89)'}}>总用户量</p>
              </div>
            </div>
            </div>
          </div>
        </div>
        <div style={{display: 'inline-block',width: "47%", backgroundColor: 'white',borderRadius: '8px', marginLeft: '50px'}}>
          <div
            style={{width: "100%", height: "150px", backgroundColor: "#25a4aw", padding:'18px 0'}}
          >
            <Tag color="volcano" style={{marginLeft: '10px'}}>访问量统计</Tag>
            <div className="container px-5 py-4 mx-auto">
              <div className="flex flex-wrap -m-4 text-center">
              <div className="p-4 sm:w-1/2 w-1/2">
                  <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{viewNum}</h2>
                  <p className="leading-relaxed" style={{color: 'rgb(89 89 89)'}}>访问量</p>
                </div>
                <div className="p-4 sm:w-1/2 w-1/2">
                  <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900">{userNum}</h2>
                  <p className="leading-relaxed" style={{color: 'rgb(89 89 89)'}}>用户量</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style={{padding: '0 10%'}}>
        <div style={{display: 'inline-block',width: "47%", backgroundColor: 'white', borderRadius: '8px'}}>
        <div
            ref={chartRef1}
            style={{width: "100%", height: "370px", backgroundColor: "#25a4aw", padding:'18px 0'}}
          ></div>
        </div>
        <div style={{display: 'inline-block',width: "47%", backgroundColor: 'white',borderRadius: '8px', marginLeft: '50px'}}>
          <div
            ref={chartRef}
            style={{width: "100%", height: "370px", backgroundColor: "#25a4aw", padding:'18px 0'}}
          ></div>
        </div>
      </div>
    </div>);
};

export default BarChart;
