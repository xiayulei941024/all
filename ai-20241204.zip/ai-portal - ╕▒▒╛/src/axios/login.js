import {service} from './index'
function checkLogin() {
    const code = localStorage.getItem('code')
    if (!code) {
      localStorage.setItem('login', false)
      getCode()
    }
}
function getCode() {
    const url ='https://iam.trinasolar.com/mga/sps/oauth/oauth20/authorize';
    let redirect_uri = 'https://matrix.trinasolar.com/'
    if (import.meta.env.MODE === 'development') {
      redirect_uri = 'http://localhost:5600/'
    }
    const params ={
      response_type:'code',
      client_id:'matrix_cli',
      redirect_uri
    };
    
    const newUrl = url +'?'+ new URLSearchParams(params).toString();
    location.href = newUrl
}
async function getToken() {
    if (!localStorage.getItem('token')) {
        const result = await service.get(`/getcode?code=${localStorage.getItem('code')}`)
        if (result && result.status === 200) {
          const res = await service.post('/getToken', {
            code: localStorage.getItem('code'),
          })
          if (res && res.data.access_token) {
            localStorage.setItem('token',res.data.access_token)
          } else {
            localStorage.setItem('code', '');
            checkLogin()
          }
        } else {
          localStorage.setItem('code', '');
          checkLogin()
        }
    }
}
async function getUesrInfo() {
  if (localStorage.getItem('token')) {
    if (!localStorage.getItem('userInfo') || !(JSON.parse(localStorage.getItem('userInfo')).cn)) {
      const res = await service.get(`/userinfo?accessToken=${localStorage.getItem('token')}`)
      if (res.status === 200 && res.data) {
        let userInfo = res.data
        localStorage.setItem('userInfo', JSON.stringify(userInfo))
        localStorage.setItem('login', true)
        localStorage.setItem('pathname', '')
      } else {
        localStorage.setItem('code', '');
        checkLogin()
      }
    }
  } else {
    localStorage.setItem('code', '');
    checkLogin()
  }
    
}

function webVisits() {
  service.post('/webVisits', {
    user_info_uid: JSON.parse(localStorage.getItem('userInfo')).uid,
    user_info_department_number: JSON.parse(localStorage.getItem('userInfo')).departmentnumber
  })
  .then(response =>{
    console.log(response.data);
  })
  .catch(error =>{
    console.log(error);
  });
}
export{checkLogin, getToken, getUesrInfo, webVisits}