import React from 'react';
import {platformName} from "../Trina";

function Faqs() {
  return (
    <section>
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="py-12 md:py-20 border-b border-gray-100">
          {/* Section header */}
          <div className="pb-12 md:pb-20">
            <h2 className="h2 font-cabinet-grotesk">Q&A</h2>
          </div>
          {/* Columns */}
          <div className="md:flex md:space-x-12 space-y-8 md:space-y-0">
            {/* Column */}
            <div className="w-full md:w-1/2 space-y-8">
              {/* Item */}
              <div className="space-y-2">
                <h4 className="text-xl font-cabinet-grotesk font-bold">AI开放平台的作用是什么?</h4>
                <p className="text-gray-500">AI开放平台是天合光能大数据部对外推广的AI普惠平台.</p>
              </div>
              {/* Item */}
              <div className="space-y-2">
                <h4 className="text-xl font-cabinet-grotesk font-bold">NLP和CV是什么?</h4>
                <p className="text-gray-500">NLP是自然语言处理，CV是机器视觉.</p>
              </div>
              {/* Item */}

            </div>
            {/* Column */}
            <div className="w-full md:w-1/2 space-y-8">
              {/* Item */}
              <div className="space-y-2">
                <h4 className="text-xl font-cabinet-grotesk font-bold">我要怎么开始使用{platformName}平台?</h4>
                <p className="text-gray-500">点击通用能力有多个Demo可以试玩, 点击加入{platformName}可以使用{platformName}平台训练自己的人工智能模型.</p>
              </div>
              <div className="space-y-2">
                <h4 className="text-xl font-cabinet-grotesk font-bold">我有业务需求要怎么联系你们?</h4>
                <p className="text-gray-500">平台右上角点击业务合作填写表单，或点击联系我们发送邮件.</p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Faqs;
