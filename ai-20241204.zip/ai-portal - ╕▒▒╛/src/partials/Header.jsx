import React from 'react';
import { Link } from 'react-router-dom';
import HeroImage from "../images/hero-image.png";
import TrinaImage from "../images/logo-mat.png";
import * as dd from 'dingtalk-jsapi'; // 此方式为整体加载，也可按需进行加载
import {headerCreate, headerPlat, platformName} from "../Trina";
import {axiosTranslate} from "../axios";
import {clickRecord} from '../ClickRecord'

const userInfo = JSON.parse(localStorage.getItem('userInfo'))

function Header() {
  return (
    <header className="absolute w-full z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Site branding */}
          <div className="shrink-0 mr-4">
            {/* Logo */}
            <Link className="block group" to="/" aria-label="Cruip">
              <img src={TrinaImage} className="md:max-w-none mt-20" width="80" height="80" alt="Hero Illustration" />

              {/*<svg*/}
              {/*  className="fill-blue-500 group-hover:fill-blue-600 transition duration-150 ease-in-out w-8 h-8"*/}
              {/*  width="32"*/}
              {/*  height="32"*/}
              {/*  xmlns="http://www.w3.org/2000/svg"*/}
              {/*>*/}
              {/*  <path d="m7.799 4.47.325.434a19.264 19.264 0 0 0 4.518 4.204l.27.175-.013.257a17.638 17.638 0 0 1-.437 2.867l-.144.564a18.082 18.082 0 0 1-2.889 5.977c2.272.245 4.492.88 6.5 1.886 1.601.788 3.062 1.798 4.344 2.972l.142.135-.017.232a17.034 17.034 0 0 0 1.227 7.504l-.724.323c-1.555-2.931-4.113-5.287-7.19-6.632-3.075-1.351-6.602-1.622-9.857-.844-.822.194-1.532.094-2.146-.183a3.138 3.138 0 0 1-1.29-1.146l-.076-.133-.078-.154-.085-.201a2.893 2.893 0 0 1-.095-1.694c.174-.624.55-1.2 1.239-1.67 2.734-1.85 4.883-4.537 5.944-7.68.704-2.076.925-4.32.633-6.545l-.101-.647Zm4.674-.284.16.2a15.87 15.87 0 0 0 5.629 4.322c3.752 1.76 8.363 2.075 12.488.665.419-.14.78-.044 1.002.158l.106.12.066.11.026.063c.125.33.024.751-.4.994-3.404 1.905-5.92 5.05-6.98 8.573a13.967 13.967 0 0 0 .727 10.055l.241.484-.724.323c-.913-2.227-2.326-4.302-4.12-6.05l-.28-.262.026-.305a16.667 16.667 0 0 1 1.121-4.652l.206-.488c1.05-2.443 2.676-4.59 4.664-6.293-3.064.442-6.273.17-9.243-.858a19.036 19.036 0 0 1-4.072-1.93l-.204-.132.017-.322a18.337 18.337 0 0 0-.415-4.605l-.04-.17ZM10.957 0a18.125 18.125 0 0 1 1.424 3.792l.092.394-.174-.219A14.803 14.803 0 0 1 10.235.322L10.957 0ZM7.046 1.746c.277.725.494 1.463.653 2.206l.1.519-.012-.016a17.99 17.99 0 0 1-1.203-1.891l-.262-.495.724-.323Z" />*/}
              {/*</svg>*/}
            </Link>
          </div>
          {/* Desktop navigation */}
          <nav className="flex grow">
            {/* Desktop sign in links */}
            <ul className="flex grow justify-end flex-wrap items-center">

              {/*<li>*/}
                {/*<a className="btn text-gray-600 bg-white hover:bg-blue-100 hover:text-blue-600 w-full shadow-sm" href="https://ai.trinasolar.com" target="_blank" rel="noopener noreferrer">*/}
                {/*  {headerCreate}*/}
                {/*</a>*/}
                {/*<Link*/}
                {/*  className="font-medium text-gray-600 decoration-blue-500 decoration-2 underline-offset-2 hover:underline px-3 lg:px-5 py-2 flex items-center transition duration-150 ease-in-out"*/}
                {/*  to="/signin"*/}
                {/*>*/}
                {/*</Link>*/}
              {/*</li>*/}
              <li className="ml-3">
                <a 
                  className="btn text-white bg-blue-500 hover:bg-blue-600 w-full shadow-sm" 
                  href="https://aimodel.trinasolar.com" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  onClick={(event) =>clickRecord(event, 'AI模型训练平台')}
                >
                  {headerPlat}
                </a>
                {/*<Link className="btn-sm text-white bg-blue-500 hover:bg-blue-600 w-full shadow-sm" to="/signup">*/}
                {/*  使用开放平台*/}
                {/*</Link>*/}
              </li>
              {/*<li className="ml-3">*/}
              {/*  <Link className="btn text-gray-600 bg-white hover:bg-blue-100 hover:text-blue-600 w-full shadow-sm" to="/signup" target="_blank" rel="noopener noreferrer">*/}
              {/*    业务合作*/}
              {/*  </Link>*/}
              {/*</li>*/}
              <li className="ml-3">
                <a 
                className="btn text-gray-600 bg-white hover:bg-blue-100 hover:text-blue-600 w-full shadow-sm" 
                href="" 
                target="" 
                // rel="noopener noreferrer"
                onClick={(event) =>{
                  console.log('gaotao',event);
                  event.preventDefault()
                  const data = {
                    user_info_uid: userInfo.uid,
                    user_info_sub: userInfo.sub,
                    user_info_display_name: userInfo.displayname,
                    user_info_department_number: userInfo.departmentnumber,
                    brand: '',
                    model: '',
                    netInfo: '',
                    operatorType: '',
                  }
                  dd.biz.chat.openSingleChat({
                    corpId: "dinga41ec6a58a4911d0f2c783f7214b6d69",
                    userId: "366033",
                    onSuccess : function(res) {
                      // 调用成功时回调
                      data['success'] = true
                      data.brand = res
                      axiosTranslate.post('getUserLog',data).then(response =>{
                        console.log(response.data);
                      })
                      .catch(error =>{
                        console.log(error);
                      });
                    },
                    onFail : function(err) {
                      // 调用失败时回调
                      data['success'] = false
                      data.brand = res
                      axiosTranslate.post('getUserLog',data).then(response =>{
                        console.log(response.data);
                      })
                      .catch(error =>{
                        console.log(error);
                      });
                      console.log(err)
                    }
                  });
                  clickRecord(event, '联系我们')
                }}
                >
                  联系我们
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
