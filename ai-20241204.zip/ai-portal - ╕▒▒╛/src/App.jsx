import React, { useEffect } from 'react';
import {
  Routes,
  Route,
  useLocation
} from 'react-router-dom';

import 'aos/dist/aos.css';
import './css/style.css';
import './charts/ChartjsConfig';

import AOS from 'aos';

import Home from './pages/Home';
import NewHome from './pages/HomePage'
// Import pages
import Dashboard from './pages/Dashboard';
import AiNews_backup from './pages/AiNews_backup';
import AiNews from './pages/AiNews';
// import NewsPage from './pages/NewsPage';
import SignIn from './pages/SignIn';
import Collaboration from './pages/Collaboration';
import ResetPassword from './pages/ResetPassword';
import Record from './pages/Record';
import Translation from './pages/Translation';
import ImageGeneration from './pages/image-generation/ImageGeneration';
import CustomerBot from './pages/customer-bot/index.jsx';
// import DataCompass from './pages/DataCompass'

function App() {

  const location = useLocation();

  useEffect(() => {
    AOS.init({
      once: true,
      disable: 'phone',
      duration: 500,
      easing: 'ease-out-cubic',
    });
  });

  useEffect(() => {
    document.querySelector('html').style.scrollBehavior = 'auto'
    window.scroll({ top: 0 })
    document.querySelector('html').style.scrollBehavior = ''
  }, [location.pathname]); // triggered on route change

  return (
    <>
      <Routes>
        
        <Route exact path="/ai-news" element={<AiNews />} />
        <Route exact path="/backup-news" element={<AiNews_backup />} />
        {/* <Route exact path="/newspage" element={<NewsPage />} /> */}
        {/* <Route exact path="/" element={<Home />} /> */}
        <Route exact path="/" element={<NewHome />} />
        <Route exact path="/dashboard" element={<Dashboard />} />
        <Route exact path="/record" element={<Record />} />
        <Route exact path="/translation" element={<Translation />} />
        {/* <Route path="/data-compass" element={<DataCompass />} /> */}
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<Collaboration />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/customer-bot" element={<CustomerBot />} />
        <Route path="/image-generation" element={<ImageGeneration />} />
      </Routes>
    </>
  );
}

export default App;
