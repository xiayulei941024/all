# AI开放平台

```
npm install
```

### 开发

```
npm run dev
```

### 生产
