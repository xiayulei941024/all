/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      backgroundImage: {
        'home-bg': "url('@/assets/banner.png')",
        'other-bg': "url('@/assets/详情背景.png')"
      },
      boxShadow: {
        'card': '0 2px 20px 0 #0000000f',
        'power-card': '0 2px 4px 0 #0000001a',
        'service-card': '0 0 14px 0 #00000080'
      }
    }
  },
  plugins: []
}
