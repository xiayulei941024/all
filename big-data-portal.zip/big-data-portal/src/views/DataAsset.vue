<template>
  <ms-menu bg_index="other" :menu_data="asset_data"></ms-menu>
  <!-- 内容 -->
  <section class="w-full bg-[#F8F9FD] pt-52">
    <div class="mx-96 bg-white  pb-14 px-12">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">案例介绍</div>
      <div class="text-sm mt-10 leading-relaxed">
        财务团队在推进全面预算、产品业务财经、核算与报告等相关工作的过程中，大数据团队需要协助完成数据的入湖、数仓建模、数据开发、应用开发等工作，以此来支撑上层应用的数据可视化、自助分析等场景。
      </div>
      <br />
      <div class="text-sm mt-10 leading-relaxed">
        随着需求的增加、资产可视化项目的落地，财经域数据资产覆盖率低、复用度低、相关指标算不准、算不快、流程不规范等问题日益突出。
      </div>
    </div>
    <div class="mx-96 bg-white pb-14 px-12 mt-16">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">服务能力如何开展业务</div>
      <div class="text-sm mt-10 leading-relaxed mt-10">
        <!-- 在日常管理过程中，如果没有数据的沟通只能靠感觉，靠拍脑袋。业务团队在实际“物流规划-物流计划-物流运营”全流程的各环节中，都需要数据能力的支撑。 -->
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        1. 基于管理财经服务的流程，梳理财经域各业务实体之间的关系，自上而下盘点业务，和业务共创指标体系。
        2. 基于业务数据需求，自底向上，拆解指标，盘点指标和业务的关系，构建指标体系，建立指标管理规范；
        3. 构建面向财经管理的数据完善且复用度高的数据模型；
        4. 建设资产管理平台，提供资产血缘、生命周期管理能力，实现数据供应链一体化管理功能；
        5. 建设数据质量监控体系，通过质量指标实现对数据流转过程的质量情况的监控和实时反馈；
        6. 提供可量化的价值评估方法，输出对应评价指标，将资产价值从定性分析升级到定量分析；
      </div>
      <div class="mt-10">
        <img class="w-full h-full" src="@/assets/数据资产详情1.png" />
      </div>
      <div class="mt-10">
        <img class="w-full h-full" src="@/assets/数据资产详情2.png" />
      </div>
    </div>
  </section>

  <ms-use-power title="使用的能力" :use_power="use_power_ass" />

</template>

<script setup lang="ts">
import { MsMenu } from '@/components/ms-menu';
import { MsUsePower } from '@/components/ms-usePower';
import { use_power_ass, asset_data } from '@/types/interface'

</script>

<style lang="less" scoped>

</style>