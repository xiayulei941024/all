<template>
  <ms-menu bg_index="other" :menu_data="service_data" />
  <ms-carousel :service_carousel="service_carousel"/>
</template>

<script setup lang="ts">
import { MsMenu } from '@/components/ms-menu';
import { MsCarousel } from '@/components/ms-carousel';
import { service_data, service_carousel } from '@/types/interface'

</script>

<style scoped lang="less">

</style>