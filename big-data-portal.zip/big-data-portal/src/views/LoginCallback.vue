<script>
import { handleSSOCallback } from '../auth/auth';

export default {
  created() {
    handleSSOCallback();  // 处理 SSO 回调
  },
  template: '<div>正在处理登录...</div>'
}
</script>