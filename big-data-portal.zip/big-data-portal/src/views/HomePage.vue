<template>
  <ms-menu bg_index="home" />
  <ms-case title="解决方案案例精选" :case_list="case_list" />
  <ms-power title="多种能力形态 提供全链路数据服务" :power_list="power_list" />
</template>

<script setup lang="ts">
import { MsMenu } from '@/components/ms-menu';
import { MsCase } from '@/components/ms-case';
import { MsPower } from '@/components/ms-power';
import { case_list, power_list } from '@/types/interface'

</script>

<style lang="less" scoped>
</style>
