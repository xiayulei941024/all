<template>
  <ms-menu bg_index="other" :menu_data="log_data"></ms-menu>
  <!-- 内容 -->
  <section class="w-full bg-[#F8F9FD] pt-52">
    <div class="mx-96 bg-white  pb-14 px-12">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">案例介绍</div>
      <div class="text-sm mt-10 leading-relaxed">
        物流仓储团队在下单后会基于各家船司提供的船期、航程天数，安排最优路线订舱，以确保订单以最低的物流成本，最高的物流时效，按客户要求交付。
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        随着天合业务量的增长，围绕“基础职能的履行（比如库容、物流发运等）、费用及降本管理、供应商管理”等，业务始终要回答“好不好，差多少，问题在哪里，怎么改善，需要投入多少，做到什么程度”？等一些列问题。
      </div>
    </div>
    <div class="mx-96 bg-white pb-14 px-12 mt-16">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">服务能力如何开展业务</div>
      <div class="text-sm mt-10 leading-relaxed mt-10">
        在日常管理过程中，如果没有数据的沟通只能靠感觉，靠拍脑袋。业务团队在实际“物流规划-物流计划-物流运营”全流程的各环节中，都需要数据能力的支撑。
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        大数据部基于业务场景为物流仓储ISC部门提供了数据化管理解决方案，让业务部门凡事“拿数据说话”，利用BI产品，提升看数、用数的效率。
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        数据化管理的解决方案里，主要包括以下几方面：
        a、拿数据：拉通相关系统，建立底层数据模型；
        b、建指标：围绕管理目标，实现数据指标化，利用数据衡量问题；
        c、可视化：围绕核心问题，进行可视化看板搭建，快速发现、定位问题；
        d、做预警：关键业务场景，进行指标预警规则的建立，快速预警问题；
        f、智能化：在涉及到决策/评估的场景，建立预测、推荐模型，辅助进行业务决策；
        通过上述能力，辅助业务利用数据去“看清现状、发现问题、寻找解决方案、评估方案可行性”，进行数据化管理的全流程。
      </div>
      <div class="text-sm leading-relaxed mt-10">
        <span class="text-lg font-bold text-[#222222]">从无到有，核心指标可视化</span>
      </div>
      <div class="text-sm leading-relaxed mt-2.5">
        天合的物流业务具有全球化、流程长、角色多等特点，业务团队的同事在面对复杂业务时每天都有这样的思考。从全球物流视角出发，业务团队与大数据团队，历时两年合作与探索，对包含国际、国内物流、关务及仓储模块进行”数据化基建“，对接7大系统，构造91张表，实现176个指标系统计算，制作30张管理看板，助力用户对24个主题达成深刻理解。
      </div>
      <div class="mt-5">
        <img class="w-full h-full" src="@/assets/物流仓储1.png" />
      </div>
      <div class="text-sm leading-relaxed mt-10">
        <span class="text-lg font-bold text-[#222222]">从有到优，关键策略智能化</span>
      </div>
      <div class="text-sm leading-relaxed mt-2.5">
        <p class="mt-2.5">全球仓储费用每年30亿+，有什么办法可以降低？哪些环节可以降低？</p>
        <p class="mt-2.5">实际入库和主计划偏差大，库容利用率异常，流量仓和包仓比例怎么分配可以优化库容利用率？</p>
        <p class="mt-2.5">EU直发订单42%超30天发出，欧洲仓储成本是总部6倍，这部分成本能不能降？</p>
        <p class="mt-2.5">……</p>
        <p class="mt-2.5">
          面对业务部门迫切的降本需求，大数据团队和业务团队共同牵头，拉通销售运营、物流运营、采购等部门，定位问题，量化问题，使业务问题透明化；尝试采用运筹学、仿真学等先进算法，为仓储方案优化提供新思路，通过仿真策略，预计可实现降本18%
        </p>
      </div>
      <div class="mt-5">
        <img class="w-full h-full" src="@/assets/物流仓储2.png" />
      </div>
      <div class="text-sm leading-relaxed mt-10">
        <span class="text-lg font-bold text-[#222222]">建设愿景：以终为始，问题导向，从BI到AI</span>
      </div>
      <div class="text-sm leading-relaxed mt-2.5">
        <p class="mt-2.5">
          经过两年多从无到有、由浅到深的探索，物流仓储领域的资深数据分析师，这样分享到：“BI类的项目如果要有规划，都应该要围绕最终想实现的目标来走；在建设指标和看板的时候，要有意识地识别和反映业务过程中的问题；梳理问题之间的关联，寻找可以解决的方法，逐渐向AI进化；最终真正实现从发现问题到解决问题的进化，助力业务管理水平提升。”
        </p>
      </div>
      <div class="mt-5">
        <img class="w-full h-full" src="@/assets/物流仓储3.png" />
      </div>
    </div>
  </section>
  <ms-use-power title="使用的能力" :use_power="use_power_bi" />
</template>

<script setup lang="ts">
import { MsMenu } from '@/components/ms-menu';
import { MsUsePower } from '@/components/ms-usePower';
import { use_power_bi, log_data } from '@/types/interface'

</script>

<style lang="less" scoped>

</style>
