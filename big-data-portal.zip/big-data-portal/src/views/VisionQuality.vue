<template>
  <ms-menu  bg_index="other" :menu_data="vision_data"></ms-menu>
  <!-- 内容 -->
  <section class="w-full bg-[#F8F9FD] pt-52">
    <div class="mx-96 bg-white  pb-14 px-12">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">案例介绍</div>
      <div class="text-sm mt-10 leading-relaxed">
        组件车间在光伏制造中起着至关重要的作用，它是光伏制造流程中的最后一步，负责将前面步骤制造的电池片通过焊接、层压、装框等步骤组装成光伏组件。这一过程的质量控制直接影响到光伏组件的性能和可靠性，进而影响到光伏电站的发电效率和运行寿命。组件是天合制造的核心一环，出厂良率直接影响产品质量和天合品牌力。
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        旧的生产模式下，每道工序均由人工目检，随着天合产能扩张，组件生产车间质检环节的效率和质量也面临严峻的挑战。传统的员工目检存在明显的劣势：检测速度慢、主观影响大、人员流动频繁，同时招聘、培训和管理等因素也大大提升了用人成本。为支撑日益增长的订单量，保持高质量的出货品质，急需高效高质量的检测手段辅助车间质检。
      </div>
    </div>
    <div class="mx-96 bg-white pb-14 px-12 mt-16">
      <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">服务能力如何开展业务</div>
      <div class="text-sm mt-10 leading-relaxed mt-10">
        我们针对天合自身的组件生产流程、车间构造、电池片特征及成像效果，研发了AI视觉质检算法，并基于天合历史组件成像数据，训练迭代了高精度的检测模型，配合灵活的特殊后处理规则，实现了对不同片型、不同片源的全系支持与针对性适配。
      </div>
      <br />
      <div class="text-sm leading-relaxed">
        工业视觉的应用依赖于AI视觉算法，需根据具体检测需求收集图像样本，设计检测逻辑和前后处理规则，利用传统图像处理算法或深度学习模型，构建目标识别或分类模块，并融入业务
        流程，提升视觉类任务处理效率。应用场景有各类视觉质检、文字识别、物品识别、考勤及智能安防、动作识别等。
      </div>
      <div class="mt-10">
        <img class="w-full h-full" src="@/assets/工业视觉详情.png" />
      </div>
    </div>
  </section>
  <ms-use-power title="使用的能力" :use_power="use_power_vis" />
</template>

<script setup lang="ts">
import { MsMenu } from '@/components/ms-menu';
import { MsUsePower } from '@/components/ms-usePower';
import { use_power_vis, vision_data } from '@/types/interface'
</script>

<style lang="less" scoped>
</style>
