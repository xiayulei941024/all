<template>
    <el-container>
        <el-header class="pt-common" height="64">
            <ms-header @change-chart="changeChart" />
        </el-header>
        <el-main class="pt-common">
            <router-view v-slot="{ Component }">
                <keep-alive>
                    <component :is="Component" />
                </keep-alive>
            </router-view>
        </el-main>
        <el-footer class="pt-common">
            <ms-footer />
        </el-footer>
    </el-container>
    <ms-chart v-model:dialogFormVisible="dialogFormVisible" />
</template>
<script setup lang="ts">
import { MsHeader } from '@/components/ms-header';
import { MsFooter } from '@/components/ms-footer';
import { MsChart } from '@/components/ms-chart';
import { onMounted, ref } from 'vue';
const dialogFormVisible = ref(false);

const changeChart = (value: boolean) => {
    dialogFormVisible.value = value
}

const setRem = () => {
    const ui_w = 1180;
    // // 获取屏幕的宽度
    const clientWidth = document.documentElement.clientWidth || document.body.clientWidth;
    console.log(ui_w, clientWidth);

    // 通过js动态改变html根节点字体大小
    const html_ = document.getElementsByTagName('html')[0];
    const body_ = document.getElementsByTagName('body')[0];
    html_.style.fontSize = (clientWidth / ui_w) * 10 + 'px';
    body_.style.fontSize = (clientWidth / ui_w) * 10 + 'px';
    
}
// window.onresize 浏览器被重置大小执行事件
window.onresize = setRem;
onMounted(() => {
    setRem()
})
</script>
<style lang="less" scoped>
:deep(.pt-common) {
    padding: 0;
}
</style>