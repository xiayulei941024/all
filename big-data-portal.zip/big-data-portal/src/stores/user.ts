import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', () => {
  const userInfo = ref<{
    displayName: string,
    [key: string]: any
  }>({})
  function setUserInfo(value) {
    userInfo.value = value
  }

  return { userInfo, setUserInfo }
}, {
  persist: true

})
