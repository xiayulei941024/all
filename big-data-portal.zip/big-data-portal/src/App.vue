<script setup>
import { RouterView } from 'vue-router'

</script>

<template>
  <router-view />
</template>

<style lang="less">

</style>
