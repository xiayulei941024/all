<template>
    <footer class="w-full h-96 bg-[#F8F9FD]">
        <div class="mx-96 flex items-center justify-between  pt-36">
            <div class="flex items-center">
                <img src="@/assets/天合光能logo.png" class="w-32 h-auto" />
                <div class="w-px h-6 bg-[#B7B7B7] mx-6"></div>
                <img src="@/assets/编组.png" class="w-14 h-auto" />
                <span class="ml-4 text-xl font-bold">大数据团队平台门户</span>
            </div>

            <span class="text-sm text-[#666666]">Developed By 天合光能大数据部</span>
        </div>
    </footer>
</template>
<script setup lang="ts"></script>
<style lang="sass" scoped>

</style>