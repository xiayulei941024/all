<template>
    <header class="flex h-16 items-center  w-full justify-between bg-[#000000e6]">
        <div class="flex justify-center items-center h-full">
            <img src="@/assets/平台logo.png" class="ml-8 size-7">
            <span class="ml-2 text-sm text-[#D3D3D3]">天合光能AI与大数据部</span>
        </div>
        <div class="flex h-full leading-[4rem]">
            <ul class="flex list-none text-[#D3D3D3] tracking-wide z-10">
                <li v-for="item in tabs_index" :key="item.name"
                    class="h-16 leading-[4rem] min-w-32 text-sm text-center mx-12 cursor-pointer hover:text-white hover:font-bold hover:border-b-2 hover:border-b-[#008BD6]"
                    @click="routeHome(item)" @mouseover="mouseClick(item)" @mouseleave="showDetailMenu = false">
                    {{ item.name }}
                    <div v-show="showDetailMenu && item.name === '解决方案'" class="bg-white leading-10 text-[#666666]">
                        <div v-for="item in second_tabs" :key="item.name" class="hover:text-[#008BD6] hover:underline"
                            @click="gotoDetail(item.to)">{{ item.name }}
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="flex mr-7">
            <div class="mr-4 flex text-sm items-center text-[##008BD6] tracking-wide justify-center h-9 w-28 rounded-3xl bg-white cursor-pointer"
                @mouseover="showMenu = false" @click="openModal">
                <img src="@/assets/联系我们.png" class="w-4 h-3 mr-1"> 联系我们
            </div>
            <!-- <div class="flex text-sm items-center text-white tracking-wide justify-center h-9 w-28 cursor-pointer"
                @mouseover="showMenu = false" @click="openModal">
                {{ userInfo?.displayName }}
                <ArrowDown />
            </div> -->

                    
            <el-popover placement="bottom" trigger="click">
                <template #reference>
                    <div class="flex text-base items-center text-white tracking-wide justify-center h-9 cursor-pointer">
                        <span class="text-base mr-2">{{ userInfo?.displayName }}</span>
                        <el-icon>
                            <ArrowDown />
                        </el-icon>
                    </div>
                </template>
                <ul>
                    <li class="cursor-pointer" @click="handleLogout" >
                        <span>退出系统</span>
                    </li>
                </ul>
            </el-popover>
            
        </div>

        <div class="absolute w-full h-[28rem]  bg-white top-16 py-10 px-96 z-30" v-show="showMenu" @mouseover="mouseHandle"
            @mouseleave="handleMouseLeave">
            <div class="flex justify-between">
                <dl class="w-1/4">
                    <dt class="text-[#008BD6] text-2xl tracking-wide">
                        <div class="leading-[3.5rem] border-b-[1px] border-[#dddddd]">数据底座</div>
                    </dt>
                    <dd class="text-[#666666] mt-7 tracking-wide">大数据底座</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">AI底座</dd>
                </dl>
                <dl class="w-1/4">
                    <dt class="text-[#008BD6] text-2xl  tracking-wide">
                        <div class="leading-[3.5rem] border-b-[1px] border-[#dddddd]">数据应用</div>
                    </dt>
                    <dd class="text-[#666666] mt-7 tracking-wide">API</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">自助取数&分析</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">专题分析</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">管理看板</dd>
                </dl>
                <dl class="w-1/4">
                    <dt class="text-[#008BD6] text-2xl  tracking-wide">
                        <div class="leading-[3.5rem] border-b-[1px] border-[#dddddd]">AI应用</div>
                    </dt>
                    <dd class="text-[#666666] mt-7 tracking-wide">机器学习</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">工业视觉</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">运筹优化</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">离散事件仿真</dd>
                    <dd class="text-[#666666] mt-7 tracking-wide">自然语言处理</dd>
                </dl>
            </div>
            <div class="mt-8 text-[#008BD6] text-2xl  text-center cursor-pointer tracking-wide"
                @click="gotoDetail('/home/service')">
                查看所有服务 >
            </div>
        </div>
    </header>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { tabs_index, second_tabs } from '@/types/interface'
import { useRouter } from 'vue-router';
import { ArrowDown } from '@element-plus/icons-vue'
import { useUserStore } from "../../stores/user.ts"
import { logout, CLIENT_ID, REDIRECT_URI } from '../../auth/auth';
import { ElMessageBox } from 'element-plus'

const { userInfo } = useUserStore()
const showPopover = ref(false)

const router = useRouter();
const showMenu = ref(false)

interface Emits {
    (e: 'change-chart', visible: boolean): void
}

const emits = defineEmits<Emits>()

const showDetailMenu = ref(false)

const mouseClick = (item: any) => {
    if (item.name === '解决方案') {
        showDetailMenu.value = true
        showMenu.value = false
    } else if (item.name === '服务目录') {
        showDetailMenu.value = false
        showMenu.value = true
    } else {
        showDetailMenu.value = false
        showMenu.value = false
    }
}

const mouseHandle = () => {
    showMenu.value = true
}

const handleMouseLeave = () => {
    setTimeout(() => {
        showMenu.value = false
    }, 200);
}

const routeHome = (item: any) => {
    if (item.name === '首页') {
        router.push(item.to)
    }
}

const gotoDetail = (to: any) => {
    router.push(to)
}


const openModal = () => {
    emits('change-chart', true)
}

function handleLogout() {
    ElMessageBox.confirm(
    '提示',
    '是否退出该账号？',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(() => {
        
        const url = 'https://iam.trinasolar.com/pkmslogout';
      
        const params ={
          client_id: CLIENT_ID,
          redirect_uri: REDIRECT_URI
        };
        const newUrl = url +'?'+ new URLSearchParams(params).toString();
        location.href = newUrl

        logout();
    })

}
</script>

<style lang="scss" scoped></style>