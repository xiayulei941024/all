<template>
    <section class="w-full">
        <div class="text-[#222222] text-center text-3xl pt-36 tracking-wide">{{ title }}</div>
        <div class="mx-96 mt-10 pb-36">
            <ul class="flex flex-wrap gap-5 p-0">
                <li v-for="item in case_list" :key="item.name" class="relative w-[31%] h-[33.75rem] border border-[#DADCDF] shadow-sm shadow-[#0000001a]">
                    <img :src="item.src" class="w-full h-60" />
                    <div class="text-[#222222] text-2xl font-bold mx-10 my-5">
                        {{item.name}}
                    </div>
                    <div class="text-[#666666] text-sm mx-10 my-5">
                       {{item.des}}
                    </div>
                    <div class="mx-10 my-0 flex gap-2">
                        <span v-for="m in item.tag" :key="m"  class="inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-[#909399] ring-1 ring-inset ring-gray-500/10">{{m}}</span >
                    </div>
                    <div class="absolute bottom-5 left-10">
                        <button class="text-sm bg-[#008BD6] rounded-md w-28 h-10 text-white" @click="gotoDetail(item)">
                            查看详情<el-icon class="el-icon--right mr-2">
                                <ArrowRight />
                            </el-icon>
                        </button>
                    </div>
                </li>
            </ul>
        </div>
    </section>
</template>
<script setup lang="ts">
import { ArrowRight } from '@element-plus/icons-vue'
import { useRouter } from 'vue-router';

interface Props {
    title: string,
    case_list: any
}

const router = useRouter();
const props = defineProps<Props>()

const gotoDetail = (item:any) => {
    router.push(item.to)
}
</script>
<style lang="sass" scoped></style>