<template>
    <section class="mx-96">
        <ul class="flex my-16">
            <li v-for="(item, i) in service_carousel" :key="item.title"
                :class="active_sel === i ? 'scale-150 font-bold opacity-100' : 'opacity-60'"
                class="text-2xl text-[#222222] mr-36 cursor-pointer transition-transform duration-300"
                @click="changeCarousel(i)">
                {{ item.title }}
            </li>
        </ul>
        <ul class="flex">
            <li v-for="(item, i) in service_carousel[active_sel].second_list" :key="item.label"
                :class="{ 'text-[#008BD6] border-b-4 border-[#008BD6]': active_sec === i }"
                class="cursor-pointer mr-24 flex flex-col items-center" @mouseenter="mouseHandle(i)">
                <img :src="active_sec === i ? item.select : item.unselect" class="size-20">
                <div class="text-2xl text-center mt-2.5 leading-10">{{ item.label }}</div>
            </li>
        </ul>
        <ul class="w-full h-[32rem] mt-24 mb-36 relative">
            <li v-for="(item, i) in service_carousel[active_sel].second_list" :key="item.label"
                :class="`absolute shadow-service-card w-[45rem] transition-transform ease-in-out duration-500 h-full inset-x-1/2 bg-cover ${item.bgImg}`"
                :style="active_sec === i ? { zIndex: 30, transform: 'translate(-50%, 0%) scale(1)' } : {
                    zIndex: i === 0 ? (10 + active_sec) : active_sec > i ? (20 + i) : (10 - i), transform: `translate(-${(50 - 10 * i) + active_sec * 10}%, 0%) scale(${active_sec > i
                        ? ((1 + 0.1 * i) - 0.1 * active_sec).toFixed(1) : ((1 - 0.1 * i) + 0.1 * active_sec).toFixed(1)})`
                }">
                <div class="h-full w-80 bg-[#242C47] opacity-90 px-10">
                    <div class="pt-28 text-2xl text-white">{{item.label}}</div>
                    <div class="mt-9 text-base text-white">
                        {{ item.des }}</div>
                    <div class="mt-14">
                        <a :href="item.link" target="_blank">
                            <button class="text-sm bg-[#008BD6] rounded-md w-28 h-10 text-white">
                                查看详情<el-icon class="el-icon--right">
                                    <ArrowRight />
                                </el-icon>
                            </button>
                        </a>
                    </div>
                </div>
            </li>
        </ul>
    </section>
</template>
<script setup lang="ts">
import { ArrowRight } from '@element-plus/icons-vue';
import { ref } from 'vue'
interface Props {
    service_carousel: any
}

const props = defineProps<Props>()
const active_sel = ref(0)
const active_sec = ref(0)

const changeCarousel = (i: number) => {
    active_sel.value = i
    active_sec.value = 0
}

const mouseHandle = (i: number) => {
    active_sec.value = i
}

</script>
<style lang="sass" scoped>

</style>