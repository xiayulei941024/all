<template>
    <section class="w-full bg-[#F8F9FD]">
        <div class="text-[#222222] text-center text-3xl pt-36 tracking-wide">多种能力形态 提供全链路数据服务</div>
        <ul class="flex justify-between mx-96 pt-20 px-5 pb-16">
            <li v-for="(item, i) in power_list"
                :class="activeTab === i ? 'bg-[#008BD6] text-white shadow-md shadow-[#008bd633]' : 'bg-white'"
                class="w-60 h-[4.5rem] cursor-pointer text-[#222222] flex items-center" :key="item.name"
                @click="handleTabClick(i)">
                <img :src="item.src" class="w-20 h-[4.5rem] ml-5">
                <span class="text-xl ml-4" :class="{ 'font-bold': activeTab === i }">{{ item.name }}</span>
            </li>
            <li class="w-60 h-[4.5rem] bg-white cursor-pointer text-[#222222] flex items-center justify-center"
                @click="routeService">
                <span class="text-xl">所有服务</span>
            </li>
        </ul>
        <div v-for="item in power_sel_list" :key="item.name"
            class="h-[30rem] mx-96 bg-white py-20 px-12 flex justify-between">
            <img :src="item.img" class="w-[35rem] h-80" />
            <div class="w-96 pt-4">
                <div class="text-[#222222] text-xl font-bold">
                    {{ item.name }}
                </div>
                <div class="text-[#666666 text-sm my-5">
                    {{ item.des }}
                </div>
                <div class="flex gap-5">
                    <span v-for="m in item.tag" :key="m" class="inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-[#909399] ring-1 ring-inset ring-gray-500/10">{{ m }}</span>
                </div>
                <div class="my-16 flex gap-5 flex-wrap">
                    <a v-for="n in item.link" :key="n.title" :href="n.url" target="_blank">
                        <button class="text-sm bg-[#008BD6] rounded-md px-3 py-2 text-white">
                            {{ n.title }}<el-icon class="el-icon--right mr-2">
                                <ArrowRight />
                            </el-icon>
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </section>
</template>
<script setup lang="ts">
import { power_list } from '@/types/interface';
import { ArrowRight } from '@element-plus/icons-vue'
import { ref, computed } from 'vue';
import { useRouter } from 'vue-router';


const router = useRouter();
interface Props {
    title: string,
    power_list: any
}
const activeTab = ref(0)

const power_sel_list = computed(() => {
    return power_list.filter((item, i) => activeTab.value === i)
})

const handleTabClick = (value: number) => {
    setTimeout(() => {
        activeTab.value = value
    }, 200);
}

const routeService = () => {
    router.push('/home/service')
}

</script>
<style lang="sass" scoped>

</style>