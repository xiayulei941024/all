<template>
    <section class="w-full h-[31rem]">
        <div class="w-full h-full bg-no-repeat bg-cover bg-center"
        style="background-position: center center; background-repeat: no-repeat;"
            :class="bg_index === 'home' ? 'bg-home-bg' : 'bg-other-bg'">
            <div v-if="bg_index === 'other'" class="ml-96 h-full relative">
                <div class="text-sm  pt-8">
                    <el-breadcrumb :separator-icon="ArrowRight">
                        <el-breadcrumb-item v-for="item in menu_data.breed" :key="item" class="text-sm">{{item}}</el-breadcrumb-item>
                    </el-breadcrumb>
                </div>
                <div class="text-4xl font-bold text-[#222222] pt-16">
                    {{menu_data.title}}
                </div>
                <div class="w-[31rem] text-sm text-[#666666] mt-5 text-justify">
                    {{ menu_data.des }}
                </div>
                <div class="mt-9 flex gap-5">
                    <span v-for="item in menu_data.tag" :key="item" class="inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-[#909399] ring-1 ring-inset ring-gray-500/10">{{item}}</span>
                </div>
                <div class="w-[45rem] h-44  absolute -bottom-20 flex justify-between">
                    <div v-for="item in menu_data.card_list" :key="item.name" class="w-80 h-full bg-white shadow-card p-9 flex items-center justify-between">
                        <img :src="item.src" class="size-20">
                        <div class="w-36">
                            <div class="text-sm mb-4">{{item.name}}</div>
                            <div class="text-5xl font-bold text-[#008BD6]">
                                {{ item.value }}<span class="text-sm ml-2">{{ item.unit }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<script setup lang="ts">
import { ArrowRight } from '@element-plus/icons-vue'

interface Props {
    bg_index: string,
    menu_data?: any
}
const props = defineProps<Props>()


</script>
<style lang="sass" scoped>

</style>