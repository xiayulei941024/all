<template>
    <div class="w-full bg-[#F8F9FD]">
        <div class="pt-24 mx-96">
            <div class="text-3xl text-center h-28 leading-[7rem] border-b-2 border-[#DDDDDD]">{{ title }}</div>

            <div class="grid grid-cols-3 gap-4 mt-10">
                <div v-for="item in use_power" :key="item.title"
                    class="h-auto bg-white border border-[#DADCDF] p-7 flex items-start hover:shadow-power-card">
                    <img src="@/assets/位图.png" class="size-16">
                    <div class="ml-6 tracking-wide text-justify">
                        <div class="text-lg font-bold text-[#222222] mb-3.5">{{ item.title }}</div>
                        <div class="text-sm text-[#555555]">{{ item.des }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
interface Props {
    title: string,
    use_power: any
}

const props = defineProps<Props>()
</script>
<style lang="sass" scoped>

</style>