<template>
    <el-dialog v-model="isShowChart" title="联系我们" width="500" class="p-12">
        <el-form :model="form" class="mt-2.5">
            <el-form-item label="用户名" label-width="100px">
                <el-input v-model="form.name" placeholder="gaotao" disabled />
            </el-form-item>
            <el-form-item label="邮箱" label-width="100px">
                <el-input v-model="form.mail" placeholder="gaotao@trinasolar.com" disabled />
            </el-form-item>
            <el-form-item label="问题与建议" label-width="100px">
                <el-input v-model="form.desc" :autosize="{ minRows: 2, maxRows: 4 }"
                    type="textarea" placeholder="请输入..." />
            </el-form-item>
        </el-form>
        <template #footer>
            <div class="dialog-footer">
                <el-button @click="handleClose">取消</el-button>
                <el-button type="primary" @click="handleClose">确认</el-button>
            </div>
        </template>
    </el-dialog>
</template>
<script setup lang="ts">
import { computed, reactive } from 'vue';

interface Props {
    dialogFormVisible: boolean,
}


interface Emits {
    (e: 'update:dialogFormVisible', visible: boolean): void
}

const emits = defineEmits<Emits>()
const props = defineProps<Props>()

const isShowChart = computed({
    get() {
        return props.dialogFormVisible
    },
    set(val: boolean) {
        emits('update:dialogFormVisible', val)
    }
})

const form = reactive({
    name: '',
    mail: '',
    desc: ''
})

const handleClose = () => {
    emits('update:dialogFormVisible', false)
}

</script>
<style lang="sass" scoped></style>