import './assets/main.css'
// import 'normalize.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import { checkAuthentication, handleRedirect } from './auth/auth'
// vue3持久化
import piniaPersistedState  from 'pinia-plugin-persistedstate'

// import apiClient from './axios';  // 引入配置好的 Axios 实例


import App from './App.vue'
import router from './router'
const pinia = createPinia()
pinia.use(piniaPersistedState)

const app = createApp(App)


app.use(pinia)
app.use(router)
app.use(ElementPlus)

// 在应用实例中全局挂载 Axios 实例
// app.config.globalProperties.$axios = apiClient;



checkAuthentication()
if (localStorage.getItem('code') && !localStorage.getItem('token')) {
  handleRedirect().then(res => {
    console.log(res);
  }).catch(err => {
    console.log('err',err);
  })
}

app.mount('#app')
