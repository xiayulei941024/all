// src/auth.js
import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from "./../stores/user.ts";

export const CLIENT_ID = '5jq9HqfRYGb1C6kGERtU'
// export const REDIRECT_URI = 'http//ll5ca1host:5173/home/homePage' // * 本地调试
export const REDIRECT_URI = 'https://ai.trinasolar.com/home/homePage'
const AUTHORIZATION_URL = 'https://iam.trinasolar.com/mga/sps/oauth/oauth20/authorize' // 替换为您的 SSO 提供者的授权 URL
const TOKEN_URL = '/admin-api/system/auth/auth-login' // 替换为您的 SSO 提供者的 Token URL

export function checkAuthentication() {
  const token = localStorage.getItem('token')
  if (!token) {
    const code = _getCodeByUrl();
    if (!code) login() // 如果没有 token，自动重定向到登录页面
  } else {
    setAxiosDefaults() // 如果有 token，设置 axios 默认请求头
  }
}

function _getCodeByUrl() {
  let _code = localStorage.getItem('code');
  if (!_code) {
    const params = new URLSearchParams(new URL(location.href).searchParams)
    
    _code = params.get('code');
  
    if (_code) {
      localStorage.setItem('code', _code)
    } 
  }
  return _code;
}

export function login() {
  const url = `${AUTHORIZATION_URL}?response_type=code&client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}`
  window.location.href = url // 重定向到 SSO 登录页面
}

export async function handleRedirect() {
  const userStore = useUserStore()
  const code = localStorage.getItem('code')
  if (code) {
    try {
      // 使用 GET 请求获取 token
      const response = await axios.get(TOKEN_URL, {
        params: {
          code
        }
      })
      const res= response.data;
      // if (res.code == 1002000008) {
      //   return;
      // }
      if (res.code != 0) {
      // if (res.code == 1002000008) {
        logout();
        ElMessage({
          type: 'warning',
          message: res.msg
        });
        return;
      }
      const {accessToken} = res.data // 假设返回的 response.data 中有 token
      if(accessToken){
        localStorage.setItem('token', accessToken) // 将 token 存储在 localStorage 中
        // localStorage.setItem("userInfo", JSON.stringify(res.data)) // 将 userInfo 存储在 localStorage 中
        userStore.setUserInfo(res.data);

        const baseHref = window.location.origin + window.location.pathname;
        window.location.href = baseHref;

        setAxiosDefaults() // 设置 axios 默认请求头
      }
    } catch (error) {
      console.error('Token exchange failed:', error)
    }
  }
}

export function logout() {
  localStorage.removeItem('token') // 清除 token
  localStorage.removeItem('code') // 清除 token
  // 可能需要重定向到 SSO 登出 URL
}

export function getToken() {
  return localStorage.getItem('token') // 获取 token
}

// 配置 axios 默认请求头
export function setAxiosDefaults() {
  const token = getToken()
  if (token) {
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
  }
}

export function handleSSOCallback() {
    checkAuthentication()
}
