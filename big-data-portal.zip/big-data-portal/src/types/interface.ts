export const tabs_index = [
  { name: '首页', to: '/home/homePage' },
  { name: '服务目录', to: '/' },
  { name: '解决方案', to: '/' }
]

export const second_tabs = [
  { name: '物流仓储BI', to: '/home/storageLogistic' },
  { name: '数据资产化', to: '/home/dataAsset' },
  { name: '视觉质检', to: '/home/visionQuality' }
]

export const case_list = [
  {
    name: '物流仓储BI',
    des: '通过BI工具实现物流仓储全流程数据化管理，年降本约800万。',
    to: '/home/storageLogistic',
    src: '/assets/test.png',
    tag: ['场景化数据分析', '可视化BI应用', '天玑']
  },
  {
    name: '数据资产化',
    des: '财经数据资产化，效率倍增，覆盖率翻番。',
    to: '/home/dataAsset',
    src: '/assets/资产.png',
    tag: ['数据湖', '数据资产运营']
  },
  {
    name: '视觉质检',
    des: 'AI视觉革新质检，提效降本，保障光伏组件品质。',
    to: '/home/visionQuality',
    src: '/assets/工业视觉.png',
    tag: ['工业视觉']
  }
]

export const power_list = [
  {
    name: '数据底座',
    des: '专精数据资产管理，涵盖目录、元数据、质量管理及生命周期管理，保障数据资产价值最大化。',
    tag: ['数据湖', '自助取数平台', '数据资产运营'],
    src: '/assets/编组 21.png',
    img: '/assets/数据底座.jpg',
    link: [
      {
        title: '数据开发平台',
        url: 'http://datagovnew.trinasolar.com/'
      },
      {
        title: '数据资产平台',
        url: 'http://dataassets.trinasolar.com/'
      }
    ]
  },
  {
    name: '数据应用',
    des: '专注于数据可视化和应用开发，提供自助分析服务和场景化数据分析，助力业务洞察和决策。',
    tag: ['场景化数据分析', '数字化转型', '天玑（统一数据门户）'],
    src: '/assets/编组 19.png',
    img: '/assets/数据应用.jpg',
    link: [
      {
        title: '天玑',
        url: 'https://bigdata.trinasolar.com/portal/changeLang?serverName=SJQ'
      },
      {
        title: '永洪',
        url: 'http://10.160.173.24:38081/bi/'
      },
      {
        title: '数据补录系统',
        url: 'http://tsczbdapprd3.trinasolar.com:6080/dataCollection/#/'
      }
    ]
  },
  {
    name: 'AI应用',
    des: '利用AI技术进行数据分析和决策支持，提供机器学习、自然语言处理等高级分析工具，推动企业数字化转型。',
    tag: ['工业视觉', '自然语言处理', '运筹优化'],
    src: '/assets/编组 18.png',
    img: '/assets/AI应用.jpg',
    link: [
      {
        title: '算法平台',
        url: 'https://matrix.trinasolar.com/'
      }
    ]
  }
]

export const use_power_vis = [
  {
    title: '工业视觉',
    des: '利用计算机视觉技术对工业生产过程中的各种图像进行自动识别、定位、检测等操作，从而实现自动化、智能化生产。'
  }
]

export const use_power_ass = [
  {
    title: '数据湖',
    des: '接入大数据&提供PB级大规模数据存储能力，支持结构化、半结构化、非结构化存储； 提供高性能计算能力，支持离线计算、实时计算； 提供高性能的OLAP查询能力。'
  },
  {
    title: '数据汇聚',
    des: '接入大数据&能够将不同来源和类型的数据进行有效汇聚的能力，包括实时数据和批量数据的接入，数据来源覆盖关系型数据库、外部接口、非关系型数据库、第三方数据包SDK等。'
  },
  {
    title: '数据开发与处理能力',
    des: '提供数据加工、处理和分析的工具，支持数据的清洗、转换和加载（ETL）操作，以及数据建模、任务调度等。'
  },
  {
    title: '数据资产管理',
    des: '具备数据资产目录管理、元数据管理、数据质量管理、数据血缘分析和数据生命周期管理等功能。'
  },
  {
    title: '数据服务能力',
    des: '能够将数据封装成服务，提供数据API、数据接口、数据产品等，以支持业务应用、数据分析等。'
  },
  {
    title: '数据安全能力',
    des: '保障数据在采集、存储、处理和传输过程中的安全性，包括数据加密、访问控制、数据脱敏和安全审计等，保障用户数据流通的安全性。'
  },
  {
    title: '数据资产运营',
    des: '能够对数据资产进行识别、应用，并基于策略和方法对使用情况进行优化和推广，形成基于成本管理和价值评估的评价体系。'
  }
]

export const use_power_bi = [
  {
    title: '数据开发与处理能力',
    des: '接入大数据&提供数据加工、处理和分析的工具，支持数据的清洗、转换和加载（ETL）操作，以及数据建模、任务调度等。'
  },
  {
    title: '数据资产管理',
    des: '接入大数据&具备数据资产目录管理、元数据管理、数据质量管理、数据血缘分析和数据生命周期管理等功能。'
  },
  {
    title: '场景化数据分析',
    des: '接入大数据&从业务角度出发，为用户提供深入洞察、精准预测的能力，在业务场景数据挖掘中，提供定制化数据分析工具，助力用户优化业务流程，提升业务效率和决策质量。'
  },
  {
    title: '数据分析决策报告',
    des: '接入大数据&我们通过多源数据整合和分析，帮助企业打通数据孤岛，提供定制化服务，生成准确、及时、有针对性的可视化决策分析报告。这有助于企业洞察市场趋势、优化业务流程，提升运营效率。'
  },
  {
    title: '可视化BI应用',
    des: '接入大数据&一站式大数据分析平台，在一个统一的平台上完成自助式、全流程数据分析任务，零代码开发，拖拽布局，编辑过程“所见即所得”，提供普通业务人员就能上手的数据分析产品。'
  },
  {
    title: '天玑（统一数据门户）',
    des: '接入大数据&业务人员可通过自助实时数据分析，监控预警并获得决策建议。个性化看板指标，严控数据权限安全，提升数据一致性，实现数据共享和业务协同，提高运营效率。'
  }
]

export const log_data = {
  breed: ['解决方案', '物流仓储'],
  title: '从BI到AI：如何帮物流仓储团队“运营管理看得清，核心流程走得顺',
  des: '本案例通过BI工具实现物流仓储全流程数据化管理，覆盖CMBU全球物流与仓储业务，服务140+用户。关键指标显著提升，库容需求减少25%，年降本约800万。方案整合数据能力，提高效率，减少人力依赖，实现数据驱动的决策优化。',
  tag: ['场景化数据分析', '可视化BI应用', '天玑'],
  card_list: [
    {
      src: '/assets/编组 5.png',
      name: '受用人数',
      value: '140+',
      unit: '人'
    },
    {
      src: '/assets/编组 6.png',
      name: '库容面积减少',
      value: '25',
      unit: '%'
    }
  ]
}

export const asset_data = {
  breed: ['解决方案', '数据资产化'],
  title: '以指标为牵引，让运营助力数据资产建设效果可量化！',
  des: '本案例通过指标牵引，实现数据资产建设效果量化，显著提升开发效率50%，存储节省17.4TB，资产覆盖率从30%增至80%。整合财经数据，构建高效指标体系，通过资产管理平台和数据质量监控，优化数据供应链，实现资产价值的量化评估。',
  tag: ['数据湖', '数据资产运营', '数据资产运营'],
  card_list: [
    {
      src: '/assets/编组 5.png',
      name: '存储节省',
      value: '17.4',
      unit: 'TB'
    },
    {
      src: '/assets/编组 6.png',
      name: '开发效率提升',
      value: '50',
      unit: '%'
    }
  ]
}

export const vision_data = {
  breed: ['解决方案', '视觉质检'],
  title: 'AI视觉助力组件全流程质检，人力节省50%+！',
  des: 'AI视觉技术应用于光伏组件全流程质检，准确率超99.9%，人力成本节省50%+。技术已覆盖1700+产线，15个基地，全工序多检测点，识别27种缺陷，显著提升生产效率与组件质量，优化天合品牌竞争力。',
  tag: ['工业视觉'],
  card_list: [
    {
      src: '/assets/编组 5.png',
      name: '节省目检人力',
      value: '50',
      unit: '%'
    },
    {
      src: '/assets/编组 6.png',
      name: '提升质检准确率',
      value: '99',
      unit: '%'
    }
  ]
}

export const service_data = {
  breed: ['服务目录', '服务能力'],
  title: '服务能力',
  des: '为伙伴提供技术客户、营销企业运作等全方位支持，帮助伙伴成功，共享AI未来，解决方案和行业的数字化服务、基于推进企业数字化转型的共同愿景，讲发挥各自在行业和业务领域的优势，展开全方位的合作。',
  tag: [],
  card_list: []
}

export const service_carousel = [
  {
    title: '数据底座',
    second_list: [
      {
        label: '数据存储',
        select: '/assets/serviceImages/icon-选择-数据存算.png',
        unselect: '/assets/serviceImages/icon-未选择-数据存算.png',
        bgImg: 'bg-[url(/assets/serviceImages/机器学习.png)]',
        des: '数据存算好比制造业的顶尖智能仓库，能轻松支撑住PB级的各种多样化的数据形态；计算能力强劲，处理数据如同流水线般高效，支持即时响应；OLAP查询则像是仓库智能导航，能快速定位所需信息，实现高速检索。',
        link: 'https://bigdatayh.trinasolar.com/bi/Viewer'
      },
      {
        label: '算力&模型',
        select: '/assets/serviceImages/icon-选择-算力&模型.png',
        unselect: '/assets/serviceImages/icon-未选择-算力&模型.png',
        bgImg: 'bg-[url(/assets/serviceImages/算力大模型.png)]',
        des: 'Matrix平台用于提供AI算力基础能力，提供10张显卡+6240Tops的算力支撑，目前已承载100+算法模型，包含聊天机器人、翻译、图像生成等各个领域的应用',
        link: 'https://matrix.trinasolar.com/'
      }
    ]
  },
  {
    title: '数据应用',
    second_list: [
      {
        label: 'API',
        select: '/assets/serviceImages/icon-选择-api.png',
        unselect: '/assets/serviceImages/icon-未选择-api.png',
        bgImg: 'bg-[url(/assets/serviceImages/数据应用API.png)]',
        des: '能够将数据转化为可消费的服务形式，通过提供数据API、数据接口和数据产品，有效支撑业务应用的需求和深入的数据分析工作，促进数据价值的全面释放和高效利用。',
        link: 'https://bigdatayh.trinasolar.com/bi/Viewer'
      },
      {
        label: '自助取数&分析',
        select: '/assets/serviceImages/icon-选择-自助取数分析.png',
        unselect: '/assets/serviceImages/icon-未选择-自助取数分析.png',
        bgImg: 'bg-[url(/assets/serviceImages/自助取数.png)]',
        des: '自助取数通过单一的入口简化了数据获取流程。业务用户可以自主浏览和选择符合自身需求的数据集，无需编程技能即可直接提取和使用数据，极大地提升了数据获取的效率和便利性，支持业务决策的快速形成。',
        link: 'https://bigdatayh.trinasolar.com/bi/Viewer'
      },
      {
        label: '专题分析',
        select: '/assets/serviceImages/icon-选择-专题分析.png',
        unselect: '/assets/serviceImages/icon-未选择-专题分析.png',
        bgImg: 'bg-[url(/assets/serviceImages/机器学习.png)]',
        des: '为你提供定制化主题数据透视及分析服务，支持手工补录历史业务数据完善分析数据源，并支持指标预警规则配置及实时推送，提升业务效率和决策质量。',
        link: 'https://bigdatayh.trinasolar.com/bi/Viewer'
      },
      {
        label: '管理看板',
        select: '/assets/serviceImages/icon-选择-管理看板.png',
        unselect: '/assets/serviceImages/icon-未选择-管理看板.png',
        bgImg: 'bg-[url(/assets/serviceImages/运筹优化.png)]',
        des: '为你提供可快速复用的数据产品，包含多种高效敏捷丰富的产品组件，支持包括表间跳转、下钻、联动等交互能力，满足管理层快速洞察经营业务的需求。',
        link: 'https://bigdatayh.trinasolar.com/bi/Viewer'
      }
    ]
  },
  {
    title: 'AI应用',
    second_list: [
      {
        label: '机器学习',
        select: '/assets/serviceImages/icon-选择-机器学习.png',
        unselect: '/assets/serviceImages/icon-未选择-机器学习.png',
        bgImg: "bg-[url('/assets/serviceImages/机器学习.png')]",
        des: '从已有的数据中发现规律，然后用这些规律去预测新的数据。例如，模型可以识别出发电量与天气变化之间的显著关联，从而利用天气数据精确预测发电量。',
        link: 'https://matrix.trinasolar.com/'
      },
      {
        label: '工业视觉',
        select: '/assets/serviceImages/icon-选择-工业视觉.png',
        unselect: '/assets/serviceImages/icon-未选择-工业视觉.png',
        bgImg: "bg-[url('/assets/serviceImages/工业视觉.png')]",
        des: '对工业生产过程中的各种图像进行自动识别、定位、检测等操作，从而实现自动化、智能化生产。例如，利用视觉质检技术可以自动识别产品缺陷，提升质量控制效率。',
        link: 'https://matrix.trinasolar.com/'
      },
      {
        label: '运筹优化',
        select: '/assets/serviceImages/icon-选择-运筹优化.png',
        unselect: '/assets/serviceImages/icon-未选择-运筹优化.png',
        bgImg: "bg-[url('/assets/serviceImages/运筹优化.png')]",
        des: '通过对资源的合理配置和决策的优化，提高系统的效率和效益。例如，在物流管理中，运筹优化可以帮助确定最佳运输路线和配送方案，从而降低成本、缩短配送时间。',
        link: 'https://matrix.trinasolar.com/'
      },
      {
        label: '离散事件仿真',
        select: '/assets/serviceImages/icon-选择-离散事件仿真.png',
        unselect: '/assets/serviceImages/icon-未选择-离散事件仿真.png',
        bgImg: "bg-[url('/assets/serviceImages/离散事件仿真.png')]",
        des: '模仿真实世界的系统或过程，通过仿真，人们可以在虚拟环境中试验和观察复杂现象，从而更好地理解和控制这些现象。例如，在制造业中，离散事件仿真可以用来模拟生产线的流程，评估瓶颈、优化资源配置和提高生产效率。',
        link: 'https://matrix.trinasolar.com/'
      },
      {
        label: '自然语言处理',
        select: '/assets/serviceImages/icon-选择-自然语言处理.png',
        unselect: '/assets/serviceImages/icon-未选择-自然语言处理.png',
        bgImg: "bg-[url('/assets/serviceImages/自然语言处理.png')]",
        des: '结合大模型技术，处理文本和语言数据，如从海量数据中抽取想要的信息、快速阅读海量文献进行要点总结等。',
        link: 'https://matrix.trinasolar.com/'
      }
    ]
  }
]
