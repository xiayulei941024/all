import {defineConfig} from 'vite'
import postcss from './postcss.config.js'
import react from '@vitejs/plugin-react'
import legacy from '@vitejs/plugin-legacy';

// https://vitejs.dev/config/
export default defineConfig(({mode}) => ({
  server: {
    host: "0.0.0.0",
    port: 5600,
    proxy: {
      '/api': {
        target: mode === 'development' ? "https://127.0.0.1:3000": 'https://matrixbackend.trinasolar.com',  //target: "http://127.0.0.1:3000"
        changeOrigin: true,
        secure: mode !== 'development',
        rewrite: (path) => {
          return path.replace(/^\/api/, "")
        },
      },
    },
    https: mode !== 'development',
  },
  define: {
    "process.env": process.env,
  },
  css: {
    postcss,
  },
  plugins: [
    react(),
    legacy({
      targets: ['Chrome 69', 'android >= 4.2'],
      additionalLegacyPolyfills: ['regenerator-runtime/runtime'],
      modernPolyfills: true,
      polyfills: [
        'es.symbol',
        'es.promise',
        'es.promise.finally',
        'es/map',
        'es/set',
        'es.array.filter',
        'es.array.for-each',
        'es.array.flat-map',
        'es.object.define-properties',
        'es.object.define-property',
        'es.object.get-own-property-descriptor',
        'es.object.get-own-property-descriptors',
        'es.object.keys',
        'es.object.to-string',
        'web.dom-collections.for-each',
        'esnext.global-this',
      ]
    }),
  ],
  resolve: {
    alias: [
      {
        find: /^~.+/,
        replacement: (val) => {
          return val.replace(/^~/, "");
        },
      },
    ],
  },
  build: {
    target: 'es2015',
    cssTarget: "chrome69",
    // rollupOptions: {
    //   external: ['dingtalk-jsapi']
    // },
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },
}));
