// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBV4VlWBjvGQcwnvWReJjNPgf06Rqdf854",
    authDomain: "matrix-5edae.firebaseapp.com",
    projectId: "matrix-5edae",
    storageBucket: "matrix-5edae.appspot.com",
    messagingSenderId: "1033604938639",
    appId: "1:1033604938639:web:3fa8920aa3391b0b9269fa"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
