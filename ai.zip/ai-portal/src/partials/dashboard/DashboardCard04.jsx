import React ,{useEffect, useState} from 'react';
import BarChart from '../../charts/BarChart01';

// Import utilities
import { service } from '../../axios';
// import dayjs from 'dayjs';

function DashboardCard04() {

  const [visitData, setVisitData]  = useState(null)
  const [clickData, setClickData]  = useState(null)
  const [userData, setUserData]  = useState(null)

  const getVisitData = async () => {
    const res = await service.get('/getVisit2Week')
    res.data.map((item) => {
      return item
    })
    setVisitData(res.data)   
  }

  const getClickData = async () => {
    const res = await service.get('/getClick2Week')
    setClickData(res.data)   
  }
  
  const getUserData = async () => {
    const res = await service.get('/getUser2Week')
    setUserData(res.data)   
  }
  
  useEffect(() => {
    getVisitData()
    getClickData()
    getUserData()
  }, [])

  if (!visitData || !clickData || !userData) {
    return <div>Loading...</div>
  }

  const chartData = {
    labels: visitData.map(e => {
      let utcDate = new Date(e.date);
      let chinaDate = new Date(utcDate.getTime() + 8 * 60 * 60 * 1000); 
      return chinaDate.toLocaleDateString('zh-CN', {timeZone: 'Asia/Shanghai'})
    }),
    datasets: [
      // Light blue bars
      {
        label: '访问量',
        data: visitData.map(e => e.total_count),
        backgroundColor: '#67BFFF',
        hoverBackgroundColor: '#56B1F3',
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        borderRadius: 4,
      },
      // Blue bars
      {
        label: '点击量',
        data: clickData.map(e => e.total_count),
        backgroundColor: '#8470FF',
        hoverBackgroundColor: '#755FF8',
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        borderRadius: 4,
      },
       // Blue bars
      {
        label: '用户量',
        data: userData.map(e => e.total_count),
        backgroundColor: '#3EC972',
        hoverBackgroundColor: '#34BD68',
        barPercentage: 0.7,
        categoryPercentage: 0.7,
        borderRadius: 4,
      },
    ],
  };

  return (
    <div className="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <header className="px-5 py-4 border-b border-gray-100 dark:border-gray-700/60">
        <h2 className="font-semibold text-gray-800 dark:text-gray-100">访问量 VS 点击量 VS 用户量</h2>
      </header>
      {/* Chart built with Chart.js 3 */}
      {/* Change the height attribute to adjust the chart height */}
      <BarChart data={chartData} width={595} height={248} />
    </div>
  );
}

export default DashboardCard04;
