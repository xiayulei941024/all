import React ,{useEffect, useState} from 'react';
import { Link } from 'react-router-dom';
import LineChart from '../../charts/LineChart01';
import { chartAreaGradient } from '../../charts/ChartjsConfig';
// import EditMenu from '../../components/DropdownEditMenu';

// Import utilities
import { hexToRGB } from '../../utils/Utils';
import { service } from '../../axios';
import dayjs from 'dayjs';

function DashboardCard03() {

  const [data, setData]  = useState(null)
  const [totalNum, setTotalNum] = useState()
  const [percent, setPercent] = useState(null)
  
  const getTotalNum = async () => {
    const res = await service.get('/getTotalUserNum')
    setTotalNum(res.data.total_count)
  }

  const getWeekNum = async () => {
    const res = await service.get('/getUserWeek')
    const lastTwoWeek = res.data.slice(-2)
    const per = ((lastTwoWeek[1].total_count - lastTwoWeek[0].total_count) / lastTwoWeek[0].total_count * 100).toFixed(2)
    
    setPercent(per)
    setData(res.data.slice(1))   
  }
  
  useEffect(() => {
    getTotalNum()
    getWeekNum()
  }, [])
  
  if (!data) {
    return <div>Loading...</div>
  }
  const chartData = {
    labels: data.map((e) => {
      return dayjs(e.last_day_of_week).format('MM-DD')
    }),
    datasets: [
      // Indigo line
      {
        data: data.map(e => e.total_count),
        fill: true,
        backgroundColor: function(context) {
          const chart = context.chart;
          const {ctx, chartArea} = chart;
          return chartAreaGradient(ctx, chartArea, [
            { stop: 0, color: `rgba(${hexToRGB('#8470FF')}, 0)` },
            { stop: 1, color: `rgba(${hexToRGB('#8470FF')}, 0.2)` }
          ]);
        },       
        borderColor: '#8470FF',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 3,
        pointBackgroundColor: '#8470FF',
        pointHoverBackgroundColor: '#8470FF',
        pointBorderWidth: 0,
        pointHoverBorderWidth: 0,          
        clip: 20,
        tension: 0.2,
      },
      // Gray line
    ],
  };

  return (
    <div className="flex flex-col col-span-full sm:col-span-6 xl:col-span-4 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <div className="px-5 pt-5">
        <header className="flex justify-between items-start mb-2">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-2">用户量（周次）</h2>
          {/* Menu button */}
          {/* <EditMenu align="right" className="relative inline-flex">
            <li>
              <Link className="font-medium text-sm text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-200 flex py-1 px-3" to="#0">
                Option 1
              </Link>
            </li>
            <li>
              <Link className="font-medium text-sm text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-200 flex py-1 px-3" to="#0">
                Option 2
              </Link>
            </li>
            <li>
              <Link className="font-medium text-sm text-red-500 hover:text-red-600 flex py-1 px-3" to="#0">
                Remove
              </Link>
            </li>
          </EditMenu> */}
        </header>
        <div className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase mb-1">人</div>
        <div className="flex items-start">
        <div className="text-3xl font-bold text-gray-800 dark:text-gray-100 mr-2">{totalNum}</div>
          {percent >= 0 ? <div className="text-sm font-medium text-red-700 px-1.5 bg-red-500/20 rounded-full">{percent}%</div>
          : <div className="text-sm font-medium text-green-700 px-1.5 bg-green-500/20 rounded-full">{percent}%</div>}
        </div>
      </div>
      {/* Chart built with Chart.js 3 */}
      <div className="grow max-sm:max-h-[128px] xl:max-h-[128px]">
        {/* Change the height attribute to adjust the chart height */}
        <LineChart data={chartData} width={389} height={128} />
      </div>
    </div>
  );
}

export default DashboardCard03;
