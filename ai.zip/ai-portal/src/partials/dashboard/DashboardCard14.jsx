import React ,{useEffect, useState} from 'react';

import { service } from '../../axios';

function DashboardCard14() {

  const [customers, setCustomers] = useState([])
  const getTotalUser = async () => {
    const res = await service.get('/getTranslationTopUser')
    const user = res.data.slice(3,13).map((e, i) => {  // 剔除最高的12个用户，基本都是本组用户
      return {
        id: i,
        name: e.user_info_uid,
        spent: e.click_count,
      }
    })    
    setCustomers(user)
  }
  
  useEffect(() => {
    getTotalUser()
  }, [])

  return (
    <div className="col-span-full xl:col-span-6 bg-white dark:bg-gray-800 shadow-sm rounded-xl">
      <header className="px-5 py-4 border-b border-gray-100 dark:border-gray-700/60">
        <h2 className="font-semibold text-gray-800 dark:text-gray-100">TOP AI翻译页面访问次数</h2>
      </header>
      <div className="p-3">

        {/* Card content */}
        {/* "Today" group */}
        <div>
          <div className="flex justify-between text-xs uppercase text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50 rounded-sm font-semibold p-2">
            <span>姓名</span>
            <span>访问次数</span>
          </div>
          <ul className="my-1">
            {customers.length && customers.map( e => {
              return (
                <li className="flex px-2" key={e.id}>
                  <div className="grow flex items-center border-b border-gray-100 dark:border-gray-700/60 text-sm py-2">
                    <div className="grow flex justify-between">
                      <div className="self-center">{e.name}</div>
                      <div className="shrink-0 self-start ml-2">
                        <span className="font-medium text-green-600">{e.spent}</span>
                      </div>
                    </div>
                  </div>
                </li>
              )
            })}
          </ul>
        </div>

      </div>
    </div>
  );
}

export default DashboardCard14;
