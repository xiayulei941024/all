import React from 'react';

import Post01 from '../images/blog-01.jpg';
import Post02 from '../images/blog-02.jpg';
import Post03 from '../images/blog-03.jpg';
import Post04 from '../images/inspiration-05.jpg';
import Post05 from '../images/inspiration-09.jpg';
import PostAuthor01 from '../images/blog-author-01.jpg';
import PostAuthor02 from '../images/blog-author-02.jpg';
import PostAuthor03 from '../images/blog-author-03.jpg';
import clickRecord from '../ClickRecord'

function Blog() {
  return (
    <section>
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="py-12 md:py-20">
          {/* Section header */}
          <div className="pb-12 md:pb-15">
            <h2 className="h2 font-cabinet-grotesk text-center md:text-left">文章分享</h2>
            <p className="text-right text-gray-500">来自大数据部WIKI.</p>

          </div>
          {/* Posts */}
          <div className="max-w-sm mx-auto md:max-w-none grid gap-12 md:grid-cols-3 md:gap-x-6 md:gap-y-8 items-start">
            {/* 1st Post */}
            <article className="h-full flex flex-col space-y-5" data-aos="fade-down">
              {/* Image */}
              <a className="block group overflow-hidden"
              onClick={(event) =>clickRecord(event, 'AI算法')}
              href="https://wiki-bigdata.trinasolar.com/s/63a0c3dc-2c4d-4137-af7f-49d1ea7c086c">
                <img className="w-full aspect-[7/4] object-cover group-hover:scale-105 transition duration-700 ease-out" src={Post01} width="347" height="198" alt="Post 01" />
              </a>
              {/* Content */}
              <div className="grow flex flex-col">
                <header>
                  <h3 className="h4 font-cabinet-grotesk font-bold mb-2">
                    <a className="inline-block decoration-blue-500 decoration-2 underline-offset-2 hover:underline"
                    onClick={(event) =>clickRecord(event, 'AI算法')}
                    href="https://wiki-bigdata.trinasolar.com/s/63a0c3dc-2c4d-4137-af7f-49d1ea7c086c">AI算法 &amp; 算法组能力</a>
                  </h3>
                </header>
                <p className="text-gray-500 grow">EL视觉检测 功率预测.</p>
                <footer className="flex items-center text-sm mt-4">
                  {/*<a href="#0">*/}
                  {/*  <img className="rounded-full shrink-0 mr-3" src={PostAuthor01} width="32" height="32" alt="Author 01" />*/}
                  {/*</a>*/}
                  <div>
                    <span className="text-gray-500">By</span> 
                    <a className="font-medium decoration-blue-500 decoration-2 underline-offset-2 hover:underline" href="#0">张轩磊 (算法组Leader)</a>
                  </div>
                </footer>
              </div>
            </article>
            {/* 2nd Post */}
            <article className="h-full flex flex-col space-y-5" data-aos="fade-down" data-aos-delay="100">
              {/* Image */}
              <a className="block group overflow-hidden"
              onClick={(event) =>clickRecord(event, '大模型')}
              href="https://wiki-bigdata.trinasolar.com/s/e139174b-9221-431a-94c8-6ea11a1fb27d">
                <img className="w-full aspect-[7/4] object-cover group-hover:scale-105 transition duration-700 ease-out" src={Post02} width="347" height="198" alt="Post 02" />
              </a>
              {/* Content */}
              <div className="grow flex flex-col">
                <header>
                  <h3 className="h4 font-cabinet-grotesk font-bold mb-2">
                    <a className="inline-block decoration-blue-500 decoration-2 underline-offset-2 hover:underline"
                    onClick={(event) =>clickRecord(event, '大模型')}
                    href="">大模型 &amp; 扩散模型</a>
                  </h3>
                </header>
                <p className="text-gray-500 grow">扩散模型.</p>
                <footer className="flex items-center text-sm mt-4">
                  {/*<a href="#0">*/}
                  {/*  <img className="rounded-full shrink-0 mr-3" src={PostAuthor02} width="32" height="32" alt="Author 02" />*/}
                  {/*</a>*/}
                  <div>
                    <span className="text-gray-500">By</span> <a className="font-medium decoration-blue-500 decoration-2 underline-offset-2 hover:underline" href="#0">宋保柱 (NLP专家)</a>
                  </div>
                </footer>
              </div>
            </article>
            {/* 3rd Post */}
            <article className="h-full flex flex-col space-y-5" data-aos="fade-down" data-aos-delay="200">
              {/* Image */}
              <a className="block group overflow-hidden"
              onClick={(event) =>clickRecord(event, '机器学习')}
              href="https://wiki-bigdata.trinasolar.com/s/b2389029-4c40-44ad-9c9a-662bcaee02ee">
                <img className="w-full aspect-[7/4] object-cover group-hover:scale-105 transition duration-700 ease-out" src={Post03} width="347" height="198" alt="Post 03" />
              </a>
              {/* Content */}
              <div className="grow flex flex-col">
                <header>
                  <h3 className="h4 font-cabinet-grotesk font-bold mb-2">
                    <a className="inline-block decoration-blue-500 decoration-2 underline-offset-2 hover:underline"
                    onClick={(event) =>clickRecord(event, '机器学习')}
                    href="https://wiki-bigdata.trinasolar.com/s/b2389029-4c40-44ad-9c9a-662bcaee02ee">机器学习 &amp; 可解释</a>
                  </h3>
                </header>
                <p className="text-gray-500 grow">XAI可解释机器学习.</p>
                <footer className="flex items-center text-sm mt-4">
                  {/*<a href="#0">*/}
                  {/*  <img className="rounded-full shrink-0 mr-3" src={PostAuthor03} width="32" height="32" alt="Author 03" />*/}
                  {/*</a>*/}
                  <div>
                    <span className="text-gray-500">By</span> <a className="font-medium decoration-blue-500 decoration-2 underline-offset-2 hover:underline" href="#0">韩懿恺 (ML算法工程师)</a>
                  </div>
                </footer>
              </div>
            </article>

            <article className="h-full flex flex-col space-y-5" data-aos="fade-down" data-aos-delay="200">
              {/* Image */}
              <a className="block group overflow-hidden"
              onClick={(event) =>clickRecord(event, '工业质检')}
              href="#0">
                <img className="w-full aspect-[7/4] object-cover group-hover:scale-105 transition duration-700 ease-out" src={Post04} width="347" height="198" alt="Post 03" />
              </a>
              {/* Content */}
              <div className="grow flex flex-col">
                <header>
                  <h3 className="h4 font-cabinet-grotesk font-bold mb-2">
                    <a className="inline-block decoration-blue-500 decoration-2 underline-offset-2 hover:underline"
                    onClick={(event) =>clickRecord(event, '工业质检')}
                    href="#0">工业质检 &amp; CV</a>
                  </h3>
                </header>
                <p className="text-gray-500 grow">EL检测.</p>
                <footer className="flex items-center text-sm mt-4">
                  {/*<a href="#0">*/}
                  {/*  <img className="rounded-full shrink-0 mr-3" src={PostAuthor03} width="32" height="32" alt="Author 03" />*/}
                  {/*</a>*/}
                  <div>
                    <span className="text-gray-500">By</span> <a className="font-medium decoration-blue-500 decoration-2 underline-offset-2 hover:underline" href="#0">俞立 (CV算法工程师)</a>
                  </div>
                </footer>
              </div>
            </article>
            <article className="h-full flex flex-col space-y-5" data-aos="fade-down" data-aos-delay="200">
              {/* Image */}
              <a className="block group overflow-hidden"
              onClick={(event) =>clickRecord(event, '订单排产')}
              href="#0">
                <img className="w-full aspect-[7/4] object-cover group-hover:scale-105 transition duration-700 ease-out" src={Post05} width="347" height="198" alt="Post 03" />
              </a>
              {/* Content */}
              <div className="grow flex flex-col">
                <header>
                  <h3 className="h4 font-cabinet-grotesk font-bold mb-2">
                    <a className="inline-block decoration-blue-500 decoration-2 underline-offset-2 hover:underline"
                    onClick={(event) =>clickRecord(event, '订单排产')}
                    href="#0">订单排产 &amp; 运筹优化</a>
                  </h3>
                </header>
                <p className="text-gray-500 grow">运筹学解决订单排产问题.</p>
                <footer className="flex items-center text-sm mt-4">
                  {/*<a href="#0">*/}
                  {/*  <img className="rounded-full shrink-0 mr-3" src={PostAuthor03} width="32" height="32" alt="Author 03" />*/}
                  {/*</a>*/}
                  <div>
                    <span className="text-gray-500">By</span> <a className="font-medium decoration-blue-500 decoration-2 underline-offset-2 hover:underline" href="#0">龚林 (运筹算法工程师)</a>
                  </div>
                </footer>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Blog;
