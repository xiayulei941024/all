'use client'

import React, { useRef, useEffect, useState } from 'react';  
import { Dialog, DialogPanel } from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'
import { EnvelopeIcon, PhoneIcon } from '@heroicons/react/20/solid'
import TrinaImage from "../images/logo-mat.png";
import homeBg from '../images/homebg.gif';
import homebgImg from '../images/home-bg.png';
// import chatbotImg from '../images/bot-logo.png';
// import translationImg from '../images/translation-card.png';
// import chatpixImg from '../images/chatpix.png';
// import newsImg from '../images/AI资讯.png';

// import asrImg from '../images/语音识别-logo.png';
// import chatbiImg from '../images/datacompass-logo3.png';
import chatpixImg from '../images/ai-service/图片生成.png';
import translationImg from '../images/ai-service/文档翻译.png';
import asrImg from '../images/ai-service/语音识别.png';
import newsImg from '../images/ai-service/AI资讯.png';
import chatbiImg from '../images/ai-service/chatBI.png';
import robotImg from '../images/aigc-logo.png';
import chatbotImg from '../images/ai-service/chatBot.png';

import powerImg from '../images/project/功率预测.png';
import purchaseImg from '../images/project/智慧采购.png';
import cellImg from '../images/project/组件质检.png';

import stroeImg from '../images/com-tools/仓库库容.png';
import faceImg from '../images/com-tools/AI换脸.png';
import modelImg from '../images/com-tools/AI模型训练.png';
import fastImg from '../images/com-tools/FastGPT.png';

import { color } from 'echarts';
import clickRecord from '../ClickRecord';
import { useNavigate } from 'react-router-dom';

const whiteList = ['tao.gao03', 'xuanlei.zhang']
const posts = [
  {
    id: 1,
    title: 'AI资讯',
    tag: 'AI NEWS',
    href: window.location.origin + '/ai-news',
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl:newsImg,
    date: 'May  16, 2024',
    datetime: '2020-03-16',
    author: {
      name: '高涛，程威',
      imageUrl:
        "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
    },
  },
  {
    id: 2,
    title: '文档翻译',
    tag: '智能翻译',
    href: window.location.origin + '/translation',
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl:translationImg,
    date: 'Dec 16, 2023',
    datetime: '2020-03-16',
    author: {
      name: '高涛，狄晨',
      imageUrl:
        "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
    },
  },
  {
    id: 3,
    title: '图像生成',
    tag: '图像生成',
    href: "https://aigc.trinasolar.com/",
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl:chatpixImg,
    date: 'Dec 16, 2023',
    datetime: '2020-03-16',
    author: {
      name: '韩懿恺',
      imageUrl:
        "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
    },
  },
  {
    id: 4,
    title: 'ChatBot',
    tag: 'ChatBot',
    href: "https://bot.trinasolar.com/",
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl: chatbotImg,
    date: 'Dec 16, 2023',
    datetime: '2020-03-16',
    author: {
      name: '宋保住',
      imageUrl:
        "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
    },
  },
  {
    id: 5,
    title: '语音识别',
    tag: 'ASR',
    href: "http://10.31.141.252:8999",
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl:asrImg,
    date: 'May  16, 2024',
    datetime: '2020-03-16',
    author: {
      name: '程威',
      imageUrl:
        "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
    },
  },
  // {
  //   id: 6,
  //   title: 'ChatBI',
  //   tag: 'ChatBI',
  //   href: "https://datacompass.trinasolar.com/pc/index.html",
  //   description:
  //     'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
  //   imageUrl:chatbiImg,
  //   date: 'May  16, 2024',
  //   datetime: '2020-03-16',
  //   author: {
  //     name: '',
  //     // imageUrl:
  //     //   'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  //   },
  // },
  {
    id: 6,
    title: '客服机器人',
    tag: '客服机器人',
    href: "http://172.22.3.1:8509/",
    description:
      'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.',
    imageUrl:robotImg,
    date: 'May  16, 2024',
    datetime: '2020-03-16',
    author: {
      name: '',
      // imageUrl:
      //   'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    },
  },
  // More posts...
]
const navigation1 = {
  main: [
    { name: '天玑', href: 'https://bigdata.trinasolar.com/' },
    { name: 'Wiki', href: 'https://wiki-bigdata.trinasolar.com/home' },
    { name: '数据开发平台', href: 'http://datagovnew.trinasolar.com/' },
    { name: '数据资产平台', href: 'http://dataassets.trinasolar.com/' },
    { name: '数据补录系统', href: 'http://tsczbdapprd3.trinasolar.com:6080/dataCollection/#/' },
    { name: '永洪', href: 'http://10.160.173.24:38081/bi/' },
    { name: '大数据门户', href: 'http://10.31.141.252:5173/' },
  ],
}

const people1 = [
  {
    name: '张轩磊',
    title: 'Leader',
    role: 'Admin',
    email: 'xuanlei.zhang@trinasolar.com',
    telephone: '144813',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
  {
    name: '宋保柱',
    title: 'NLP大模型',
    // role: 'Admin',
    email: 'baozhu.song@trinasolar.com',
    telephone: '302097',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
  {
    name: '龚林',
    title: '运筹优化',
    // role: 'Admin',
    email: 'lin.gong@trinasolar.com',
    telephone: '262072',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
  {
    name: '俞立',
    title: '视觉仿真',
    // role: 'Admin',
    email: 'li.yu02@trinasolar.com',
    telephone: '179844',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
  {
    name: '韩懿凯',
    title: '机器学习',
    // role: 'Admin',
    email: 'yikai.han@trinasolar.com',
    telephone: '302326',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
  {
    name: '高涛',
    title: '应用开发',
    // role: 'Admin',
    email: 'tao.gao03@trinasolar.com',
    telephone: '365515',
    imageUrl:
      "https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64",
  },
]
export default function HomePage() {

  const targetRef1 = useRef(null);
  const targetRef2 = useRef(null); 
  const targetRef3 = useRef(null); 
  // const targetRef4 = useRef(null); 

  const [showDashboard, setShowDashboard] = useState(false);
  const scrollToTarget = (ref) => {  
    if (ref.current) {
      console.log(ref.current);
      
      ref.current.scrollIntoView({ behavior: "auto",block: "center"});  
    }  
  }; 

  const navigate = useNavigate();
  const params = new URLSearchParams(new URL(location.href).searchParams)
  if (params.get('code')) {
    localStorage.setItem('code',params.get('code'))
    // location.href = location.origin
  }

  useEffect(() => {
    if (localStorage.getItem('pathname')) {
      const pathname = localStorage.getItem('pathname')
      navigate(pathname)
    }
    document.title = "天合光能AI算法平台"; // 设置初始标题
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      const userInfo = JSON.parse(localStorage.getItem('userInfo'))
      if (userInfo) {
        if (whiteList.includes(userInfo.uid)) {
          setShowDashboard(true);
        } 
        clearInterval(timer);
      }
    }, 500);

    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <div className="bg-white">
      <header className="flex items-center justify-between px-8 py-4  w-full inset-x-0 top-0 fixed bg-white z-10 border-b">
        {/* <!-- logo - start --> */}
        <a href="/" className="inline-flex items-center gap-2.5 text-2xl font-bold text-black md:text-3xl" aria-label="logo">
          {/* <svg width="95" height="94" viewBox="0 0 95 94" className="h-auto w-6 text-indigo-500" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M96 0V47L48 94H0V47L48 0H96Z" />
          </svg> */}

          <img
            alt=""
            src={TrinaImage}
            className="h-8 w-auto"
          />
        </a>
        {/* <!-- logo - end --> */}

        {/* <!-- nav - start --> */}
        <nav className="hidden gap-12 lg:flex">
          <a href="#" className="text-lg font-semibold text-sky-700">首页</a>
          <a href="#service" onClick={() => scrollToTarget(targetRef1)} className="text-lg font-semibold text-gray-600 transition duration-100 hover:text-sky-700 active:text-sky-800">AI服务</a>
          <a href="#scenario" onClick={() => scrollToTarget(targetRef2)} className="text-lg font-semibold text-gray-600 transition duration-100 hover:text-sky-700 active:text-sky-800">标杆场景</a>
          <a href="#tool" onClick={() => scrollToTarget(targetRef3)} className="text-lg font-semibold text-gray-600 transition duration-100 hover:text-sky-700 active:text-sky-800">工具平台</a>
          {showDashboard && <a href={window.location.origin + '/dashboard'} onClick={() => scrollToTarget(targetRef3)} className="text-lg font-semibold text-gray-600 transition duration-100 hover:text-sky-700 active:text-sky-800">监控平台</a>}
        </nav>
        {/* <!-- nav - end --> */}

        {/* <!-- buttons - start --> */}
        <a href={`dingtalk://dingtalkclient/page/profile?corp_id=dinga41ec6a58a4911d0f2c783f7214b6d69&staff_id=365515`}
          onClick={(event) => clickRecord(event, '高涛')}
          className="hidden rounded-lg bg-gray-200 px-8 py-3 text-center text-sm font-semibold text-gray-500 outline-none ring-indigo-300 transition duration-100 hover:bg-gray-300 focus-visible:ring active:text-gray-700 md:text-base lg:inline-block">联系我们</a>
      </header>
      <div className=" pb-6 mt-20 pt-8 sm:pb-8 lg:pb-12" style={{backgroundImage:`url(${homebgImg})`,backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat'}}>
        <div className="mx-auto max-w-screen-2xl px-6 md:px-16">

          <section className="mb-8 flex flex-col justify-between gap-6 sm:gap-10 md:mb-16 md:gap-4 lg:flex-row">
            {/* <!-- content - start --> */}
            <div className="flex flex-col justify-center sm:text-center lg:py-12 lg:text-left xl:w-1/2">
              

              <h1 className="mb-8 text-4xl font-bold text-black sm:text-5xl md:mb-12 md:text-8xl" style={{backgroundImage: 'linear-gradient(79deg, #2b0aff, #ff5b8a 49%, #ff5b8a 55%, #fba64b 77%, #f99b52)', color: 'transparent', backgroundClip: 'text'}}>Matrix</h1>
              <p className="mb-4 font-semibold text-indigo-500 md:mb-6 md:text-lg xl:text-xl" style={{backgroundImage: 'linear-gradient(79deg, #2b0aff, #ff5b8a 49%, #ff5b8a 55%, #fba64b 77%, #f99b52)', color: 'transparent', backgroundClip: 'text'}}>未来人类社会将从‘瓦特+比特’时代走向‘PV+AI ’时代</p>

              {/* <div className="flex flex-col gap-2.5 sm:flex-row sm:justify-center lg:justify-start">
                <a href="#" className="inline-block rounded-lg bg-indigo-500 px-8 py-3 text-center text-sm font-semibold text-white outline-none ring-indigo-300 transition duration-100 hover:bg-indigo-600 focus-visible:ring active:bg-indigo-700 md:text-base">Start now</a>

                <a href="#" className="inline-block rounded-lg bg-gray-200 px-8 py-3 text-center text-sm font-semibold text-gray-500 outline-none ring-indigo-300 transition duration-100 hover:bg-gray-300 focus-visible:ring active:text-gray-700 md:text-base">Take tour</a>
              </div> */}
            </div>
            {/* <!-- content - end --> */}

            {/* <!-- image - start --> */}
            <div className="h-48 overflow-hidden mt-8 rounded-lg bg-gray-100 shadow-lg lg:h-96 xl:w-1/2">
              <img src={homeBg} loading="lazy" alt="Photo by Fakurian Design" className="h-full w-full cover object-center" />
            </div>
            {/* <!-- image - end --> */}
          </section>

          <section className="flex flex-col items-center justify-between gap-10 border-t pt-8 lg:flex-row lg:gap-8">
            {/* <!-- stats - start --> */}
            <div className="-mx-6 grid grid-cols-2 gap-4 md:-mx-8 md:flex md:divide-x">
              <div className="px-6 md:px-8">
                <span className="block text-center text-lg font-bold text-sky-700 md:text-left md:text-xl">700+</span>
                <span className="block text-center text-sm font-semibold text-gray-800 md:text-left md:text-base">用户</span>
              </div>

              <div className="px-6 md:px-8">
                <span className="block text-center text-lg font-bold text-sky-700 md:text-left md:text-xl">8000+</span>
                <span className="block text-center text-sm font-semibold text-gray-800 md:text-left md:text-base">访问量</span>
              </div>

              <div className="px-6 md:px-8">
                <span className="block text-center text-lg font-bold text-sky-700 md:text-left md:text-xl">10</span>
                <span className="block text-center text-sm font-semibold text-gray-800 md:text-left md:text-base">AI服务和工具</span>
              </div>

              <div className="px-6 md:px-8">
                <span className="block text-center text-lg font-bold text-sky-700 md:text-left md:text-xl">3</span>
                <span className="block text-center text-sm font-semibold text-gray-800 md:text-left md:text-base">标杆运营场景</span>
              </div>
            </div>
            {/* <!-- stats - end -->   text-indigo-500 */}

          </section>
        </div>
      </div>
      <div className="bg-white py-24 sm:py-32" ref={targetRef1} id="service" style={{srcollBehavior: 'smooth', backgroundColor: '#eff6ff'}}>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mb-10 md:mb-16">
              <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">AI服务</h2>

              <p className="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">工欲善其事，必先利其器，AI为您排忧解难，让复杂变得简单，让智慧触手可及</p>
            </div>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl auto-rows-fr grid-cols-1 gap-8 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3">
            {posts.map((post) => (
              <article
                key={post.id}
                className="relative isolate flex flex-col justify-end overflow-hidden rounded-2xl bg-gray-900 px-8 pb-8 pt-80 sm:pt-48 lg:pt-80"
              >
                <img alt="" src={post.imageUrl} className="absolute inset-0 -z-10 h-full w-full object-cover" />
                <div className="absolute inset-0 -z-10 bg-gradient-to-t from-gray-900 via-gray-900/5" />
                <div className="absolute inset-0 -z-10 rounded-2xl ring-1 ring-inset ring-gray-900/10" />

                <div className="flex flex-wrap items-center gap-y-1 overflow-hidden text-sm leading-6 text-gray-300">
                  {/* <time dateTime={post.datetime} className="mr-8">
                    {post.date}
                  </time> */}
                  {/* <div className="-ml-4 flex items-center gap-x-4">
                    <svg viewBox="0 0 2 2" className="-ml-0.5 h-0.5 w-0.5 flex-none fill-white/50">
                      <circle r={1} cx={1} cy={1} />
                    </svg>
                    {post.author.imageUrl && <div className="flex gap-x-2.5">
                      <img alt="" src={post.author.imageUrl} className="h-6 w-6 flex-none rounded-full bg-white/10" />
                      {post.author.name}
                    </div>}
                  </div> */}
                </div>
                <h3 className="mt-3 text-lg font-semibold leading-6 text-white">
                  <a href={post.href} onClick={(event) => clickRecord(event, post.tag)}>
                    <span className="absolute inset-0" />
                    {post.title}
                  </a>
                </h3>
              </article>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white py-24 sm:py-32" ref={targetRef2} id='scenario' style={{srcollBehavior: 'smooth', backgroundColor: '#dbeafe'}}>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* <!-- text - start --> */}
          <div className="mb-10 md:mb-16">
            <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">标杆场景</h2>

            <p className="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">实践是检验真理的唯一标准，这些标杆场景不仅是技术的展示窗，更是未来工作方式的预演舞台</p>
          </div>
          {/* <!-- text - end --> */}

          <div className="grid gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-3 xl:gap-8">
            {/* <!-- article - start --> */}
            <div className="flex flex-col overflow-hidden rounded-lg border bg-white">
              <a href="https://aimodel.trinasolar.com/grafana/" onClick={(event) => clickRecord(event, '工业质检')} className="group relative block h-48 overflow-hidden bg-gray-100 md:h-64">
                <img src={cellImg} loading="lazy" alt="Photo by Minh Pham" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-1 flex-col p-4 sm:p-6">
                <h2 className="mb-2 text-lg font-semibold text-gray-800">
                  <a href="https://aimodel.trinasolar.com/grafana/" onClick={(event) => clickRecord(event, '工业质检')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">组件质检</a>
                </h2>

                <p className="mb-8 text-gray-500">对工业生产过程中的各种图像进行自动识别、定位、检测等操作，从而实现自动化、智能化生产。例如，利用视觉质检技术可以自动识别产品缺陷，提升质量控制效率。</p>

                {/* <div className="mt-auto flex items-end justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-gray-100">
                      <img src="https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64" loading="lazy" alt="Photo by Brock Wegner" className="h-full w-full object-cover object-center" />
                    </div>

                    <div>
                      <span className="block text-indigo-500">徐媛</span>
                      <span className="block text-sm text-gray-400">July 19, 2021</span>
                    </div>
                  </div>

                  <a href="https://aimodel.trinasolar.com/grafana/" onClick={(event) => clickRecord(event, '工业质检')} className="rounded border px-2 py-1 text-sm text-gray-500">进入</a>
                </div> */}
              </div>
            </div>
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            <div className="flex flex-col overflow-hidden rounded-lg border bg-white">
              <a href="https://scp.trinasolar.com/" onClick={(event) => clickRecord(event, '功率预测')} className="group relative block h-48 overflow-hidden bg-gray-100 md:h-64">
                <img src={powerImg} loading="lazy" alt="Photo by Lorenzo Herrera" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-1 flex-col p-4 sm:p-6">
                <h2 className="mb-2 text-lg font-semibold text-gray-800">
                  <a href="https://scp.trinasolar.com/" onClick={(event) => clickRecord(event, '功率预测')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">功率预测</a>
                </h2>

                <p className="mb-8 text-gray-500">功率预测的主要的问题是如何在多个限制条件下，达成最优分配。基于仿真和优化构建产供销一体的模拟推演和寻优系统形成计划优化体系，为经营决策提供可靠依据。</p>

                {/* <div className="mt-auto flex items-end justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-gray-100">
                      <img src="https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64" loading="lazy" alt="Photo by peter bucks" className="h-full w-full object-cover object-center" />
                    </div>

                    <div>
                      <span className="block text-indigo-500">龚林</span>
                      <span className="block text-sm text-gray-400">April 07, 2024</span>
                    </div>
                  </div>

                  <a href="https://scp.trinasolar.com/" onClick={(event) => clickRecord(event, '功率预测')} className="rounded border px-2 py-1 text-sm text-gray-500">进入</a>
                </div> */}
              </div>
            </div>
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            <div className="flex flex-col overflow-hidden rounded-lg border bg-white">
              <a href="http://172.22.3.17/fw_front/#/login" onClick={(event) => clickRecord(event, '智慧采购')} className="group relative block h-48 overflow-hidden bg-gray-100 md:h-64">
                <img src={purchaseImg} loading="lazy" alt="Photo by Magicle" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-1 flex-col p-4 sm:p-6">
                <h2 className="mb-2 text-lg font-semibold text-gray-800">
                  <a href="http://172.22.3.17/fw_front/#/login" onClick={(event) => clickRecord(event, '智慧采购')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">智慧采购</a>
                </h2>

                <p className="mb-8 text-gray-500">智慧采购系统能够广泛收集光储产业链上的供需、价格，宏观面的经济、政策等信息，进行合理的价格预测，并基于对价格的预判，进行采购策略的模拟。从而实现对品类采购策略的支撑，辅助原材料降本。</p>

                {/* <div className="mt-auto flex items-end justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-gray-100">
                      <img src="https://images.unsplash.com/photo-1586116104126-7b8e839d5b8c?auto=format&q=75&fit=crop&w=64" loading="lazy" alt="Photo by Jassir Jonis" className="h-full w-full object-cover object-center" />
                    </div>

                    <div>
                      <span className="block text-indigo-500">倪瑞芹</span>
                      <span className="block text-sm text-gray-400">March 15, 2024</span>
                    </div>
                  </div>

                  <a href="http://172.22.3.17/fw_front/#/login" onClick={(event) => clickRecord(event, '智慧采购')} className="rounded border px-2 py-1 text-sm text-gray-500">进入</a>
                </div> */}
              </div>
            </div>
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            {/* <div className="flex flex-col overflow-hidden rounded-lg border bg-white">
              <a href="#" className="group relative block h-48 overflow-hidden bg-gray-100 md:h-64">
                <img src="https://images.unsplash.com/photo-1610465299996-30f240ac2b1c?auto=format&q=75&fit=crop&w=600" loading="lazy" alt="Photo by Martin Sanchez" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-1 flex-col p-4 sm:p-6">
                <h2 className="mb-2 text-lg font-semibold text-gray-800">
                  <a href="#" className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">物流优化</a>
                </h2>

                <p className="mb-8 text-gray-500">通过BI工具实现物流仓储全流程数据化管理，覆盖CMBU全球物流与仓储业务，服务140+用户。关键指标显著提升，库容需求减少25%，年降本约800万</p>

                <div className="mt-auto flex items-end justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-gray-100">
                      <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&q=75&fit=crop&w=64" loading="lazy" alt="Photo by Aiony Haust" className="h-full w-full object-cover object-center" />
                    </div>

                    <div>
                      <span className="block text-indigo-500">倪瑞芹</span>
                      <span className="block text-sm text-gray-400">January 27, 2024</span>
                    </div>
                  </div>

                  <span className="rounded border px-2 py-1 text-sm text-gray-500">进入</span>
                </div>
              </div>
            </div> */}
            {/* <!-- article - end --> */}

          </div>
        </div>
      </div>

      <div className="bg-white py-24 sm:py-32" ref={targetRef3} id='tool' style={{backgroundColor: '#eff6ff'}}>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* <!-- text - start --> */}
          <div className="mb-10 md:mb-16">
            <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">工具平台</h2>

            <p className="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">给我一个支点，我可以撬动地球。这里工具齐全,即便是技术小白也能轻松驾驭，让AI触手可及</p>
          </div>
          {/* <!-- text - end --> */}

          <div className="grid gap-8 sm:grid-cols-2 sm:gap-12 lg:grid-cols-2 xl:grid-cols-2 xl:gap-16">
            {/* <!-- article - start --> */}
            {/* <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="#" className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src="https://images.unsplash.com/photo-1593508512255-86ab42a8e620?auto=format&q=75&fit=crop&w=600" loading="lazy" alt="Photo by Minh Pham" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">
                <span className="text-sm text-gray-400">July 19, 2023</span>

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="#" className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">算法平台</a>
                </h2>

                <p className="text-gray-500">开放的AI应用窗口，提供了一系列功能强大且易用的工具和服务。</p>

                <div>
                  <a href="#" className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div> */}
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="https://aimodel.trinasolar.com" onClick={(event) => clickRecord(event, 'AI模型训练平台')} className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src={modelImg} loading="lazy" alt="Photo by Magicle" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">
                {/* <span className="text-sm text-gray-400">March 15, 2024</span> */}

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="https://aimodel.trinasolar.com" onClick={(event) => clickRecord(event, 'AI模型训练平台')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">AI模型训练平台</a>
                </h2>

                <p className="text-gray-500">支持自定义场景的建模工具库，提供全流程的自动AI算法建模和部署。</p>

                <div>
                  <a href="https://aimodel.trinasolar.com" onClick={(event) => clickRecord(event, 'AI模型训练平台')} className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div>
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            {/* <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="http://10.31.141.251:3800/" onClick={(event) => clickRecord(event, 'FastGPT')} className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src={fastImg} loading="lazy" alt="Photo by Martin Sanchez" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="http://10.31.141.251:3800/" onClick={(event) => clickRecord(event, 'FastGPT')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">FastGPT</a>
                </h2>

                <p className="text-gray-500">基于 LLM 大语言模型的知识库问答系统，提供开箱即用的数据处理、模型调用等能力。同时可以通过 Flow 可视化进行工作流编排，从而实现复杂的问答场景。</p>

                <div>
                  <a href="http://10.31.141.251:3800/" onClick={(event) => clickRecord(event, 'FastGPT')} className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div> */}
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            {/* <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="#" className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&q=75&fit=crop&w=600" loading="lazy" alt="Photo by Lorenzo Herrera" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">
                <span className="text-sm text-gray-400">April 07, 2024</span>

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="#" className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">CP4D平台</a>
                </h2>

                <p className="text-gray-500">This is a section of some simple filler text, also known as placeholder text.</p>

                <div>
                  <a href="#" className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div> */}
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="http://172.22.3.1:8511/" onClick={(event) => clickRecord(event, '仓储库容优化')} className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src={stroeImg} loading="lazy" alt="Photo by Martin Sanchez" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">
                {/* <span className="text-sm text-gray-400">January 27, 2024</span> */}

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="http://172.22.3.1:8511/" onClick={(event) => clickRecord(event, '仓储库容优化')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">仓库库容优化</a>
                </h2>

                <p className="text-gray-500">仓库仿真优化，闭环解决方案。</p>

                <div>
                  <a href="http://172.22.3.1:8511/" onClick={(event) => clickRecord(event, '仓储库容优化')} className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div>
            {/* <!-- article - end --> */}

            {/* <!-- article - start --> */}
            {/* <div className="flex flex-col items-center gap-4 md:flex-row lg:gap-6">
              <a href="http://10.31.141.252:1234/" onClick={(event) => clickRecord(event, 'Face Swapping')} className="group relative block h-56 w-full shrink-0 self-start overflow-hidden rounded-lg bg-gray-100 shadow-lg md:h-24 md:w-24 lg:h-40 lg:w-40">
                <img src={faceImg} loading="lazy" alt="Photo by Martin Sanchez" className="absolute inset-0 h-full w-full object-cover object-center transition duration-200 group-hover:scale-110" />
              </a>

              <div className="flex flex-col gap-2">

                <h2 className="text-xl font-bold text-gray-800">
                  <a href="http://10.31.141.252:1234/" onClick={(event) => clickRecord(event, 'Face Swapping')} className="transition duration-100 hover:text-indigo-500 active:text-indigo-600">AI 换脸</a>
                </h2>

                <p className="text-gray-500">下一代面部交换器和增强器。</p>

                <div>
                  <a href="http://10.31.141.252:1234/" onClick={(event) => clickRecord(event, 'Face Swapping')} className="font-semibold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">进入</a>
                </div>
              </div>
            </div> */}
            {/* <!-- article - end --> */}
            
          </div>
        </div>
      </div>
      
      <div className="bg-white py-24 sm:py-32" style={{srcollBehavior: 'smooth', backgroundColor: '#dbeafe'}}>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {/* <!-- text - start --> */}
          <div className="mb-10 md:mb-16">
            <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">专利展示</h2>

            <p className="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">知识就是力量。专利之林，智慧之果</p>
          </div>
          {/* <!-- text - end --> */}

          <div className="grid gap-4 sm:grid-cols-2 md:gap-8 xl:grid-cols-3" onClick={(event) => clickRecord(event, '专利')}>
            {/* <!-- feature - start --> */}
            <div className="flex flex-col rounded-lg border p-4 md:p-6 bg-white">
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P241444CN1</h3>
              <p className="mb-4 text-gray-500">一种基于机器学习的光伏EL图像检测后处理方法.</p>
              <a href="https://wiki-bigdata.trinasolar.com/doc/5lit5yip566a6lw-q02fArDl4d" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div>
            {/* <!-- feature - end --> */}

            {/* <!-- feature - start --> */}
            <div className="flex flex-col rounded-lg border p-4 md:p-6 bg-white" onClick={(event) => clickRecord(event, '专利')}>
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P230383CN1</h3>
              <p className="mb-4 text-gray-500">一种自适应的光伏EL图像预处理方法.</p>
              <a href="https://wiki-bigdata.trinasolar.com/doc/5lit5yip566a6lw-q02fArDl4d" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div>
            {/* <!-- feature - end --> */}

            {/* <!-- feature - start --> */}
            <div className="flex flex-col rounded-lg border p-4 md:p-6 bg-white" onClick={(event) => clickRecord(event, '专利')}>
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P230292CN1</h3>
              <p className="mb-4 text-gray-500">一种基于深度学习的光伏 EL 图像不良检测方法.</p>
              <a href="https://wiki-bigdata.trinasolar.com/doc/5lit5yip566a6lw-q02fArDl4d" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div>
            {/* <!-- feature - end --> */}

            {/* <!-- feature - start --> */}
            <div className="flex flex-col rounded-lg border p-4 md:p-6 bg-white" onClick={(event) => clickRecord(event, '专利')}>
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P241146CN1</h3>
              <p className="mb-4 text-gray-500">一种基于整数规划的功率预测方法.</p>
              <a href="https://wiki-bigdata.trinasolar.com/doc/5lit5yip566a6lw-lxqesGIoWU" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div>
            {/* <!-- feature - end --> */}

            {/* <!-- feature - start --> */}
            <div className="flex flex-col rounded-lg border p-4 md:p-6 bg-white" onClick={(event) => clickRecord(event, '专利')}>
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P231597CN1</h3>
              <p className="mb-4 text-gray-500">一种基于启发式算法的功率预测方法.</p>
              <a href="https://wiki-bigdata.trinasolar.com/doc/5lit5yip566a6lw-lxqesGIoWU" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div>
            {/* <!-- feature - end --> */}

            {/* <!-- feature - start --> */}
            {/* <div className="flex flex-col rounded-lg border p-4 md:p-6">
              <h3 className="mb-2 text-lg font-semibold md:text-xl">P231597CN1</h3>
              <p className="mb-4 text-gray-500">一种基于启发式算法的功率预测方法.</p>
              <a href="#" className="mt-auto font-bold text-indigo-500 transition duration-100 hover:text-indigo-600 active:text-indigo-700">详情</a>
            </div> */}
            {/* <!-- feature - end --> */}
          </div>
        </div>
      </div>

      {/* <div className="bg-white py-24 sm:py-32" style={{backgroundColor: '#eff6ff'}}>
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mb-10 md:mb-16">
              <h2 className="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">团队成员</h2>

              <p className="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">我们是一群充满活力的个体，对我们所做的事情充满热情，并致力于为客户提供最佳的结果</p>
            </div>
          </div>
          <ul role="list" className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-16">
            {people1.map((person) => (
              <li key={person.name} className="col-span-1 divide-y divide-gray-200 rounded-lg bg-white shadow">
                <div className="flex w-full items-center justify-between space-x-6 p-6">
                  <div className="flex-1 truncate">
                    <div className="flex items-center space-x-3">
                      <h3 className="truncate text-sm font-medium text-gray-900">{person.name}</h3>
                      {person.role && <span className="inline-flex flex-shrink-0 items-center rounded-full bg-green-50 px-1.5 py-0.5 text-xs font-medium text-green-700 ring-1 ring-inset ring-green-600/20">
                        {person.role}
                      </span>}
                    </div>
                    <p className="mt-1 truncate text-sm text-gray-500">{person.title}</p>
                  </div>
                  <img alt="" src={person.imageUrl} className="h-10 w-10 flex-shrink-0 rounded-full bg-gray-300" />
                </div>
                <div>
                  <div className="-mt-px flex divide-x divide-gray-200">
                    <div className="flex w-0 flex-1">
                      <a
                        href={`mailto:${person.email}?subject=test&body=测试邮件`}
                        onClick={(event) => clickRecord(event, person.email)}
                        className="relative -mr-px inline-flex w-0 flex-1 items-center justify-center gap-x-3 rounded-bl-lg border border-transparent py-4 text-sm font-semibold text-gray-900"
                      >
                        <EnvelopeIcon aria-hidden="true" className="h-5 w-5 text-gray-400" />
                        Email
                      </a>
                    </div>
                    <div className="-ml-px flex w-0 flex-1">
                      <a
                        href={`dingtalk://dingtalkclient/page/profile?corp_id=dinga41ec6a58a4911d0f2c783f7214b6d69&staff_id=${person.telephone}`}
                        onClick={(event) => clickRecord(event, person.name)}
                        className="relative inline-flex w-0 flex-1 items-center justify-center gap-x-3 rounded-br-lg border border-transparent py-4 text-sm font-semibold text-gray-900"
                      >
                        <PhoneIcon aria-hidden="true" className="h-5 w-5 text-gray-400" />
                        天讯
                      </a>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div> */}

      
      <footer className="bg-white" style={{backgroundColor: '#eff6ff'}}>
        <div className="mx-auto max-w-7xl overflow-hidden px-6 py-20 sm:py-24 lg:px-8">
          <nav aria-label="Footer" className="-mb-6 columns-2 sm:flex sm:justify-center sm:space-x-12">
            {navigation1.main.map((item) => (
              <div key={item.name} className="pb-6">
                <a href={item.href} className="text-sm leading-6 text-gray-600 hover:text-gray-900">
                  {item.name}
                </a>
              </div>
            ))}
          </nav>
          <p className="mt-10 text-center text-xs leading-5 text-gray-500">
            &copy; 2024 AI与大数据部
          </p>
        </div>
      </footer>
    </div>
  )
}
