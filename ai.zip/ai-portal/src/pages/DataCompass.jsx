import React , { useEffect }from 'react';

const AxureComponent = () => {
  useEffect(() => {
    document.title = "天合光能AI算法平台"; // 设置初始标题
    // return () => {
    //   document.title = "天合光能AI算法平台"; // 组件卸载前重置标题
    // };
  }, []);
  return (
    <iframe
      title="Axure Prototype"
      src="datacompass/合并版本.html"
      style={{width: '100%', height:'100vh'}}
      frameBorder={0}
    />
  );
};

export default AxureComponent;