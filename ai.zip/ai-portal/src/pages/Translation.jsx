import React, { useEffect, useRef, useState, useCallback } from "react";
import '../css/translation.css'
import { CloseOutlined,AlertTwoTone } from "@ant-design/icons";
import { Table, Drawer, Button, ConfigProvider } from 'antd';
import {service, axiosTranslate} from "../axios";
import { debounce } from 'lodash';
import OSS from 'ali-oss';
import ArrowLogo from "../images/translation/arrow.png";
import DocxLogo from "../images/translation/docx.png";
import HtmlLogo from "../images/translation/html.png";
import loadingLogo from "../images/translation/loading.png";
import PdfLogo from "../images/translation/pdf.png";
import TranslateLogo from "../images/translation/logo.png";
import TxtLogo from "../images/translation/txt.png";
import UploadLogo from "../images/translation/upload.png";


const tabClass = `box-content pt-3 pr-5 pb-4 pl-4 bg-white rounded-lg border border-gray-200 flex
          shadow-md shadow-slate-200 cursor-pointer mr-4 items-center relative`
const activeClass= `before:content-[""]
          before:w-full before:h-full before:absolute before:left-0 before:top-0
          before:rounded-lg before:border-b-4 before:border-b-blue-500`          
const fileExtArr = ['pdf', 'docx', 'pptx']

const client = new OSS({
  // yourRegion填写Bucket所在地域。以华东1（杭州）为例，Region填写为oss-cn-hangzhou。
  endpoint: "oss-cn-cz-thgndsj-d01-a.asoops.trinasolar.com/",
  // 从STS服务获取的临时访问密钥（AccessKey ID和AccessKey Secret）。
  accessKeyId: "NM2SKmzlH27xBH9g",
  accessKeySecret: "mQnvH3K0vrGkb8RFzdP3RAegaigZXF",
  // secureProtocol: 'SSLv3_method',
  // 从STS服务获取的安全令牌（SecurityToken）。
  // stsToken: "yourSecurityToken",
  // 填写Bucket名称，例如examplebucket。
  bucket: "aibigdata",
});

const userInfo = JSON.parse(localStorage.getItem('userInfo'))
if (localStorage.getItem('pathname') !== '/ai-news') {
  localStorage.setItem('pathname', '')
}
const Translation = () => {
  const [activetab, setActivetab] = useState(1)
  const [tLanguage, setTLanguage] = useState('中文')
  const [translationType, setTranslationType] = useState('快速翻译');
  const [fields, setFields] = useState('光伏');
  const [styleType, setStyleType] = useState('正式')
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);
  const [file, setFile] = useState({});
  const [fileExt, setFileExt] =  useState('');
  const [recogPic, setRecogPic] = useState('false');
  const [fData, setFData] = useState({})
  const [uploadComplete, setUploadComplete] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [translatedFile, setTranslatedFile] = useState('');
  const [historyMap, setHistoryMap] = useState([{
    key: '',
    name: '',
    time: ''
  }])
  const [loading, setLoading] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const fileInputRef = useRef(null);
  const [message, setMessage] = useState('');

  const [open, setOpen] = useState(false);
  const columns = [
    {
      title: '文件名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '时间',
      dataIndex: 'time',
      key: 'time',
      width: 180,
    },
    {
      title: 'Action',
      key: 'action',
      width: 80,
      render: (e) => {
        return e.name ? <Button type="link" onClick={() => downloadClick(e.filePath)} style={{fontSize: '16px'}}>下载</Button> : ''
      },
    },
  ];

  const downloadFile = (path) => {
    const filename = path.split('/').pop()
    // 配置响应头实现通过URL访问时自动下载文件，并设置下载后的文件名。
    const response = {
      "content-disposition": `attachment; filename=${encodeURIComponent(
        filename
      )}`,
    };
    const url = client.signatureUrl(path, { response });
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  const downloadClick = (filePath) => {
    downloadFile(filePath)
  }
  const showDrawer = () => {
    getHistory();
    setOpen(true);
  };

  const onClose = () => {
    setOpen(false);
  };

  const translatePicMap = [
    { id: 'false', title: '否' },
    { id: 'true', title: '是（识别图片速度慢！）' },
  ]

  const choseTranslatePic = (event) => {
    setFData(prevstate => ({
      ...prevstate,
      recognize_picture: event.target.value,
    }))
    setRecogPic(event.target.value)
  }
  const handleChangeLanguage = (event) => {
    setFData(pre => ({
      ...pre,
      target_language: event.target.value,
    }))
    setTLanguage(event.target.value)
  }
  const handleTranslationTypeChange = (event) => {
    setFData(pre => ({
      ...pre,
      selected_model: event.target.value,
    }))
    setTranslationType(event.target.value);
  };

  const handleFieldsChange = (event) => {
    setFData(pre => ({
      ...pre,
      field: event.target.value,
    }))
    setFields(event.target.value);
  };

  const handleStyleTypeChange = (event) => {
    setFData(pre => ({
      ...pre,
      style: event.target.value,
    }))
    setStyleType(event.target.value);
  };

  const handleFileUpload = (files) => {
    const uploadedFile = files[0];
    const ext = uploadedFile.name.split('.').pop()
    setFileExt(ext)
    setFile(uploadedFile);
    setUploadComplete(false);
    setUploadProgress(0)
    setTranslatedFile('')
    setMessage('')
    if (fileExtArr.includes(ext)) {
      setFData(prevstate => ({
        ...prevstate,
        sub: userInfo.sub,
        uid: userInfo.uid,
        selected_model: translationType,
        target_language: tLanguage,
        recognize_picture: recogPic,
        oss_file_path: `FileTranslationResources/${userInfo.sub}/${uploadedFile.name}`,
        field: fields,
        style: styleType,
      }))
    } else {
      setFData(prevstate => ({
        ...prevstate,
        sub: userInfo.sub,
        uid: userInfo.uid,
        selected_model: translationType,
        target_language: tLanguage,
        recognize_picture: 'false',
        oss_file_path: `FileTranslationResources/${userInfo.sub}/${uploadedFile.name}`,
        field: fields,
        style: styleType,
      }))
    }
  };

  const handleTranslate = () => {
    uploadFile2Oss(fData.oss_file_path, file, fData)
  }

  const getHistory = async () => {
    const res = await axiosTranslate.post('getHistory', {sub: userInfo.sub})
    if (res.status == 200 ) {
      if (res.data.success) {
        const data = res.data.data.reverse().map((e, i) => {
          return {
            key: i,
            name: e[0] ,
            filePath: e[1],
            time: formatTime(new Date(e[2]))
          }
        })
        setHistoryMap(data)
      }
    } else {
      console.error('historyErr', res.data);
    } 
  }

  const formatTime = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }
  const noticeTranslate = async (data) => {
    try {
      const res = await axiosTranslate.post('translate_file', data)
      // 处理下载文件
      if (res.status === 200) {
        if (res.data.success) {
          setWaiting(false)
          getHistory()
          setMessage('文件翻译完成！请下载')
          setTranslatedFile(res.data.data.translated_oss_path)
        } else{
          setWaiting(false)
          setUploadComplete(false)
          setMessage('文件翻译失败！')
        }
      }
    } catch (error) {
      setWaiting(false)
      console.error('translate_file', error);
    }
  }

  const fileInfoRecord = async () => {
    try {
      const res = await axiosTranslate.post('fileInfoRecord', {
        filename: file.name,
        file_ext: fileExt,
        file_size: Math.ceil(file.size / 1024),
        user_info_uid: userInfo.uid,
        user_info_sub: userInfo.sub,
        user_info_display_name: userInfo.displayname,
        user_info_department_number: userInfo.departmentnumber
      })
      console.log('fileInfo', res);
    } catch (error) {
      console.log(error);
    }
  }

  const uploadFile2Oss = async (osspath, file, data) => {
    setUploadProgress(0)
    setUploadComplete(false);
    setMessage('')
    const formData = new FormData();
    formData.append('file', file);
    formData.append('ossPath', osspath)

    axiosTranslate.post('upload2back', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (p) => {
        const percentCompleted = Math.round((p.loaded * 100) / p.total);
        setUploadProgress(percentCompleted);
        if (percentCompleted === 100) {
          setUploadComplete(true);
          setMessage('请稍等，正在翻译中...，若等待时间过长，可稍后在历史记录中查看')
          fileInfoRecord()
          setWaiting(true)
          setTranslatedFile('')
        }
      }
    })
    .then(response => {
      console.log('File uploaded successfully:', response);
      if (response.status == 200) {
        noticeTranslate(data)
      }
    }).catch(error => {
      console.error('文件上传失败',error.message);
      setUploadComplete(false);
      setWaiting(false)
      setMessage('文件上传失败！请稍后刷新页面重新上传')
    });
    // try {
    //   // 填写Object完整路径。Object完整路径中不能包含Bucket名称。
    //   // 您可以通过自定义文件名（例如exampleobject.txt）或文件完整路径（例如exampledir/exampleobject.txt）的形式实现将数据上传到当前Bucket或Bucket中的指定目录。
    //   // data对象可以自定义为file对象、Blob数据或者OSS Buffer。
    //   const options = {
    //     meta: { temp: "demo" },
    //     mime: "json",
    //     headers: { "Content-Type": file.type },
    //     // 获取分片上传进度、断点和返回值。
    //     progress: (progressEvent, cpt, res) => {
    //       const percentComplete = Math.round((progressEvent * 100));
    //       setUploadProgress(percentComplete);
    //       if (percentComplete === 100) {
    //         setUploadComplete(true);
    //         setMessage('文件上传成功！请稍等，正在翻译中...')
    //         setWaiting(true)
    //         setTranslatedFile('')
    //       }
    //     },
    //   };
    //   const res = await client.multipartUpload(osspath, file, options);
    //   if (res.res.status == 200) {
    //     noticeTranslate(data)
    //   } else {
    //     console.error('文件上传失败', res);
    //     setUploadComplete(false);
    //     setWaiting(false)
    //     setMessage('文件上传失败！请稍后重试，或者请联系大数据部高涛')
    //   }   
    // } catch (e) {
    //   console.error('文件上传失败',e);
    //   setUploadComplete(false);
    //   setWaiting(false)
    //   setMessage('文件上传失败！请稍后刷新页面重新上传，或者请联系大数据部高涛')
    // }
  }

  const cancel = () => {
    document.getElementById('my_modal').close()
  }

  const confirm = () => {
    document.getElementById('my_modal').close()
    uploadFile2Oss(fData.oss_file_path, file, fData)
  }
  useEffect(() => {
    if (!fileExtArr.includes(fileExt)) {
      if (fData.oss_file_path && activetab === 1) {
        document.getElementById('my_modal').showModal()
      }
    }
  }, [tLanguage,translationType,file, fields, styleType])
  
  const handleFileChange = (event) => {
    const files = event.target.files;
    if (files.length > 0) {
      handleFileUpload(files);
    }
  };
  const handleDragOver = (event) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (event) => {
    event.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setIsDragOver(false);
    const files = event.dataTransfer.files;
    if (files.length > 0) {
      handleFileUpload(files);
    }
  };

  // const handleDelete = () => {
  //   setFile({});
  //   setUploadProgress(0);
  //   setUploadComplete(false);
  // };

  const handleDownload = () => {
    downloadFile(translatedFile)
  };

  const deleteContent = () => {
    setInputText('')
  }
  const getTranslation = async (text, tType, tLang, tField, tStyleType) => {
    if(text === '') {
      return
    }
    setLoading(true)
    try {
      const response = await axiosTranslate.post('translate_text', {
        text: text,
        selected_model: tType,
        source_language: '英文',
        target_language: tLang,
        field: tField,
        style: tStyleType,
      })

      setLoading(false)
      if (response.data.success) {
        setTranslatedText(response.data.data.translated_text);
      } else {
        translationType === '自由翻译' && setShowToast(true)
        console.error('Error translating text:', response.data);
      }
    } catch (error) {
      setLoading(false)
      translationType === '自由翻译' && setShowToast(true)
      console.error('Error catch translating text:', error.message);
    }
  }

   // 使用 useCallback 创建防抖的 fetchTranslation 函数
  const debouncedFetchTranslation = useCallback(debounce(getTranslation, 500), []);
  const handleInputChange = async (event) => {
    const text = event.target.value;
    setInputText(text);
    debouncedFetchTranslation(text, translationType, tLanguage, fields, styleType);
  };

  const recordUserInfo = async () => {
    const res = await service.post('translationInfo', {
      page_tag: '智能翻译',
      user_info_uid: userInfo.uid,
      user_info_department_number: userInfo.departmentnumber
    })
    console.log(res);  
  }

  useEffect(() => {
    document.title = "天合光能AI算法平台"; // 设置初始标题
    recordUserInfo()
  }, []);

  useEffect(() => {
    getTranslation(inputText, translationType, tLanguage, fields, styleType)
  }, [tLanguage,translationType, fields, styleType])

  useEffect(() => {
    setTimeout(() => {
      setShowToast(false)
    }, 3000);
  }, [showToast])
  return (
    <div className='w-full h-screen  bg-slate-100 relative' style={{minHeight: '1000px'}}>
      <header className='w-full bg-white fixed shadow-md shadow-slate-200 z-10' style={{height: '60px', padding: '0 40px'}}>
        <div className='flex items-center h-full'>
          <img src={TranslateLogo} style={{width: '30px', height: '30px'}}></img>
          <span className='font-bold tracking-wider' style={{marginLeft: '10px'}}>文档翻译</span>
        </div>
      </header>
      
      <div className='flex mx-auto flex-row' style={{maxWidth: '1200px', paddingTop: '73px'}}>
        <div className='flex pt-3 pb-4'>
          <div className='box-content mr-4 flex-1'>
            <span>目标语言</span>
            <select className="select select-info w-full mt-1.5 text-base"
              value={tLanguage}
              onChange={handleChangeLanguage}
              name="slang"
            >
              <option value='中文'>中文</option>
              <option value='英文'>英文（English）</option>
              <option value='法文'>法文（Français）</option>
              <option value='西班牙文'>西班牙文（Español）</option>
              <option value='德文'>德文（Deutsch）</option>
              <option value='日文'>日文（日本語）</option>
              <option value='韩文'>韩文（한국어）</option>
              <option value='俄文'>俄文（Русский） </option>
            </select>
          </div>
          <div className='box-content mr-4 flex-1'>
            <span>翻译类型</span>
            <select className="select select-info w-full mt-1.5 text-base"
              value={translationType}
              onChange={handleTranslationTypeChange}
              name="stype"
            >
              <option value='快速翻译'>快速翻译</option>
              <option value='自由翻译'>高级翻译（效果较好，速度极慢 ）</option>
            </select>
          </div>
          <div className={translationType === '自由翻译' ? 'box-content mr-4 flex-1' : 'box-content mr-4 flex-1 invisible'}>
            <span>行业领域</span>
            <select className="select select-info w-full mt-1.5 text-base"
              value={fields}
              onChange={handleFieldsChange}
              name="stype"
            >
              <option value='光伏'>光伏</option>
              <option value='法务'>法务</option>
              <option value='财经'>财经</option>
              <option value='物流'>物流</option>
              <option value='通用'>通用</option>
            </select>
            {/* <input type="text" value={fields} onChange={handleFieldsChange} name="tFields"
              className="input border-0 input-bordered w-full mt-1.5 text-base" /> */}
          </div>
          <div className={translationType === '自由翻译' ? 'box-content mr-4 flex-1' : 'box-content mr-4 flex-1 invisible'}>
            <span>翻译风格</span>
            <select className="select select-info w-full mt-1.5 text-base"
              value={styleType}
              onChange={handleStyleTypeChange}
              name="stype"
            >
              <option value='正式'>正式</option>
              <option value='口语'>口语</option>
            </select>
          </div>
        </div>
      </div>
      <div className="flex justify-between mx-auto" style={{maxWidth: '1200px', paddingTop: '10px'}}>
        <div className='flex'>
          <div className={activetab === 1 ? `${activeClass} ${tabClass}` : tabClass} 
            onClick={() => setActivetab(1)}
            activetab={activetab}>
            <img 
            className='w-8 h-8 mr-4 align-middle'
            src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFjSURBVHgB7dsxTsNAEIXh3xEHSOnSPSUlElCGU0COwA3CDSKFC3ATQEKU0KR36TKFa5tYot012ayS9c77pDiFN7IymbyRVjYYVxDR5dX1Q9F16x7mpKGmn622P5+vrgUzYuq6VUJfflBRdGvfggtiX3Dv4/2NFNzc3g1v3h8kbgdMkAqAcUEZMJb2f/+9kynLkuXykfvFgkOFdUBiad80DZvNCyFCp0A1HFJK+7ZtCaEQxDhNAd/JnNLexd8BGaW9y9gUqIZDDmnvohDEOBUA41QAjFMBME4FwDgVAONUAIzTjhARxNoZOse+gzqACFLZMQqhEMQ4ZQARaApMmKYAxqkAGKcpgHGaAhinAmBc7LvFz8oxjWrfZ7LugAJ29P2zb01WHbD9/jr4CRiFIMZpCjBBIWnvkkUH/CftXSbZASFp76IQxDhNgZHzu/1rfurnAkbUROTvgL5/in3BYxyT9uLwC0mGZjeS2/Y4AAAAAElFTkSuQmCC'></img>
            <div>
              <h3>翻译文件</h3>
              <p className='text-xs text-slate-500'>18种格式文件</p>
            </div>
          </div>
          <div className={activetab === 2 ? `${activeClass} ${tabClass}` : tabClass}
            onClick={() => setActivetab(2)}
            activetab={activetab}>
            <img 
            className='w-8 h-8 mr-4 align-middle'
            src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGTSURBVHgB7ZqxToNQFIZ/GscOTg1u7i5NHLXq2L6AulleQH0EnerYNyi+gwkdVXAui5MdOjKalBksRGushFsNl5ae/0sI5HJyw/04uSF/MKBgb//gwoiifgxso1pMENduXv2X+7yiGhSYjYZdwcUn7MKI+qqiLVVBEATp+fnpEVXi6PgkOSlfnLIDNh0KgHAoAMKhAAiHAiAcCoBwKADCoQAIhwIgHGUi9F8+E5nC0JVIsQOgmU67DdM0f40nWaMzHC5dowutAiyrC6vbzbznj/xvAZ02ms1mZp25Y2IwsKELbQLyFv+neQqYIw9te0CRD65TAr8DIBwKgHAoAMKhAAiHAiAcCoBwKADCoQAIZ2UC3sbj+fVoFo+tCu2h6CJhGKLXu4PrefOxgW2nAWgSo2WFozoptQNc18Pp2fmPxX+RBKSXV9dwHL0p8CKldkCrdTg7HrBOcBOEcCgAwqEACIcCIBwKgHAoAMKhAAiHAiAcZSBSr9fTGKvoPz9LYqIqUHZAOJ1ay0y0bhjAO+L4VlX3ASEMXgmonmaGAAAAAElFTkSuQmCC'></img>
            <div>
              <h3>翻译文本</h3>
              <p className='text-xs text-slate-500'>支持多种语言</p>
            </div>
          </div>
        </div>
        <div className={tabClass} onClick={showDrawer}>
          <img 
            className='w-8 h-8 mr-4 align-middle'
            src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALRSURBVHgB7ZpPctowFMafZNNkyRHICUJnegB6g9wgSko6kC5KTpBwgiSLpkzDH/UETE+QHKAz9Q3Ktqt6006ZYr1K7nQacAjCeQHF0W/BDEIGf+i9Z1vfA/B4PB6PuzDIiag3alypKnBehlWiVKw4j2S3cw05WFqwERoAO0aAGqwTBiP1G19K2Rktd9gSvHr9ZheVkuAQyLkYfHj30Xa+tWAhGhUesq/gHrGa4HPbleZgCQ/gGNykzEI2sJ1stcJCtMo8HH+fGkSdQwz38haPvIiDgypX4VCfeeXGsF7ljS0pz+JFx9utcPirmhlDbK9arEFeXkbAkvOZ4TKUflRsjrcO6VkUhxGsCQU8ygxiYHV5zC34sRICMSbHbP/thbAkTkOYEFLB+/XmqS5mLaACQ/OdZ/3u+yMggiykhTg0hY1O7H9aadQQ8eRymEywlBcRIp4DMeY7KfOYNIcHvY4JP0latLoOFy0DdVWlxudw0fGCi44XXHS84KLjBRcdL7joeMFFh/zx8KFIzQD+U7Ag3EaFtby+p/OCU0/L2DxsvAMQlPUOyD1MXscF79cPtZ+FZmOQzIN2UrAJ3yAcDxF06BLjXNFKQ7g0/jLXcEeIjZEHOXFOcFDiQy2okvnAiFTJkUo2toxrCTlxKqSNc6GLUmbT3WzVYrJ58s8OFfUG5MUZwX89qducC2zr7d8TIMKZkA4wPM2OYrvfpRNrcGKFTWdQpkjpnO33aMUanFhhjrA7O3afwnTnb1nNmvA4eyAjc/SAs9rUe726d7VTcHVLFbf9Kbtpz0b6ZVo0g7cUNqa5yZi9DOkbjk9z5+vwh4BlO4omm1YWj/Vd6V69ecXW3X03D2Sy37uwSgHrHMZJmlML24JWjr7zUolq204PbCdG0ed4u/riG2NsB1yCY3PQt2+fWr65NH1cY1czjWErR5/4dQLL94o9ufZhj8fj8bjMH10ABMgWKc36AAAAAElFTkSuQmCC'></img>
          <div>
            <h3>历史记录</h3>
            <p className='text-xs text-slate-500'>下载历史文件</p>
          </div>
        </div>
      </div>
      
      {/* <div className='flex mx-auto mt-6' style={{maxWidth: '1200px'}}>
          <div class="flex items-center">
              <input id="inline-radio" type="radio" value="" name="inline-radio-group" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
              <label htmlFor="inline-radio" className='ml-1.5'>快速翻译（翻译速度快）</label>
          </div>
          <div class="flex items-center ml-2">
              <input id="inline-2-radio" type="radio" value="" name="inline-radio-group" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"/>
              <label htmlFor="inline-2-radio" className='ml-1.5'>高级翻译（自定义风格翻译，效果好，速度较慢）</label>
          </div>
      </div> */}
      {/* 翻译内容模块 */}
      {activetab === 1 ? <div>
        <div className='flex items-center justify-center flex-col bg-slate-200 mt-6 mx-auto
          rounded-3xl' style={{border: '2px dashed #d3daec', maxWidth: '1200px', height:'360px'}}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}>
          {!isDragOver ? <>
            <div className='flex flex-row items-center flex-wrap'>
            <div className='flex flex-col items-center'>
              <img className='mx-5' style={{width: '70px', height: '70px'}} src={PdfLogo}></img>
              <span className='mt-3'>pdf 文件</span>
            </div>
            <div className='flex flex-col items-center'>
              <img className='mx-5' style={{width: '70px', height: '70px'}} src={HtmlLogo}></img>
              <span className='mt-3'>html 文件</span>
            </div>
            <div className='flex flex-col items-center'>
              <img className='mx-5' style={{width: '70px', height: '70px'}} src={DocxLogo}></img>
              <span className='mt-3'>docx 文件</span>
            </div>
            <div className='flex flex-col items-center'>
              <img className='mx-5' style={{width: '70px', height: '70px'}} src={TxtLogo}></img>
              <span className='mt-3'>txt 文件</span>
            </div>
            </div>
            <button className='rounded-lg bg-blue-500 h-12 mt-11 mb-6
              text-lg text-white font-bold tracking-wider
              flex justify-center items-center' 
              onClick={() => {
                // fileInputRef.current.value = ''
                // fileInputRef.current.dispatchEvent(new Event('change'));
                fileInputRef.current.click()
              }}
              style={{width: '220px'}}>
              打开文件
            </button>
            <input type="file" style={{display: "none"}} 
            ref={fileInputRef}
            onChange={handleFileChange}
            id="upload" accept=".csv, .docx, .htm, .html, .jpeg, .jpg, .msg, .mthml, .pdf, .png, .pptx, .tab, .txt, .txv, .xlf, .xliff, .xls, .xlsx"/>
            <div className='text-sm '>点击打开文件或把本地文件拖到这里</div>
            <div className='text-sm pt-3 text-gray-500'>csv,docx,htm,html,jpeg,jpg,msg,mthml,pdf,png,pptx,tab,txt,txv,xlf,xliff,xls,xlsx</div>
            <div className='text-sm pt-3 text-red-500'>
              <AlertTwoTone/> 加密文件请先解密后在进行翻译！</div>
            </> : <div className='flex flex-row items-center flex-wrap'>
              <div className='flex flex-col items-center'>
                <img className='mx-5' style={{width: '70px', height: '70px'}} src={UploadLogo}></img>
                <span className='mt-3'>松开后开始处理</span>
              </div>
            </div>
          }
        </div>
        {/* 进度条 */}
        {/* <progress className="progress  w-56 ml-4"  value={uploadProgress} max="100">{uploadProgress}%</progress> */}
        {fileExtArr.includes(fileExt) && <div className='mx-auto mt-5 ' style={{maxWidth: '1200px', paddingTop: '10px'}}>
          <legend className="leading-6">是否需要翻译图片</legend>
          <div className="mt-6 space-y-6 sm:flex sm:items-center sm:space-x-10 sm:space-y-0">
            {translatePicMap.map((item) => {
              return <div key={item.id} className="flex items-center cursor-pointer">
                <input
                  defaultChecked={item.id === recogPic}
                  value={item.id}
                  name="trasPic"
                  onChange={choseTranslatePic}
                  type="radio"
                  className="h-4 w-4 border-gray-300 focus:ring-blue-500 "
                />
                <span className="ml-3 block text-sm font-medium leading-6">
                  {item.title}
                </span>
              </div>
            })}
          </div>
          <button onClick={handleTranslate} className="mt-6 px-4 py-2 text-sm bg-blue-500 text-white rounded-lg shadow-sm">
              翻译
          </button>
        </div>}

        {file.name && (
          <div className='flex mx-auto mt-5 items-center' style={{maxWidth: '1200px', paddingTop: '10px'}}>
            <p>{file.name}:</p>
            <progress className="progress  w-56 ml-4"  value={uploadProgress} max="100"></progress><span className="ml-3">{uploadProgress}%</span>
            <span className={uploadComplete ? 'text-green-500' : 'text-red-500'} style={{ marginLeft: '10px'}}>{message}</span>
            {waiting && <img src={loadingLogo} className="w-4 h-4 my-rotate ml-4"></img>}
            {/* {uploadComplete && (
              <button
                onClick={handleDelete}
                style={{ marginLeft: '10px', cursor: 'pointer', color: 'red' }}
              >
                删除
              </button>
            )} */}
          </div>
        )}

        {translatedFile && (
          <div className='flex mx-auto mt-5 items-center' style={{maxWidth: '1200px', paddingTop: '10px'}}>
            <button onClick={handleDownload} className="px-4 py-2 text-sm bg-blue-500 text-white rounded-lg shadow-sm">
              下载文件
            </button>
          </div>
        )}
      </div> : <div className='flex items-center flex-col mt-3 h-80 mx-auto' 
        style={{maxWidth: '1200px', height:'325px'}}>
        {/* <div className='flex items-center w-full'>
          <div>检测源语言</div>
          <img src='src/images/translation/arrow.png' className='mx-5' style={{width: '18px', height: '18px'}}></img>  style={{backgroundImage: 'url(src/images/translation/delete.png)'}}
          <div>简体中文</div>
        </div> */}
        <div className='flex justify-center mt-3 mb-4 gap-2 w-full'>
            <div className='w-full relative'>
              {/* <div className="absolute top-3 right-3 w-4 h-4 cursor-pointer z-10" style={{backgroundImage: 'url(src/images/translation/delete.png)'}}></div> */}
              <div className="absolute top-3 right-3 w-4 h-4 cursor-pointer z-10" onClick={deleteContent}><CloseOutlined/></div>
              <textarea className='w-full h-full p-6 border-none text-lg
                whitespace-pre-wrap focus:outline-0' 
                style={{minHeight: '354px',maxHeight: '600px',borderRadius: '8px', border: '1px solid #e5e7eb', scrollbarWidth: 'thin'}}
                value={inputText}
                onChange={handleInputChange}
                placeholder='请输入需要翻译的内容'>
              </textarea>
            </div>
            <div className='w-full relative'>
              <textarea className='w-full h-full p-6 border-none text-lg
                whitespace-pre-wrap focus:outline-0'
                defaultValue={translatedText}
                readOnly
                style={{minHeight: '354px',maxHeight: '600px',borderRadius: '8px', border: '1px solid #e5e7eb', scrollbarWidth: 'thin'}}>
              </textarea>
              {loading && <div className="absolute top-1/2 right-1/2 -translate-y-6">
                <img src={loadingLogo} className="w-8 h-8 my-rotate"></img>
              </div>}
            </div>
        </div>
      </div>}
      {showToast && <div className="toast toast-center toast-top top-40">
        <div className="alert alert-error">
          <span className="text-white">高级翻译繁忙，请切换快速翻译！</span>
        </div>
      </div>}
      <Drawer title="翻译文件历史记录" width={800} onClose={onClose} open={open}>
        <ConfigProvider
          theme={{
            components: {
              Table: {
                cellFontSize: 16
              }
            }
          }}
        >
          <Table columns={columns} dataSource={historyMap} size="large" pagination={{pageSize: 15, position: ['bottomRight']}}/>
        </ConfigProvider>
      </Drawer>
      <dialog id="my_modal" className="modal">
        <div className="modal-box">
          <h3 className="font-bold text-lg">提示</h3>
          <p className="mt-4">当前文件将使用 <span className="font-semibold">{translationType == '自由翻译' ? '高级翻译' : translationType}</span> 翻译成 <span className="font-semibold">{tLanguage}</span> 。</p>
          <div className="modal-action">
            <button className="px-4 py-2 text-sm bg-slate-200 rounded-lg shadow-sm" onClick={cancel}>取消</button>
            <button className="px-4 py-2 text-sm bg-blue-500 text-white rounded-lg shadow-sm" onClick={confirm}>确认</button>
          </div>
        </div>
      </dialog>
      <div className="text-red-500 text-center absolute bottom-5 right-1/2 translate-x-1/2">
        如有问题请点击联系人
        <a className="text-blue-500 cursor-pointer" href="dingtalk://dingtalkclient/page/profile?corp_id=dinga41ec6a58a4911d0f2c783f7214b6d69&staff_id=366033">『狄晨』</a>
        <a className="text-blue-500 cursor-pointer" href="dingtalk://dingtalkclient/page/profile?corp_id=dinga41ec6a58a4911d0f2c783f7214b6d69&staff_id=365515">『高涛』</a>
      </div>
    </div>
  )
}

export default Translation;