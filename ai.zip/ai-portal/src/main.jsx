import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App';
import {checkLogin, getToken, getUesrInfo, webVisits} from './axios/login';

import PiwikPro from '@piwikpro/react-piwik-pro';
PiwikPro.initialize('afde4cb1-bc80-4f99-9a47-853d75469e17', 'https://yikai.piwik.pro');
// ReactDOM.render(<App />, document.getElementById('root'))
debugger
checkLogin()
if (localStorage.getItem('code')) {
  getToken().then(res => {
    console.log(res);
    getUesrInfo()
  }).catch(err => {
    console.log('err',err);
  })
}

if (localStorage.getItem('userInfo')) {
  webVisits()
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Router>
      <App />
    </Router>
  </React.StrictMode>
);
